# -*- coding: utf-8 -*-
"""
/***************************************************************************
 AboutDialog
                                 A QGIS plugin
 Collection of internet map services
                             -------------------
        begin                : 2014-11-21
        git sha              : $Format:%H$
        copyright            : (C) 2017 A.Solabre. JCCM. D.G.Carreteras
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtWidgets import QDialog, QDialogButtonBox
from PyQt5 import uic

from qgis.core import *
from qgis.gui import *

import configparser
import os
from time import gmtime, localtime, strftime


CURR_PATH = os.path.dirname(__file__)
FORM_CLASS, _ = uic.loadUiType(os.path.join(CURR_PATH, './menus/about_dialog_base.ui'))

# Comprobamos si existen los ficheros de ayuda
Proj = QgsProject.instance().fileName()
unidadSIG = Proj[:2]
unidadSIG1= u'U:'
unidadSIG2= u'Z:'
# file:///U:/cartografia/datos_Q/AYUDA/
if not os.path.exists(unidadSIG+'/cartografia/datos_Q/AYUDA/'):
    print ('No existe unidad - '+ 'file:///'+ unidadSIG+'/cartografia/datos_Q/AYUDA/')
    unidadSIG = unidadSIG1
    # if not os.path.exists('file:///'+ unidadSIG+'/cartografia/datos_Q/AYUDA/'):
    if not os.path.exists(unidadSIG+'/cartografia/datos_Q/AYUDA/'):
        print ('No existe unidad - '+ 'file:///'+ unidadSIG+'/cartografia/datos_Q/AYUDA/')
        unidadSIG = unidadSIG2

# VARIABLES DEL FICHERO DE METADATOS
# cfg = configparser.Safeconfigparser()
cfg = configparser.ConfigParser()

fileMetadata = os.path.join(os.path.dirname(__file__), 'metadata.txt')
cfg.read(fileMetadata)
fecha = strftime("%d %b %Y %H:%M ", localtime(os.path.getmtime(fileMetadata)))
version = cfg.get('general', 'version')
author= cfg.get('general', 'author')
# desarrolloorig= cfg.get('general', 'desarrolloorig')
# desarrolloadap= cfg.get('general', 'desarrolloadap')
email= cfg.get('general', 'email')
telefono= cfg.get('general', 'telefono')
organizacion= cfg.get('general', 'organizacion')
# about=  textwrap( cfg.get('general', 'about'),300,'*')
about=  cfg.get('general', 'about')
changelog =  cfg.get('general', 'changelog')
# unidadSIG= cfg.get('general', 'unidadSIG')

# VARIABLES DE FICHEROS DE AYUDA
ayudaCOMPLE='file:///'+ unidadSIG+'/cartografia/datos_Q/AYUDA/JCCM_Carreteras_v134_Manual%20de%20instalacion%20y%20explotacion.pdf'
# ayudaCOMPLE='file:///U:/cartografia/datos_Q/AYUDA/JCCM_Carreteras_v134_Manual%20de%20instalacion%20y%20explotacion.pdf'
ayudaSIG='file:///'+unidadSIG+'/cartografia/datos_Q/AYUDA/SIG%20REG%20CTRAS%20AYUDA.pdf'
ayudaINST='file:///'+unidadSIG+'/cartografia/datos_Q/INSTALACION%20SIG_CLM_QGIS/INSTALACION_SIG_CLM_QGIS%20V105.doc'
ayudaASISTW7='file:///'+unidadSIG+'/cartografia/datos_Q/AYUDA/Asistencia%20remota%20solicitada%20por%20usuario%20final%20en%20Windows%207.pdf'
ayudaASISTWXP='file:///'+unidadSIG+'/cartografia/datos_Q/AYUDA/Asistencia%20remota%20solicitada%20por%20usuario%20final%20en%20Windows%20XP.pdf'
dirREPO='file:///'+unidadSIG+'/cartografia/datos_Q/INSTALACION%20SIG_CLM_QGIS/jccm_bar/'
iconoMENU='iconos/jccm.jpg'

# print 'ayudaCOMPLE --- ', ayudaCOMPLE
# print 'ayudaSIG ------ ', ayudaSIG
# print 'ayudaINST ----- ', ayudaINST
# print 'ayudaASISTW7 -- ', ayudaASISTW7
# print 'ayudaASISTWXP - ', ayudaASISTWXP
# print 'dirREPO ------- ', dirREPO

class AboutDialog(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(AboutDialog, self).__init__(parent)
        self.setupUi(self)
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))


        self.btnHelp = self.buttonBox.button(QDialogButtonBox.Help)

        self.lblLogo.setPixmap(QPixmap(os.path.join(CURR_PATH, iconoMENU)))

        self.lblVersion.setText(self.tr('Version: %s Fecha: %s') % (version, fecha))

        self.lblmetadata.setHtml(self.get_about_text())
        self.lblAyuda.setText(self.get_ayuda_text())
        # self.tbhistorial.setPlainText(self.get_historial())
        self.tbhistorial.setPlainText(changelog)


    def get_about_text(self):
        return self.tr(
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">  Junta de Comunidades de castilla La Mancha (</span><a href="https://www.jccm.es//"><span style=" font-size:8pt; text-decoration: underline; color:#0000ff;">JCCM</span></a><span style=" font-size:8pt;">). </span><a href="http://www.castillalamancha.es/gobierno/fomento"><span style=" font-size:8pt; text-decoration: underline; color:#0000ff;">Consejeria de Fomento</span></a><span style=" font-size:8pt;">. </span></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">Direccion General de Carreteras (DGC). Servicio Provincial de Carreteras de Albacete</span></p>'
            '<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"><br /></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt; font-weight:600;">Autor: </span><span style=" font-size:8pt;"> '+author+'</span></p>'
            # '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">    </span><span style=" font-size:8pt; font-weight:600;">   -Desarrollo Original:</span><span style=" font-size:8pt;">  '+desarrolloorig+'</span></p>'
            # '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">    </span><span style=" font-size:8pt; font-weight:600;">   -Analisis y adaptacion:</span><span style=" font-size:8pt;"> '+desarrolloadap+'</span></p>'
            '<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"><br /></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt; font-weight:600;">CONTACTO:  email: </span><span style=" font-size:8pt;"> </span><a href="mailto:'+email+'"><span style=" font-size:8pt; text-decoration: underline; color:#0000ff;">'+email+'</span></a><span style=" font-size:8pt; font-weight:600;">         Telefono:</span><span style=" font-size:8pt;">  '+telefono+'</span></p>'
            '<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"><br /></p>'
            )

    def get_ayuda_text(self):
        text =self.tr(
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'+ayudaCOMPLE+'"><span style=" font-size:10pt; text-decoration: underline; color:#0000ff;">AYUDA</span></a><span style=" font-size:10pt;"> sobre las FUNCIONALIDADES DE CARRETERAS</span></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'+ayudaSIG+'"><span style=" font-size:10pt; text-decoration: underline; color:#0000ff;">AYUDA</span></a><span style=" font-size:10pt;"> sobre el SIG DE CARRETERAS</span></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'+ayudaINST+'"><span style=" font-size:10pt; text-decoration: underline; color:#0000ff;">AYUDA</span></a><span style=" font-size:10pt;"> instalacion SIG DE CARRETERAS</span></p>'
            '<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;"><br /></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'+ayudaASISTW7+'"><span style=" font-size:10pt; text-decoration: underline; color:#0000ff;">Solicitud</span></a><span style=" font-size:10pt;"> Asistencia Remota Windows 7</span></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'+ayudaASISTWXP+'"><span style=" font-size:10pt; text-decoration: underline; color:#0000ff;">Solicitud</span></a><span style=" font-size:10pt;"> Asistencia Remota Windows XP</span></p>'
            '<p><strong>Acceso al repositorio:</strong> <a href="'+dirREPO+'">REPOSITORIO</a></p>'
            )
        return text

    def get_historial(self):
        with open(os.path.join(CURR_PATH, 'historial.txt')) as f:
            return f.read()