# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           settings.py
Purpose:    Configuración inicial del pluggin jccm_bar3 y del QGIS3

        --------------------------------------------------------------------
        begin                : 2019-06-05
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
# VERSION QGIS3

from PyQt5.QtCore import QSettings
from qgis.utils import iface
from qgis.core import QgsProject, QgsExpressionContextUtils, QgsApplication, QgsCoordinateReferenceSystem

import os
import sqlite3

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.environment["EPSG"]

class Settings:

    def initVAR(self):
        qs = QSettings()
        self.fun = Functions()

        #       --  Detectamos la UNIDAD del Proyecto
        dirOS = os.getcwd()
        Proj = QgsProject.instance().fileName()
        uniProj = Proj[:2]
        
        #       --  Variables Generales DE USUARIO --
        qs.setValue('Qgis/enableMacros',3)                      # Activar Macros - Siempre
        qs.setValue('Qgis/warnOldProjectVersion', False)        # Avisar de Proyecto guardado con version ant. - false
        qs.setValue('Qgis/checkVersion', False)                 # Chequear Version QGIS al empezar
        qs.setValue('Qgis/askToSaveProjectChanges', False)      # Quita el aviso inicial de guardar

        #       --  Proyección a emplear --
        # EPSG = '25830'
        EPSG = str(srcVal)
        ################################################################################
        ####            CONTROL SE DEBE AVISAR SI NO COINCIDE EL SRC                ####
        ################################################################################
        qs.setValue('Projections/defaultBehavior', 'useProject')            # Projections/defaultBehaviour - useProject
        qs.setValue('Projections/layerDefaultCrs', 'EPSG:'+EPSG)            # Projections/layerDefaultCrs - EPSG:25830
        qs.setValue('Projections/projectDefaultCrs', 'EPSG:'+EPSG)          # Projections/projectDefaultCrs - EPSG:25830
        qs.setValue('Projections/otfTransformAutoEnable', True)             # Projections/otfTransformAutoEnable - true
        qs.setValue('Projections/otfTransformEnabled', False)               # Projections/otfTransformEnabled - false
        qs.setValue('Projections/showDatumTransformDialog', False)          # Projections/showDatumTransformDialog - false
        dirTemplates = uniProj+u'\cartografia\datos_Q\QSIG\PLANTILLAS'      
        qs.setValue('Composer/searchPathsForTemplates',[dirTemplates])      # Composer/searchPathsForTemplates
        # qs.setValue('Composer/searchPathsForTemplates',[u'Z:\cartografia\datos_Q\QSIG\PLANTILLAS'])
        # qs.setValue('Composer/searchPathsForTemplates',[u'U:\cartografia\datos_Q\QSIG\PLANTILLAS'])


        #       -- Creación de Sistema de Referencia de Coordenadas CRS - ETRS89 ED50  IGN REJILLA --
        # pathCRS = u'u:/cartografia/datos_Q/QSIG/TRANS ED50-ETR89/PENR2009.gsb' # ANTIGUO DIRECTORIO
        pathCRS = u'u:/cartografia/datos_Q/QSIG/TRANS_ED50_ETR89/PENR2009.gsb'
        listUnd = [uniProj, 'u:', 'z:']
        pathCRS = self.fun.buscaFichUnd(listUnd, pathCRS)

        if pathCRS is not None:
            nomCRS = "ETRS89 ED50 IGN REJILLA"

            #               Comprobamos si existe el CRS usuario
            con = sqlite3.connect(QgsApplication.qgisUserDatabaseFilePath())
            cur = con.cursor()
            cur.execute('select * from tbl_srs')
            rows = cur.fetchall()
            existCRSuser = False
            for crs in rows:
              # print (crs[0], crs[1])
              if crs[1] == nomCRS:
                # print ('El SRC USER '+nomCRS+' ya existe')
                existCRSuser = True

            # Se crea el CRS user si no existe
            if existCRSuser == False:
                result = os.path.exists(pathCRS[0])
                if result == True:
                  user_crs = QgsCoordinateReferenceSystem()
                  user_crs.createFromProj4("+proj=utm +zone=30 +ellps=intl +nadgrids=%s +units=m +wktext +no_defs"%(pathCRS[0]))
                  # user_crs.createFromWkt("+proj=utm +zone=30 +ellps=intl +nadgrids=%s +units=m +wktext +no_defs"%(pathCRS[0]))
                  user_crs.createFromUserInput("+proj=utm +zone=30 +ellps=intl +nadgrids=%s +units=m +wktext +no_defs"%(pathCRS[0]))
                  user_crs.saveAsUserCrs(nomCRS)
                  print ('Se crea '+nomCRS+' correctamente')
                else:
                  print ('El fichero '+pathCRS[0]+' no se encuentra')
                  pass


        #  -- Variables del PROYECTO --  
        # Directorios de trabajo 
        DIRCATlocal = u'z:/Cartografia_COTYV/03_CARTOGRAFIA_ORIGINAL_OFICIAL/DG_CATASTRO/'
        DIRCATservtol = u'w:/03_CARTOGRAFIA_ORIGINAL_OFICIAL/DG_CATASTRO/'

        # QgsExpressionContextUtils.setProjectVariable('DIRCATlocal',DIRCATlocal)
        QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(),'DIRCATlocal',DIRCATlocal)
        # QgsExpressionContextUtils.setProjectVariable('DIRCATservtol',DIRCATservtol)
        QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(),'DIRCATservtol',DIRCATservtol)
        
        global gml_salida_file  
        
        # print (u'Configuradas las Variables')
        return uniProj
        
    def entrarUser(self):
        # Control de accesos a la aplicacion por medio de USER
        #  --------------------------------------------------------------------
        #                     USUARIOS EDITORES Y ADMINISTRADORES
        #  --------------------------------------------------------------------
        qs = QSettings()

        userEdit =  ['aass04', 'ffas09', 'agusa']
        # userEdit =  ['aass04', 'ffas09']
        userAdmin = ['aass04', 'agusa']
        # userAdmin = ['aass04']
        #  --------------------------------------------------------------------
        
        tittle = u'SIG REGIONAL DE CARRETERAS'
        # msg = QMessageBox()
        
        userSIG = os.environ.get('USERNAME')
        userSIGequipo = os.environ.get('LOGONSERVER')
        if userSIG in userEdit:
            tipoUser = 'EDITOR'
            # QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(),'ACCESOEDITOR','True')
            qs.setValue('JCCM_carreteras/ACCESOEDITOR', True)

            if userSIG in userAdmin:
                tipoUser = 'ADMINISTRADOR'
        else:
            tipoUser = 'BASICO QGIS'
            # QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(),'ACCESOEDITOR','False')
            qs.setValue('JCCM_carreteras/ACCESOEDITOR', False)

        return (userSIG, tipoUser)
        
        
    def setVarUser(self):
        qs = QSettings()

        qs.setValue('JCCM_carreteras/00firstUse', False)            # Variable firstUse
        qs.setValue('JCCM_carreteras/01Ambito', 'CLM')              # Variable Ambito
        qs.setValue('JCCM_carreteras/02tipoUser', 'Usuario')        # Variable tipoUser

        pass
        