# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrExpro_cargacapas.py
                                 A QGIS plugin
 herrExpro
                             -------------------
        begin                : 2017-01-25
        git sha              : $Format:%H$
        copyright            : (C) A.Solabre 2017
        email                : gis.carreteras@jccm.es
 ***************************************************************************/
"""

from PyQt5.QtCore import QSettings
from qgis.core import Qgis, QgsProject, QgsExpressionContextUtils, QgsExpressionContextScope, QgsExpressionContextUtils, QgsLayerDefinition, QgsMessageLog

from osgeo import ogr, osr

import os, time, fnmatch
import shutil
import datetime
import sys
from stat import *
from os.path import isfile, join
from qgis.gui import *

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES
from .gestorCapas import gestorCapas

listaUNIDADES = ['z:', 'u:']

class herrExpro_cargacapas():

    def __init__(self, iface, parent=None):
        self.fun = Functions()
        self.iface = iface
        self.setVar = QSettings()

        self.current_configuration = configuration()
        
        iface.messageBar().pushMessage(u'Carga de Capas de EXPROPIACIONES', u'', level=Qgis.Info, duration= 5 )
        
        # Control de accesos
        # if QgsExpressionContextScope.hasVariable(QgsExpressionContextUtils.projectScope(QgsProject.instance()), 'ACCESOEDITOR'):
            # result = QgsExpressionContextScope.variable(QgsExpressionContextUtils.projectScope(QgsProject.instance()), 'ACCESOEDITOR')
        # else:
            # QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(),'ACCESOEDITOR', None)
            # result = 'False'
            
        if self.setVar.value("JCCM_carreteras/ACCESOEDITOR"):
            result = self.setVar.value("JCCM_carreteras/ACCESOEDITOR")
        else:
            self.setVar.setValue('JCCM_carreteras/ACCESOEDITOR', False)
            result = False
            
        qlrFileName = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXP_GRUPEXPROfich")
        if qlrFileName is None:
            if result == False:
                qlrFileName=self.current_configuration.expropiacionB["EXP_GRUPEXPROfich"]
            else:
                qlrFileName=self.current_configuration.expropiacion["EXP_GRUPEXPROfich"]

        nombGRUEXPROPIACIONES = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXP_GRUPEXPROnom")
        if nombGRUEXPROPIACIONES is None:
            if result == False:
                nombGRUEXPROPIACIONES = self.current_configuration.expropiacionB["EXP_GRUPEXPROnom"]
            else:
                nombGRUEXPROPIACIONES = self.current_configuration.expropiacion["EXP_GRUPEXPROnom"]
            
        uniProj = QgsProject.instance().fileName()[:2]
        listUnd = [uniProj, 'z:', 'u:']
        if self.fun.buscaFichUnd(listUnd, qlrFileName) is None:
            # print( "NO SE ENCUENTRA EL GRUPO DE CAPAS: ", nombGRUEXPROPIACIONES)
            iface.messageBar().clearWidgets()
            return
        else:
            qlrFileName = self.fun.buscaFichUnd(listUnd, qlrFileName)[0] 
            
        print (qlrFileName)
        root = QgsProject.instance().layerTreeRoot()            
        grupoEXIST = root.findGroup(nombGRUEXPROPIACIONES)
        if grupoEXIST is None:
            if os.path.isfile(qlrFileName):
                result=QgsLayerDefinition().loadLayerDefinition(qlrFileName, QgsProject.instance(), root)
                if result[0]=='False':
                    iface.messageBar().clearWidgets()
                    iface.messageBar().pushMessage("Fallo al cargar el grupo : " + nombGRUEXPROPIACIONES, u'', level=Qgis.Warning, duration= 3 )       
                    return

                # Se recoloca el grupo al principio de todo
                grupoANADIDO = root.findGroup(nombGRUEXPROPIACIONES)
                if grupoANADIDO is not None:
                    grupoCLONADO = grupoANADIDO.clone()
                    root.insertChildNode(0, grupoCLONADO)
                    root.removeChildNode(grupoANADIDO)
        else:
            iface.messageBar().clearWidgets()
            iface.messageBar().pushMessage(u'YA EXISTE EL GRUPO DE CAPAS DE EXPROPIACIONES', u'', level=Qgis.Warning, duration= 3 )       
        pass


class herrExpro_cargaEstado():

    def __init__(self, iface, parent=None):
        self.fun = Functions()
        self.iface = iface
        self.setVar = QSettings()
        self.current_configuration = configuration()
        self.gestorCapas = gestorCapas(iface)

        iface.messageBar().pushMessage(u'Estado de EXPROPIACIONES (Remisión a Catastro)', u'', level=Qgis.Info, duration= 5 )
        
        nombCapaEXPROPIACIONES = {'type': 'Grupo', 
            'source': 'v:/cartografia/datos_Q/Qsig/GRUPOS_CAPAS/ESTADO DE LAS EXPROPIACIONES.qlr', 
            'nombre': 'ESTADO EXPROPIACIONES', 
            'estilo': 'Default', 
            'grupo':  'Internas', 
            'agrupado': ''}
            
        uniProj = QgsProject.instance().fileName()[:2]
        listUnd = [uniProj, 'v:', 'u:']
        nombCapaEXPROPIACIONES["source"]= self.fun.buscaFichUnd(listUnd, nombCapaEXPROPIACIONES["source"])[0] 
        if nombCapaEXPROPIACIONES ["source"] is None:
            iface.messageBar().clearWidgets()
            return
        
        noMove = False
        
        root = QgsProject.instance().layerTreeRoot()            
        grupoEXIST = root.findGroup(nombCapaEXPROPIACIONES["nombre"])
        # print ('GRUPO - ', nombCapaEXPROPIACIONES)
        if grupoEXIST is None:
            self.gestorCapas.cargarCapa(nombCapaEXPROPIACIONES)

            # Se recoloca el grupo al principio de todo
            grupoANADIDO = root.findGroup(nombCapaEXPROPIACIONES["nombre"])
            if grupoANADIDO is not None:
                grupoCLONADO = grupoANADIDO.clone()
                root.insertChildNode(0, grupoCLONADO)
                root.removeChildNode(grupoANADIDO)
        else:
            iface.messageBar().clearWidgets()
            iface.messageBar().pushMessage(u'YA EXISTE EL GRUPO DE CAPAS DE ESTADO EXPROPIACIONES', u'', level=Qgis.Warning, duration= 3 )       
        pass
        
