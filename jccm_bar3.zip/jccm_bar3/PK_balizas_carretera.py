# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           PK_balizas_carretera.py
Purpose:

        --------------------------------------------------------------------
        begin                : 2019-09-03
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt, QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu

from PyQt5 import QtGui, uic
from PyQt5.QtWidgets import QDialog
    # PyQt5.QtWidgets - https://doc.qt.io/qt-5/qtwidgets-module.html

# SE CARGAN LAS LIBRERÍAS CON CLASES A CASCOPORRO
# from qgis.PyQt.QtGui import *
# from qgis.PyQt.QtCore import *
# from qgis.PyQt.QtWidgets import *
# from qgis.PyQt.QtXml import *
# from qgis.gui import *              # https://qgis.org/pyqgis/3.0/core/index.html
# from qgis.core import *             # https://qgis.org/pyqgis/3.0/gui/index.html

# from qgis.core import *
# from PyQt4.QtGui import *
# import qgis.utils
# from PyQt4 import QtGui, uic

import os
from osgeo import ogr, osr

# import urllib2                    # VER LIBRERÍA ALTERNATIVA
import urllib
import json
from time import sleep


from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/PK_balizas_carretera.ui'))

# class balizas_carreteraDialog(QtGui.QDialog, FORM_CLASS):
class balizas_carreteraDialog(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(balizas_carreteraDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.fun = Functions()
        # self.logoJCCM.setPixmap(QtGui.QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))

    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        return text.encode('utf-8')
        
    def cancel(self):
        return 'CANCEL'