# -*- coding: utf-8 -*-
"""
/***************************************************************************
 jccm_borrarmarcadores
                                 A QGIS plugin
 Collection of internet map services
                             -------------------
        begin                : 2014-11-21

        git sha              : $Format:%H$
        copyright            : (C) 2017 A.Solabre. JCCM. D.G.Carreteras
        email                : asolabre@jccm.es
 ***************************************************************************/
"""
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import QSettings
from PyQt5.QtWidgets import QDialog, QDialogButtonBox
from PyQt5 import uic
from qgis.core import QgsProject, QgsLayerDefinition, QgsLayerTreeGroup
from qgis.gui import QgsVertexMarker

# from PyQt4 import QtGui, uic
# from PyQt4.QtCore import QSettings, QTranslator, qVersion, QCoreApplication
# from PyQt4.QtGui import QAction, QIcon,  QDialog, QDialogButtonBox, QPixmap
# from qgis.core import *
# from qgis.gui import *

# import ConfigParser

import os

from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

# CURR_PATH = os.path.dirname(__file__)
# FORM_CLASS, _ = uic.loadUiType(os.path.join(CURR_PATH, './menus/jccm_borrarmarcadores.ui'))
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/jccm_borrarmarcadores.ui'))


class borrarmarcadores(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
        """Constructor."""
        super(borrarmarcadores, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.fun = Functions()

        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))

        self.chbBORRAMARCAS.setChecked(True)
        self.chbBORRAPARCAT.setChecked(False)
        self.chbBORRATMCAT.setChecked(False)
        self.chbCAPASCATALOGO.setChecked(False)
        self.btnBORRAR.clicked.connect(self.borrado_click)
        self.btnCANCELA.clicked.connect(self.cancela)

        self.chbCAPASCATALOGO.hide()

    def borrado_click(self):
        if self.chbBORRAMARCAS.isChecked():
            nombreCAPA = 'TRAMOS_BUSCADOS'
            # Borrado de las capas de 'TRAMOS_BUSCADOS'
            for layer in QgsProject.instance().mapLayers().values():
                if layer.name() == nombreCAPA:
                    QgsProject.instance().removeMapLayers([layer.id()])

        '''
            # Borrado de las marcas de las búsquedas
            self.fun.showJCCMessage('PASAMOS LINEA 66')  #####  BORRAR ESTO   #####

            ### 1a VERSION
            # vertex_items = [ i for i in self.iface.mapCanvas().scene().items() if issubclass(type(i), QgsVertexMarker)]
            # for ver in vertex_items:
                # if ver.data(1)=="COGOStartPoint":
                    # self.iface.mapCanvas().scene().removeItem(ver)

            ### 2a VERSION
            # vertex_items = [ i for i in self.iface.mapCanvas().scene().items() if issubclass(type(i), qgis.gui.QgsVertexMarker)]
            # self.fun.showJCCMessage('PASAMOS LINEA 76')  #####  BORRAR ESTO   #####
            # for ver in vertex_items:
                # if ver in self.iface.mapCanvas().scene().items():
                    # self.iface.mapCanvas().scene().removeItem(ver)
            # iface.mapCanvas().refresh()

            ### 3a VERSION
            items = self.iface.mapCanvas().items()
            for item in items:
                self.iface.mapCanvas().removeItem(item)
            return annotations


            vertex_items = [ i for i in self.iface.mapCanvas().scene().items() if issubclass(type(i), qgis.gui.QgsVertexMarker)]
            self.fun.showJCCMessage('PASAMOS LINEA 68')  #####  BORRAR ESTO   #####

            for ver in vertex_items:
                if ver in iface.mapCanvas().scene().items():
                    iface.mapCanvas().scene().items().remove(ver)


            vertex_items = [ i for i in self.iface.mapCanvas().scene().items() if issubclass(type(i), qgis.gui.QgsVertexMarker)]
            self.fun.showJCCMessage('PASAMOS LINEA 78')  #####  BORRAR ESTO   #####
            for ver in vertex_items:
                if ver in iface.mapCanvas().scene().items():
                    iface.mapCanvas().scene().removeItem(ver)

            # vertex_items = [ i for i in self.iface.mapCanvas().scene().items() if issubclass(type(i), QgsVertexMarker)]
            # vertex_items = []
            # for i in self.iface.mapCanvas().scene().items():
            # for i in context().scene().items():
                # self.fun.showJCCMessage('PASAMOS BUCLE LINEA 68')  #####  BORRAR ESTO   #####
                # if issubclass(type(i), QgsVertexMarker):
                    # vertex_items.add(i)
                # pass

            # if len(vertex_items) > 0:
                # self.fun.showJCCMessage('PASAMOS LINEA 74')  #####  BORRAR ESTO   #####
                # for ver in vertex_items:
                    # self.fun.showJCCMessage('PASAMOS BUCLE LINEA 76')  #####  BORRAR ESTO   #####
                    # if ver in self.iface.mapCanvas().scene().items():
                        # self.iface.mapCanvas().scene().removeItem(ver)

            # rc_items = [ i for i in self.iface.mapCanvas().scene().items() if issubclass(type(i), QgsRubberBand)]
            # if len(rc_items) > 0:
                # for ver in rc_items:
                    # self.fun.showJCCMessage('PASAMOS BUCLE LINEA 77')  #####  BORRAR ESTO   #####
                    # if ver in self.iface.mapCanvas().scene().items():
                        # self.iface.mapCanvas().scene().removeItem(ver)
        '''

        if self.chbBORRAPARCAT.isChecked():
            nombreCAPA = 'PARCELAS CATASTRALES'

            # Borrado de los grupos de PARCELAS CATASTRALES
            root = QgsProject.instance().layerTreeRoot()
            grupoBUSCAT = root.findGroup(nombreCAPA)
            if not grupoBUSCAT is None:
                root.removeChildNode(grupoBUSCAT)
            
            # Borrado de las capas de PARCELAS CATASTRALES
            for layer in QgsProject.instance().mapLayers().values():
                if layer.name() == nombreCAPA:
                    QgsProject.instance().removeMapLayers([layer.id()])
            

        if self.chbBORRATMCAT.isChecked():
            # Borrado de capas de catastro correspondienes a Terminos Municipales
            root = QgsProject.instance().layerTreeRoot()
            nomCATtm = 'CAT -'
            for grupo in root.children():
                if isinstance(grupo, QgsLayerTreeGroup):
                    nom = grupo.name()
                    if nom[:5] == nomCATtm:
                        root.removeChildNode(grupo)

            # Borrado de las capas de TERMINOS CATASTRALES
            root = QgsProject.instance().layerTreeRoot()
            nomCATtm = 'CAT-'
            for layer in QgsProject.instance().mapLayers().values():
                if layer.name()[0:4] == nomCATtm:
                    QgsProject.instance().removeMapLayers([layer.id()])


        if self.chbCAPASCATALOGO.isChecked():
            bcap = True
        self.close()

        self.iface.mapCanvas().refresh()            


    def cancela(self):
        self.close()
        pass