# -*- coding: utf-8 -*-
"""
/***************************************************************************
impresion_directa.py
QGIS 3.8
                                 A QGIS plugin
                              -------------------
  Imprime o exporta a fichero PDF el mapa actual usando un diseñador existente. 
    En caso de tratarse de un 'diseñador inteligente' que se genera a partir de los datos 
    de una tabla de atriibutos, permite seleccionarlo y trabajar con el mismo
        begin                : 2016-10-13
        git sha              : $Format:%H$
        copyright            : (C) 2016 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 Basado en el pluggin 'DirectPrintFromView' 
    (2016 by Martí Angelats i Ribera, carlos.lopez@psig.es)
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QSettings
from PyQt5.QtWidgets import QDialog, QListWidgetItem
from PyQt5 import uic

from qgis.core import QgsProject, QgsLayoutItemMap, QgsExpressionContextUtils

# from PyQt4.QtCore import QSettings
# from PyQt4.QtCore import *
# from PyQt4.QtGui import *
# from PyQt4 import QtGui, uic
# from qgis.core import *
# from qgis.gui import *

import os.path
import datetime
import math
# from utils import *

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

# Constantes
EXPORT_PATH = 'export path'
CURR_PATH = os.path.dirname(__file__)
FORM_CLASS, _ = uic.loadUiType(os.path.join(CURR_PATH, './menus/selector_disenadores.ui'))

class impresionDirecta(QDialog, FORM_CLASS):

    def __init__(self, iface, parent=None):
        """Constructor.
        """
        super(impresionDirecta, self).__init__(parent)
        self.setupUi(self)
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.icon = QIcon(os.path.join(os.path.dirname(__file__), 'iconos\jccm.jpg'))
        self.fun = Functions()
        self.setVar = QSettings()

        self.iface = iface
        self.projectLayoutManager = QgsProject.instance().layoutManager()
        
        # Safe plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        self.icon = QIcon(os.path.join(self.plugin_dir, 'icon.png'))

        # Make settings (used to save preferences)
        self.settings = QSettings("JCCM_carreteras", "impresionDirecta")

        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'DirectPrintFromView_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator) 
        
        # Configura los widgets
        scale=int(iface.mapCanvas().scale())
        self.lneESCALA.setText(str(scale))
        self.lneVARMAPA.hide()
        self.btnA4Vert.hide()
        self.btnA4Hori.hide()
        self.btnA3Vert.hide()
        self.btnA3Hori.hide()
        self.printer = None
        
        # Crear la lista de Layouts del widget
        self.Layout_list.clear()
        
        # Añade todos los diseñadores en el proyecto
        # composers = iface.activeComposers()
        Layouts = self.projectLayoutManager.layouts()
        for layout in Layouts:
            print (u'Diseñador - titulo- ='+layout.name())
            QListWidgetItem(layout.name(), self.Layout_list)
        self.Layout_list.setCurrentRow(0)
        if len(self.Layout_list) != 0:
            self.cambiaComposer(Layouts[self.Layout_list.currentRow()])
            self.cbxVARMAPA.setEnabled(True)
            self.lneVARMAPA.setEnabled(True)        
        else:
            self.cbxVARMAPA.setEnabled(False)
            self.lneVARMAPA.setEnabled(False)        

        # Controla el tipo y datos del LAYOUT
        self.Layout_list.currentItemChanged.connect(self.cambiaComposer)

        # Conectamos las funciones a la opción
        self.print_btn.clicked.connect(lambda: self.get_salidarun(iface, 'Print'))
        self.export_btn.clicked.connect(lambda: self.get_salidarun(iface, 'Pdf'))
        self.presentationBtn.clicked.connect(lambda: self.get_salidarun(iface, 'Presen'))
        

    def get_salidarun(self, iface, printAction):
        """Run method that performs all the real work"""
        # composers = iface.activeComposers()
        Layouts = self.projectLayoutManager.layouts()
        composerListo = False
        
        iface.mainWindow().statusBar().showMessage(u'PREPARANDO IMPRESIÓN ... ... ... ... ... ')

        # Seleccionar el diseñador
        if len(self.Layout_list) == 0:
            self.close()
            composition, composer = self.makeComposer(iface)
            composerListo = True
            print ('composerListo ', composerListo)
            # Layouts = iface.activeComposers()

        else:
            composer = Layouts[self.Layout_list.currentRow()]
            # print (composer.composerWindow().windowTitle())
            # composition = composer.composition()
            # composer.composerWindow().show()
            iface.openLayoutDesigner(composer)
            # composer.refreshItems()
            composer.refresh()

            
        # Cerramos el menu de impresión    
        self.close()

        # varmapa = self.lneVARMAPA.text()
        varmapa = self.cbxVARMAPA.currentText()
        self.setVar.setValue("JCCM_carreteras/lastVARMAPA", varmapa)
        # print varmapa
        # VAR_DATO
        # CAMPO_ID
        # TABLA_DATOS
        varPers = []
        # scopeComp = QgsExpressionContextUtils.compositionScope(composition)
        scopeComp = QgsExpressionContextUtils.layoutScope(composer)
        for var in scopeComp.variableNames():
            if not scopeComp.isReadOnly(var):
                # Asignamos -varmapa- a todas las variables no-readonly
                #print var, scopeComp.isReadOnly(var)
                if var == 'VAR_DATO':
                    # QgsExpressionContextUtils.setCompositionVariable(composition, var, varmapa)
                    QgsExpressionContextUtils.setLayoutVariable(composer, var, varmapa)
                varPers.append([var,scopeComp.variable(var)])
        
        print (varPers)
        if varPers == [] and composerListo == False:
            # Colocamos Titulo y Escala
            try:
                self.mapTITULO = composition.getComposerItemById('TITULO')
                titulo = self.lneTITULO.text()
                self.mapTITULO.setText(titulo)
            except:
                pass
        
            # Colocamos Escala y centramos mapa
            self.mapitem = composition.getComposerItemById('MAPA0')
            if self.mapitem is None:
                print ('NO APARECE UN MAPA LLAMADO -MAPA0-')
                for item in composer.items():
                    # if item.__class__ == qgis.core.QgsComposerMap:
                    if item.__class__ == QgsComposerMap:
                        print (type(item).__name__, item.id())
            centerAllCompositionMaps(composition, iface.mapCanvas().center())
            escala = float(self.lneESCALA.text())
            # escala = self.dialogui.comboBox_scale.scale()
            if math.isinf(escala) or math.isnan(escala) or abs(escala) < 1E-6:
                iface.mainWindow().statusBar().showMessage(u'')
                return
            # newscale = 1. / escala
            newscale = escala
            extent = self.mapitem.extent()
            center = extent.center()
            newwidth = extent.width() / self.mapitem.scale() * newscale
            newheight = extent.height() / self.mapitem.scale() * newscale
            x1 = center.x() - 0.5 * newwidth
            y1 = center.y() - 0.5 * newheight
            x2 = center.x() + 0.5 * newwidth
            y2 = center.y() + 0.5 * newheight
            self.mapitem.setNewExtent(QgsRectangle(x1, y1, x2, y2))
        
        # Imprimir o Exportar a PDF
        if printAction == 'Printer':
            # Get the printer
            # printer = askPrinter(self.icon)
            # Make sure it actually selected a printer
            # if printer is not None:
                # getattr(composition, 'print')(printer)
            if not self.printer:
                self.printer = QPrinter()

            printdialog = QPrintDialog(self.printer)
            if printdialog.exec_() != QDialog.Accepted:
                iface.mainWindow().statusBar().showMessage(u'')
                return
        elif printAction == 'Pdf':
            # Ask where to save the exported file

            path = QFileDialog.getSaveFileName(
                None,
                None,
                os.path.join(
                    self.settings.value(EXPORT_PATH, os.path.expanduser("~")),      #default folder
                    ""
                ),
                "PDF (*.pdf)"
            )

            # If the path is not incorrect
            if path != None and path != "":
                # Save the folder path in the settings for the next time
                self.settings.setValue(u'C:/temp/', os.path.dirname(path))

                # Export to PDF
                composition.exportAsPDF(path)
                # And show the result using the default application
                openFile(path)
        iface.mainWindow().statusBar().showMessage(u'')
        self.close()


    def cambiaComposer(self, i):
        # composers = iface.activeComposers()
        Layouts = self.projectLayoutManager.layouts()
        layoutSelect = Layouts[self.Layout_list.currentRow()]
        if layoutSelect is None:
            print ('No layoutSelect')
            return
        else:
            # print layoutSelect.composerWindow().windowTitle()
            composition = layoutSelect
            # composition = QgsLayoutItemMap(layoutSelect)
            pass

        varmapa = self.lneVARMAPA.text()
        # VAR_DATO    - Contiene el valor de CAMPO_ID a imprimir
        # CAMPO_ID    - Contiene el nombre del campo que contendrá el CAMPO_ID que conforma el informe
        # TABLA_DATOS - Contiene el nombre de la capa que contiene el campo CAMPO_ID
        varPersDatos = []
        var_dato = ''
        campo_id = ''
        tabla_datos = ''
        # scopeComp = QgsExpressionContextUtils.compositionScope(composition)
        scopeComp = QgsExpressionContextUtils.layoutScope(composition)
        for var in scopeComp.variableNames():
            if not scopeComp.isReadOnly(var):
                # print var, scopeComp.variable(var)
                if var == 'VAR_DATO':
                    var_dato = scopeComp.variable(var)
                    # QgsExpressionContextUtils.setCompositionVariable(composition, var, varmapa)
                    QgsExpressionContextUtils.setLayoutVariable(composition, var, varmapa)
                    varPersDatos.append('VAR_DATO:'+scopeComp.variable(var))
                if var == 'CAMPO_ID':
                    campo_id = scopeComp.variable(var)
                    varPersDatos.append('CAMPO_ID:'+scopeComp.variable(var))
                if var == 'TABLA_DATOS':
                    tabla_datos = scopeComp.variable(var)
                    varPersDatos.append('TABLA_DATOS:'+scopeComp.variable(var))

        # print var_dato, campo_id, tabla_datos
        print (varPersDatos)
        #self.fun.showJLMMessageERR( message,'','Impresión de ficha de desde tabla' )

        try:
            layer = self.fun.getLayerByName(tabla_datos)
            listaValores=[]
            for feature in layer.getFeatures():
                listaValores.append(feature[campo_id])
            # print listaValores
            listaValores = list(set(listaValores))
            listaValores.sort(reverse=True)
            self.cbxVARMAPA.clear()
            self.cbxVARMAPA.addItems(listaValores)
            lastVARMAPA = self.setVar.value("JCCM_carreteras/lastVARMAPA")
            if lastVARMAPA in listaValores:
                self.cbxVARMAPA.setCurrentIndex(listaValores.index(lastVARMAPA))
                
            self.cbxVARMAPA.setEnabled(True)
            # self.lneVARMAPA.setEnabled(True)
        except:
            self.cbxVARMAPA.setEnabled(False)
            # self.lneVARMAPA.setEnabled(False)
        
    def makeComposer(self, iface):
        # Creamos la composición
        mapRenderer = iface.mapCanvas().mapRenderer()
        c = QgsComposition(mapRenderer)
        c.setPlotStyle(QgsComposition.Print)
        
        # Añadimos un mapa
        x, y = 0, 0
        w, h = c.paperWidth(), c.paperHeight()
        mapitem = QgsComposerMap(c, x ,y, w, h)
        c.addItem(mapitem)
        centerAllCompositionMaps(c, iface.mapCanvas().center())
        escala = float(self.lneESCALA.text())
        # escala = self.dialogui.comboBox_scale.scale()
        if math.isinf(escala) or math.isnan(escala) or abs(escala) < 1E-6:
            return
        # newscale = 1. / escala
        newscale = escala
        extent = mapitem.extent()
        center = extent.center()
        newwidth = extent.width() / mapitem.scale() * newscale
        newheight = extent.height() / mapitem.scale() * newscale
        x1 = center.x() - 0.5 * newwidth
        y1 = center.y() - 0.5 * newheight
        x2 = center.x() + 0.5 * newwidth
        y2 = center.y() + 0.5 * newheight
        mapitem.setNewExtent(QgsRectangle(x1, y1, x2, y2))
        
        # Añadimos un Titulo
        composerLabel = QgsComposerLabel(c)
        composerLabel.setText(u'Título')
        composerLabel.adjustSizeToText()
        c.addItem(composerLabel)
        # composer = QgsComposerMap(c)
        
        
        # find items and items prop widget
        composer = iface.createNewComposer()
        composer.setComposition(c)
        
        win = composer.composerWindow()
        items_widget = win.findChildren(QDockWidget, 'ItemsDock')[0]

        items_widget_prop = win.findChildren(QDockWidget, 'ItemDock')[0]
        items_widget_prop.show()

        # set items model
        items_list_widget = items_widget.findChildren(QTreeView,'')[0]
        items_model = c.itemsModel()
        items_list_widget.setModel(items_model)

        QObject.connect( items_list_widget.selectionModel(), SIGNAL("currentChanged( QModelIndex, QModelIndex)"), c.itemsModel(),SLOT("setSelected( QModelIndex )"))

        return c, composer

