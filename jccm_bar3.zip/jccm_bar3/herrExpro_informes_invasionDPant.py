# -*- coding: utf-8 -*-
"""
/***************************************************************************
herrExpro_informes_invasionDP.py
                                 A QGIS plugin

                             -------------------
        begin                : 2019-02-11
        git sha              : $Format:%H$
        Codigo Original     : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWidgets import QDialog, QTableWidgetItem, QApplication
from PyQt5.QtCore import QSettings
from PyQt5 import uic
from qgis.core import QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsFeature, QgsField, QgsExpression, QgsFeatureRequest
from qgis.PyQt.QtCore import Qt


import os
from osgeo import ogr, osr, gdal
# from cookielib import CookieJar
from xml.etree import cElementTree as ElementTree
# import urllib2
import urllib

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

from .herrExpro_CONFIG_dialog import herrExpro_CONFIGdlg_expInvDP


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_informes_invasionDPdlg.ui'))

tipoCARGA = 'CAPAPAR'
        # tipoCARGA = 'CAPAPAR' # tipoCARGA = 'CAPAPAR' - Carga las parcelas en una capa única
        # tipoCARGA = 'CAPAIND' # tipoCARGA = 'CAPAIND' - Carga las parcelas en capas individuales

current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.environment["EPSG"]

class herrExpro_informes_invasionDP(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrExpro_informes_invasionDP, self).__init__(parent)
        self.current_configuration = configuration()
        self.setVar = QSettings()
        self.fun = Functions()
        self.iface = iface;
        self.setupUi(self)

        #######################################################################
        #  Estudiar SI NO ESTÁN LAS VARIABLES DE LIMITES DE EXPROPIACION
        #######################################################################
        proviEXPRO = self.setVar.value("JCCM_carreteras/EXPprovincia")
        if proviEXPRO is None:
            proviEXPRO = 'ALBACETE'
        layerLIMI = self.setVar.value("JCCM_carreteras/EXPlayerLIMEXPRO")
        if layerLIMI is None:
            layerLIMI = 'LIMITES DE EXPROPIACION AB'
        layerINFEXP = self.setVar.value("JCCM_carreteras/EXPlayerINFOEXPRO")
        if layerINFEXP is None:
            layerINFEXP = 'Informes de Expropiaciones'

        #  Estudiar SI NO ESTÁ LA CAPA LIMITES DE EXPROPIACION
        if len(QgsProject.instance().mapLayersByName(layerLIMI))==0:
            text = u"INVESTIGACIÓN DE INVASIÓN DE 'LÍMITES DE EXPROPIACIÓN'\n\nNo están cargadas las capas necesarias"
            text2 = '¿CONFIGURAR?'
            # self.fun.showJCCMessage(u"INVESTIGACIÓN DE INVASIÓN DE 'LÍMITES DE EXPROPIACIÓN'\n\nNo están cargadas las capas necesarias")
            retval = self.fun.showJCCMessageYESNO(text,text2,tittle="JCCM",)

            # tipoCONF = 'COMPLETA'
            # result = self.herrExpro_CONFIG(tipoCONF).exec_()

            if retval == 1024:       # Se ha pulsado ACEPTAR
                result = self.herrExpro_CONFIG()
                if result is None:
                    self.close()
                    return
                else:
                    proviEXPRO  = self.setVar.value("JCCM_carreteras/EXPprovincia")
                    layerLIMI   = self.setVar.value("JCCM_carreteras/EXPlayerLIMEXPRO")
                    layerINFEXP = self.setVar.value("JCCM_carreteras/EXPlayerINFOEXPRO")

            elif retval == 4194304:    # Se ha pulsado CANCELAR
                # self.reject()
                self.close()
                return


        self.logo.setPixmap(QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.setFixedSize(810, 425)
        self.botonAbajo = 'U'
        # self.btnAbrirAbajo.setArrowType(Qt.UpArrow)
        self.btnAbrirAbajo.setArrowType(Qt.UpArrow)
        self.tabWidget.setCurrentIndex(4)
        self.lblINFOSUP.setText(u'Paso '+self.tabWidget.tabText(self.tabWidget.currentIndex()))
        self.btnANTERIOR.setVisible(1)
        # self.btnANTERIOR.setEnabled(False)
        self.btnSIGUIENTE.setVisible(1)
        self.lblINFOSUP.setVisible(1)

        self.lblCapaLIMEXPRO.setText(u'CAPA LIM.EXPRO: %s'%(layerLIMI))
        self.lblCapaINFOEXPRO.setText(u'CAPA INFO.EXPRO: %s'%(layerINFEXP))

        # Control de cambios de TABS
        # self.tabWidget.blockSignals(True)
        self.tabWidget.currentChanged.connect(self.onChange)

        self.btnANTERIOR.clicked.connect(lambda: self.botonAntSig(1))
        self.btnSIGUIENTE.clicked.connect(lambda: self.botonAntSig(2))
        self.btnAbrirAbajo.clicked.connect(lambda: self.botonAmpliarAbajo())
        self.lblNOCATASTRO.hide()

        # self.btnCargaMasiva.clicked.connect(self.cargaMasiva)
        # self.combo_tabla.currentIndexChanged.connect(self.actualizarCampos) # Revisar esto y tal vez quitar el botón ACTUALIZAR CAMPOS
        # self.btnIrCargaMasiva.clicked.connect(self.IrCargaMasiva)

        QApplication.restoreOverrideCursor()

        if configuration.custom_configuration != "":
            #QgsMessageLog.logMessage( "Cargando configuracion personalizada","jccm_bar")
            import imp
            try:
                custom_file = configuration.custom_configuration
                foo = imp.load_source('custom_config', custom_file)
                custom_config =  foo.custom_config()
                self.current_configuration = custom_config
            except:
                #QgsMessageLog.logMessage( "Archivo no encontrado, se carga configuracion por defecto..","jccm_bar")
                pass

        '''
        ***************************************************************************/
                PASO 1.Buscador de parcelas catastrales
                CONTROLES
        ***************************************************************************/
        '''
        self.RC_CenterList = []  # Este dato no se sabe muy bien para que es, se quitan las referencias

        lista_provincias = self.fun.getProvinciasCatastro()
        self.combo_provincia.clear()
        if lista_provincias is not None and lista_provincias != 'nocat':
            self.combo_provincia.addItems(lista_provincias)
            lastProvSelect = self.setVar.value("JCCM_carreteras/lastProvSelect")
            if lastProvSelect in lista_provincias:
                self.combo_provincia.setCurrentIndex(lista_provincias.index(lastProvSelect))
        else:
            self.lblNOCATASTRO.show()
            # self.close()
            return None

        # Se colocan los valores por defecto con el último valor tecleado
        #----------------------------------------------------------------------
        lastRC14Select = self.setVar.value("JCCM_carreteras/lastRC14Select")
        self.ref_catastral.setText(lastRC14Select)
        lastNPOLSelect = self.setVar.value("JCCM_carreteras/lastNPOLSelect")
        self.poligono.setText(lastNPOLSelect)
        lastNPARSelect = self.setVar.value("JCCM_carreteras/lastNPARSelect")
        self.parcela.setText(lastNPARSelect)

        self.updateCombos()

        self.addParcCatastrales()   #Añade las parcelas catastrales seleccionadas desde fichero si existe

        self.addToListRCButton.clicked.connect(self.addRCtoListClicked)
        self.addToListRusticaButton.clicked.connect(self.addToListRusticaButtonClicked)
        self.zoomYCerrarButton.clicked.connect(self.zoomYCerrarButtonClicked)
        self.quitarItemButton.clicked.connect(self.quitarItemClicked)
        self.limpiarListaButton.clicked.connect(self.limpiarListaClicked)
        self.combo_provincia.currentIndexChanged.connect(self.provincia_updated)

        '''
        ***************************************************************************/
                PASO 2.Geoproceso
                CONTROLES
        ***************************************************************************/
        '''
        self.tablaRefCatResult.setColumnWidth(0, 120)   # ANCHO 590
        self.tablaRefCatResult.setColumnWidth(1, 80)
        self.tablaRefCatResult.setColumnWidth(2, 85)
        self.tablaRefCatResult.setColumnWidth(3, 65)
        self.tablaRefCatResult.setColumnWidth(4, 55)
        self.tablaRefCatResult.setColumnWidth(5, 55)
        self.tablaRefCatResult.setColumnWidth(6, 130)

        self.btnRESULTADOS.clicked.connect(self.intersectParcelas)



    '''
    ***************************************************************************/
    ***    FUNCIONES GENÉRICAS     ***
    ***************************************************************************/
    '''
    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()
        self.close()
        # super(herrExpro_informes_invasionDP, self).close()


    def onChange(self,i): #changed!
        tabname = self.tabWidget.tabText(i)
        self.lblINFOSUP.setText('Paso '+tabname)
        # print "Actual Tab: %d %s" % (i, tabname)
        pass


    def botonAntSig(self,sentido):
        # Sentido = 1 > ANTERIOR
        # Sentido = 2 > SIGUIENTE
        actIndex = self.tabWidget.currentIndex()
        self.btnANTERIOR.setEnabled(True)
        self.btnSIGUIENTE.setEnabled(True)

        if sentido == 1:
            self.tabWidget.setCurrentIndex(actIndex+1)
            # if self.tabWidget.currentIndex()== 4:
                # self.btnANTERIOR.setEnabled(False)
        else:
            self.tabWidget.setCurrentIndex(actIndex-1)
            # if self.tabWidget.currentIndex()== 0:
                # self.btnSIGUIENTE.setEnabled(False)

        self.lblINFOSUP.setText(u'Paso '+self.tabWidget.tabText(self.tabWidget.currentIndex()))
        self.logo.setVisible(1)
        self.setFixedSize(810, 425)
        self.btnAbrirAbajo.setArrowType(Qt.UpArrow)
        self.botonAbajo = 'U'


    def botonAmpliarAbajo(self):
        if self.botonAbajo == 'D':
            self.logo.setVisible(1)
            # self.btnANTERIOR.setVisible(0)
            # self.btnSIGUIENTE.setVisible(0)
            # self.lblINFOSUP.setVisible(0)
            self.setFixedSize(810, 425)
            self.btnAbrirAbajo.setArrowType(Qt.UpArrow)
            self.botonAbajo = 'U'
        elif self.botonAbajo == 'U':
            self.logo.setVisible(1)
            # self.btnANTERIOR.setVisible(1)
            # self.btnSIGUIENTE.setVisible(1)
            # self.lblINFOSUP.setVisible(1)
            self.setFixedSize(810, 75)
            self.btnAbrirAbajo.setArrowType(Qt.DownArrow)
            self.botonAbajo = 'D'

    '''
    ***************************************************************************/
            PASO 1.Buscador de parcelas catastrales
    Esta parte es similar al buscador general de la append
    De hecho se deben unificar las funciones y no repetirlas

    *** FUNCIONES ***
    getProvinciasCatastro
    provincia_updated
    updateCombos

    quitarItemClicked
    limpiarListaClicked
    zoomYCerrarButtonClicked
    zoomToCurrentList
    addRCtoListClicked
    addToListRusticaButtonClicked

    goToRC_clicked
    ***************************************************************************/
    def getProvinciasCatastro(self):
        params = []
        url = u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejeroCodigos.asmx/ConsultaProvincia?'
        # Ejemplo http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejeroCodigos.asmx/ConsultaProvincia?

        # data = urllib.urlencode(params)
        data = urllib.parse.urlencode(params)
        response = json.load(urllib.request.urlopen(url+data))
        try:
            features =  response["features"]
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.CtraPktoCoorsAcim LIN:384)")
            return 'Error: No hay elementos'

        try:
            req = urllib2.urlopen(url, data)
        except urllib2.HTTPError as e:
            if e.code == 407:
                self.fun.showJCCMessage(u"PROBLEMAS DE CONEXIÓN POR PROXY, CONSULTE CON INFORMÁTICA")
                return 'nocat'
            else:
                self.fun.showJCCMessage(u"-- LA SEDE ELECTRÓNICA DE CATASTRO NO DA RESPUESTA --")
                return 'nocat'

        except urllib2.URLError as e:
            self.fun.showJCCMessage(u"Error de conexión a internet")
            return 'nocat'

        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)

        lista_provincias = []

        for prov in xml.iter(u"{http://www.catastro.meh.es/}prov"):
           for data in prov.iter(u"{http://www.catastro.meh.es/}np"):
               lista_provincias.append(data.text)
        return lista_provincias
    '''


    def quitarItemClicked(self):
        self.quitarSelectedItemsList()
        pass


    def limpiarListaClicked(self):
        # Se borran todos los elementos en la lista de RC
        current_lista_rc =  [str(self.listaRCs.item(i).text()) for i in range(self.listaRCs.count())]
        for i in range(len(current_lista_rc)):
            # print i
            self.listaRCs.takeItem(0)


    def quitarSelectedItemsList(self):
        # Se borran los elementos seleccionados en la lista de RC
        listItems=self.listaRCs.selectedItems()
        if not listItems: return
        for item in listItems:
            index = self.listaRCs.row(item)
            self.listaRCs.takeItem(index)


    def zoomYCerrarButtonClicked(self):
        self.setVar.setValue("JCCM_carreteras/lastProvSelect", self.combo_provincia.currentText())
        self.setVar.setValue("JCCM_carreteras/lastMuniSelect", self.combo_tmuni.currentText())

        self.zoomToCurrentList(True, tipoCARGA)
        QApplication.restoreOverrideCursor()


    def zoomToCurrentList(self, close, tipoCARGA):
        # Carga todas las parcelas de la lista de RC y les añade los atributos
        # tipoCARGA = 'CAPAPAR' # tipoCARGA = 'CAPAPAR' - Carga las parcelas en una capa única
        # tipoCARGA = 'CAPAIND' # tipoCARGA = 'CAPAIND' - Carga las parcelas en capas individuales

        QApplication.setOverrideCursor(Qt.WaitCursor)

        current_lista_rc =  [str(self.listaRCs.item(i).text()) for i in range(self.listaRCs.count())]
        # print 'current_lista_rc - ', len(current_lista_rc), ' elementos'
        if len(current_lista_rc) < 1:
            self.fun.showJCCMessage("No hay elementos en la lista")
            QApplication.restoreOverrideCursor()
            return

        # Comprobamos si existe la capa
        nom_layer = 'PARCELAS CATASTRALES'
        srs =  self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        src= 'crs='+ srs
        # src= "crs=epsg:25830"
        tipo_layer= "Polygon"
        layerEXIST = QgsProject.instance().mapLayersByName(nom_layer)
        if not layerEXIST:
            # CREACIÓN DE LA CAPA
            vl = QgsVectorLayer(tipo_layer+'?'+src, nom_layer, 'memory')
        else:
            vl = layerEXIST[0]
            # La capa existe pero está vacía
            if vl.featureCount() == 0:
                QgsProject.instance().removeMapLayer( vl.id() )
                vl = QgsVectorLayer(tipo_layer+'?'+src, nom_layer, 'memory')
        layers = []
        geometries = []
        bbox = None

        # listaParcErr=[]
        # textMsgINI = 'CARGANDO PARCELAS CATASTRALES...'+'\n'
        # self.txeAVISOS.setText(textMsgINI)
        for rc in current_lista_rc:
            # print current_lista_rc.index(rc), ' de ', len(current_lista_rc)
            pc1= rc[:7]
            pc2= rc[7:14]
            progress = 'Cargando Parcela %s de %s - %s ...'%(str(current_lista_rc.index(rc)+1), str(len(current_lista_rc)), rc)
            self.iface.mainWindow().statusBar().showMessage(progress)

            # Comprobamos si la parcela ya existe en la capa
                # Obtiene un iterador de elementos desde una expresión
            consulta = u'"PCAT1" = \''+pc1+'\' and "PCAT2" = \''+pc2+'\''
            expr = QgsExpression( consulta )
            it = vl.getFeatures( QgsFeatureRequest( expr ) )
            ids = [j.id() for j in it]

            if len(ids) == 0:
                # print rc + ' NO EXISTE, SE CARGA'
                result = self.fun.getPointFromRC(self.iface,rc)
                ldt= result[2]

                if pc1[5] =='A':
                    # Obtencion de tipoPAR en caso de parcelas de RC rústica
                    if pc2[3] =='9':
                        tipoPAR =  u'X'
                    else:
                        tipoPAR =  u'R'
                    # Obtención de cp,cm,pol,par
                    cp = pc1[0:2]
                    cmc = pc1[2:5]
                    cpo = pc1[6]+pc2[0:2]
                    cpa = pc2[2:7]
                    HOJA= pc1[0:6]
                    # print 'PRO-'+cp+'/MUN-'+cmc+'/POL-'+cpo+'/PAR-'+cpa
                else:
                    # Obtencion de tipoPAR en caso de parcelas de RC urbana y diseminados
                    if ldt[0:14] == 'TN DISEMINADOS':
                        tipoPAR =  u'D'
                    else:
                        tipoPAR = u'U'

                    # Obtención de cp,cm,pol,par
                    cp = '00'
                    cmc = '000'
                    cpo = pc1[0:5]
                    cpa = pc1[5:7]
                    HOJA = pc2

                '''
                #           PCAT1,PCAT2,EJERCICIO,NUM_EXP,CONTROL,COORY,VIA,NUMERO,NUMERODUP,NUMSYMBOL,AREA,FECHAALTA,FECHABAJA,MAPA ,DELEGACIO,MUNICIPIO,MASA,HOJA    ,TIPO   ,PARCELA,COORX
                #atributos=[pc1  ,pc2  ,0        ,0      ,0      ,0    ,cv ,pnp   ,0        ,0        ,0   ,0        ,0        ,MAPA ,cp       ,cmc      ,cpo ,pc2     ,cn[:1] ,cpa    ,0    , RC14]
                atributos =[pc1  ,pc2  ,0        ,0      ,0      ,0    ,0  ,0     ,0        ,0        ,0   ,0        ,0        ,0    ,cp       ,cmc      ,cpo ,HOJA    ,tipoPAR,cpa    ,0    , rc]
                '''
                #           RC14,PCAT1,PCAT2,EJERCICIO,NUM_EXP,CONTROL,COORY,VIA,NUMERO,NUMERODUP,NUMSYMBOL,AREA,FECHAALTA,FECHABAJA,MAPA ,DELEGACIO,MUNICIPIO,MASA,HOJA    ,TIPO   ,PARCELA,COORX
                atributos =[rc  ,pc1  ,pc2  ,0        ,0      ,0      ,0    ,0  ,0     ,0        ,0        ,0   ,0        ,0        ,0    ,cp       ,cmc      ,cpo ,HOJA    ,tipoPAR,cpa    ,0    ]

                if tipoCARGA == 'CAPAIND':
                    # Esta opcion genera una capa independiente para cada parcela, en el grupo 'PARCELAS CATASTRALES'
                    result = self.fun.cargarCapaParcelaCatastro(rc,nom_layer, atributos, 'shp',srs)
                    if result[0] != u'ERROR':
                        layer = result[0]
                        layers.append(layer)
                    else:
                        return
                else:
                    # Esta opcion genera o añade las parcelas a una capa unica llamada 'PARCELAS CATASTRALES'

                    # AÑADIR LA CAPA INDIVIDUAL DE LA PARCELA
                    # nombrecapa = "PARCELAS CATASTRALES"
                    tipolayer = 'shp'
                    MAPA=0
                    HOJA='XXXXXX'

                    result = self.fun.cargarCapaParcelaCatastroSHP(rc,nom_layer, atributos, 'shp', srs)

                    if result == 'ERROR':
                        # La RC no tiene geometría
                        listaParcErr.append(rc)
                        textMsg = rc.encode("utf-8")+ u' SIN GEOMETRÍA'
                        self.txeAVISOS.append(textMsg)
                        continue
                    newbox = result[3]

                    if bbox == None:
                        bbox = newbox
                    else:
                        ## DA ERROR LA RC 02074A01909000
                        if(newbox.xMinimum() < bbox.xMinimum()):
                            bbox.setXMinimum(newbox.xMinimum())
                        if(newbox.yMinimum() < bbox.yMinimum()):
                            bbox.setYMinimum(newbox.yMinimum())
                        if(newbox.xMaximum() > bbox.xMaximum()):
                            bbox.setXMaximum(newbox.xMaximum())
                        if(newbox.yMaximum() > bbox.yMaximum()):
                            bbox.setYMaximum(newbox.yMaximum())

            else:
                if tipoCARGA == 'CAPAIND':
                    # print rc + ' EXISTE, SOLO ZOOM'
                    layerBUSQ = QgsProject.instance().mapLayersByName('PARCELA_'+rc)
                    if layerBUSQ:
                        layer = layerBUSQ[0]
                        layers.append(layer)
                else:
                    ########################################################
                    #  Estudiar QUE PASA CUANDO LAS PARCELAS YA ESTÁN
                    ########################################################
                    for feat in it:
                        newbox = feat.geometry().bbox()
                        if bbox == None:
                            bbox = newbox
                        else:
                            if(newbox.xMinimum() < bbox.xMinimum()):
                                bbox.setXMinimum(newbox.xMinimum())
                            if(newbox.yMinimum() < bbox.yMinimum()):
                                bbox.setYMinimum(newbox.yMinimum())
                            if(newbox.xMaximum() > bbox.xMaximum()):
                                bbox.setXMaximum(newbox.xMaximum())
                            if(newbox.yMaximum() > bbox.yMaximum()):
                                bbox.setYMaximum(newbox.yMaximum())

            rowPosition = self.tablaRefCatResult.rowCount()
            self.tablaRefCatResult.insertRow(rowPosition)
            self.tablaRefCatResult.setItem(rowPosition , 0, QTableWidgetItem(rc))

        if tipoCARGA == 'CAPAIND':
            # Zoom a las capas INDIVIDUALES añadidas
            self.fun.zoomToListLayer(layers,self.iface)
        else:
            # Zoom a los elementos (parcelas) añadidos
            if bbox is not None:
                ## ERROR CON 02074A01909000
                self.iface.mapCanvas().zoomToFeatureExtent(bbox)
                self.iface.mapCanvas().refresh()

        if close == True:
            #Minimizar el cuadro de diálogo
            # self.close()
            self.logo.setVisible(0)
            self.setFixedSize(810, 75)
            self.btnAbrirAbajo.setArrowType(Qt.DownArrow)
            self.botonAbajo = 'D'

        progress = '-FINALIZADO- %s Parcelas Cargadas'%(str(len(current_lista_rc)))
        self.iface.mainWindow().statusBar().showMessage(progress)
        pass


    def addRCtoListClicked(self, rc):
        rc = self.ref_catastral.text().upper()

        # Se comprueba si la RC existe ya en la lista
        if len(self.listaRCs.findItems(rc, Qt.MatchExactly)) > 0:
            # print 'Ya existe la RC ', rc
            return

        # Se comprueba si la RC tiene 14 dígitos
        if len(rc)!=14:
            if len(rc)>14:
                rc = rc[:14]
                text = u'LA REFERENCIA CATASTRAL DEBE SER DE 14 POSICIONES\n'
                text+= u' SE TRUNCA A 14 DÍGITOS-  '+rc
                self.fun.showJCCMessage(text)
            else:
                text = u'LA REFERENCIA CATASTRAL TIENE MENOS DE 14 POSICIONES'
                self.fun.showJCCMessage(text)
                return

        point = None
        # Esto comprueba la existencia de la referencia catastral
        point_response = self.fun.getPointFromRC(self.iface,rc)

        if point_response is not None and point_response[0] == "Error":
            self.fun.showJCCMessage(point_response[1])
        elif point_response is not None:
            point = point_response[1]
        if point is not None:
            puntoData = [point, rc]
            # self.RC_CenterList.append(puntoData)
            self.listaRCs.addItem(rc)
        pass

        self.setVar.setValue("JCCM_carreteras/lastRC14Select", self.ref_catastral.text().upper())


    def addToListRusticaButtonClicked(self):
        poligono = self.poligono.text()
        parcela = self.parcela.text()
        provincia_selected = self.combo_provincia.currentText()
        provincia_code = self.fun.getProvinciaCode(provincia_selected)

        municipio_selected = self.combo_tmuni.currentText()
        municipio_code = self.fun.getMuniCode(provincia_selected, municipio_selected)

        rc_provincia = self.fun.completarCeros(provincia_code,2)
        rc_municipio = self.fun.completarCeros(municipio_code,3)
        rc_sector = 'A'
        rc_poligono = self.fun.completarCeros(poligono,3)
        rc_parcela = self.fun.completarCeros(parcela,5)

        rc = rc_provincia + rc_municipio + rc_sector + rc_poligono + rc_parcela
        point = None
        point_response = self.fun.getPointFromRC(self.iface, rc)
        if point_response is not None and point_response[0] == "Error":
            self.fun.showJCCMessage(point_response[1])
        elif point_response is not None:
            point = point_response[1]
        if point is not None:
            puntoData = [point, rc]
            # self.RC_CenterList.append(puntoData)
            self.listaRCs.addItem(rc)
        pass

        self.setVar.setValue("JCCM_carreteras/lastNPOLSelect", self.poligono.text())
        self.setVar.setValue("JCCM_carreteras/lastNPARSelect", self.parcela.text())


    def goToRC_clicked(self):

        #print 'Zoom a RC'

        rc = self.ref_catastral.text()
        #rc = '9169204WJ9196G0001' # temporal rc
        srs =  srcVal
        params = [
            ('SRS', 'EPSG:'+ str(srs) ),
            ('RC',rc),
            ('Provincia',''),
            ('Municipio','') ]


        url = self.current_configuration.environment["url_catastro_rc"]
        data = urllib.urlencode(params)
        req = urllib2.urlopen(url, data)
        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)

        #print xml_txt
        x = None
        y = None
        for elem in xml.iter(u"{http://www.catastro.meh.es/}xcen"):
            x = float(elem.text)
        for elem in xml.iter(u"{http://www.catastro.meh.es/}ycen"):
            y = float(elem.text)
        if (x is None or y is None):
            for elem in xml.iter(u"{http://www.catastro.meh.es/}des"):
                error = elem.text
                self.fun.showJCCMessage(error)
        else:
            #point = ogr.Geometry(ogr.wkbPoint)
            #point.AddPoint(y, x)
            #self.fun.zoomToGeometry(self.iface,point)
            source = osr.SpatialReference()
            source.ImportFromEPSG(srs)
            target_qg = self.iface.mapCanvas().mapSettings().destinationCrs()
            target_txt = target_qg.authid()
            target_id = target_txt.split(":")[1]
            target = osr.SpatialReference()
            target.ImportFromEPSG(int(target_id))

            transform = osr.CoordinateTransformation(source, target)
            point = ogr.Geometry(ogr.wkbPoint)
            point.AddPoint(x,y)
            point.Transform(transform)
            #print point
            self.fun.zoomToGeometry(self.iface,point)


    def provincia_updated(self,i):
        self.updateCombos()
        pass


    def updateCombos(self):
        provincia_selected = self.combo_provincia.currentText()
        provincia_code = self.fun.getProvinciaCode(provincia_selected)

        provincia_selected = provincia_selected.encode('utf-8', errors='ignore')

        params = {'Provincia' : provincia_selected,
                  'Municipio' : ''
                  }

        url = self.current_configuration.environment["url_catastro_municipio"]
        # url = 'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaMunicipio?'
        data = urllib.parse.urlencode(params)

        try:
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            self.fun.showJCCMessage(u"Error de conexión a internet (catastroBuscador.updateCombos lin:547)")
            return 'nocat'

        try:
            xml_txt =  req.read()
        except:
            self.fun.showJCCMessage(u"Error de conexión a catastro en LISTA MUNICIPIOS")
            return

        xml = ElementTree.fromstring(xml_txt)

        municipios = []
        for muni in xml.iter(u"{http://www.catastro.meh.es/}muni"):
            municipios.append(muni.find(u"{http://www.catastro.meh.es/}nm").text)

        self.combo_tmuni.clear()
        self.combo_tmuni.addItems(municipios)
        lastMuniSelect = self.setVar.value("JCCM_carreteras/lastMuniSelect")
        if lastMuniSelect in municipios:
            self.combo_tmuni.setCurrentIndex(municipios.index(lastMuniSelect))


    def addParcCatastrales(self):
        layerPARC = 'PARCELAS CATASTRALES'

        if len(QgsProject.instance().mapLayersByName(layerPARC))==0:
            return

        layer1 = QgsProject.instance().mapLayersByName(layerPARC)[0]

        countW = layer1.selectedFeatureCount()
        featuresW = layer1.getFeatures()
        if countW > 0:
            featuresW = layer1.selectedFeatures()

        ####################################################################################
        ###  Estudiar QUE PASA si la capa PARCELAS CATASTRALES NO TIENE EL CAMPO RC     ###
        ####################################################################################

        for w in featuresW:      #Cada elemento de la capa 1. Se llamará W
            RC14 = w["RC14"]
            self.listaRCs.addItem(RC14[:14])
            rowPosition = self.tablaRefCatResult.rowCount()
            self.tablaRefCatResult.insertRow(rowPosition)
            self.tablaRefCatResult.setItem(rowPosition , 0, QTableWidgetItem(RC14[:14]))


    def buscaRegistroProp(self, idufir):
        # https://geoportal.registradores.org/geoportal/index.html?idVisor=2&idufir=02009000992832
        idufir = '02008000768300'
        return


    '''
    ***************************************************************************/
            PASO 2.Geoprocesos

    *** FUNCIONES ***
    intersectParcelas()
    ***************************************************************************/
    '''

    def intersectParcelas(self):
        layerPARC = 'PARCELAS CATASTRALES'
        # layerLIMI = 'LIMITES DE EXPROPIACION'
        proviEXPRO = self.setVar.value("JCCM_carreteras/EXPprovincia")
        if proviEXPRO is None:
            proviEXPRO = 'ALBACETE'
        layerLIMI = self.setVar.value("JCCM_carreteras/EXPlayerLIMEXPRO")
        if layerLIMI is None:
            layerLIMI = 'LIMITES DE EXPROPIACION AB'
        layerINFEXP = self.setVar.value("JCCM_carreteras/EXPlayerINFOEXPRO")
        if layerINFEXP is None:
            layerINFEXP = 'Informes de Expropiaciones'

        epsg= '25830'
        estiloCAPAINT = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + u'/ZONAS_INVADIDAS.qml')

        #  Salir si no está la capa de PARCELAS CATASTRALES
        layerPARC = 'PARCELAS CATASTRALES'
        if len(QgsProject.instance().mapLayersByName(layerPARC))==0:
            text = u"No hay ninguna capa denominada '"+layerPARC+"' y con un campo 'RC14' que contenga la RefCat"
            text+= u"\n\nEmplear 'Buscador de Parcelas'"
            self.fun.showJCCMessage(text)
            # super(herrExpro_informes_invasionDP, self).reject()
            return

        '''
        if len(QgsProject.instance().mapLayersByName(layerLIMI))==0:
            self.fun.showJCCMessage(u"No está cargada la capa 'LIMITES DE EXPROPIACION'")
            return
        '''
        layer1 = QgsProject.instance().mapLayersByName(layerPARC)[0]
        layer2 = QgsProject.instance().mapLayersByName(layerLIMI)[0]

        mapcanvas = self.iface.mapCanvas()   #Pone el mapa en una variable llamada mapcanvas
        layers = self.iface.mapCanvas().layers()     #Pone la lista de capas en una variable llamada layers
        pselections=[]                  #Declara la lista de polígonos 1
        pmselections=[]                 #Declara la lista de polígonos 2

        # Creamos la capa de resultados
        result = QgsVectorLayer('Polygon?crs=EPSG:'+epsg+
            '&field=EX_NUM:String(13)'+                # AQUI VAN LOS CAMPOS
            '&field=EX_TMUNIC:String(25)'+
            '&field=EX_TEXTINF:String(252)'+
            '&field=EX_SUPEXPR:Real(10,2)'+
            '&field=EX_SUPINF:Real(10,2)'+
            '&field=EX_TIPOINV:String(10)'+
            '&field=CAT_NMSPC:String(25)',
            'Zonas invadidas', 'memory')
        # Establecemos el estilo de la capa
        result.loadNamedStyle(estiloCAPAINT)


        # Metemos todos los campos de las capas LAYER1 y LAYER2
        prov = result.dataProvider()
        result.startEditing()           #Capa de intersecciones
        attributes = []
        fields1 = layer1.fields()       # Cargamos en la capa result los fields de layer1
        for field in fields1:
            attributes.append(QgsField(field.name(),field.type()))
        fields2 = layer2.fields()       # Cargamos en la capa result los fields de layer2
        for field in fields2:
            attributes.append(QgsField(field.name(),field.type()))
        prov.addAttributes(attributes)
        result.updateFields()
        result.commitChanges()


        fields = prov.fields()
        feats = []
        # for w in layer1.getFeatures():      #Cada elemento de la capa 1. Se llamará W
        countW = layer1.selectedFeatureCount()
        featuresW = layer1.getFeatures()
        if countW > 0:
            featuresW = layer1.selectedFeatures()

        # Limpiamos la tabla de resultados
        self.tablaRefCatResult.setRowCount(0);

        countINV = 1
        for w in featuresW:      #Cada elemento de la capa 1. Se llamará W
            RC14 = w["RC14"][:14]
            countS = layer2.selectedFeatureCount()
            featuresS = layer2.getFeatures()
            if countS > 0:
                featuresS = layer2.selectedFeatures()
            tipoINV='NO INVADE'

            for s in featuresS:  #Comprobamos la intersección en cada elemento seleccionado de la capa 2. Se llamará S
                if s.geometry().intersects(w.geometry()): #Comprobamos si S y W intersectan
                    tipoINV = 'INVADE'
                    intersection = s.geometry().intersection(w.geometry())
                    if self.chbRESTOPARC.isChecked():
                        difference = w.geometry().difference(s.geometry())
                    # Agregamos todos los ATRIBUTOS  de LAYER1 y LAYER2
                    TMUNIC = s['TERM_MUNIC']
                    textINF = u'Informe sobre invasión de Dominio Público de la parcela catastral RC %s del T.M de %s'%(RC14,TMUNIC)

                    data = []
                    data.append('INVASION'+str(countINV))   # EX_NUM
                    data.append(TMUNIC)                     # EX_TMUNIC
                    data.append(textINF)                    # EX_TEXTINF
                    data.append(0)                          # EX_SUPEXPR
                    data.append(intersection.area())        # EX_SUPINF
                    data.append(tipoINV)                    # EX_TIPOINV
                    data.append('ES.LOCAL.CP')                  # CAT_NMSPC

                    if self.chbRESTOPARC.isChecked():
                        dataR = []
                        dataR.append(RC14+'-R')                 # EX_NUM
                        dataR.append(TMUNIC)                    # EX_TMUNIC
                        dataR.append('Resto Parcela '+RC14)     # EX_TEXTINF
                        dataR.append(0)                         # EX_SUPEXPR
                        dataR.append(difference.area())         # EX_SUPINF
                        dataR.append('RESTO_PARC')              # EX_TIPOINV
                        dataR.append('ES.SDGC.CP')                 # CAT_NMSPC

                    # Se agregan los atributos de la capa de parcelas
                    for attr in w.attributes():
                        data.append(attr)
                        if self.chbRESTOPARC.isChecked():
                            dataR.append(attr)
                    # Se agregan los atributos de la capa de Limites de DP
                    for attr in s.attributes():
                        data.append(attr)
                        if self.chbRESTOPARC.isChecked():
                            dataR.append(attr)
                    # print data

                    pmselections.append(s['EXPTE1'])  #Get the Name in Attribute Column 0
                    pselections.append(w['RC14'][:14])  #Put those into the Lists

                    # Se agrega la geometría de la interseccion
                    feat = QgsFeature(fields)
                    feat.setGeometry(intersection)
                    feat.setAttributes(data)
                    feats.append(feat)
                    if self.chbRESTOPARC.isChecked():
                        # Se agrega la geometría de la diferencia
                        featR = QgsFeature(fields)
                        featR.setGeometry(difference)
                        featR.setAttributes(dataR)
                        feats.append(featR)

                    # Ponemos los valores del análisis en su fila enla tabla del menú
                    rowPosition = self.tablaRefCatResult.rowCount()
                    self.tablaRefCatResult.insertRow(rowPosition)
                    self.tablaRefCatResult.setItem(rowPosition , 0, QTableWidgetItem(feat["RC14"]))       #feat["name"]
                    self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(feat["EX_TIPOINV"]))
                    self.tablaRefCatResult.setItem(rowPosition , 2, QTableWidgetItem(feat["EXPTE1"]))
                    self.tablaRefCatResult.setItem(rowPosition , 3, QTableWidgetItem(feat["CTRA"]))
                    # self.tablaRefCatResult.setItem(rowPosition , 4, QTableWidgetItem(feat["PKINI"]))
                    # self.tablaRefCatResult.setItem(rowPosition , 5, QTableWidgetItem(feat["PKFIN"]))
                    self.tablaRefCatResult.setItem(rowPosition , 6, QTableWidgetItem(feat["EX_TMUNIC"]))
                    countINV += 1

            if tipoINV=='NO INVADE':
                rowPosition = self.tablaRefCatResult.rowCount()
                self.tablaRefCatResult.insertRow(rowPosition)
                self.tablaRefCatResult.setItem(rowPosition , 0, QTableWidgetItem(RC14))                   #feat["name"]
                self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(tipoINV))
                self.tablaRefCatResult.setItem(rowPosition , 2, QTableWidgetItem(''))
                self.tablaRefCatResult.setItem(rowPosition , 3, QTableWidgetItem(''))
                self.tablaRefCatResult.setItem(rowPosition , 4, QTableWidgetItem(''))
                self.tablaRefCatResult.setItem(rowPosition , 5, QTableWidgetItem(''))
                self.tablaRefCatResult.setItem(rowPosition , 6, QTableWidgetItem(''))
                #rowPosition+=1

        # Se escribe un fichero de resultados
        testfile = open('C:\Temp\IntersectTest.txt', 'w')

        prov.addFeatures(feats)
        QgsProject.instance().addMapLayer(result)
        i=0
        for x in pselections:
            # print "%s" %x
            # print "     intersects %s" %pmselections[i]
            testfile.write(x + ', ' + pmselections[i] + '\n')
            i+=1
        testfile.close()

        # print "TERMINADO"

    def herrExpro_CONFIG(self):
        self.herrExpro_CONFIGdlg_expInvDP = herrExpro_CONFIGdlg_expInvDP(self.iface)
        result = self.herrExpro_CONFIGdlg_expInvDP.exec_()
        return result
        pass




    '''
    ***************************************************************************
            Carga masiva de parcelas (ELIMINAR)
    ***************************************************************************

    def cargaMasiva(self):
        capas_csv = self.fun.getCapasCsv(self.iface)
        if len(capas_csv) == 0:
            self.fun.showJCCMessage('No hay ninguna capa vectorial o tabla con RefCat para cargar')
            return
        self.setFixedSize(750, 410)
        self.btnCargaMasiva.setEnabled(False)
        self.combo_tabla.clear()
        self.combo_tabla.addItems(capas_csv)
        self.combo_tabla.setEditable(False)
        self.combo_tabla.setCurrentIndex(0)


    def actualizarCampos(self):
        layername = self.combo_tabla.currentText()
        if layername == "":
            # self.fun.showJCCMessage("Debes cargar una capa csv en la tabla de contenidos")
            return None
        selected_table = self.fun.getLayerByName(layername)
        fields = selected_table.pendingFields()
        # fields = selected_table.fields()
        # text_fields = []
        # numeric_fields = [""]
        list_fields = ['']
        for field in fields:
            list_fields.append(field.name())

        self.combo_REFCAT.clear()
        self.combo_REFCAT.addItems(list_fields)
        for field in list_fields:
            if field != '':
                self.combo_REFCAT.setCurrentIndex(list_fields.index(field))
                break


    def IrCargaMasiva(self):
        menu = self
        campo_REFCAT = self.combo_REFCAT.currentText()
        layername = self.combo_tabla.currentText()
        selected_table = self.fun.getLayerByName(layername)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        if campo_REFCAT != "" and (selected_table is not None):
            self.obtenerRCFromLayer(selected_table,self.iface,campo_REFCAT,menu)
            QApplication.restoreOverrideCursor()
        else:
            QApplication.restoreOverrideCursor()
            self.fun.showJCCMessage(u'Seleccione una TABLA y un CAMPO')
            return


    def obtenerRCFromLayer(self, layer, iface, campo_REFCAT, menu):
        # print 'EMPEZAMOS A CARGAR LAS RC'
        features = layer.getFeatures()
        numfeat = layer.featureCount()
        listaParcelas = []
        cuentaParcelas = 0
        textMsg = ''
        textMsgINI = 'CARGANDO PARCELAS ...'+'\n'
        self.txeAVISOS.setText(textMsgINI)
        # print 'layer= ',layer.name(), ' campo_REFCAT= ',campo_REFCAT, ' numfeat= ', numfeat
        for feature in features:
            QApplication.processEvents()
            rc = feature[campo_REFCAT]
            if not rc:
                rc = 'NO-PARCELA'
            else:
                # print rc
                point = None
                rc = rc[0:14].upper()
                if len(self.listaRCs.findItems(rc, Qt.MatchExactly)) == 0:
                    # Esto comprueba la existencia de la referencia catastral
                    point_response = self.fun.getPointFromRC(self.iface,rc)
                    if point_response is not None and point_response[0] == "Error":
                        textMsg = rc+ ' '+ point_response[1]
                        self.txeAVISOS.append(textMsg)
                    elif point_response is not None:
                            textMsg = rc.encode("utf-8")+ ' OK'
                            listaParcelas.append(rc)
                            self.listaRCs.addItem(rc)
                            cuentaParcelas += 1
                            self.txeAVISOS.append(textMsg)
                else:
                    textMsg = rc.encode("utf-8")+ ' REPETIDA'
                    self.txeAVISOS.append(textMsg)

            # Se coloca el cursos rl final del mensaje
            cursor = self.txeAVISOS.textCursor()
            cursor.movePosition(QTextCursor.End)
            self.txeAVISOS.setTextCursor(cursor)

        #textMsg += u'   %s de %s RefCat  válidas leídas'%(cuentaParcelas, numfeat)
        textMsg1 = u'   %s de %s RefCat  válidas leídas'%(cuentaParcelas, numfeat)
        #self.txeAVISOS.setText(textMsg)
        self.txeAVISOS.append(textMsg1)


        if cuentaParcelas >0:
            # QApplication.restoreOverrideCursor()
            return listaParcelas
        else:
            self.fun.showJCCMessage(u'No se ha añadido ninguna RefCat de un total de %s registros'%(numfeat))
            # QApplication.restoreOverrideCursor()
            return
    ***************************************************************************
    ***************************************************************************
    ***************************************************************************/
    '''
