# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrCTRAS_CAPAfromCTRAPKS
                                 A QGIS plugin
 jcml_bar
                             -------------------
        begin                : 2016-06-06
        git sha              : $Format:%H$
        copyright            : (C) 2016 by JCCM. Dirección General de Carreteras
        Codigo Original      : Jon Garrido (ALAUDA) - Hasta v QGIS 2.14 - 1.26
        copyright            : (C) 2019 by Agustín Solabre Suárez/DIRECCIÓN GENERAL DE CARRETERAS
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QDialog, QFileDialog
from PyQt5 import uic
# from PyQt4 import QtGui, uic
from qgis.core import Qgis
from qgis.utils import qgsfunction, reloadPlugin, iface
# import qgis.utils

import os
from os.path import basename
from osgeo import ogr, osr
from time import sleep
import timeit

import urllib
import json

from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_CAPAfromCTRAPKS.ui'))


class herrCTRAS_CAPAfromCTRAPKS(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrCTRAS_CAPAfromCTRAPKS, self).__init__(parent)
        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
        self.iface = iface;
        self.fun = Functions()
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.logo.setPixmap(QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))

        capas_csv = self.getCapasCSV()
        self.combo_tabla.clear()
        self.combo_tabla.addItems(capas_csv)
        self.combo_tabla.setEditable(True)
        self.combo_tabla.setCurrentIndex(1)
        self.combo_tabla.currentIndexChanged.connect(self.actualizarCampos) # Revisar esto y tal vez quitar el botón ACTUALIZAR CAMPOS
        self.actualizarCampos()
        
        # --- BOTONES ---
        # self.file_browser.clicked.connect(self.file_browser_clicked)
        # self.button_actualizar.clicked.connect(self.actualizarCampos)
        # self.button_actualizar.setVisible(False)
        self.button_mostrar.clicked.connect(self.mostrarEventos)
        self.RECALC = self.chbRecalcula.clicked.connect(self.cambiatxeRECALCULA)
        
        # self.btnCancelar.clicked.connect(self.cancelar_Calculo)
        # QMetaObject.connectSlotsByName(self)
        self.btnCancelar.hide()
        
        self.destino_button.clicked.connect(self.seleccionar_destino)
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)    
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')
        maxfeat = 0
        self.chbMaxFeat.clicked.connect(self.cambiaMaxFeat)

    
    def seleccionar_destino(self):
        namefile = self.layername.text()
        filename = QFileDialog.getSaveFileName(self, "Guardar archivo de destino", namefile, "*.shp")
        if filename[0] != '':
            self.layername.setText(filename[0])


    def getCapasCSV(self):
        capas_csv = self.fun.getCapasCsv(self.iface)
        return capas_csv

        
    def cambiaMaxFeat(self):
        if self.chbMaxFeat.isChecked():
            self.lneMaxFeat.setEnabled(True)
        else:
            self.lneMaxFeat.setEnabled(False)
        pass
        
        
    def actualizarCampos(self):
        layername = self.combo_tabla.currentText()
        if layername == "":
            # self.fun.showJCCMessage("Debes cargar una capa csv en la tabla de contenidos")
            return None
        selected_table = self.fun.getLayerByName(layername)
        fields = selected_table.fields()
        list_fields = ['']
        for field in fields:
            list_fields.append(field.name())
        
        self.combo_carretera.clear()
        self.combo_carretera.addItems(list_fields)
        for field in list_fields:
            if field != '':
                self.combo_carretera.setCurrentIndex(list_fields.index(field))
                break
            pass
        
        self.combo_pkini.clear()
        self.combo_pkini.addItems(list_fields)
        for field in list_fields:
            if field != '':
                self.combo_pkini.setCurrentIndex(list_fields.index(field))
                break
            pass

        self.combo_pkfin.clear()
        self.combo_pkfin.addItems(list_fields)
        self.combo_disteje.clear()
        self.combo_disteje.addItems(list_fields)
        pass
        
        
    def cambiatxeRECALCULA(self):
        if self.chbRecalcula.isChecked():
            self.lneNomCapaDestino.setEnabled(False)
            self.combo_pkfin.setEnabled(False)
            return False
        else:
            self.lneNomCapaDestino.setEnabled(True)
            self.combo_pkfin.setEnabled(True)
            return True
        pass
        
        
    def mostrarEventos(self):
        menu = self
        campo_carretera = self.combo_carretera.currentText()
        campo_pk_ini = self.combo_pkini.currentText()
        campo_pk_fin = self.combo_pkfin.currentText()
        campo_disteje = self.combo_disteje.currentText()
        layername = self.combo_tabla.currentText()
        selected_table = self.fun.getLayerByName(layername)
        dest_path = self.layername.text()
        dest_name = self.lneNomCapaDestino.text()
        if self.chbMaxFeat.isChecked():
            maxfeat = int(self.lneMaxFeat.text())
        else:
            maxfeat = 0
        progressBar_dlg = self.progressBar
        infolbl = self.lblINFO
        infolbl.setText('INFO: COMENZANDO LECTURA DE ARCHIVO...')
        FactPKINI = self.lneFactPKINI.text()
        FactPKFIN = self.lneFactPKFIN.text()
                
        # Análisis de máximo de elementos
        # numfeat = layer.featureCount()

                
        start = timeit.default_timer()
        if(campo_carretera != "" and campo_pk_ini != ""):
            self.fun.mostraEventosFromCSVLayer(selected_table,self.iface,campo_carretera,campo_pk_ini,campo_pk_fin,campo_disteje,dest_path,progressBar_dlg,infolbl,dest_name,maxfeat,self.RECALC,FactPKINI,FactPKFIN,menu)
                    #mostraEventosFromCSVLayer(self,layer    ,iface     ,campo_carretera,campo_pkini ,campo_pkfin ,campo_disteje,dest_path,progressBar_dlg,infolbl,dest_name,maxfeat,RECALC     ,FactPKINI,FactPKFIN):
        else:
            self.fun.showJCCMessage("Hay que seleccionar una tabla y seleccionar los campos de datos")
            
        stop = timeit.default_timer()
        text = '  --- TERMINADO ---'
        tiempo = 'Tiempo: '+"%0.2f"%(stop - start)+' seg.'
        infolbl.setText(self.lblINFO.text()+text+tiempo)
        self.fun.showJCCMessage(text+'\n\n'+tiempo)
        self.close()
            
    def addCSV(self):
        filename = QFileDialog.getOpenFileName(self, "Cargar archivo csv","", "*.csv")

        if filename != None and filename != "":
            uri = u"file:///" + filename + u"?type=csv&delimiter=;&geomType=none&subsetIndex=no&watchFile=no"
            import os
            name = basename(filename)
            vlayer = QgsVectorLayer(uri, name, "delimitedtext")
            if vlayer.isValid():
                 QgsMapLayerRegistry.instance().addMapLayer(vlayer)
                 self.updateCapasCsv()
            else:
                self.fun.showJCCMessage(u"Falló la carga del archivo. El csv debe tener delimitador de campos ';'")
                
        pass
        
        
    def updateCapasCsv(self):
        try:
            print ("Actualizando combo csvs")
        except:
            pass
        capascsv = self.getCapasCSV()
        self.combo_tabla.clear()
        self.combo_tabla.addItems(capascsv)
        
    def cancelar_Calculo(self):
        self.fun.showJCCMessage(u'Hemos pulsado CANCELAR')
        pass
