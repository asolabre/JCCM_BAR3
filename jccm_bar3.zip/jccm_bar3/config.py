#!/usr/bin/python
# -*- coding: utf-8 -*-
class configuration:
  environment = {
    'EPSG': 25830,
    '01Ambito': 'CASTILLA LA MANCHA - CLM',
    'wfs_carreteras': u'http://geoservicios.castillalamancha.es/arcgis/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/WFSServer?',
    'wfs_carreteras_layer': u'GEO_BTAcalibrada',
    'rest_carreteras': u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?',
    'rest_municipios': u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_Poblaciones_Municipios_WFS/MapServer/0/query?',
    'municipio_text_field': u'Nucleo'
    }
    # 'url_catastro_rc': u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_CPMRC?',
    # 'url_catastro_municipio': u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaMunicipio?'

  catastro_tool ={
    'url_catastro_distancia': u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_RCCOOR_Distancia?',
    'url_catastro_rc':        u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_CPMRC?',
    'url_catastro_RCCOOR':    u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_RCCOOR?',
    'url_catastro_Provincia': u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaProvincia?',
    'url_catastro_municipio': u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaMunicipio?',
    'url_catastro_DNPRC':     u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/Consulta_DNPRC?',
    'url_catastro_DNPPP':     u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/Consulta_DNPPP?',
    'url_catastro_DescGML':   u'http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?',

    'dir_shps': u'//jclm.es/otvu/sc/DAT_CARTOGRAFIA/03_CARTOGRAFIA_ORIGINAL_OFICIAL/DG_CATASTRO/CATASTRO_',
    'year': 2016,
    'dir_estilos_catastro': u'./ESTILOS CAPAS/',
    'pos_toc': 0,
    'capas_urbanas' : [
    { 'capa' : u'CONSTRU.shp' , 'nombre' : u'U-Cons-' , 'estilo' : u'CAT_U_CONSTRU.qml' },
    { 'capa' : u'PARCELA.shp' , 'nombre' : u'U-Par-' , 'estilo' : u'CAT_U_PARCELA.qml' },
    { 'capa' : u'MASA.shp' , 'nombre' : u'U-Pol-' , 'estilo' : u'CAT_U_POLIGONO.qml' }
   ],
    'capas_rusticas' : [
    { 'capa' : u'SUBPARCE.shp' , 'nombre' : u'R-Sub-' , 'estilo' : u'CAT_R_SUBPARCE.qml' },
    { 'capa' : u'MASA.shp' , 'nombre' : u'R-Pol-' , 'estilo' : u'CAT_R_POLIGONO.qml' },
    { 'capa' : u'PARCELA.shp' , 'nombre' : u'R-Par-' , 'estilo' : u'CAT_R_PARCELA.qml' }
   ]
    }
  lrs = {
    'identificador_carretera_carreteras': u'Matricula_Plan',
    'default_log_folder': u'C:/TEMP/',
    'bal_dest_path': u'C:/TEMP/',
    'bal_nom_layer': u'BALIZAS DE CARRETERA',
    'bal_estiloCAPA': u'./ESTILOS CAPAS/BALIZAS DE CARRETERA.qml'
    }
  otros = {
    'carpeta_estilos': u'./ESTILOS CAPAS',
    'fich_config_capas': u'u:/cartografia/datos_Q/QSIG/config/capasQSIG.txt'
    }

  data_internos = {
    'UD_SIGFOMSC': u'U:',
    'DIR_SIGFOMSC': u'//JCLM.ES/INFR/CARRETERAS_SIG',
    'UD_SIGFOMLO': u'Z:',
    'DIR_SIGFOMLO': u'//jclm.es/INFR/AB/SIG_FOMENTO_AB',
    'UD_SIGCTRLO': u'V:',
    'DIR_SIGCTRLO': u'//JCLM.ES/INFR/AB/SIG_CTRAS_AB',
    'UD_CARTOGSC': u'W:',
    'DIR_CARTOGSC': u'//jclm.es/otvu/sc/DAT_CARTOGRAFIA',
    'DIR_GRUPEXPRO': u'Z:/cartografia/datos_Q/Qsig/GRUPOS_CAPAS/',
    'FICH_GRUPEXPRO': u'012 EXPRO PATRIMONIO - CASILLAS_EDIT.qlr',
    'NOM_GRUPEXPRO': u'EXPROPIACIONES B.INMU EDIT',
    'GDB_Geometrias': u'u:/SIGCLM/APPJCCM/Datos/sig_reg_ctras.gdb',
    'GDB_Aforos': u'u:/SIGCLM/APPJCCM/Datos/sig_reg_ctras.gdb'
    }
    
  ficherosCopySeg = {
    u'V:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/00_EXPROPIACIONES COMPLETAS/EXPROPIACIONES_COMPLETAS_AB.gpkg',
    u'V:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/00_EXPROPIACIONES COMPLETAS/EXPROPIACIONES_COMPLETAS_ALBACETE.shp',
    u'V:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/00_EXPROPIACIONES COMPLETAS/INFORMES EXPROPIACIONES.shp',
    u'V:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/00_EXPROPIACIONES COMPLETAS/EXPROPIACIONES_PARCELAS_ALBACETE.shp'
    }
  dstDirCopySeg = u'V:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/00_EXPROPIACIONES COMPLETAS/COPIA_SEGURIDAD/'
  extListCopySeg = {'.gpkg', '.shp', '.shx', '.dbf'}
  
  expropiacion = {
    'EXPprovincia': 'ALBACETE - AB',
    'EXPlayerLIMEXPRO'         : 'LIMITES DE EXPROPIACION AB',
    'EXPlayerLIMEXPROFich'     : 'V:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/00_EXPROPIACIONES COMPLETAS/EXPROPIACIONES_COMPLETAS_ALBACETE.shp',
    'EXPlayerLIMEXPROexptes'   : 'V:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/',
    'EXPlayerINFOEXPRO'        : 'Informes de Expropiaciones',
    'EXPlayerINFOEXPROFich'    : 'V:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/00_EXPROPIACIONES COMPLETAS/INFORMES EXPROPIACIONES.shp',
    'EXPlayerINFOEXPROexptes'  : 'P:/Documentacion/Expropiaciones/',
    'EXPlayerParcPATRI'        : 'CASILLAS P.C. ETRS89',
    'EXPlayerParcPATRIFich'    : 'V:/cartografia/datos/Casillas_PC_OFICINAS_DESTACAMENTOS_ALMACENES/casillas_pc_area_ETRS89.shp',
    'EXPlayerParcPATRIexptes'  : 'V:/cartografia/datos/Casillas_PC_OFICINAS_DESTACAMENTOS_ALMACENES/',
    'EXP_GRUPEXPROfich'        : u'V:/cartografia/datos_Q/Qsig/GRUPOS_CAPAS/012 EXPRO PATRIMONIO - CASILLAS_EDIT.qlr',
    'EXP_GRUPEXPROnom'         : u'EXPROPIACIONES B.INMU EDIT'
    }
    
  expropiacionB = {
    'EXPprovincia': 'ALBACETE - AB',
    'EXPlayerLIMEXPRO'         : 'LIMITES DE EXPROPIACION AB',
    'EXPlayerLIMEXPROFich'     : 'V:/cartografia/datos/EXPROPIACIONES/00_EXPROPIACIONES COMPLETAS/EXPROPIACIONES_COMPLETAS_AB.gpkg',
    'EXPlayerLIMEXPROexptes'   : 'V:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/',
    'EXPlayerINFOEXPRO'        : 'Informes de Expropiaciones',
    'EXPlayerINFOEXPROFich'    : 'V:/cartografia/datos/EXPROPIACIONES/00_EXPROPIACIONES COMPLETAS/EXPROPIACIONES_COMPLETAS_AB.gpkg',
    'EXPlayerINFOEXPROexptes'  : 'P:/Documentacion/Expropiaciones/',
    'EXPlayerParcPATRI'        : 'CASILLAS P.C. ETRS89',
    'EXPlayerParcPATRIFich'    : 'V:/cartografia/datos/Casillas_PC_OFICINAS_DESTACAMENTOS_ALMACENES/casillas_pc_area_ETRS89.shp',
    'EXPlayerParcPATRIexptes'  : 'V:/cartografia/datos/Casillas_PC_OFICINAS_DESTACAMENTOS_ALMACENES/',
    'EXP_GRUPEXPROfich'        : u'Z:/cartografia/datos_Q/Qsig/GRUPOS_CAPAS/012 EXPRO PATRIMONIO - CASILLAS.qlr',
    'EXP_GRUPEXPROnom'         : u'EXPROPIACIONES B.INMU'
    }

  listTIPOEXPTE = [
        'INVASION',
        'NO INVASION',
        'INVASION AEE',
        'NO COLIND.JCCM',
        'REMISION CATASTRAL',
        'ACLAR RECT.CATASTRAL',
        'BIENES PATRIMONIALES',
        'PERMUTA',
        'REVERSION',
        'SIN CLASIFICAR'
        ]
  listINGENIERO = [
        'Agustín Solabre Suárez',
        'José Ignacio Alfaro Molina',
        'L.Antoliano Hernández García'
        ]
  listMARGEN = [
        'Ambas',
        'Izquierda',
        'Derecha'
        ]
  listCORREOELEC = [
        ] 
  listINTERESADO  = [
        'REGISTRO DE LA PROPIEDAD DE YESTE',
        'REGISTRO DE LA PROPIEDAD DE ALCARAZ',
        'REGISTRO DE LA PROPIEDAD DE CHINCHILLA DE MONTE-ARAGÓN',
        'REGISTRO DE LA PROPIEDAD DE VILLARROBLEDO',
        'REGISTRO DE LA PROPIEDAD DE CASAS-IBÁÑEZ',
        'REGISTRO DE LA PROPIEDAD DE HELLÍN',
        'GERENCIA DE CATASTRO'
        ]

    
  max_features = 10
  custom_configuration = u''
