# -*- coding: utf-8 -*-
"""
/***************************************************************************
herrExpro_informes_invasionDP.py
                                 A QGIS plugin

                             -------------------
        begin                : 2019-02-11
        git sha              : $Format:%H$
        Codigo Original     : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWidgets import QDialog, QTableWidgetItem, QApplication
from PyQt5.QtCore import QSettings
from PyQt5 import uic
from qgis.core import QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsFeature, QgsField, QgsExpression, QgsFeatureRequest, QgsGeometry
from qgis.PyQt.QtCore import Qt, QDate


import os
from osgeo import ogr, osr, gdal
from xml.etree import cElementTree as ElementTree
import urllib

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

from .herrExpro_CONFIG_dialog import herrExpro_CONFIGdlg_expInvDP
from .herrExpro_generaGML import herrExpro_generaGML


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_informes_invasionDPdlg.ui'))

tipoCARGA = 'CAPAPAR'
        # tipoCARGA = 'CAPAPAR' # tipoCARGA = 'CAPAPAR' - Carga las parcelas en una capa única
        # tipoCARGA = 'CAPAIND' # tipoCARGA = 'CAPAIND' - Carga las parcelas en capas individuales

current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.environment["EPSG"]
nomLayerINT = 'Zonas invadidas'
layerPARCnom = 'PARCELAS CATASTRALES'

listTIPOEXPTE = current_configuration.listTIPOEXPTE
listINGENIERO = current_configuration.listINGENIERO
listMARGEN = current_configuration.listMARGEN
listCORREOELEC = current_configuration.listCORREOELEC
listINTERESADO = current_configuration.listINTERESADO


class herrExpro_informes_invasionDP(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrExpro_informes_invasionDP, self).__init__(parent)
        self.current_configuration = configuration()
        self.setVar = QSettings()
        self.fun = Functions()
        self.iface = iface;
        self.setupUi(self)

        #######################################################################
        #  Estudiar SI NO ESTÁN LAS VARIABLES DE LIMITES DE EXPROPIACION
        #######################################################################
        proviEXPRO = self.setVar.value("JCCM_carreteras/JCCM_EXPRO/EXPprovincia")
        if proviEXPRO is None:
            # self.proviEXPRO = 'ALBACETE - AB'
            proviEXPRO = self.current_configuration.expropiacion["EXPprovincia"]
        layerLIMInom = self.setVar.value("JCCM_carreteras/JCCM_EXPRO/EXPlayerLIMEXPRO")
        if layerLIMInom is None:
            # layerLIMInom = 'LIMITES DE EXPROPIACION AB'
            layerLIMInom = self.current_configuration.expropiacion["EXPlayerLIMEXPRO"]
        self.layerINFEXPnom = self.setVar.value("JCCM_carreteras/JCCM_EXPRO/EXPlayerINFOEXPRO")
        if self.layerINFEXPnom is None:
            # self.layerINFEXPnom = 'Informes de Expropiaciones'
            self.layerINFEXPnom = self.current_configuration.expropiacion["EXPlayerINFOEXPRO"]

        #  Estudiar SI NO ESTÁ LA CAPA LIMITES DE EXPROPIACION
        if len(QgsProject.instance().mapLayersByName(layerLIMInom))==0:
            text = u"INVESTIGACIÓN DE INVASIÓN DE 'LÍMITES DE EXPROPIACIÓN'\n\nNo están cargadas las capas necesarias"
            text2 = '¿CONFIGURAR?'
            retval = self.fun.showJCCMessageYESNO(text,text2,tittle="JCCM",)

            if retval == 1024:       # Se ha pulsado ACEPTAR
                result = self.herrExpro_CONFIG()
                if result is None:
                    self.close()
                    return
                else:
                    proviEXPRO  = self.setVar.value("JCCM_carreteras/JCCM_EXPRO/EXPprovincia")
                    layerLIMInom   = self.setVar.value("JCCM_carreteras/JCCM_EXPRO/EXPlayerLIMEXPRO")
                    self.layerINFEXPnom = self.setVar.value("JCCM_carreteras/JCCM_EXPRO/EXPlayerINFOEXPRO")

            elif retval == 4194304:    # Se ha pulsado CANCELAR
                # self.reject()
                self.close()
                return


        self.logo.setPixmap(QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.setFixedSize(810, 525)
        self.botonAbajo = 'U'
        # self.btnAbrirAbajo.setArrowType(Qt.UpArrow)
        self.btnAbrirAbajo.setArrowType(Qt.UpArrow)
        self.tabWidget.setCurrentIndex(3)
        self.lblINFOSUP.setText(u'Paso '+self.tabWidget.tabText(self.tabWidget.currentIndex()))
        self.btnANTERIOR.setVisible(1)
        # self.btnANTERIOR.setEnabled(False)
        self.btnSIGUIENTE.setVisible(1)
        self.lblINFOSUP.setVisible(1)

        self.lblCapaLIMEXPRO.setText(u'CAPA LIM.EXPRO: %s'%(layerLIMInom))
        self.lblCapaINFOEXPRO.setText(u'CAPA INFO.EXPRO: %s'%(self.layerINFEXPnom))

        # Control de cambios de TABS
        # self.tabWidget.blockSignals(True)
        self.tabWidget.currentChanged.connect(self.onChange)

        self.btnANTERIOR.clicked.connect(lambda: self.botonAntSig(1))
        self.btnSIGUIENTE.clicked.connect(lambda: self.botonAntSig(2))
        self.btnSelectCapasTRAB.clicked.connect(self.herrExpro_CONFIG)

        self.btnAbrirAbajo.clicked.connect(lambda: self.botonAmpliarAbajo())
        self.lblNOCATASTRO.setVisible(0)

        QApplication.restoreOverrideCursor()

        if configuration.custom_configuration != "":
            #QgsMessageLog.logMessage( "Cargando configuracion personalizada","jccm_bar")
            import imp
            try:
                custom_file = configuration.custom_configuration
                foo = imp.load_source('custom_config', custom_file)
                custom_config =  foo.custom_config()
                self.current_configuration = custom_config
            except:
                #QgsMessageLog.logMessage( "Archivo no encontrado, se carga configuracion por defecto..","jccm_bar")
                pass

        '''
        ***************************************************************************/
                PASO 1.Buscador de parcelas catastrales
                CONTROLES
        ***************************************************************************/
        '''
        # lista_provincias = self.fun.getProvinciasCatastro()
        lista_provincias, lista_cpine = self.fun.getProvinciasCatastro()
        self.combo_provincia.clear()
        if lista_provincias is not None and lista_provincias != 'nocat':
            self.combo_provincia.addItems(lista_provincias)
            lastProvSelect = self.setVar.value("JCCM_carreteras/last/lastProvSelect")
            if lastProvSelect in lista_provincias:
                self.combo_provincia.setCurrentIndex(lista_provincias.index(lastProvSelect))
        else:
            self.lblNOCATASTRO.show()
            return None

        # Se colocan los valores por defecto con el último valor tecleado
        #----------------------------------------------------------------------
        lastRC14Select = self.setVar.value("JCCM_carreteras/last/lastRC14Select")
        self.ref_catastral.setText(lastRC14Select)
        lastNPOLSelect = self.setVar.value("JCCM_carreteras/last/lastNPOLSelect")
        self.poligono.setText(lastNPOLSelect)
        lastNPARSelect = self.setVar.value("JCCM_carreteras/last/lastNPARSelect")
        self.parcela.setText(lastNPARSelect)

        # Controles del buscador catasral que igaul se deben quitar
        self.txeAVISOS.hide()

        self.fun.updateCombos(self) # Actualiza el combo Municipios a los de la Provincia

        self.addParcCatastrales()   # Añade las parcelas catastrales seleccionadas desde fichero si existe

        self.addToListRCButton.clicked.connect(lambda: self.fun.addRCtoListClicked(self))
        self.addToListRusticaButton.clicked.connect(lambda: self.fun.addToListRusticaButtonClicked(self))
        self.zoomYCerrarButton.clicked.connect(lambda: self.cargarParcelas())
        self.quitarItemButton.clicked.connect(lambda: self.fun.quitarSelectedItemsList(self, 'INF'))
        self.limpiarListaButton.clicked.connect(lambda: self.fun.limpiarListaClicked(self))

        self.combo_provincia.currentIndexChanged.connect(lambda: self.fun.updateCombos(self))

        # Acciones con ENTER en textlines
        self.ref_catastral.returnPressed.connect(lambda: self.fun.addRCtoListClicked(self))
        self.parcela.returnPressed.connect(lambda: self.fun.addToListRusticaButtonClicked(self))


        '''
        ***************************************************************************/
                PASO 2.Geoproceso
                CONTROLES
        ***************************************************************************/
        '''
        self.tablaRefCatResult.setColumnWidth(0, 100)    # ANCHO 650
        self.tablaRefCatResult.setColumnWidth(1, 100)
        self.tablaRefCatResult.setColumnWidth(2, 80)
        self.tablaRefCatResult.setColumnWidth(3, 85)
        self.tablaRefCatResult.setColumnWidth(4, 65)
        self.tablaRefCatResult.setColumnWidth(5, 55)
        self.tablaRefCatResult.setColumnWidth(6, 55)
        self.tablaRefCatResult.setColumnWidth(7, 130)

        self.btnRESULTADOS.clicked.connect(lambda: self.intersectParcelas(proviEXPRO, layerPARCnom, layerLIMInom, self.layerINFEXPnom))

        ## IDENTIFICAMOS EL´SIGUIENTE EXPEDIENTE A CREAREXPTE
        dirINFEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerINFOEXPROexptes")
        if dirINFEXPRO is None:
            dirINFEXPRO=configuration().expropiacion["EXPlayerINFOEXPROexptes"]
        self.qleEXPTEINICIO.setText(self.busquedaDirNuevoEXPTE(dirINFEXPRO))

        self.btnASIGNAEXPTE.clicked.connect(self.asignaExptes)
        self.btnRESULTADOS.setEnabled(True)
        self.chbRESTOPARC.setEnabled(True)
        self.btnASIGNAEXPTE.setEnabled(False)
        self.chbASIGNATODOENUNO.setEnabled(False)
        self.chbASIGNATODOENUNO.clicked.connect(self.cambiaASIGNATODOENUNO)
        self.lblINFO.hide()
        self.progressBar.hide()


        '''
        ***************************************************************************/
                PASO 3.CAMBIA ATRIBUTOS
                CONTROLES
        ***************************************************************************/
        '''
        self.gpbDATOSARCHIVO.setEnabled(False)
        self.gpbDATOSDESTINO.setEnabled(False)
        self.gpbPARCELAS.setEnabled(False)
        self.btnCREAEXPTE.setEnabled(False)
        self.btnGENERAGML.setEnabled(False)

        self.spbINFORMES.setMinimum(1)
        self.spbINFORMES.setMaximum(1)
        self.spbINFORMES.valueChanged.connect(lambda: self.colocaAtributosExpte())
        self.EX_ESTAARCHIVADO.hide()    # Se esconden estos controles innecesarios
        self.EX_FECHAARCHIVO.hide()     # Se esconden estos controles innecesarios
        self.btnCREAEXPTE.clicked.connect(lambda: self.creaEXPTE(proviEXPRO, layerLIMInom, self.layerINFEXPnom))
        self.btnGENERAGML.clicked.connect(lambda: self.GENERAGML(self.layerINFEXPnom))
        # self.btnCREAEXPTE.setEnabled(False)
        # self.btnGENERAGML.setEnabled(False)


    '''
    ***************************************************************************/
    ***    FUNCIONES GENÉRICAS     ***
    ***************************************************************************/
    '''

    def onChange(self,i): #changed!
        tabname = self.tabWidget.tabText(i)
        self.lblINFOSUP.setText('Paso '+tabname)
        # print "Actual Tab: %d %s" % (i, tabname)
        pass

    def botonAntSig(self,sentido):
        # Sentido = 1 > ANTERIOR
        # Sentido = 2 > SIGUIENTE
        actIndex = self.tabWidget.currentIndex()
        self.btnANTERIOR.setEnabled(True)
        self.btnSIGUIENTE.setEnabled(True)

        if sentido == 1:
            self.tabWidget.setCurrentIndex(actIndex+1)
        else:
            self.tabWidget.setCurrentIndex(actIndex-1)

        self.lblINFOSUP.setText(u'Paso '+self.tabWidget.tabText(self.tabWidget.currentIndex()))
        self.logo.setVisible(1)
        self.setFixedSize(810, 525)
        self.btnAbrirAbajo.setArrowType(Qt.UpArrow)
        self.botonAbajo = 'U'

    def botonAmpliarAbajo(self):
        if self.botonAbajo == 'D':
            self.logo.setVisible(1)
            self.setFixedSize(810, 525)
            self.btnAbrirAbajo.setArrowType(Qt.UpArrow)
            self.botonAbajo = 'U'
        elif self.botonAbajo == 'U':
            self.logo.setVisible(1)
            self.setFixedSize(810, 75)
            self.btnAbrirAbajo.setArrowType(Qt.DownArrow)
            self.botonAbajo = 'D'

    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()
        self.close()

    '''
    ***************************************************************************/
            PASO 1.Buscador de parcelas catastrales
    ***************************************************************************/
    Esta parte es similar al buscador CATASTRAL de la apP
    Se unifican las funciones para no repetirlas

    *** FUNCIONES ***
    provincia_updated
    updateCombos

    addParcCatastrales
    ***************************************************************************/
    '''

    def cargarParcelas(self):
        self.fun.zoomToCurrentList(False, tipoCARGA, self)
        self.addParcCatastrales()
        pass


    def addParcCatastrales(self):
        layerPARCnom = 'PARCELAS CATASTRALES'

        if len(QgsProject.instance().mapLayersByName(layerPARCnom))==0:
            return

        layerPARC = QgsProject.instance().mapLayersByName(layerPARCnom)[0]

        countlayerPARC = layerPARC.selectedFeatureCount()
        featureslayerPARC = layerPARC.getFeatures()
        if countlayerPARC > 0:
            featureslayerPARC = layerPARC.selectedFeatures()

        for featLayerPARC in featureslayerPARC:      #Cada elemento de la capa PARCELAS. Se llamará featLayerPARC
            RC14 = featLayerPARC["RC14"]
            if len(self.listaRCs.findItems(RC14, Qt.MatchExactly)) == 0:
                self.listaRCs.addItem(RC14[:14])

            flag = False
            # Comprobamos si está ya metida la RC14 en tablaRefCatResult
            for row in range(self.tablaRefCatResult.rowCount()):
                if RC14 == self.tablaRefCatResult.item(row,1).text():
                    flag = True

            if flag == False:
                # Añadimos una fila de análisis
                rowPosition = self.tablaRefCatResult.rowCount()
                self.tablaRefCatResult.insertRow(rowPosition)
                self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(RC14[:14]))


    def buscaRegistroProp(self, idufir):
        # https://geoportal.registradores.org/geoportal/index.html?idVisor=2&idufir=02009000992832
        idufir = '02008000768300'
        return


    '''
    ***************************************************************************/
            PASO 2. Analisis de Resultados

    *** FUNCIONES ***
    intersectParcelas()
    asignaExptes()
    ***************************************************************************/
    '''

    def intersectParcelas(self, proviEXPRO, layerPARCnom, layerLIMInom, layerINFEXPnom):

        QApplication.setOverrideCursor(Qt.WaitCursor)   # Cursor TRABAJANDO

        # Comprobamos si hay parcelas en listaRCs
        if self.listaRCs.count() == 0:
            msg = u'NO HAY PARCELAS CATASTRALES PARA ANALIZAR'
            self.fun.showJCCMessage(u'ANÁLISIS DE INVASIÓN DEL D.P.', msg)
            QApplication.restoreOverrideCursor()
            return

        estiloCAPAINT = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + u'/ZONAS_INVADIDAS.qml')

        #  Salir si no está la capa de PARCELAS CATASTRALES
        if len(QgsProject.instance().mapLayersByName(layerPARCnom))==0:
            text = u"No hay ninguna capa denominada '"+layerPARCnom+"' y con un campo 'RC14' que contenga la RefCat"
            text+= u"\n\nEmplear 'Buscador de Parcelas'"
            self.fun.showJCCMessage(text)
            # super(herrExpro_informes_invasionDP, self).reject()
            QApplication.restoreOverrideCursor()
            return

        self.lblINFO.show()
        self.progressBar.show()
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)    
        self.progressBar.setValue(0)

        layerPARC = QgsProject.instance().mapLayersByName(layerPARCnom)[0] # Capa de Parcelas Catastrales
        layerLIMI = QgsProject.instance().mapLayersByName(layerLIMInom)[0] # Capa de Límites de Expropiación

        mapcanvas = self.iface.mapCanvas()   #Pone el mapa en una variable llamada mapcanvas
        layers = self.iface.mapCanvas().layers()     #Pone la lista de capas en una variable llamada layers
        pselections=[]                  #Declara la lista de polígonos 1
        pmselections=[]                 #Declara la lista de polígonos 2

        # Se borra la capa de 'Zonas invadidas' SI EXISTE
        layerEXIST = QgsProject.instance().mapLayersByName(nomLayerINT)
        if layerEXIST:
            for layer0 in layerEXIST:
                QgsProject.instance().removeMapLayer( layer0.id() )

        # Creamos la capa de resultados
        result = QgsVectorLayer('Polygon?crs=EPSG:'+str(srcVal)+
            '&field=fid:integer'+                # AQUI VAN LOS CAMPOS
            '&field=ex_num:String(20)'+
            '&field=ex_tmunic:String(100)'+
            '&field=ex_textinf:String(252)'+
            '&field=ex_supexpr:Real(10,2)'+
            '&field=ex_supinf:Real(10,2)'+
            '&field=ex_tipoinv:String(50)'+
            # Se crean campos de la BD de Expte de Carreteras
            '&field=ex_margen:String(20)'+
            '&field=ex_registro:String(50)'+
            '&field=ex_fecha:String(50)'+
            '&field=ex_solicitante:String(200)'+
            '&field=ex_interesado:String(200)'+
            '&field=ex_correoelec:String(200)'+
            # Campo de cierre
            '&field=cat_nmspc:String(25)',
            nomLayerINT, 'memory')
        # Establecemos el estilo de la capa
        result.loadNamedStyle(estiloCAPAINT)

        # Metemos todos los campos de las capas layerPARC y layerLIMI
        prov = result.dataProvider()
        result.startEditing()           #Capa de intersecciones
        attributes = []
        fieldsLayerPARC = layerPARC.fields()       # Cargamos en la capa result los fields de layerPARC
        for field in fieldsLayerPARC:
            attributes.append(QgsField(field.name().lower(),field.type()))
        fieldsLayerLIMI = layerLIMI.fields()       # Cargamos en la capa result los fields de layerLIMI
        for field in fieldsLayerLIMI:
            if field.name() == 'fid':
                attributes.append(QgsField((field.name().lower()+'_E'),field.type()))
            else:
                attributes.append(QgsField(field.name().lower(),field.type()))

        prov.addAttributes(attributes)
        result.updateFields()
        result.commitChanges()

        fieldsLayerINT = prov.fields()
        feats = []
        countlayerPARC = layerPARC.selectedFeatureCount()
        featureslayerPARC = layerPARC.getFeatures()
        if countlayerPARC > 0:
            featureslayerPARC = layerPARC.selectedFeatures()
        else:
            countlayerPARC = layerPARC.featureCount()

        # Limpiamos la tabla de resultados
        self.tablaRefCatResult.setRowCount(0);

        # Análisis de invasiones
        countINV = 1
        countParc = 1
        parcINVADIDAS = []

        for featLayerPARC in featureslayerPARC:      #Cada elemento de la capa PARCELAS. Se llamará featLayerPARC
            RC14 = featLayerPARC["RC14"][:14]
            self.lblINFO.setText(u'INFO: ANALIZANDO - '+ RC14 + '  ('+str(countParc)+'/'+str(countlayerPARC)+')')
            # countParc += 1
            # self.progressBar.setValue(100*countParc/countlayerPARC)


            tipoINV='NO INVASION'
            countLayerLIMI = layerLIMI.selectedFeatureCount()
            featuresLayerLIMI = layerLIMI.getFeatures()
            precision = 0.01 # Precisión para obtener el poleOfInaccessibility
            tolmaxSup = 1.00 # Tolerancia en metros cuadrados, bajo la cual se considera NO INVASIÓN

            dataDICT ={}
            for featLayerLIMI in featuresLayerLIMI:  #Comprobamos la intersección en cada elemento seleccionado de la capa LIMEXPRO. Se llamará featLayerLIMI
                if featLayerLIMI.geometry().intersects(featLayerPARC.geometry()):
                    # listTIPOEXPTE = [
                        # 'INVASION',
                        # 'NO INVASION',
                        # 'INVASION AEE',
                        # 'NO COLIND.JCCM',
                        # 'REMISION CATASTRAL',
                        # 'ACLAR RECT.CATASTRAL',
                        # 'BIENES PATRIMONIALES',
                        # 'PERMUTA',
                        # 'REVERSION',
                        # 'SIN CLASIFICAR'
                        # ]

                    #Comprobamos si featLayerLIMI (LIMITES) y featLayerPARC (PARCELAS) intersectan
                    intersection = featLayerLIMI.geometry().intersection(featLayerPARC.geometry())
                    tolmax = float(self.qleTOLINV.text())

                    # Calculamos el polo de inaccesibilidad
                    resultINT = intersection.poleOfInaccessibility(precision)

                    # Calculamos CTRA y PK desde el poleOfInaccessibility
                    # resultCTRA = self.fun.pointToPK(resultINT[0].asPoint(),self.iface,'NO','NO')
                    ctra, pkini, pkfin, distEJE = self.fun.poligToPKINIPKFIN(featLayerPARC.geometry(), self.iface,'NO')
                    # if pkini > 10000: pkini = 0
                    # if pkfin > 10000: pkfin = 0
                    # print ('ctra:', ctra, 'pkini:', pkini, 'pkfin:', pkfin, 'distEJE:', distEJE)

                    # Analizamos la máxima distancia desde el poleOfInaccessibility
                    # print (RC14, 'CIRC-INSERT= ',resultINT[1], 'tolmax= ', tolmax, 'Sup =', format(intersection.area(), '.1f'), 'tolmaxSup= ', tolmaxSup)
                    if resultINT[1] < tolmax or intersection.area() < tolmaxSup :
                        msg = 'La parcela  ' + RC14 + u'\n'
                        msg += 'INVASION con un polígono de '+ str(round(resultINT[1],3)) +u' m. máximo\n\n     SE IGNORA'
                        # self.fun.showJCCMessage('ANÁLISIS DE POLIGONOS INVADIDOS', msg)

                    else:
                        # print (RC14 + ' INVASION')
                        tipoINV = 'INVASION'
                        # Hay que analizar el tipo de DP invadido
                        FUNCIONALI = featLayerLIMI['FUNCIONALI']
                        if FUNCIONALI == "DP" or FUNCIONALI == "CAMINO" or FUNCIONALI == "RESTOS":
                            tipoINV = 'INVASION'
                        elif FUNCIONALI == "ARISTA":
                            tipoINV = 'INVASION AEE'
                        elif FUNCIONALI == "PATRIMONIAL":
                            tipoINV = 'BIENES PATRIMONIALES'
                        elif FUNCIONALI == "DPREV" or FUNCIONALI == "OTRAS" or FUNCIONALI == "REVERTIDO":
                            tipoINV = 'SIN CLASIFICAR'
                        else:
                            tipoINV = 'SIN CLASIFICAR'

                        if tipoINV == 'SIN CLASIFICAR':
                            msg = u'Analizar la parcela %s \n Presenta una invasión %s - %s\n\n- SE RECOMIENDA SU REVISIÓN MANUAL -'%(RC14+'-'+TMUNIC,tipoINV,FUNCIONALI)
                            self.fun.showJCCMessage(u'ANÁLISIS DE INVASIÓN DEL D.P.', msg)
                            pass

                        parcINVADIDAS.append(featLayerPARC['RC14'][:14])

                        # Agregamos todos los ATRIBUTOS  de layerPARC y layerLIMI
                        TMUNIC = featLayerLIMI['TERM_MUNIC']
                        textINF = u'Informe sobre invasión del Dominio Público de la parcela catastral RC %s del T.M de %s'%(RC14,TMUNIC)

                        dataDICT ={
                          "fid"           : 999999999,                            # fid
                          "ex_num"        : tipoINV+str(countINV),                # EX_NUM
                          "ex_tmunic"     : TMUNIC,                               # EX_TMUNIC
                          "ex_textinf"    : textINF,                              # EX_TEXTINF
                          "ex_supexpr"    : 0,                                    # EX_SUPEXPR
                          "ex_supinf"     : format(intersection.area(), '.1f'),   # EX_SUPINF
                          "ex_tipoinv"    : tipoINV,                              # EX_TIPOINV
                          "ex_tipoinv"    : tipoINV,                              # EX_TIPOINV
                          "ex_margen"     : 'Ambas',                              # ex_margen
                          "ex_registro"   : '',                                   # ex_registro
                          "ex_fecha"      : '',                                   # ex_fecha
                          "ex_solicitante": '',                                   # ex_solicitante
                          "ex_interesado" : '',                                   # ex_interesado
                          "ex_correoelec" : '',                                   # ex_correoelec
                          "cat_nmspc"     : 'ES.LOCAL.CP'                         # CAT_NMSPC
                        }
                        '''
                        --- CAMPOS DE BD EXPLOTACIÓN ---
                        EX_NUM,                                         # 00 NUMEXPRO
                        '',                                             # 01 REGISTRO
                        QDate.currentDate(),                            # 02 FECHA          --- VER ESTA ---
                        '',                                             # 03 SOLICITANTE
                        '',                                             # 04 INTERESADO
                        '',                                             # 05 DNI
                        '',                                             # 06 NOMBRE
                        '',                                             # 07 DOMICILIO
                        '',                                             # 08 CODIGOPOST
                        '',                                             # 09 TLFNO
                        '',                                             # 10 POBLACION
                        self.tablaRefCatResult.item(numOrden,4).text(), # 11 CARRETERA
                        self.tablaRefCatResult.item(numOrden,5).text(), # 12 KILOMETRO
                        self.tablaRefCatResult.item(numOrden,6).text(), # 13 KILOMET2
                        'Ambas',                                        # 14 MARGEN
                        '',                                             # 15 OBSERVAPK
                        txtTIPO,                                        # 16 TIPO
                        '',                                             # 17 ARCHIVO
                        '',                                             # 18 IG
                        '',                                             # 19 INGENIERO
                        '',                                             # 20 ADMIN
                        '',                                             # 21 ESTAARCHIVADO
                        '',                                             # 22 FECHAARCHIVO       --- VER ESTA ---
                        self.tablaRefCatResult.item(numOrden,3).text(), # 23 EXPTE_EXPROPIACION
                        '',                                             # 24 EXPTES_RELACIONADOS
                        NOM_TRAMO,                                      # 25 NOMBRE_TRAMO
                        '',                                             # 26 DECR_ACUERDO_RESOLUCION
                        '',                                             # 27 ACTAS_PREVIAS
                        CAT_REMISI,                                     # 28 REMISION_CATASTRAL --- VER ESTA ---
                        '',                                             # 29 NUMORDEN
                        '',                                             # 30 POLIGONO
                        '',                                             # 31 PARCELAS
                        TM,                                             # 32 TM
                        TIPO_EXPEDIENTE,                                # 33 TIPO_EXPEDIENTE
                        QDate.currentDate(),                            # 34 FECHAINFORME        --- VER ESTA ---
                        NOM_PROYEC,                                     # 35 TITULO_EXPROPIACION
                        '',                                             # 36 EX_EXPTE_OBRA_RELACIONADO
                        RC14,                                           # 37 REF_CATASTRAL
                        QDate.currentDate(),                            # 38 FECHA_ULTIMO_TRAMITE --- VER ESTA ---
                        'Entrada Solicitud',                            # 39 TRAMITE_EXPROPIACION
                        ''                                              # 40 CORREOELEC
                        '''

                        # Se agregan los atributos de la capa de PARCELAS
                        for field in fieldsLayerPARC:
                            dataDICT[field.name().lower()] = featLayerPARC[field.name()]

                        # Se agregan los atributos de la capa de LIMITES DE DP
                        for field in fieldsLayerLIMI:
                            if field.name() == 'fid':
                                dataDICT[field.name().lower()+'_E'] = featLayerLIMI['fid']
                            else:
                                dataDICT[field.name().lower()] = featLayerLIMI[field.name()]

                        # Se alteran PKINI, PKFIN y margen
                        # print ('pkini:', pkini, type(pkini), 'pkfin', pkfin, type(pkfin))
                        if ('pkini' in dataDICT) and ((type(pkini) == int) or (type(pkini) == float)): dataDICT['pkini'] = int(pkini*1000)
                        if ('pkfin' in dataDICT) and ((type(pkfin) == int) or (type(pkfin) == float)): dataDICT['pkfin'] = int(pkfin*1000)
                        if distEJE < 0:
                            dataDICT['ex_margen'] = 'Izquierda'
                        else:
                            dataDICT['ex_margen'] = 'Derecha'

                        # for x in dataDICT: print(x,' : ', dataDICT[x])

                        pmselections.append(featLayerLIMI['EXPTE1'])    #Get the Name in Attribute Column 0
                        pselections.append(featLayerPARC['RC14'][:14])  #Put those into the Lists

                        # Se agrega la geometría de la interseccion
                        featINV = QgsFeature(fieldsLayerINT)
                        featINV.setGeometry(intersection)
                        for field in fieldsLayerINT:
                            featINV[field.name()] = dataDICT[field.name()]

                        feats.append(featINV)

                        countINV += 1

            if tipoINV == 'NO INVASION':
                # En Caso de que la parcela sea NO INVASION, hay que agregar la parcela catastral en bruto
                # Agregamos todos los ATRIBUTOS  de layerPARC
                # PROVINC = self.fun.consultaCatastroCodProvtoProvincia(featLayerPARC['DELEGACIO'])
                # TMUNIC = self.fun.consultaCatastroCodMunitoMunicipio(PROVINC, featLayerPARC['MUNICIPIO'])[0]
                TMUNIC = featLayerPARC["NOM_MUNI"]
                textINF = u'Informe sobre NO INVASIÓN del Dominio Público de la parcela catastral RC %s del T.M de %s'%(RC14,TMUNIC)
                centroids = featLayerPARC.geometry().centroid().asPoint()
                ctra, pkini, pkfin, distEJE = self.fun.poligToPKINIPKFIN(featLayerPARC.geometry(), self.iface,'NO')
                # print ('ctra:', ctra, 'pkini:', pkini, 'pkfin:', pkfin, 'distEJE:', distEJE)

                if ctra is None:
                    # tipoINV = 'NO COLIND CTRA JCCM'
                    tipoINV = 'NO COLIND.JCCM'
                    textINF = u'Informe de NO COLINDANCIA A CTRA. DE LA JCCM de la parcela catastral RC %s del T.M de %s'%(RC14,TMUNIC)
                    ctra= 'DESCONOCIDA'
                    pkini = 0
                    pkfin = 0
                    distEJE = 0
                elif ctra[:2] != 'CM':
                    # tipoINV = 'NO COLIND CTRA JCCM'
                    tipoINV = 'NO COLIND CTRA JCCM'
                    textINF = u'Informe de NO COLINDANCIA A CTRA. DE LA JCCM de la parcela catastral RC %s del T.M de %s'%(RC14,TMUNIC)

                dataDICT ={
                  "fid"         : 999999999,                # fid
                  "ex_num"      : tipoINV+str(countINV),    # EX_NUM
                  "ex_tmunic"   : TMUNIC,                   # EX_TMUNIC
                  "ex_textinf"  : textINF,                  # EX_TEXTINF
                  "ex_supexpr"  : 0,                        # EX_SUPEXPR
                  "ex_supinf"   : 0,                        # EX_SUPINF
                  "ex_tipoinv"  : tipoINV,                  # EX_TIPOINV
                  "ex_margen"   : 'Ambas',                  # ex_margen
                  "ex_registro" : '',                       # ex_registro
                  "ex_fecha"    : '',                       # ex_fecha
                  "ex_solicitante": '',                     # ex_solicitante
                  "ex_interesado" : '',                     # ex_interesado
                  "ex_correoelec" : '',                     # ex_correoelec
                  "cat_nmspc"   : 'ES.LOCAL.CP'             # CAT_NMSPC
                }

                # Se agregan los atributos de la capa de PARCELAS
                for field in fieldsLayerPARC:
                    dataDICT[field.name().lower()] = featLayerPARC[field.name()]

                # Se agregan los atributos de la capa de LIMITES DE DP
                for field in fieldsLayerLIMI:
                    if field.name() == 'fid':
                        dataDICT[field.name().lower()+'_E'] = None
                    else:
                        dataDICT[field.name().lower()] = None

                # Se alteran 'ctra' 'pkini' 'pkfin' y margen
                if 'ctra' in dataDICT: dataDICT['ctra'] = ctra
                try:
                    if 'pkini' in dataDICT: dataDICT['pkini'] = int(pkini*1000)
                    if 'pkfin' in dataDICT: dataDICT['pkfin'] = int(pkfin*1000)
                except:
                    if 'pkini' in dataDICT: dataDICT['pkini'] = 0
                    if 'pkfin' in dataDICT: dataDICT['pkfin'] = 0

                if distEJE < 0:
                    dataDICT['ex_margen'] = 'Izquierda'
                else:
                    dataDICT['ex_margen'] = 'Derecha'

                # for x in dataDICT: print(x,' : ', dataDICT[x])

                # Se agrega la geometría completa de la parcela original
                featNOINV = QgsFeature(fieldsLayerINT)
                featNOINV.setGeometry(featLayerPARC.geometry())
                for field in fieldsLayerINT:
                    featNOINV.setAttribute(field.name(), dataDICT[field.name()])

                feats.append(featNOINV)

            # Ponemos los valores del análisis en su fila en la tabla del menú
            rowPosition = self.tablaRefCatResult.rowCount()
            self.tablaRefCatResult.insertRow(rowPosition)
            self.tablaRefCatResult.setItem(rowPosition , 0, QTableWidgetItem(u'EX-2020/XXX-1'))
            self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(dataDICT['rc14']))
            self.tablaRefCatResult.setItem(rowPosition , 2, QTableWidgetItem(dataDICT['ex_tipoinv']))
            self.tablaRefCatResult.setItem(rowPosition , 3, QTableWidgetItem(dataDICT['expte1']))
            self.tablaRefCatResult.setItem(rowPosition , 4, QTableWidgetItem(dataDICT['ctra']))
            self.tablaRefCatResult.setItem(rowPosition , 5, QTableWidgetItem(str(dataDICT['pkini'])))
            self.tablaRefCatResult.setItem(rowPosition , 6, QTableWidgetItem(str(dataDICT['pkfin'])))
            self.tablaRefCatResult.setItem(rowPosition , 7, QTableWidgetItem(dataDICT['ex_tmunic']))

            countParc += 1
            self.progressBar.setValue(100 * countParc/countlayerPARC)

        self.spbINFORMES.setMaximum(self.tablaRefCatResult.rowCount())


        ##  ANÁLISIS DE 'RESTOS'
        # Se deben disolver todos los elementos invadidos en uno solo antes de analizar los restos
        if self.chbRESTOPARC.isChecked():
            geomDissolve = None
            for currentFeature in feats:
                # print ('area parc- '+str(currentFeature.geometry().area()))
                if geomDissolve == None:
                    geomDissolve = currentFeature.geometry()
                else:
                    geomDissolve = geomDissolve.combine( currentFeature.geometry() )

            # Calculamos los restos para cada parcela que invade
            countlayerPARC = layerPARC.selectedFeatureCount()
            featureslayerPARC = layerPARC.getFeatures()
            if countlayerPARC > 0:
                featureslayerPARC = layerPARC.selectedFeatures()
            else:
                countlayerPARC = layerPARC.featureCount()

            for featLayerPARC in featureslayerPARC:
                RC14 = featLayerPARC["RC14"][:14]
                TMUNIC = featLayerPARC["NOM_MUNI"]
                self.lblINFO.setText(u'INFO: CALCULANDO RESTO -  parcela %s'%(RC14))

                if RC14 in parcINVADIDAS:
                    # print ('Diff - '+RC14)
                    difference = featLayerPARC.geometry().difference(geomDissolve)
                    dataDICTR ={
                      "fid"         : 999999999,                        # fid
                      "ex_num"      : RC14+'-R',                        # EX_NUM
                      "ex_tmunic"   : TMUNIC,                           # EX_TMUNIC
                      "ex_textinf"  : 'Resto Parcela '+RC14,            # EX_TEXTINF
                      "ex_supexpr"  : 0,                                # EX_SUPEXPR
                      "ex_supinf"   : format(difference.area(), '.1f'), # EX_SUPINF
                      "ex_tipoinv"  : 'RESTO',                          # EX_TIPOINV
                      "ex_margen"   : '',                               # ex_margen
                      "ex_registro" : '',                               # ex_registro
                      "ex_fecha"    : '',                               # ex_fecha
                      "ex_solicitante": '',                             # ex_solicitante
                      "ex_interesado" : '',                             # ex_interesado
                      "ex_correoelec" : '',                             # ex_correoelec
                      "cat_nmspc"   : 'ES.SDGC.CP'                      # CAT_NMSPC
                    }
                    for field in fieldsLayerPARC:
                        dataDICTR[field.name().lower()] = featLayerPARC[field.name()]

                    # Se agrega la geometría de la diferencia
                    featR = QgsFeature(fieldsLayerINT)
                    featR.setGeometry(difference)
                    for field in fieldsLayerINT:
                        try:
                            featR.setAttribute(field.name(), dataDICTR[field.name()])
                        except:
                            pass

                    feats.append(featR)

        prov.addFeatures(feats)
        result.commitChanges()


        # Se escribe un fichero de resultados
        testfile = open('C:\Temp\IntersectTest.txt', 'w')

        QgsProject.instance().addMapLayer(result)
        i=0
        for x in pselections:
            # print "%s" %x
            # print "     intersects %s" %pmselections[i]
            testfile.write(x + ', ' + pmselections[i] + '\n')
            i+=1
        testfile.close()

        # Desactivamos el botón una vez hechas las intersecciones
        self.btnRESULTADOS.setEnabled(False)
        self.chbRESTOPARC.setEnabled(False)

        # Activamos botones de trabajo
        self.btnASIGNAEXPTE.setEnabled(True)

        if self.tablaRefCatResult.rowCount() > 1:
            self.chbASIGNATODOENUNO.setEnabled(True)
            self.chbASIGNATODOENUNO.setChecked(True)
            self.spbINFORMES.setVisible(1)
        else:
            self.spbINFORMES.setVisible(0)

        # Rellenamos el primer grupo de datos
        self.colocaAtributosExpte()

        self.lblINFO.setText(u'INFO: ANALIZADAS -  %s parcelas'%(countlayerPARC))
        QApplication.restoreOverrideCursor()


    def asignaExptes(self):
        ## IDENTIFICAMOS EL´SIGUIENTE EXPEDIENTE A CREAREXPTE
        ExpteNUM = self.qleEXPTEINICIO.text()

        if self.tablaRefCatResult.rowCount() <= 1:
            self.spbINFORMES.hide()
        else:
            if self.chbASIGNATODOENUNO.isChecked():
                self.spbINFORMES.show()

        # Trasladamos loa valores al panel de ANÁLISIS DE RESULTADOS
        rowNumber = self.tablaRefCatResult.rowCount()
        valSubExpte = 1
        listaExptesInforme = []
        for row in range(rowNumber):
            if not self.chbASIGNATODOENUNO.isChecked():
                ExNumDato = u'EX-'+ ExpteNUM[:4]+ExpteNUM[4:]
                self.tablaRefCatResult.setItem(row , 0, QTableWidgetItem(ExNumDato))
                ExpteNUM = str(int(ExpteNUM)+1)
            else:
                ExNumDato = u'EX-'+ ExpteNUM[:4]+ExpteNUM[4:]+'-'+str(valSubExpte)
                self.tablaRefCatResult.setItem(row , 0, QTableWidgetItem(ExNumDato))
                valSubExpte += 1

            # Poner el valor en la tabla de la capa 'Zonas invadidas'
            RC14 = self.tablaRefCatResult.item(row,1).text()
            Result = self.tablaRefCatResult.item(row,2).text()
            listaExptesInforme.append({ExNumDato, RC14, Result})

            # Meter los datos en la capa 'Zonas Invadidas' modificando los existentes
            layers = QgsProject.instance().mapLayersByName(nomLayerINT)

            vl = layers[0]
            it = vl.getFeatures()

            vl.startEditing()
            expr = QgsExpression( u'"RC14" = \''+RC14+'\'' )
            it = vl.getFeatures( QgsFeatureRequest( expr ) )
            data = []
            for feat in it:
                if feat["EX_TIPOINV"]== 'RESTO':
                    vl.changeAttributeValue(feat.id(), 1, ExNumDato+'-R')
                else:
                    vl.changeAttributeValue(feat.id(), 1, ExNumDato)
                    data = feat.attributes()
            vl.commitChanges()

        # Rellenamos el primer grupo de datos
        self.colocaAtributosExpte()

        # Activamos el panel de datos
        self.gpbDATOSARCHIVO.setEnabled(True)
        self.gpbDATOSDESTINO.setEnabled(True)
        self.gpbPARCELAS.setEnabled(True)
        self.btnCREAEXPTE.setEnabled(True)


    def busquedaDirNuevoEXPTE(self, dirINFEXPRO):
        # Búsqueda de directorio nuevo de expte
        anoLast = 2000
        expteLast = 0
        for subdir1 in self.listdirs(dirINFEXPRO):
            if subdir1[:3] == u'Año' and subdir1[-4:].isnumeric():
                if int(subdir1[-4:]) > anoLast:
                    anoLast = int(subdir1[-4:])
        dirExpteAno = dirINFEXPRO + u'Año_' + str(anoLast)
        for subdir2 in self.listdirs(dirExpteAno):
            if subdir2[:3] == u'EX-' and subdir2[-3:].isnumeric():
                if int(subdir2[-3:]) > expteLast:
                    expteLast = int(subdir2[-3:])
        ExpteNUM = str(anoLast) + self.fun.completarCeros(str(expteLast+1),3)
        return ExpteNUM


    def listdirs(self, path):
        # print (path)
        if os.path.exists(path):
            return [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
        else:
            return ('NO EXISTE DIRECTORIO')


    def cambiaASIGNATODOENUNO(self):
        if self.chbASIGNATODOENUNO.isChecked():
            # self.spbINFORMES.setVisible(False)
            self.spbINFORMES.setMaximum(1)
        else:
            self.spbINFORMES.setMaximum(self.tablaRefCatResult.rowCount())
            self.spbINFORMES.show()


    def herrExpro_CONFIG(self):
        self.herrExpro_CONFIGdlg_expInvDP = herrExpro_CONFIGdlg_expInvDP(self.iface)
        result = self.herrExpro_CONFIGdlg_expInvDP.exec_()
        return result


    '''
    ***************************************************************************/
            PASO 3.Cambiar atributos

    *** FUNCIONES ***
    colocaAtributosExpte()

    ***************************************************************************/
    '''

    def colocaAtributosExpte(self):
        numOrden = self.spbINFORMES.value() -1

        RC14 = self.tablaRefCatResult.item(numOrden,1).text()
        EX_NUM = self.tablaRefCatResult.item(numOrden,0).text()[3:]
        TM = self.tablaRefCatResult.item(numOrden,7).text()
        TIPO_EXPEDIENTE = self.tablaRefCatResult.item(numOrden,2).text()

        # BUSCAR DATOS DE EXPEDIENTE EN capa 'ZONAS INVADIDAS'
        layer = QgsProject.instance().mapLayersByName(nomLayerINT)[0] # Capa de ZONAS INVADIDAS
        features = layer.getFeatures()
        EXPTE_EXPROPIACION = self.tablaRefCatResult.item(numOrden,3).text()
        NOM_TRAMO = u's/d'
        NOM_PROYEC = u's/d'
        CAT_REMISI = u''
        txtTIPO = u'Informe sobre INVASIÓN de Dominio Público de la parcela catastral RC '+RC14+' del T.M de '+ TM
        txtMARGEN = 'Ambas'
        EX_ACTAS_PREVIAS = 'S/D'
        EX_DECR_ACUERDO_RESOLUCION = 'S/D'
        for feat in features:
            fieldNames = []
            for field in feat.fields(): fieldNames.append(field.name())
            # if RC14 == feat["RC14"][:14]:
            if self.tablaRefCatResult.item(numOrden,0).text() == feat["ex_num"]:
                if feat["nom_tramo"]:
                    NOM_TRAMO = feat["nom_tramo"]
                if feat["nom_proyec"]:
                    NOM_PROYEC = feat["nom_proyec"]
                if feat["cat-remisi"]:
                    CAT_REMISI = feat["cat-remisi"]
                if feat["ex_textinf"]:
                    txtTIPO = feat["ex_textinf"]
                if "lee_decr_acue_reso" in fieldNames:
                    EX_DECR_ACUERDO_RESOLUCION = str(feat["lee_decr_acue_reso"])
                if "lee_actas previas"  in fieldNames:
                    EX_ACTAS_PREVIAS = str(feat["lee_actas previas"])

        if self.chbASIGNATODOENUNO.isChecked():
            # Agrupar RCs
            RC14 = ''
            for i in range(self.listaRCs.count()):
                RC14 += self.listaRCs.item(i).text()
                if i < self.listaRCs.count()-2:
                    RC14 += ', '
                if i == self.listaRCs.count()-2:
                    RC14 += ' y '

            # Quitar el numero de orden de expedientes
            EX_NUM = EX_NUM[0:EX_NUM.find('-',3)]

            # Establecer el texto de la SOLICITUD
            txtTIPO = 'Informe sobre posible invasión del Dominio Público de las parcelas catastrales RC '+RC14+' del T.M de '+ TM

            # Analizar Invasiones
            TIPO_EXPEDIENTE = ''
            for row in range(self.tablaRefCatResult.rowCount()):
                if self.tablaRefCatResult.item(row,2).text() == 'INVASION' or TIPO_EXPEDIENTE =='INVASION':
                    TIPO_EXPEDIENTE ='INVASION'
                else:
                    TIPO_EXPEDIENTE = self.tablaRefCatResult.item(row,2).text()
                    pass


        # Se rellenan los combos
            ## ESTO SE DEBE HACER A PARTIR DEL FICHERO DE INFORMES O DE CONFIGURACIÓN

        #destLYR = QgsProject.instance().mapLayersByName(layerINFEXPnom)[0]     # Capa destino INFORMES DE EXPROPIACIONES
        listSOLICITANTE = []

        self.EX_MARGEN.clear()
        self.EX_MARGEN.addItems(listMARGEN)
        self.EX_INGENIERO.clear()
        self.EX_INGENIERO.addItems(listINGENIERO)
        self.EX_TIPO_EXPEDIENTE.clear()
        self.EX_TIPO_EXPEDIENTE.addItems(listTIPOEXPTE)
        self.EX_SOLICITANTE.clear()
        self.EX_SOLICITANTE.addItems(listSOLICITANTE)
        self.EX_INTERESADO.clear()
        self.EX_INTERESADO.addItems(listINTERESADO)


        # Lista completa de valorees
        listaVAL = [
            EX_NUM,                                         # 00 NUMEXPRO
            '',                                             # 01 REGISTRO
            QDate.currentDate(),                            # 02 FECHA          --- VER ESTA ---
            '',                                             # 03 SOLICITANTE
            '',                                             # 04 INTERESADO
            '',                                             # 05 DNI
            '',                                             # 06 NOMBRE
            '',                                             # 07 DOMICILIO
            '',                                             # 08 CODIGOPOST
            '',                                             # 09 TLFNO
            '',                                             # 10 POBLACION
            self.tablaRefCatResult.item(numOrden,4).text(), # 11 CARRETERA
            self.tablaRefCatResult.item(numOrden,5).text(), # 12 KILOMETRO
            self.tablaRefCatResult.item(numOrden,6).text(), # 13 KILOMET2
            txtMARGEN,                                      # 14 MARGEN
            '',                                             # 15 OBSERVAPK
            txtTIPO,                                        # 16 TIPO
            '',                                             # 17 ARCHIVO
            '',                                             # 18 IG
            '',                                             # 19 INGENIERO
            '',                                             # 20 ADMIN
            '',                                             # 21 ESTAARCHIVADO
            '',                                             # 22 FECHAARCHIVO       --- VER ESTA ---
            self.tablaRefCatResult.item(numOrden,3).text(), # 23 EXPTE_EXPROPIACION
            '',                                             # 24 EXPTES_RELACIONADOS
            NOM_TRAMO,                                      # 25 NOMBRE_TRAMO
            EX_DECR_ACUERDO_RESOLUCION,                     # 26 DECR_ACUERDO_RESOLUCION
            EX_ACTAS_PREVIAS,                               # 27 ACTAS_PREVIAS
            CAT_REMISI,                                     # 28 REMISION_CATASTRAL --- VER ESTA ---
            '',                                             # 29 NUMORDEN
            '',                                             # 30 POLIGONO
            '',                                             # 31 PARCELAS
            TM,                                             # 32 TM
            TIPO_EXPEDIENTE,                                # 33 TIPO_EXPEDIENTE
            QDate.currentDate(),                            # 34 FECHAINFORME        --- VER ESTA ---
            NOM_PROYEC,                                     # 35 TITULO_EXPROPIACION
            '',                                             # 36 EX_EXPTE_OBRA_RELACIONADO
            RC14,                                           # 37 REF_CATASTRAL
            QDate.currentDate(),                            # 38 FECHA_ULTIMO_TRAMITE --- VER ESTA ---
            'Entrada Solicitud',                            # 39 TRAMITE_EXPROPIACION
            ''                                              # 40 CORREOELEC
            ]

        # Colocamos valores de la tabla en el cuadro
        # Se rellenan los campos traídos desde el dock de Info Exptes
        self.EX_NUMEXPRO.setText('EX-'+listaVAL[0])         # 00 NUMEXPRO;2020033
        self.EX_REGISTRO.setText(listaVAL[1])               # 01 REGISTRO;79945
        self.EX_FECHA.setDate(QDate.currentDate())          # 02 FECHA; Expte remisión; 01/01/2020
        #               Selector en combo SOLICITANTE       # 03 SOLICITANTE;FRANCISCO MANGANESO HELIO
        self.EX_SOLICITANTE.setCurrentIndex(self.EX_SOLICITANTE.findText(listaVAL[3], Qt.MatchFixedString))
        #               Selector en combo INTERESADO        # 04 INTERESADO;ARTURO SELENIO RUBIDIO
        self.EX_INTERESADO.setCurrentIndex(self.EX_INTERESADO.findText(listaVAL[4], Qt.MatchFixedString))
                                                            # 05 DNI;123456789
                                                            # 06 NOMBRE;HEREDEROS
                                                            # 07 DOMICILIO;C/ ELEMENTOS, 27
                                                            # 08 CODIGOPOST;02630
                                                            # 09 TLFNO;927654321
                                                            # 10 POBLACION;BONETE
        self.EX_CARRETERA.setText(listaVAL[11])             # 11 CARRETERA;CM3209
        self.EX_KILOMETRO.setText(listaVAL[12])             # 12 KILOMETRO;0
        self.EX_KILOMET2.setText(listaVAL[13])              # 13 KILOMET2;16124
        #               Selector en combo MARGEN            # 14 MARGEN;IZQDA
        if self.EX_MARGEN.findText(listaVAL[14], Qt.MatchFixedString) != -1:
            self.EX_MARGEN.setCurrentIndex(self.EX_MARGEN.findText(listaVAL[14], Qt.MatchFixedString))
        else:
            self.EX_MARGEN.addItem(listaVAL[14])
        self.EX_OBSERVAPK.setText(listaVAL[15])             # 15 OBSERVAPK;ESTE ES UN FICHERO DE PRUEBA
        self.EX_TIPO.setText(listaVAL[16])                  # 16 TIPO;Solicitud de comprobación de posible invasión de parcela catastral
                                                            # 17 ARCHIVO;PENDIENTE
                                                            # 18 IG;ASS
        #               Selector en combo INGENIERO         # 19 INGENIERO;Paco Quinto Rodriguez
        if self.EX_INGENIERO.findText(listaVAL[19], Qt.MatchFixedString) != -1:
            self.EX_INGENIERO.setCurrentIndex(self.EX_INGENIERO.findText(listaVAL[19], Qt.MatchFixedString))
        else:
            self.EX_INGENIERO.addItem(listaVAL[19])
        #               Selector en combo ADMIN             # 20 ADMIN;Mónica Aller Tovar
                                                            # 21 ESTAARCHIVADO;FALSO
                                                            # 22 FECHAARCHIVO;02/01/2020
        self.EX_EXPTE_EXPROPIACION.setText(listaVAL[23])    # 23 EXPTE_EXPROPIACION;CN-AB-96/115
        self.EX_EXPTES_RELACIONADOS.setText(listaVAL[24])   # 24 EXPTES_RELACIONADOS;CN-AB-96/115-M
        self.EX_NOMBRE_TRAMO.setText(listaVAL[25])          # 25 NOMBRE_TRAMO;EjeManchuela_Villamalea_A31 (Tramo 2)
        self.EX_DECR_ACUERDO_RESOLUCION.setText(listaVAL[26])# 26 DECR_ACUERDO_RESOLUCION;30-OCTUBRE-06
        self.EX_ACTAS_PREVIAS.setText(listaVAL[27])         # 27 ACTAS_PREVIAS;jun-07
        self.EX_REMISION_CATASTRAL.setText(listaVAL[28])    # 28 REMISION_CATASTRAL;25/03/2019
        self.EX_NUMORDEN.setText(listaVAL[29])              # 29 NUMORDEN;73-131
        self.EX_POLIGONO.setText(listaVAL[30])              # 30 POLIGONO;4-3
        self.EX_PARCELAS.setText(listaVAL[31])              # 31 PARCELAS;583-376
        self.EX_TM.setText(listaVAL[32])                    # 32 TM;BONETE
        #               Selector en combo TIPO_EXPEDIENTE   # 33 TIPO_EXPEDIENTE;NO INVASION
        if self.EX_TIPO_EXPEDIENTE.findText(listaVAL[33], Qt.MatchFixedString) != -1:
            self.EX_TIPO_EXPEDIENTE.setCurrentIndex(self.EX_TIPO_EXPEDIENTE.findText(listaVAL[33], Qt.MatchFixedString))
        else:
            self.EX_TIPO_EXPEDIENTE.addItem(listaVAL[33])
                                                            # 34 FECHAINFORME;02/01/2020
        self.EX_TITULO_EXPROPIACION.setText(listaVAL[35])   # 35 TITULO_EXPROPIACION;ACONDICIONAMIENTO CTRA B-11 (CM-3209), P.K. 0 AL 16,124. MONTEALEGRE-BONETE-ESTACION DE BONETE
                                                            # 36 EX_EXPTE_OBRA_RELACIONADO;
        self.EX_REF_CATASTRAL.setText(listaVAL[37])         # 37 REF_CATASTRAL;400016BWJ9140S
        self.EX_FECHA_ULTIMO_TRAMITE.setDate(QDate.currentDate()) # 38 FECHA_ULTIMO_TRAMITE;04/09/2018
        self.EX_TRAMITE_EXPROPIACION.setText(listaVAL[39])  # 39 TRAMITE_EXPROPIACION;ARCHIVADO
        self.EX_CORREOELEC.setText(listaVAL[40])            # 40 CORREOELEC;COSA@VAINA.ES


    def creaEXPTE(self, proviEXPRO, layerLIMInom, layerINFEXPnom):
        # Se crea el directorio y el fichero TXT del expediente
        resul = self.fun.creaEXPTE(self)
        if resul == 'ERROR':
            return

        self.dirExpte = resul

        # Metemos los valores del menú al fichero de invasiones
        layers = QgsProject.instance().mapLayersByName(nomLayerINT)

        vl = layers[0]
        it = vl.getFeatures()

        vl.startEditing()

        rowNumber = self.tablaRefCatResult.rowCount()
        valSubExpte = 1
        listaExptesInforme = []
        for row in range(rowNumber):
            # Poner el valor en la tabla de la capa 'Zonas invadidas'
            RC14 = self.tablaRefCatResult.item(row,1).text()

            expr = QgsExpression( u'"RC14" = \''+RC14+'\'' )
            it = vl.getFeatures( QgsFeatureRequest( expr ) )
            data = []
            for feat in it:
                ## AQUÍ METEMOS LOS VALORES DESDE EL MENÚ
                VALENMENU = 's/d'
                vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_registro'), self.EX_REGISTRO.text())
                vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_fecha'), self.EX_FECHA.date().toString('dd/MM/yyyy'))
                vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_solicitante'), self.EX_SOLICITANTE.currentText())
                vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_interesado'), self.EX_INTERESADO.currentText())
                vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_correoelec'), self.EX_CORREOELEC.toPlainText())

        vl.commitChanges()

        # Se copian los elementos de ZONAS INVADIDAS a INFORMES DE EXPROPIACIONES
        sourceLYR = QgsProject.instance().mapLayersByName(nomLayerINT)[0]   # Capa origen ZONAS INVADIDAS
        destLYR = QgsProject.instance().mapLayersByName(self.layerINFEXPnom)[0]     # Capa destino INFORMES DE EXPROPIACIONES
        pr = destLYR.dataProvider()
        destLYR.startEditing()

        # Obtenemos el máximo valor de fid de la capa INFORMES DE EXPROPIACIONES
        values = []
        for feat in destLYR.getFeatures():
           attrs = feat.attributes()
           values.append(attrs[0])
        newIndex = max(values) + 1

        for feature in sourceLYR.getFeatures():
            fet = QgsFeature(destLYR.fields())
            fet.setGeometry(  feature.geometry())
            for field in destLYR.fields():
                if field.name() == 'fid':
                    fet.setAttribute('fid', newIndex)
                    newIndex += 1
                    continue
                if sourceLYR.fields().indexFromName(field.name()) != -1:
                    fet.setAttribute(field.name(), feature[field.name()])
            pr.addFeatures( [ fet ] )

        destLYR.updateExtents()
        destLYR.commitChanges()
        # PROBLEMAS EN LOS CAMPOS
            # fid:      Se debe asignar el último de la capa
            # ex_num:   Se debe estudiar si poner / o no

        valTM = self.EX_TM.text().replace(', ', '_')
        valTM = valTM.replace(' y ', '_')
        self.gml_nomCAPA = self.EX_NUMEXPRO.text()+ '_'+valTM
        self.gml_salida_file = self.dirExpte

        self.btnGENERAGML.setEnabled(True)


    def GENERAGML(self, layerINFEXPnom):
        EX_NUMEXPROval = self.EX_NUMEXPRO.text()
        msg = u'Creamos el GML desde Capa %s - NºEXPTE %s '%(self.layerINFEXPnom, EX_NUMEXPROval)
        self.fun.showJCCMessage(u'CREACIÓN DEL GML', msg)

        # gml_salida_file= self.lneGMLsalida.text()
        # gmlDir, gmlFilExtName = os.path.split(gml_salida_file)
        # gmlFilName, gmlExt = os.path.splitext(gmlFilExtName)
        # nomCAPA = str(gmlFilName)

        # layer_origen = self.layerINFEXPnom
        layer_origen = QgsProject.instance().mapLayersByName(self.layerINFEXPnom)
        self.gml_salida_file = self.dirExpte+'/'+self.gml_nomCAPA+'.gml'
        self.fun.crea_gmlfile(layer_origen, self.gml_nomCAPA, self.gml_salida_file, '25830', '')

        msg = u'Creado el GML desde Capa %s - NºEXPTE %s \n%s'%(self.layerINFEXPnom, EX_NUMEXPROval, self.gml_salida_file)
        self.fun.showJCCMessage(u'CREACIÓN DEL GML', msg)
        pass


