﻿# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           PK_maptool.py
Purpose:

        --------------------------------------------------------------------
        begin                : 2019-09-03
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

# from qgis.PyQt.QtGui import QIcon, QColor
# from qgis.PyQt.QtCore import Qt, QSettings, QTranslator, QCoreApplication
# from qgis.PyQt.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu

from PyQt5.QtGui import QIcon, QColor, QCursor
from PyQt5.QtCore import QVariant, Qt, QSettings, QTranslator, QCoreApplication
from PyQt5.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu

from qgis.gui import QgsMapTool,QgsVertexMarker
from qgis.core import QgsProject, QgsVectorLayer, QgsField, QgsFeature, QgsGeometry

from qgis.utils import iface
    
# SE CARGAN LAS LIBRERÍAS CON CLASES A CASCOPORRO
# from qgis.PyQt.QtGui import *
# from qgis.PyQt.QtCore import *
# from qgis.PyQt.QtWidgets import *
# from qgis.PyQt.QtXml import *
# from qgis.gui import *              # https://qgis.org/pyqgis/3.0/core/index.html
# from qgis.core import *             # https://qgis.org/pyqgis/3.0/gui/index.html

# from PyQt4.QtGui import *
# from PyQt4.QtCore import *
# from qgis.core import *

# import qgis.utils
# from qgis.core import QgsSpatialIndex, QgsFeature, QgsPoint, QgsFeatureRequest, QgsGeometry

import os, glob, codecs

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .PK_info_dialog import Form_PK_info
from .PK_balizas_carretera import balizas_carreteraDialog

current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.environment["EPSG"]
dest_path = current_configuration.lrs["bal_dest_path"]
nom_layer = current_configuration.lrs["bal_nom_layer"]
estiloCAPA = os.path.join(os.path.dirname(__file__), current_configuration.lrs["bal_estiloCAPA"])

dest_path = 'en memoria'


class PkTool(QgsMapTool):   
    def __init__(self,canvas,api_rest_url,iface,action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas    
        self.api_rest_url = api_rest_url
        self.fun = Functions()
        cursor = QCursor()
        cursor.setShape(Qt.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        

    def canvasReleaseEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.getPointPK(point,self.iface)
        pass

        
    def getPointPK(self,point,iface):
        carretera_pk = self.fun.pointToPK(point,iface,pintar='SI', no9000='NO')
        
        if carretera_pk is not None:
            MuniProv = self.fun.getJCCMMuniProv(carretera_pk[7], self.iface, pintar='NO')
            # MuniProv = '---CUALQUIERA---'
            geometry = carretera_pk[8]
            
            # Se quita la llamada al cuadro de diálogo desde aquí
            # self.dlgForm_PK_info = Form_PK_info(iface.mapCanvas(), iface, geometry)
            
            # Zmdt = self.fun.Zmdt(carretera_pk[7], self.iface, pintar='NO')
            Zmdt = 0
            atributos = carretera_pk[4]
            # longGeom = carretera_pk[8].length()

            self.PK_info = Form_PK_info(self, self.iface.mapCanvas(), carretera_pk)
            
            self.PK_info.Matricula_plan.setText(atributos['Matricula_Plan'])
            self.PK_info.pk_pinchado.setText(self.fun.mostrarPK(carretera_pk[1],2))
            self.PK_info.distEje.setText(str(round(carretera_pk[5],2)))
            self.PK_info.acimEje.setText(str(round(carretera_pk[6],4)))
            self.PK_info.cotaEje.setText(str(round(Zmdt,3)))
            self.PK_info.Titularidad.setText(atributos['Titularidad'])
            self.PK_info.Funcionalidad.setText(atributos['Funcionalidad'])
            # self.PK_info.Provincia.setText(atributos['Provincia'])
            self.PK_info.Provincia.setText(MuniProv[1])
            self.PK_info.tmunicipal.setText(MuniProv[0])
            self.PK_info.Idmatricula.setText(" (Idmat:" + str(atributos['idMatricula']) + ")")
            self.PK_info.FuenteDatos.setText('FUENTE: geoservicios web')
            self.PK_info.Denominacion.setText(atributos['Denominacion'])
            self.PK_info.PkINI.setText(self.fun.mostrarPK(atributos['PkINI'],2))
            self.PK_info.PkFin.setText(self.fun.mostrarPK(atributos['PkFin'],2))
            self.PK_info.Origen.setText(atributos['Origen'])
            self.PK_info.Destino.setText(atributos['Destino'])
            self.PK_info.Longitud.setText(str(round(atributos['Longitud'],2)) + " m.")
            self.PK_info.Long_Km.setText(str(round(atributos['Long_Km'],3)) + " Km.")
            self.PK_info.Long_Geom.setText(str(round(atributos['Shape.STLength()'],2)) + " m.")
            # self.PK_info.Long_Geom.setText(str(round(longGeom,2)) + " m.")      # Longitud del elemento
            self.PK_info.Long_FIN_INI.setText(str(round((atributos['PkFin']-atributos['PkINI'])*1000,2)) + " m.")
            self.PK_info.Tipologia_DobleC.setText(atributos['Tipologia_DobleC'])
            self.PK_info.Tipologia_UnaC.setText(atributos['Tipologia_UnaC'])
            self.PK_info.idOrdenCtra.setText(str(atributos['idOrdenCtra']))
            self.PK_info.Matricula.setText(str(atributos['Matricula']))
            self.PK_info.Pk.setText(str(round(carretera_pk[1],2)))
            self.PK_info.XE.setText(str(round(carretera_pk[7][0],2)))
            self.PK_info.YE.setText(str(round(carretera_pk[7][1],2)))
            self.PK_info.ZE.setText(str(round(Zmdt,3)))
            self.PK_info.XP.setText(str(round(point[0],2)))
            self.PK_info.YP.setText(str(round(point[1],2)))

            result = self.PK_info.exec_()

        else:
            message = u"--- Se debe aproximar más a una carretera ---"
            self.fun.showJCCMessage( message,'','Identificador de Carreteras' )

        pass

   
        
class PkBalizaTool(QgsMapTool):

    def __init__(self,canvas,api_rest_url,iface,action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas    
        self.api_rest_url = api_rest_url
        self.fun = Functions()
        cursor = QCursor()
        cursor.setShape(Qt.CrossCursor)
        
        # POSIBLE SOLUCIOB DE SNAPPING
        # for item in QgsMapLayerRegistry.instance().mapLayers().values():
            # QgsProject.instance().setSnapSettingsForLayer(item.id(), False, 2, 0, 2, True)
        
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        self.dlgBalizaPK = balizas_carreteraDialog(iface)
     

    def canvasReleaseEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        
        QApplication.setOverrideCursor(Qt.WaitCursor)
        layerAct = self.iface.activeLayer()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        # print self.snap(layerAct, point, QgsSnapper.SnapToSegment, 10)

        # print "map position", point

        self.getBalizaPK(point,self.iface)

        pass


    def getBalizaPK(self,point,iface):      
        if dest_path == 'en memoria':
            dest = 'memory'
        else:
            # dest = os.path.splitext(dest_path) + os.path.splitext( nom_layer.replace(' ', '_') ) + ".shp"
            dest = dest_path + nom_layer.replace(' ', '_') + ".shp"
        # print dest
        
        tipo_layer= "point"
        # src= "crs=epsg:25830"
        src= "crs=epsg:"+str(srcVal)
        
        # Comprobamos si existe la capa
        # layerEXIST = QgsMapLayerRegistry.instance().mapLayersByName(nom_layer)
        layerEXIST = QgsProject.instance().mapLayersByName(nom_layer)

        '''
        if not layerEXIST:
            # CREACIÓN DE LA CAPA
            if dest == 'memory':
                vl = QgsVectorLayer(tipo_layer+'?'+src, nom_layer, dest)
            else:
                vl = QgsVectorLayer(dest+'|'+tipo_layer+'?'+src, nom_layer, "ogr")
            pr = vl.dataProvider()
            vl.startEditing()
        '''
        if not layerEXIST or layerEXIST[0].featureCount() == 0:
            if layerEXIST and layerEXIST[0].featureCount() == 0:
                vl = layerEXIST[0]        
                # QgsMapLayerRegistry.instance().removeMapLayer( vl.id() )
                QgsProject.instance().removeMapLayer( vl.id() )
                
            # CREACIÓN DE LA CAPA
            if dest == 'memory':
                vl = QgsVectorLayer(tipo_layer+'?'+src, nom_layer, dest)
                # qgis.utils.iface.messageBar().clearWidgets()
                # vl.setCrs(QgsCoordinateReferenceSystem(epsg, QgsCoordinateReferenceSystem.EpsgCrsId))
            else:
                print (dest)
                if not os.path.isfile(dest):
                    print (u'NO EXISTE %s - HAY QUE CREARLO'%(dest))
                vl = QgsVectorLayer(dest+'|'+tipo_layer+'?'+crs, nom_layer, "ogr")
            pr = vl.dataProvider()
            vl.startEditing()

            # AÑADIMOS LOS CAMPOS
            pr.addAttributes( [ QgsField("CTRA", QVariant.String),
                            QgsField("PK", QVariant.Double),
                            QgsField("CTRA1",  QVariant.String),
                            QgsField("idMat", QVariant.Int),
                            QgsField("DIST", QVariant.Double),
                            QgsField("ACIM", QVariant.Double),
                            QgsField("XE", QVariant.Double),
                            QgsField("YE", QVariant.Double),
                            QgsField("ZE", QVariant.Double),
                            QgsField("XP", QVariant.Double),
                            QgsField("YP", QVariant.Double),
                            QgsField("ZP", QVariant.Double),
                            QgsField("DAT1", QVariant.String),
                            QgsField("DAT2", QVariant.String) ] )

            vl.updateFields()
            
            # Añade la capa a la TOC
            # QgsMapLayerRegistry.instance().addMapLayer(vl)
            QgsProject.instance().addMapLayer(vl)
            
            # Establecemos el estilo de la capa
            vl.loadNamedStyle(estiloCAPA)
            #print estiloCAPA


            # Commit changes
            vl.commitChanges()
            # vl.startEditing()
        else:
            vl = layerEXIST[0]
            # vl.startEditing()

        # Ponemos la capa arriba
        root = QgsProject.instance().layerTreeRoot()   
        myvl = root.findLayer(vl.id())
        myvlclone = myvl.clone()
        parent = myvl.parent()
        root.insertChildNode(0, myvlclone)
        parent.removeChildNode(myvl)

        # Hacemos la capa visible  
        # qgis.utils.iface.legendInterface().setLayerVisible(vl, True)  
        # QgsProject.instance().layerTreeRoot().setLayerVisible(vl, True)   
        QgsProject.instance().layerTreeRoot().findLayer(vl.id()).setItemVisibilityChecked(True)

        # carretera_pk = self.fun.pointToPK(point,iface,pintar='NO')
        carretera_pk = self.fun.pointToPK(point,iface,pintar='NO', no9000='SI')
        
        if carretera_pk is not None:
            ZE = self.fun.Zmdt([carretera_pk[7][0],carretera_pk[7][1]],iface,pintar='NO')
            ZP = self.fun.Zmdt(point,iface,pintar='NO')
            atributos = carretera_pk[4]
            
            listaVALORES = [atributos['Matricula'],
                            self.fun.mostrarPK(carretera_pk[1],2),
                            atributos['Matricula_Plan'],
                            str(atributos['idMatricula']),
                            str(round(carretera_pk[5],2)),
                            str(round(carretera_pk[6],4)),
                            str(round(carretera_pk[7][0],2)),
                            str(round(carretera_pk[7][1],2)),
                            str(round(ZE,3)),
                            str(round(point[0],2)),
                            str(round(point[1],2)),
                            str(round(ZP,3))
                            ]
            
            # Se lanza el cuadro de diálogo de la baliza
            result = self.rundialogBalizaPK(listaVALORES)
            
            # print 'result ',result
            if (result=='CANCEL'):
                QApplication.restoreOverrideCursor()
                vl.commitChanges()
                return
            else:
                vl.startEditing()

            if (result[14]=='ptoEJE'):
                distEJE=0
            else:
                distEJE=carretera_pk[5]

            attr = [atributos['Matricula'],     #Dato 0, Matricula
                    carretera_pk[1],            #Dato 1, Pk
                    atributos['Matricula_Plan'],#Dato 2, Matricula_Plan
                    atributos['idMatricula'],   #Dato 3, idMatricula
                    # carretera_pk[5],          
                    distEJE,                    #Dato 4, Dist Eje
                    carretera_pk[6],            #Dato 5, Acimut
                    carretera_pk[7][0],         #Dato 6, XE
                    carretera_pk[7][1],         #Dato 7, YE
                    str(round(ZE,3)),           #Dato 8, ZE
                    point[0],                   #Dato 9, XP
                    point[1],                   #Dato10, YP
                    str(round(ZP,3)),           #Dato11, ZP
                    result[12],                 #Dato12, DATO1
                    result[13]                  #Dato13, DATO2
                    ]         
            
            QApplication.restoreOverrideCursor()
            
            # Añadimos la geometría
            feat = QgsFeature()
            if (result[14]=='ptoEJE'):
                # feat.setGeometry(QgsGeometry.fromPoint(carretera_pk[7]))
                feat.setGeometry(QgsGeometry.fromPointXY(carretera_pk[7]))
            else: 
                # feat.setGeometry(QgsGeometry.fromPoint(point))
                feat.setGeometry(QgsGeometry.fromPointXY(point))
            # Añadimos los atributos
            # attr =[atributos['Matricula'], carretera_pk[1], atributos['Matricula_Plan'], atributos['idMatricula'], carretera_pk[5], carretera_pk[6], carretera_pk[7][0], carretera_pk[7][1], point[0], point[1], '', '']
            feat.setAttributes(attr)
            vl.addFeature(feat)         

            vl.commitChanges()

        else:
            QApplication.restoreOverrideCursor()
            message = u"--- Se debe aproximar más a una carretera ---"
            self.fun.showJCCMessage( message,'','Balizador de Carreteras' )

            pass

        pass
        
        
    def rundialogBalizaPK(self,listaVALORES):
        
        self.dlgBalizaPK.Matricula.setText(listaVALORES[0])
        self.dlgBalizaPK.PK.setText(listaVALORES[1])
        self.dlgBalizaPK.Matricula_Plan.setText(listaVALORES[2])
        self.dlgBalizaPK.idMatricula.setText(listaVALORES[3])
        self.dlgBalizaPK.DIST.setText(listaVALORES[4])
        self.dlgBalizaPK.ACIM.setText(listaVALORES[5])
        self.dlgBalizaPK.XE.setText(listaVALORES[6])
        self.dlgBalizaPK.YE.setText(listaVALORES[7])
        self.dlgBalizaPK.ZE.setText(listaVALORES[8])
        self.dlgBalizaPK.XP.setText(listaVALORES[9])
        self.dlgBalizaPK.YP.setText(listaVALORES[10])
        self.dlgBalizaPK.ZP.setText(listaVALORES[11])
        # self.dlgBalizaPK.DAT1.setText(listaVALORES[12])
        # self.dlgBalizaPK.DAT2.setText(listaVALORES[13])
        
        QApplication.restoreOverrideCursor()
        result = self.dlgBalizaPK.exec_()

        # ANALIZAMOS LOS RADIOBUTTON
        if self.dlgBalizaPK.qrbPTOEJE.isChecked():
            tipoPUN = 'ptoEJE'
        if self.dlgBalizaPK.qrbPTOPIN.isChecked():
            tipoPUN = 'ptoPIN'          

        # print 'result ',result
        
        if result != 0:
            return [self.dlgBalizaPK.Matricula.text(),
                    self.dlgBalizaPK.PK.text(),
                    self.dlgBalizaPK.Matricula_Plan.text(),
                    self.dlgBalizaPK.idMatricula.text(),
                    self.dlgBalizaPK.DIST.text(),
                    self.dlgBalizaPK.ACIM.text(),
                    self.dlgBalizaPK.XE.text(),
                    self.dlgBalizaPK.YE.text(),
                    self.dlgBalizaPK.ZE.text(),
                    self.dlgBalizaPK.XP.text(),
                    self.dlgBalizaPK.YP.text(),
                    self.dlgBalizaPK.ZP.text(),
                    self.dlgBalizaPK.DAT1.text(),
                    self.dlgBalizaPK.DAT2.text(),
                    tipoPUN]
        else:
            return 'CANCEL'
            pass

