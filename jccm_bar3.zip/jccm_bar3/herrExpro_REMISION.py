# -*- coding: utf-8 -*-
"""
/***************************************************************************
herrExpro_REMISION.py
                                 A QGIS plugin

                             -------------------
        begin                : 2020-05-23
        git sha              : $Format:%H$
        Codigo Original     : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt5.QtGui import QIcon
# from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWidgets import QDialog
# from PyQt5.QtWidgets import QDialog, QTableWidgetItem, QApplication
from PyQt5.QtCore import QSettings
from PyQt5 import uic
# from qgis.core import QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsFeature, QgsField, QgsExpression, QgsFeatureRequest, QgsGeometry
from qgis.PyQt.QtCore import Qt, QDate

import os
import datetime
import time
import codecs

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_infoexptes_REMISION.ui'))

# VARIABLES
srcVal = configuration().environment["EPSG"]
listINGENIERO = [
    'Agustín Solabre Suárez',
    'José Ignacio Alfaro Molina',
    'L.Antoliano Hernández García'
    ]
listMARGEN = [
    'Ambas',
    'Izquierda',
    'Derecha'
    ]
listCORREOELEC = [
    ]


class herrExpro_REMISION(QDialog, FORM_CLASS):
    def __init__(self, iface, listaVAL, parent=None):
        """Constructor."""
        super(herrExpro_REMISION, self).__init__(parent)
        self.current_configuration = configuration()
        self.setVar = QSettings()
        self.fun = Functions()
        self.iface = iface;
        self.setupUi(self)
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))

        # Acciones de los botones
        self.rellenaCamposFORM(listaVAL)
        self.btnCANCELA.clicked.connect(self.cancela)
        # self.btnMODIFICADATOS.clicked.connect(self.modificaDatosCAPA)
        self.btnCREAEXPTE.clicked.connect(lambda: self.creaEXPTEyCLOSE(self))
        # self.btnCREAEXPTE.clicked.connect(lambda: self.fun.creaEXPTE(self))


    def creaEXPTEyCLOSE(self, menu):
        self.fun.creaEXPTE(self)
        self.close()
    

    def rellenaCamposFORM(self, listaVAL):
        # Se rellenan los combos
            ## ESTO SE DEBE HACER A PARTIR DEL FICHERO DE INFORMES O DE CONFIGURACIÓN
        self.EX_MARGEN.clear()
        self.EX_MARGEN.addItems(listMARGEN)
        self.EX_INGENIERO.clear()
        self.EX_INGENIERO.addItems(listINGENIERO)
            
        # Se rellenan los campos traídos desde el dock de Info Exptes
        self.EX_NUMEXPRO.setText('EX-'+listaVAL[0])         # 00 NUMEXPRO;2020033
        self.EX_REGISTRO.setText(listaVAL[1])               # 01 REGISTRO;79945
        self.EX_FECHA.setDate(QDate.currentDate())          # 02 FECHA; Expte remisión; 01/01/2020
        self.EX_SOLICITANTE.setText(listaVAL[3])            # 03 SOLICITANTE;FRANCISCO MANGANESO HELIO
        self.EX_INTERESADO.setText(listaVAL[4])             # 04 INTERESADO;ARTURO SELENIO RUBIDIO
                                                            # 05 DNI;123456789
                                                            # 06 NOMBRE;HEREDEROS
                                                            # 07 DOMICILIO;C/ ELEMENTOS, 27
                                                            # 08 CODIGOPOST;02630
                                                            # 09 TLFNO;927654321
                                                            # 10 POBLACION;BONETE
        self.EX_CARRETERA.setText(listaVAL[11])             # 11 CARRETERA;CM3209
        self.EX_KILOMETRO.setText(listaVAL[12])             # 12 KILOMETRO;0
        self.EX_KILOMET2.setText(listaVAL[13])              # 13 KILOMET2;16124
        #               Selector en combo MARGEN            # 14 MARGEN;IZQDA
        if self.EX_MARGEN.findText(listaVAL[14], Qt.MatchFixedString) != -1:
            self.EX_MARGEN.setCurrentIndex(self.EX_MARGEN.findText(listaVAL[14], Qt.MatchFixedString))
        else:
            self.EX_MARGEN.addItem(listaVAL[14])
        self.EX_OBSERVAPK.setText(listaVAL[15])             # 15 OBSERVAPK;ESTE ES UN FICHERO DE PRUEBA
        self.EX_TIPO.setText(listaVAL[16])                  # 16 TIPO;Solicitud de comprobación de posible invasión de parcela catastral
                                                            # 17 ARCHIVO;PENDIENTE
                                                            # 18 IG;ASS
        #               Selector en combo INGENIERO         # 19 INGENIERO;Paco Quinto Rodriguez
        if self.EX_INGENIERO.findText(listaVAL[19], Qt.MatchFixedString) != -1:
            self.EX_INGENIERO.setCurrentIndex(self.EX_INGENIERO.findText(listaVAL[19], Qt.MatchFixedString))
        else:
            self.EX_INGENIERO.addItem(listaVAL[19])
        #               Selector en combo ADMIN             # 20 ADMIN;Mónica Aller Tovar
        if self.EX_ADMIN.findText(listaVAL[20], Qt.MatchFixedString) != -1:
            self.EX_ADMIN.setCurrentIndex(self.EX_ADMIN.findText(listaVAL[20], Qt.MatchFixedString))
        else:
            self.EX_ADMIN.addItem(listaVAL[20])
                                                            # 21 ESTAARCHIVADO;FALSO
        self.EX_FECHAARCHIVO.setDate(QDate.fromString(listaVAL[22], 'dd/MM/yyyy')) # 22 FECHAARCHIVO;02/01/2020
        self.EX_EXPTE_EXPROPIACION.setText(listaVAL[23])    # 23 EXPTE_EXPROPIACION;CN-AB-96/115
        self.EX_EXPTES_RELACIONADOS.setText(listaVAL[24])   # 24 EXPTES_RELACIONADOS;CN-AB-96/115-M
        self.EX_NOMBRE_TRAMO.setText(listaVAL[25])          # 25 NOMBRE_TRAMO;EjeManchuela_Villamalea_A31 (Tramo 2)
        self.EX_DECR_ACUERDO_RESOLUCION.setText(listaVAL[26])# 26 DECR_ACUERDO_RESOLUCION;30-OCTUBRE-06
        self.EX_ACTAS_PREVIAS.setText(listaVAL[27])         # 27 ACTAS_PREVIAS;jun-07
        self.EX_REMISION_CATASTRAL.setText(listaVAL[28])    # 28 REMISION_CATASTRAL;25/03/2019
        self.EX_NUMORDEN.setText(listaVAL[29])              # 29 NUMORDEN;73-131
        self.EX_POLIGONO.setText(listaVAL[30])              # 30 POLIGONO;4-3
        self.EX_PARCELAS.setText(listaVAL[31])              # 31 PARCELAS;583-376
        self.EX_TM.setText(listaVAL[32])                    # 32 TM;BONETE
        #               Selector en combo TIPO_EXPEDIENTE   # 33 TIPO_EXPEDIENTE;NO INVASION
        if self.EX_TIPO_EXPEDIENTE.findText(listaVAL[33], Qt.MatchFixedString) != -1:
            self.EX_TIPO_EXPEDIENTE.setCurrentIndex(self.EX_TIPO_EXPEDIENTE.findText(listaVAL[33], Qt.MatchFixedString))
        else:
            self.EX_TIPO_EXPEDIENTE.addItem(listaVAL[33])
                                                            # 34 FECHAINFORME;02/01/2020
        self.EX_TITULO_EXPROPIACION.setText(listaVAL[35])   # 35 TITULO_EXPROPIACION;ACONDICIONAMIENTO CTRA B-11 (CM-3209), P.K. 0 AL 16,124. MONTEALEGRE-BONETE-ESTACION DE BONETE
                                                            # 36 EX_EXPTE_OBRA_RELACIONADO;
        self.EX_REF_CATASTRAL.setText(listaVAL[37])         # 37 REF_CATASTRAL;400016BWJ9140S
        self.EX_FECHA_ULTIMO_TRAMITE.setDate(QDate.currentDate()) # 38 FECHA_ULTIMO_TRAMITE;04/09/2018
        self.EX_TRAMITE_EXPROPIACION.setText(listaVAL[39])  # 39 TRAMITE_EXPROPIACION;ARCHIVADO
        self.EX_CORREOELEC.setText(listaVAL[40])            # 40 CORREOELEC;COSA@VAINA.ES


    def cancela(self):
        self.close()
        pass

    '''
    def creaEXPTE(self):
        ## SE CREA EL EXPEDIENTE

        # Directorio de trabajo de Informes de expropiaciones
        dirINFEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerINFOEXPROexptes")
        if dirINFEXPRO is None:
            dirINFEXPRO=configuration().expropiacion["EXPlayerINFOEXPROexptes"]

        #  Datos de expediente y directorios
        Expte = self.EX_NUMEXPRO.text()
        anoLast = Expte[3:7]
        # print (Expte,anoLast.isnumeric(), Expte[-3:], Expte[-3:].isnumeric(), Expte[:2], len(Expte))
        if not anoLast.isnumeric() or not Expte[-3:].isnumeric() or Expte[:3] != 'EX-' or len(Expte) != 10:
            text = 'El valor de expediente ' + Expte + ' es incorrecto.\n\n'
            text +='Debe ser del tipo EX-AAAAnnn\n'
            text +='    AAAA es el año (p.e. 2020)\n'
            text +='    nnn es el n de expte. (p.e. 023)'
            self.fun.showJCCMessageERR(text,"",tittle="JCCM",)
            return

        dirExpteAno = dirINFEXPRO + u'Año_' + str(anoLast)
        dirExpte = dirExpteAno + u'/' + Expte

        text = u'¿Crear directorio para el expediente - ' + Expte +' ?\n\n'+ dirExpte
        result = self.fun.showJCCMessageYESNO(text, '', 'JCCM')

        # Creación del directorio
        if not os.path.exists(dirExpte) and result == 1024:
            os.makedirs(dirExpte)
        self.creaFICHintercambio(dirExpte)

        
    def creaFICHintercambio(self, dirExpte):
        # Se crea el fichero en el directorio
        listaVAL = []
        listaVAL.append(self.EX_NUMEXPRO.text()[3:10])                                  # 00 NUMEXPRO;2020033
        listaVAL.append(self.datoNumVacio(self.EX_REGISTRO.text()))                     # 01 REGISTRO;79945
        listaVAL.append("#"+self.EX_FECHA.date().toString('dd/MM/yyyy')+"#") # 02 FECHA; Expte remisión; 01/01/2020
        listaVAL.append("'"+self.datoTextVacio(self.EX_SOLICITANTE.text())+"'")         # 03 SOLICITANTE;FRANCISCO MANGANESO HELIO
        listaVAL.append("'"+self.datoTextVacio(self.EX_INTERESADO.text())+"'")          # 04 INTERESADO;ARTURO SELENIO RUBIDIO
        listaVAL.append("'-'")                                                          # 05 DNI;123456789
        listaVAL.append("'-'")                                                          # 06 NOMBRE;HEREDEROS
        listaVAL.append("'-'")                                                          # 07 DOMICILIO;C/ ELEMENTOS, 27
        listaVAL.append("'-'")                                                          # 08 CODIGOPOST;02630
        listaVAL.append("'-'")                                                          # 09 TLFNO;987654321
        listaVAL.append("'-'")                                                          # 10 POBLACION;BONETE
        listaVAL.append("'"+self.datoTextVacio(self.EX_CARRETERA.text())+"'")           # 11 CARRETERA;CM3209
        listaVAL.append(self.datoNumVacio(self.EX_KILOMETRO.text()))                    # 12 KILOMETRO;0
        listaVAL.append(self.datoNumVacio(self.EX_KILOMET2.text()))                     # 13 KILOMET2;16124
        listaVAL.append("'"+self.datoTextVacio(self.EX_MARGEN.currentText())+"'")       # 14 MARGEN;IZQDA
        listaVAL.append("'"+self.datoTextVacio(self.EX_OBSERVAPK.text())+"'")           # 15 OBSERVAPK;ESTE ES UN FICHERO DE PRUEBA
        listaVAL.append("'"+self.datoTextVacio(self.EX_TIPO.toPlainText())+"'")         # 16 TIPO;Solicitud de comprobación de posible invasión de parcela catastral
        listaVAL.append("'-'")                                                          # 17 ARCHIVO;PENDIENTE
        listaVAL.append("'"+self.datoTextVacio(self.datoINICIALES(self.EX_INGENIERO.currentText()))+"'") # 18 IG;ASS
        listaVAL.append("'"+self.datoTextVacio(self.EX_INGENIERO.currentText())+"'")    # 19 INGENIERO;Agustín Solabre Suarez
        listaVAL.append("'-'")                                                          # 20 ADMIN;sl
        listaVAL.append("'"+self.datoTextVacio(self.datochbTOSINO(self.EX_ESTAARCHIVADO))+"'")   # 21 ESTAARCHIVADO;FALSO
        listaVAL.append(self.EX_FECHAARCHIVO.date().toString('dd/MM/yyyy')) # 22 FECHAARCHIVO;02/01/2020
        listaVAL.append("'"+self.datoTextVacio(self.EX_EXPTE_EXPROPIACION.text())+"'")  # 23 EXPTE_EXPROPIACION;CN-AB-96/115
        listaVAL.append("'"+self.datoTextVacio(self.EX_EXPTES_RELACIONADOS.text())+"'") # 24 EXPTES_RELACIONADOS;CN-AB-96/115-M
        listaVAL.append("'"+self.datoTextVacio(self.EX_NOMBRE_TRAMO.text())+"'")        # 25 NOMBRE_TRAMO;EjeManchuela_Villamalea_A31 (Tramo 2)
        listaVAL.append("'"+self.datoTextVacio(self.EX_DECR_ACUERDO_RESOLUCION.text())+"'")     # 26 DECR_ACUERDO_RESOLUCION;30-OCTUBRE-06
        listaVAL.append("'"+self.datoTextVacio(self.EX_ACTAS_PREVIAS.text())+"'")       # 27 ACTAS_PREVIAS;jun-07
        listaVAL.append("'"+self.datoTextVacio(self.EX_REMISION_CATASTRAL.text())+"'")  # 28 REMISION_CATASTRAL;25/03/2019
        listaVAL.append("'"+self.datoTextVacio(self.EX_NUMORDEN.text())+"'")            # 29 NUMORDEN;73-131
        listaVAL.append("'"+self.datoTextVacio(self.EX_POLIGONO.text())+"'")            # 30 POLIGONO;4-3
        listaVAL.append("'"+self.datoTextVacio(self.EX_PARCELAS.text())+"'")            # 31 PARCELAS;583-376
        listaVAL.append("'"+self.datoTextVacio(self.EX_TM.text())+"'")                  # 32 TM;BONETE
        listaVAL.append("'"+self.datoTextVacio(self.EX_TIPO_EXPEDIENTE.currentText())+"'")      # 33 TIPO_EXPEDIENTE;NO INVASION
        listaVAL.append("'-'")                                                          # 34 FECHAINFORME;02/01/2020
        listaVAL.append("'"+self.datoTextVacio(self.EX_TITULO_EXPROPIACION.toPlainText())+"'")  # 35 TITULO_EXPROPIACION;ACONDICIONAMIENTO CTRA B-11 (CM-3209), P.K. 0 AL 16,124. MONTEALEGRE-BONETE-ESTACION DE BONETE
        listaVAL.append("'-'")                                                          # 36 EX_EXPTE_OBRA_RELACIONADO;
        listaVAL.append("'"+self.datoTextVacio(self.EX_REF_CATASTRAL.text())+"'")       # 37 REF_CATASTRAL;400016BWJ9140S
        listaVAL.append(self.EX_FECHA_ULTIMO_TRAMITE.date().toString('dd/MM/yyyy'))     # 38 FECHA_ULTIMO_TRAMITE;04/09/2018
        listaVAL.append("'"+self.datoTextVacio(self.EX_TRAMITE_EXPROPIACION.text())+"'")# 39 TRAMITE_EXPROPIACION;ARCHIVADO
        listaVAL.append("'"+self.datoTextVacio(self.EX_CORREOELEC.toPlainText())+"'")   # 40 CORREOELEC;COSA@VAINA.ES
        
        
        # Creamos el fichero
        fich_csv = dirExpte + "/" + self.EX_NUMEXPRO.text() + '.txt'
        # target  = codecs.open(fich_csv, 'w+',encoding='utf-8')
        target  = codecs.open(fich_csv, 'w+',encoding='mbcs')

        count = 1
        for l in listaVAL:
            if count < len(listaVAL):
                target.write(str(l)+',')
                target.write("\r\n")
            else:
                target.write(str(l))
            count += 1
        pass
        target.close()
        
        # Mensaje final
        text = 'Se ha creado un fichero de intercambio en el directorio:\n\n'
        text += dirExpte +'\n\n'
        self.fun.showJCCMessageERR(text,"",tittle="JCCM",)
        self.close()
        

        
    def datoTextVacio(self,dato):
        if dato == '':
            return "-"
        else:
            return dato

    def datoNumVacio(self,dato):
        if dato == '':
            return 0
        else:
            return int(float(dato))
            # return int(dato,base=10)
            # return "{:.0f}".format(dato)
            
    def datoINICIALES(self, dato):
        if dato != '':
            iniciales = ''
            for word in dato.split():
                iniciales += word[0]
            return iniciales.upper()
        else:
            return '-'
            
    def datochbTOSINO(self, chb):
        if self.EX_ESTAARCHIVADO.isChecked():
            return 'SI'
        else:
            return 'NO'
   '''     

