#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
/***************************************************************************
GDBDominos.py
    
        DATOS DE DOMINIOS DE LAS TABLAS
        begin                : 2019-02-19
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
/***************************************************************************
'''


class GDBdominios:
    
    Titularidad = {
        u'JCCM',u'Estatal',u'Diputación',u'Otras',u'Ayuntamiento',u'CAM',u'JEX',u'SCL'
        }
    Funcionalidad = {
        u'Básica alta capacidad',u'Básica',u'Comarcal',u'Local',u'Travesía',u'Ramal',u'Enlace',u'Otras',u'SCL'
        }
    Tipologia_DobleC = {
        'ATP':u'Autopista de Peaje',
        'ATV':u'Autovía Convencional',
        'CON':u'Carretera convencional desdoblada, con accesos directos y otras limitaciones',
        'SCL':u'Vías de una calzada'
        }
    Tipologia_UnaC = {
        'VRP':u'Carretera convencional doble sentido, sin accesos directos a la vía salvo en enlaces, y catalogada con ese criterio',
        'CON':u'Carretera convencional doble sentido',
        'ENL':u'Enlaces',
        'OTR':u'Carril bici, Otras',
        'SCL':u'Vías de doble calzada'
        }
    idOrdenCtra = {
        '1':u'Básica alta capacidad',
        '2':u'Básica',
        '3':u'Comarcal',
        '4':u'Local',
        '5':u'Travesía',
        '6':u'Ramal',
        '700':u' Enlace Genérico (sin dar tipología ni funcionalidad)',
        '701':u' Enlace Básica Alta Capacidad (sin dar tipología)',
        '702':u' Enlace Básica (sin dar tipología)',
        '703':u' Enlace Comarcal (sin dar tipología)',
        '705':u' Enlace Local (sin dar tipología)',
        '706':u' Enlace Ramal (sin dar tipología)',
        '800':u' Caminos de servicio',
        '801':u' Tramos abandonados',
        '9 ':u' Carril Bici',
        '10':u' Otras SCL' 
        }

        
    Provincia = {
        u'Albacete', u'Ciudad Real', u'Cuenca', u'Guadalajara', u'Toledo'
        }
        
        
        
    '''
    Titularidad,Funcionalidad,Tipologia_DobleC,Tipologia_UnaC,idOrdenCtra,VAL_TIPO_DOBC,VAL_UNA_DOBC,VAL_idOrdenCtra
    CADENA,CADENA,CADENA,CADENA,ENTERO,,,
    JCCM,Básica Alta Capacidad,ATP,VRP,1,ATP = Autopista de Peaje,"VRP = Carretera convencional doble sentido, sin accesos directos a la vía salvo en enlaces, y catalogada con ese criterio",1=Básica Alta Capacidad
    Estatal,Básica,ATV,CON,2,ATV = Autovía Convencional,CON = Carretera convencional doble sentido,2=Básica
    Diputación,Comarcal,CON,SCL,3,"CON = Carretera convencional desdoblada, con accesos directos y otras limitaciones",SCL = Vías de doble calzada,3=Comarcal
    Otras,Local,SCL,ENL,4,SCL =Vías de una calzada,ENL = Enlaces,4=Local
    CAM,Travesía,,OTR ,5,,"OTR = Carril bici, camino, etc.",5=Travesía
    JEX,Ramal,,,6,,,6=Ramal
    ,Enlace,,,700,,,700= Enlace Genérico (sin dar tipología ni funcionalidad)
    ,Otras,,,701,,,701= Enlace Básica Alta Capacidad (sin dar tipología)
    ,,,,702,,,702= Enlace Básica (sin dar tipología)
    ,,,,703,,,703= Enlace Comarcal (sin dar tipología)
    ,,,,705,,,705= Enlace Local (sin dar tipología)
    ,,,,706,,,706= Enlace Ramal (sin dar tipología)
    ,,,,800,,,800= Caminos de servicio
    ,,,,801,,,801= Tramos abandonados
    ,,,,9,,,9 = Carril Bici
    ,,,,10,,,10= Otras SCL

    '''
