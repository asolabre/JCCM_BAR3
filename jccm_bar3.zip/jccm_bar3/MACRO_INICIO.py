# MACRO_INICIO.py

from qgis.core import QgsProject, QgsApplication, Qgis
from qgis.utils import qgsfunction, reloadPlugin, iface
from qgis.gui import QgsMessageBar

from PyQt5.QtWidgets import QMessageBox
 
import os, zipfile, io
import configparser
from xml.etree import ElementTree as ET 
from time import gmtime, localtime, strftime

dirOS = os.getcwd()
Proj = QgsProject.instance().fileName()
uniProj = Proj[:2]
uniRepo= u'Z:'

def openProject():
    # Datos plugin carreteras
    pluginCTRAS = u'python/plugins/jccm_bar3/metadata.txt'
    fichREPOJCCM = uniProj + u'/cartografia/datos_Q/INSTALACION SIG_CLM_QGIS/jccm_bar3/jccmctrasrepo.xml'
    if not os.path.exists(fichREPOJCCM):
        fichREPOJCCM = uniRepo + u'/cartografia/datos_Q/INSTALACION SIG_CLM_QGIS/jccm_bar3/jccmctrasrepo.xml'

    # Obtención de datos del Plugin 'JCCM Carreteras' instalado
    dirPYTJCCM = QgsApplication.qgisSettingsDirPath()
    fichPYTJCCM = os.path.normpath(os.path.join(os.path.dirname(dirPYTJCCM), pluginCTRAS))
    cfg = configparser.SafeConfigParser()
    cfg.read(fichPYTJCCM)
    # version = cfg.get('general', 'version').lower()
    version = cfg.get('general', 'version')
    fechaPlugin = strftime("%d %b %Y %H:%M ", localtime(os.path.getmtime(fichPYTJCCM)))
    
    # Obtención de datos del Plugin 'JCCM Carreteras' en repositorio
    versionREPO = u's/d'
    fechaPluginREPO = u'Sin Repositorio'
    if os.path.exists(fichREPOJCCM):
        with open(fichREPOJCCM, 'r') as f:
            tree  = ET.parse(f)
            for elem in tree.findall('pyqgis_plugin'):
                if elem.attrib["name"] == u'JCCM Carreteras (BETA)':
                    versionREPO = elem.attrib["version"].lower()
                    fechaPluginREPO = strftime("%d %b %Y %H:%M ", localtime(os.path.getmtime(fichREPOJCCM)))

    # Se actualiza el plugin si es necesario
    print ('versionREPO='+versionREPO, 'version='+version)
    if (versionREPO != u's/d' and float(versionREPO) > float(version)):
        plugin = 'jccm_bar'
        zip_dir = uniRepo + u'/cartografia/datos_Q/INSTALACION SIG_CLM_QGIS/jccm_bar3/'
        zip_file_base = 'jccm_bar3.zip'
        zip_file = zip_dir+zip_file_base
        dest = dirPYTJCCM+u'python/plugins/'
        if not os.path.exists(dest):
            os.makedirs(dest)
        zf = zipfile.ZipFile(zip_file)
        zf.extractall(dest)
        reloadPlugin(plugin)
        
        text = u'- SIG REGIONAL DE CARRETERAS -' + '\n' + u'Actualizada Versión- '+ versionREPO +' ('+fechaPluginREPO+')'

    else:
        text = u'- SIG REGIONAL DE CARRETERAS -' + '\n' + u'Vers.  Instalada- '+ version +u' ('+fechaPlugin+u')'

    # Datos en Barra de Mensajes
    text2 = u''
    tittle = u'JCCM Carreteras'
    iface.messageBar().pushMessage(text, tittle,  level=Qgis.Info, duration=5)
        

def saveProject():
    pass

def closeProject():
    pass

@qgsfunction(args="auto", group='Custom')
def quitapar(value1, feature, parent):
    pos1= value1.find('(', 0)
    pos2= value1.find(')', 0)
    if pos1==-1:
        result = value1
    else:
        result = value1[pos1+1: pos2] +" "+ value1[:pos1]
    return result
    
@qgsfunction(args="auto", group='SIG_REG_CTRAS')
def geomGetLista(geometry, prec, feature, parent):
    """ 
    Esta funcion permite listar un poligono ajustando los decimales de salida 
        geomGetLista(polygon, prec)
            polygon = Polygono WKT
            prec = decimales de precisión (ENTERO)
            
    Llamada en texto desde diseñador:
    geomGetLista(geometry( get_feature( [NOMBRE CAPA], [CAMPO],  [VALOR] )),[PRECISION])
    EJEMPLO: geomGetLista(geometry( get_feature( 'Informes de Expropiaciones', 'EX_NUM',  @VAR_INFEXPR )),2)
    """
    cadena =''
    if geometry.isMultipart():
        polygon = geometry.asMultiPolygon()
        for listPartes in polygon:
            cadena += 'Poligono '+str(polygon.index(listPartes)+1)+'\n'
            for parte in listPartes:
                i=1
                for pto in parte:
                    cadena += " ".join([str(i),' - ',u'{:.{}f}'.format(pto[0], prec),' - ',u'{:.{}f}'.format(pto[1], prec),'\n'])
                    i += 1
            cadena += '\n'
    else:
        polygon = geometry.asPolygon()
        for parte in polygon:
            i=1
            for pto in parte:
                cadena += " ".join([str(i),' - ',u'{:.{}f}'.format(pto[0], prec),' - ',u'{:.{}f}'.format(pto[1], prec),'\n'])
                i += 1
    return cadena