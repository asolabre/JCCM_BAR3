# -*- coding: utf-8 -*-
"""
/***************************************************************************
 parcela_catastralDialog
                                 A QGIS plugin
 jcml_bar
                             -------------------
        begin                : 2016-06-06
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
from osgeo import ogr, osr
from qgis.core import *
from PyQt4.QtGui import *
import qgis.utils

import urllib2
import urllib
import json

from functions import Functions
from config import configuration

from PyQt4 import QtGui, uic
from time import sleep
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/balizas_carretera.ui'))


class balizas_carreteraDialog(QtGui.QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(balizas_carreteraDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        self.setWindowIcon(QIcon(':/plugins/jccm_bar/iconos/jccm.jpg'))
        self.fun = Functions()
        # self.logoJCCM.setPixmap(QtGui.QPixmap(":/plugins/jccm_bar/iconos/jccm.jpg"))

    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        return text.encode('utf-8')
        
    def cancel(self):
        return 'CANCEL'