﻿# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           functions3.py
Purpose: Tools for plugin jccm_bar3

        --------------------------------------------------------------------
        begin                : 2019-09-03
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt, QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu, QProgressBar
from PyQt5.QtGui import QIcon, QColor, QCursor

from qgis.gui import QgsVertexMarker
            # https://qgis.org/pyqgis/3.0/core/index.html
from qgis.core import Qgis, QgsPointXY, QgsVectorLayer, QgsGeometry, QgsPoint, QgsRectangle, QgsMessageLog, QgsProject, QgsField, QgsCoordinateReferenceSystem,QgsExpression, QgsFeatureRequest,QgsFeature, QgsMapLayer, QgsVectorFileWriter, QgsWkbTypes, QgsSpatialIndex, QgsLayerTreeLayer
            # https://qgis.org/pyqgis/3.0/gui/index.html
from qgis.PyQt.QtCore import *


# SISTEMA DE CARGA DE LIBRERÍAS DESDE PyQt5
# from PyQt5.QtGui import QIcon, QPrinter, QPrinterInfo, QPrintDialog, QColor
    # https://doc.qt.io/qt-5/qtgui-module.html
# from PyQt5.QtCore import QSettings, QCoreApplication, QTranslator, qVersion, SIGNAL, Qt, QVariant
    # https://doc.qt.io/qt-5/qtcore-module.html
# from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu, QAction
    # https://doc.qt.io/qt-5/qtwidgets-module.html


from osgeo import gdal, osr, ogr

import os, glob, codecs
from os import fdopen, remove
from os.path import isfile, join

import sys
import zipfile, io
import linecache

import json
import urllib
import requests
import timeit
import time
import datetime
import math
from math import *
from xml.etree import cElementTree as ElementTree
from xml.dom import minidom
from xml.dom.minidom import parseString

from tempfile import mkstemp
from shutil import move

import locale

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.environment["EPSG"]



# CLASES PROGRAMADAS
class Functions:

    """
        RUTINAS DE CONFIGURACION INICIAL
    """

    def __init__(self):

        self.current_configuration = configuration()
        self.setVar = QSettings()

        # CONFIGURACIÓN DEL SISTEMA
        self.enableUseOfGlobalCrs()

        pass


    def enableUseOfGlobalCrs(self):
    #   Por medio de esta rutina se configura el sistema para que el CRS de las nuevs capas sea el de proyecto, y no pregunte
    # PyQGIS like a Boss  http://pyqgis.blogspot.com.es/
    # 'set new Layers to use the Project-CRS'
        """
            MODIFICAR A EPSG ACTIVO
        """
        self.s = QSettings()
        self.oldValidation = self.s.value(str("/Projections/defaultBehaviour"))
        self.s.setValue( "/Projections/defaultBehaviour", "useProject" )    # CRS para nuevas capas, por defecto usa el del proyecto
        self.s.setValue( "/Projections/layerDefaultCrs", "EPSG:"+str(srcVal) )


    def buscaUnidadesGDB(self, listGDB, GDBCLASS):
    # La rutina permite buscar el fichero de GDB en las diferentes unidades en el orden del fichero CONFIGURACION
    #******************************************************************
    # COMPROBAMOS QUE EXISTE LA GDB/GDBCLASS ENTRE LAS DE LA LISTA
    #******************************************************************
        driver = ogr.GetDriverByName("OpenFileGDB")

        GDBmal = True
        it =0
        while GDBmal:
            try:
                GDB = listGDB[it]
            except:
                GDBmal = False
                GDB = ""
            data = driver.Open(GDB, 0)
            if data is not None:
                for i in data:
                    foo = i.GetName()
                    if i.GetName() == GDBCLASS:
                        GDBmal = False
            it += 1
        # print 'La GDB es ', GDB
        return GDB


    """
    #-------------------------------------------------------------------------------
    #    RUTINAS DE SALIDAS DE MENSAJES EN PANTALLA
    #-------------------------------------------------------------------------------
    """

    def showJCCMessage(self,text,text2="",tittle="JCCM",):
        # showJCCMessage(self,text,text2="",tittle="JCCM",)
        #   Mensaje de INFORMACION
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(text)
        msg.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'));
        #   setWindowIcon(QIcon(':/plugins/Spanish_Inspire_Catastral_Downloader/icon.png'));
        msg.setInformativeText(text2)
        msg.setWindowTitle(tittle)
        msg.exec_()


    def showJCCMessageYESNO(self,text,text2="",tittle="JCCM",):
        # showJCCMessageYESNO(self,text,text2="",tittle="JCCM",)
        #       Mensaje YESNO
        # retval == 1024:       # Se ha pulsado ACEPTAR
        # retval == 4194304:    # Se ha pulsado CANCELAR

        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setStandardButtons (QMessageBox.Ok | QMessageBox.Cancel)
        msg.setDefaultButton(QMessageBox.Cancel)
        msg.setText(text)
        msg.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        #msg.setText(unicode(text).encode('utf-8'))
        msg.setInformativeText(text2)
        msg.setWindowTitle(tittle)
        retval = msg.exec_()
        # print u"Valor del mensage del botón pulsado: ", retval
        return retval


    def showJCCMessageERR(self,text,text2="",tittle="JCCM",):
        # showJCCMessageERR(self,text,text2="",tittle="JCCM",)
        # Mensaje error
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(text)
        msg.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        #msg.setText(unicode(text).encode('utf-8'))
        msg.setInformativeText(text2)
        msg.setWindowTitle(tittle)
        msg.exec_()


    def trabajando(self, text, busyDlg):
        if text != u'--- CERRAR ---':
            main_window = iface.mainWindow()
            busy_indicator_dialog = QgsBusyIndicatorDialog(text, main_window,
                                                           fl=Qt.WindowFlags())
            busy_indicator_dialog.setWindowTitle( "JCCM Carreteras" )
            busy_indicator_dialog.setMinimumWidth( 250 )

            busy_indicator_dialog.show()
            return busy_indicator_dialog
        else:
            busyDlg.destroy()


    def PrintException(self):
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        basename = os.path.basename(filename)
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        # result = 'ERROR EN ({}, LINEA {} "{}"): {}'.format(basename, lineno, line.strip(), exc_obj)
        result = 'ERROR EN ({}, LINEA {}):\n\n {} {}'.format(basename, lineno, line.strip(), exc_obj)
        # print (result)
        return result


    """ RUTINAS DE ANALISIS Y TRANSFORMACION DE VARIABLES Y FICHEROS
    #-------------------------------------------------------------------------------
    #   RUTINAS DE ANALISIS Y TRANSFORMACION DE VARIABLES Y FICHEROS
    #-------------------------------------------------------------------------------
    """

    def isFloat(self,number):
        try:
            inNumberfloat = float(number)
            return True
        except ValueError:
            return False


    def completarCeros(self,text,num):
        texto = str(text)
        longitud= len(texto)

        while (longitud < num):
            texto = "0" +texto
            longitud = len(texto)
        return texto


    def cambiaelemlista(self,lista,elem,valor):
        lista[elem]=valor
        return lista


    def Extract_PlainText(self, label):
        Rtf_text = label.text()
        Temp_Obj = QtGui.QTextEdit()
        Temp_Obj.setText(Rtf_text)
        Plain_text = Temp_Obj.toPlainText()
        del Temp_Obj
        return Plain_text


    def replace(self, file_path, pattern, subst):
        # Reemplaza en el fichero 'file_path' la cadena 'pattern' con 'subst'

        #Create temp file
        fh, abs_path = mkstemp()
        with fdopen(fh,'w') as new_file:
            with open(file_path) as old_file:
                for line in old_file:
                    new_file.write(line.replace(pattern, subst))
        #Remove original file
        remove(file_path)
        #Move new file
        move(abs_path, file_path)


    def mostrarPK(self,val,num):
        # mostrarPK(self,val,num)
        #   FUNCIÓN de presentación de un valor kilométrico (numero) KK.MMMmmm en formato (string) KK+MMM.mmm
        #   return texto
        # Creada ASS
        # print val
        if ((val != None) and (str(val) != 'nan')):
            km = int(val)
            m = round((val - km)*1000,num)
            texto = str(km) + "+" + "{:0{}.{}f}".format( m, 4+num, num )
            return texto
        else:
            return 'None'


    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        return text.encode('utf-8')


    def timeTOhms(self,time):
        # import datetime
        x=datetime.timedelta(seconds=int(time))
        # time.strftime('%H:%M:%S', time.gmtime(12345))
        return x
        pass



    """  RUTINAS DE FEATURES Y ZOOM
    #-------------------------------------------------------------------------------
    #    RUTINAS DE FEATURES Y ZOOM
    #-------------------------------------------------------------------------------
    """

    def dibujarPunto(self,x,y,iface,r=0,g=255,b=0):
        # dibujarPunto(self,x,y,iface,r=0,g=255,b=0)
        #   Dibuja un punto de un color RGB
        m = QgsVertexMarker(iface.mapCanvas())
        m.setCenter(QgsPointXY(x, y))
        m.setColor(QColor(r, g, b))
        m.setIconSize(5)
        m.setIconType(QgsVertexMarker.ICON_BOX) # or ICON_CROSS, ICON_X
        m.setPenWidth(3)
        return m


    def zoomToOgrGeometriesLin(self,iface,geometries):
        # zoomToOgrGeometriesLin(self,iface,geometries)
        #   Hace zoom a un grupo de geometrias

        cur_env = None;
        count = 1
        for geom in geometries:
            # geomtype = geom.GetGeometryType()

            env = geom.GetEnvelope()

            if cur_env == None:
                cur_env = list(env)
            else:
                if(env[0] < cur_env[0]) and (env[0] != 0):
                    cur_env[0] = env[0]
                if(env[1] > cur_env[1]) and (env[1] != 0):
                    cur_env[1] = env[1]
                if(env[2] < cur_env[2]) and (env[2] != 0):
                    cur_env[2] = env[2]
                if(env[3] > cur_env[3]) and (env[3] != 0):
                    cur_env[3] = env[3]
            print ('geom', count, env[0],env[2],env[1],env[3])
            count += 1
            
            # if cur_env != None:
                # if(env[0] < cur_env[0]):
                    # cur_env[0] = env[0]
                # if(env[1] > cur_env[1]):
                    # cur_env[1] = env[1]
                # if(env[2] < cur_env[2]):
                    # cur_env[2] = env[2]
                # if(env[3] > cur_env[3]):
                    # cur_env[3] = env[3]

        rectangle = QgsRectangle(cur_env[0],cur_env[2],cur_env[1],cur_env[3])
        print ('rectangle', cur_env[0],cur_env[2],cur_env[1],cur_env[3])
        iface.mapCanvas().zoomToFeatureExtent(rectangle)
        iface.mapCanvas().refresh()


    def zoomToGeometry(self,iface,geometry):
        # zoomToGeometry(self,iface,geometry)
        #   Hace zoom a una geometria

        geomtype = geometry.GetGeometryType()
        # print geomtype
        if geomtype == ogr.wkbPoint or geomtype == ogr.wkbPoint25D :

            margin = 1000
            rectangle = QgsRectangle(geometry.GetX() -margin ,geometry.GetY() - margin ,geometry.GetX() +margin ,geometry.GetY() + margin)
            # print rectangle
            iface.mapCanvas().setExtent(rectangle)
            iface.mapCanvas().refresh()
            m = QgsVertexMarker(iface.mapCanvas())
            # print "zoom to "

            m.setCenter(QgsPointXY(geometry.GetX() , geometry.GetY() ))

            m.setColor(QColor(0, 255, 0))
            m.setIconSize(5)
            m.setIconType(QgsVertexMarker.ICON_BOX) # or ICON_CROSS, ICON_X
            m.setPenWidth(3)
        else:
            e = geometry.GetEnvelope()
            # print e
            rectangle = QgsRectangle(e[0],e[2],e[1],e[3])

            iface.mapCanvas().zoomToFeatureExtent(rectangle)
            iface.mapCanvas().refresh()
            m = QgsVertexMarker(iface.mapCanvas())
            # print "zoom to "
            # print str(e[0]) + ", " + str(e[2])
            m.setCenter(QgsPointXY(geometry.Centroid().GetX(), geometry.Centroid().GetY()))

            m.setColor(QColor(0, 255, 0))
            m.setIconSize(5)
            m.setIconType(QgsVertexMarker.ICON_BOX) # or ICON_CROSS, ICON_X
            m.setPenWidth(3)


    """ RUTINAS DE GESTION DE RUTAS Y DATOS DE GDB (CARRETERA Y PK)
    #-------------------------------------------------------------------------------
    #   RUTINAS DE GESTION DE RUTAS (CARRETERA Y PK)
    #-------------------------------------------------------------------------------
    """

    def getRoadLmits(self,road_name):
        # getRoadLmits(self,road_name)
        #   Rutina de obtención del minimoM y maximoM de una ruta
        #       limits.append([min_m,max_m])
        #   return limits

        url = self.current_configuration.environment["rest_carreteras"]
        posSPC = road_name.find(' ')
        r_name = road_name
        if posSPC != -1 :
            r_name = road_name[:posSPC+2]
            whereCONS = self.current_configuration.lrs["identificador_carretera_carreteras"] + " like '" + r_name + u"%' and Matricula <> '9000'"
        else:
            whereCONS = self.current_configuration.lrs["identificador_carretera_carreteras"] + " = '" + r_name + u"' and Matricula <> '9000'"


        values = {'where' : whereCONS,
        # values = {'where' :  self.current_configuration.lrs["identificador_carretera_carreteras"] + " = '" + road_name + u"'",
                  'text': '',
                  'objectIds': '',
                  'geometryType' : 'esriGeometryPolyline',
                  'returnGeometry' : 'true',
                 'returnM': 'true' ,
                 'f': 'json'}

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        try:
            response = json.load(urllib.request.urlopen(url+data))
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet")
            return

        features =  response["features"]    # Los distintos features encontrados en la búsqueda


        # print features
        # print ('Encontrados %d elementos'%(len(features)))

        if features == []:
            return "No hay features"
        limits = []

        for feat in features:
            emes = []
            geometry = feat["geometry"]
            paths = geometry["paths"]
            for path in paths:
                for point in path:
                    if(point[2] is not None):
                        # print 'X - Y - M ', point[0], point[1], point[2]
                        emes.append(point[2])
            if(len(emes) > 0):
                # print emes
                min_m = min(emes)
                max_m =  max(emes)
                limits.append([min_m,max_m])
            else:

                limits.append( [None,None])

        limits.sort(key=lambda x: x[0])

        return limits


    def zoomToPk(self, iface,road_name, pk, pkDistEnt = 0, tipomed = 'DISTPK'):
        # zoomToPk(self, iface,road_name, pk)
        #   Rutina de zoom a CARRETERA, PK
        #   return x,y
        #   return None

        # result = self.CtraPktoCoorsAcim(road_name, pk)
        result = self.CtraPktoCoorsAcim(road_name, pk, pkDistEnt, tipomed)

        if not self.isFloat(result[0]):
            return result
        else:
            # print 'Resultado - ', result[0], result[1]
            point = ogr.Geometry(ogr.wkbPoint)
            point.AddPoint(result[0], result[1])
            self.zoomToGeometry(iface,point)
            return result[0], result[1]


    def CtraPktoCoorsAcim(self, road_name, pk, pkDistEnt = 0, tipomed = 'DISTPK'):
        # PRUEBA DE IDENTIFICACIÓN POR DISTANCIA A PK ANTERIOR
        # CtraPktoCoorsAcim(self, road_name, pk, pkDistEnt = 0, tipomed = 'DISTPK')
        #   road_name - Matrícula de la carretera
        #   pk        - Punto Km, en caso de tipomed = 'DISTPK' puede ser la placa entera solo
        #   pkDistEnt - Distancia a la placa de 'pk'. Si = 0 y tipomed = 'DISTPK', se evalúa la distancia por los decimales de pk
        #   tipomed - Flag de análisis del tipo de PK medido
        #       tipomed = 'DISTPK' - El Pk se ubica por distancia a la placa de PK anterior
        #       tipomed = 'CALIBRADO' - El Pk se ubica por interpolación entre las placas
        #   Rutina de transformación de CARRETERA, PK a X, Y, Acim
        #   return x,y
        #   return None

        url = self.current_configuration.environment["rest_carreteras"]
        
        # Caso de que road_name esté vacío
        if (road_name == ""):
            return 'Error: Carretera sin nombre'
        posSPC = road_name.find(' ')
        r_name = road_name
        if posSPC != -1 :
            r_name = road_name[:posSPC+2]
            whereCONS = self.current_configuration.lrs["identificador_carretera_carreteras"] + " like '" + r_name + u"%' and Matricula <> '9000'"
        else:
            whereCONS = self.current_configuration.lrs["identificador_carretera_carreteras"] + " = '" + r_name + u"' and Matricula <> '9000'"

        values = {'where' : whereCONS,
                  'text': '',
                  'objectIds': '',
                  'geometryType' : 'esriGeometryPolyline',
                  'returnGeometry' : 'true',
                  'returnM': 'true' ,
                  'f': 'json'}


        data = urllib.parse.urlencode(values)
        response = json.load(urllib.request.urlopen(url+data))
        try:
            features =  response["features"]
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.CtraPktoCoorsAcim LIN:384)")
            return 'Error: No hay elementos'
        nfeat = 1
        pkencontrado = 0
        acim = 360
        listLimites= []

        if len(features) == 0:
            return 'Error: Matricula Incorrecta'
        
        if tipomed == 'DISTPK': # tipomed = 'DISTPK'
            if pkDistEnt == 0:
                pkEnt = int(pk)
                pkDistEnt = (pk - pkEnt)*1000
            else:
                pkEnt = int(pk)
              
            # USE QgsGeometry QgsGeometry::interpolate  (   double  distance    )
            #   new_feat.setGeometry(feat.geometry().interpolate(float(row[0])))
            #   return point (x,y,[z],[m])
            
            # USE lineLocatePoint(self, point: QgsGeometry) → float
            #   return dist (float)

            
            # Busqueda de posición de PK entero
            for feat in features:
                npath = 1
                if pkencontrado == 1:
                    break
                # print nfeat, ' de ',len(features), ' features'
                if feat is not None:
                    geometry = feat["geometry"]
                    paths = geometry["paths"]
                    for path in paths:
                        # print (path)
                        path2D = []
                        for point in path:
                            path2D.append(QgsPoint(point[0],point[1]))
                        geomPath = QgsGeometry.fromPolyline(path2D)
                        
                        posini = 0
                        posfin = len(path)-1
                        while path[posini][2] == None and posini<len(path)-1:    # Buscamos el primer punto del tramo sin valor None
                            # print ('posini ',posini, path[posini][2])
                            posini+=1
                        while path[posfin][2] == None and posfin>0:              # Buscamos el último punto del tramo sin valor None
                            # print ('posfin ',posfin, path[posfin][2])
                            posfin-=1
                        if path[posini][2] == None or path[posfin][2] == None:
                            continue

                        # print ('INI-  ',path[posini][2],'  FIN-  ',path[posfin][2])
                        if path[posini][2]<path[posfin][2]: # Sentido CRECIENTE
                            limites = [path[posini][2],path[posini][0],path[posini][1],path[posfin][2],path[posfin][0],path[posfin][1]]
                            sentido = 'CRECIENTE'
                        else:   # Sentido DECRECIENTE
                            limites = [path[posfin][2],path[posfin][0],path[posfin][1],path[posini][2],path[posini][0],path[posini][1]]
                            sentido = 'DECRECIENTE'
                        listLimites.append(limites)
                        # print '%s de %s paths - %s puntos'%(npath, len(paths), len(path))
                        # print limites
                        npointprev = 0
                        npoint = 1
                        if pkencontrado == 1:
                            break
                        Mprev = None
                        # Mprev = 0.0
                        while (Mprev == None and npointprev<len(path)):
                            Pprev = path[npointprev]
                            Pprev = ogr.Geometry(ogr.wkbPoint)
                            Pprev.AddPoint(path[npointprev][0], path[npointprev][1])
                            Xprev = path[npointprev][0]
                            Yprev = path[npointprev][1]
                            Mprev = path[npointprev][2]
                            sentido = 'CRECIENTE'
                            iniloop = npointprev+1
                            npointprev += 1
                        if npointprev == len(path):
                            break

                        for npoint in range(iniloop,len(path)):
                            point = path[npoint]
                            # print '    PRE {:.0f} {:.2f} {:.2f} {:.7f}'.format(npointprev, Xprev, Yprev, Mprev),
                            # print '    ACT {:.0f} {:.2f} {:.2f} {:.7f}'.format(npoint+1, point[0], point[1], point[2])
                            if(point[2] is not None):
                                if point[2] == pkEnt:   # El pkEnt es el vértice
                                    ###############################################################
                                    ######                                                   ######
                                    ######            Calcular aquí x,y                      ######
                                    ######                                                   ######
                                    ###############################################################
                                    
                                    xPkEnt = point[0]
                                    yPkEnt = point[1]
                                    
                                    distOriPK = geomPath.lineLocatePoint(QgsGeometry.fromPointXY(QgsPointXY(xPkEnt,yPkEnt)))
                                    if sentido == 'CRECIENTE':
                                        # distOriPoint = distOriPK + 1000*pkDistEnt
                                        distOriPoint = distOriPK + pkDistEnt
                                    else:
                                        # distOriPoint = distOriPK - 1000*pkDistEnt
                                        distOriPoint = distOriPK - pkDistEnt
                                    print (distOriPK, distOriPoint)
                                        
                                    pointResul = geomPath.interpolate(distOriPoint)
                                    # print (pointResul)
                                    if pointResul.isEmpty():
                                        return u'Error: Imposible cálculo'
                                    else:
                                        x = pointResul.asPoint().x()
                                        y = pointResul.asPoint().y()

                                    acim = 0
                                    ###############################################################
                                    ###############################################################                                
                                    # CALCULO DEL ACIMUT
                                    # pointANT = QgsPointXY(Xprev,Yprev)
                                    # pointPOS = QgsPointXY(x,y)
                                    # res1 = self.calcACIMUT(pointANT,pointPOS)
                                    # acim= res1[1]
                                    # if acim < 0:
                                        # acim += 360

                                    pkencontrado = 1
                                    if point[2]> path[(point in path)+1][2]:
                                        sentido = 'DECRECIENTE'
                                    # print 'COINCIDE CON Punto %s M=%s'%(npoint, point[2])
                                    break

                                else:
                                    # Se debe analizar si el punto es M=Null
                                    if (pkEnt>=Mprev and pkEnt<point[2]) or (pkEnt<=Mprev and pkEnt>point[2]):
                                        # El pkEnt está entre el vértice previo y el siguiente
                                        if pkEnt>=Mprev and pkEnt<point[2]:
                                            sentido = 'CRECIENTE'
                                        else:
                                            sentido = 'DECRECIENTE'
                                        Psig = ogr.Geometry(ogr.wkbPoint)
                                        Psig.AddPoint(point[0], point[1])
                                        # print 'SENTIDO- %s , ENCONTRADO ENTRE Punto %s M=%s %s M=%s'%(sentido, npointprev, Mprev, npoint+1, point[2])
                                        r = (pkEnt - Mprev) / (point[2] - Mprev)
                                        modulo = r * (Pprev.Distance(Psig))

                                        alfa = math.atan2((point[1] - Yprev ) , (point[0]  - Xprev))

                                        # x = Xprev + modulo * math.cos(alfa)
                                        # y = Yprev + modulo * math.sin(alfa)

                                        ###############################################################
                                        ######                                                   ######
                                        ######            Calcular aquí x,y                      ######
                                        ######                                                   ######
                                        ###############################################################
                                        
                                        xPkEnt = Xprev + modulo * math.cos(alfa)
                                        yPkEnt = Yprev + modulo * math.sin(alfa)
                                        
                                        distOriPK = geomPath.lineLocatePoint(QgsGeometry.fromPointXY(QgsPointXY(xPkEnt,yPkEnt)))
                                        if sentido == 'CRECIENTE':
                                            # distOriPoint = distOriPK + 1000*pkDistEnt
                                            distOriPoint = distOriPK + pkDistEnt
                                        else:
                                            # distOriPoint = distOriPK - 1000*pkDistEnt
                                            distOriPoint = distOriPK - pkDistEnt
                                        # prin t (distOriPK, distOriPoint)
                                            
                                        pointResul = geomPath.interpolate(distOriPoint)
                                        # print (pointResul)
                                        if pointResul.isEmpty():
                                            return u'Error: Imposible cálculo'
                                        else:
                                            x = pointResul.asPoint().x()
                                            y = pointResul.asPoint().y()
                                        
                                        acim = 0
                                        ###############################################################
                                        ###############################################################                                
                                        # # CALCULO DEL ACIMUT
                                        # pointANT = QgsPointXY(Xprev,Yprev)
                                        # pointPOS = QgsPointXY(x,y)
                                        # res1 = self.calcACIMUT(pointANT,pointPOS)
                                        # acim= res1[1]
                                        # # if acim < 0:
                                            # # acim += 360

                                        pkencontrado = 1
                                        break
                            else:
                                # M es None
                                pass


                            # El pkEnt no está en este segmento
                            npointprev += 1
                            npoint += 1
                            Pprev = point
                            Pprev = ogr.Geometry(ogr.wkbPoint)
                            Pprev.AddPoint(point[0], point[1])
                            Xprev = point[0]
                            Yprev = point[1]
                            Mprev = point[2]

                        npath += 1

                nfeat += 1

            if pkencontrado == 0 and features!=[]:
                # Analizamos los tramos entre paths para localizar el pkEnt en los huecos

                listLimites.sort()
                # for limites in listLimites:
                    # print limites
                Tramo0 = 0
                Mini0 = listLimites[0][0]
                Mfin0 = listLimites[0][3]
                Xfin0 = listLimites[0][4]
                Yfin0 = listLimites[0][5]
                for limites in listLimites[1:]:
                    Mini1 = limites[0]
                    Mfin1 = limites[3]
                    Xini1 = limites[1]
                    Yini1 = limites[2]
                    if (pkEnt>Mfin0 and pkEnt<Mini1):
                        # Encontramos el pkEnt en un hueco
                        # print 'Encontramos el pkEnt en un hueco -', Mfin0, Mini1

                        Pprev = ogr.Geometry(ogr.wkbPoint)
                        Pprev.AddPoint(Xfin0, Yfin0)
                        Psig = ogr.Geometry(ogr.wkbPoint)
                        Psig.AddPoint(Xini1, Yini1)

                        r = (pkEnt - Mfin0) / (Mini1 - Mfin0)
                        modulo = r * (Pprev.Distance(Psig))
                        alfa = math.atan2((Yini1-Yfin0) , (Xini1-Xfin0))
                        x = Xfin0 + modulo * math.cos(alfa)
                        y = Yfin0 + modulo * math.sin(alfa)
                        # print 'r=%s mod=%s alfa=%s '%(r,modulo,alfa)
                        # print 'Xfin0=%s Yfin0=%s Xini1=%s Yini1=%s'%(Xfin0, Yfin0, Xini1, Yini1)
                        res1 = self.calcACIMUT(QgsPointXY(Xfin0, Yfin0),QgsPointXY(Xini1, Yini1))
                        acim= res1[1]
                        # if acim < 0:
                            # acim += 360
                        pkencontrado = 1
                        # print x,y, acim
                        break

                    Tramo0 += 1
                    Mini0 = Mini1
                    Mfin0 = Mfin1
                    Xfin0 = limites[4]
                    Yfin0 = limites[5]
                pass


            if pkencontrado == 1:
                Xmin =  291000
                Ymin = 4205000
                Xmax =  680000
                Ymax = 4576000
                if (x < Xmin or x > Xmax or y < Ymin or y > Ymax):
                    # print 'Las coordenadas no caen en CLM'
                    QApplication.restoreOverrideCursor()
                    return 'Error: Las coordenadas no caen en CLM'
                return x,y,acim
            else:
                # print 'El PK no esta en el tramo'
                QApplication.restoreOverrideCursor()
                return 'Error: El PK no esta en el tramo'
            nfeat += 1
            
        else:   # tipomed = 'CALIBRADO',         
            for feat in features:
                npath = 1
                if pkencontrado == 1:
                    break
                # print nfeat, ' de ',len(features), ' features'
                if feat is not None:
                    geometry = feat["geometry"]
                    paths = geometry["paths"]
                    for path in paths:
                        posini = 0
                        posfin = len(path)-1
                        while path[posini][2] == None and posini<len(path)-1:    # Buscamos el primer punto del tramo sin valor None
                            # print ('posini ',posini, path[posini][2])
                            posini+=1
                        while path[posfin][2] == None and posfin>0:              # Buscamos el último punto del tramo sin valor None
                            # print ('posfin ',posfin, path[posfin][2])
                            posfin-=1
                        if path[posini][2] == None or path[posfin][2] == None:
                            continue

                        # print ('INI-  ',path[posini][2],'  FIN-  ',path[posfin][2])
                        if path[posini][2]<path[posfin][2]: # Sentido CRECIENTE
                            limites = [path[posini][2],path[posini][0],path[posini][1],path[posfin][2],path[posfin][0],path[posfin][1]]
                        else:   # Sentido DECRECIENTE
                            limites = [path[posfin][2],path[posfin][0],path[posfin][1],path[posini][2],path[posini][0],path[posini][1]]
                        listLimites.append(limites)
                        # print '%s de %s paths - %s puntos'%(npath, len(paths), len(path))
                        # print limites
                        npointprev = 0
                        npoint = 1
                        if pkencontrado == 1:
                            break
                        Mprev = None
                        # Mprev = 0.0
                        while (Mprev == None and npointprev<len(path)):
                            Pprev = path[npointprev]
                            Pprev = ogr.Geometry(ogr.wkbPoint)
                            Pprev.AddPoint(path[npointprev][0], path[npointprev][1])
                            Xprev = path[npointprev][0]
                            Yprev = path[npointprev][1]
                            Mprev = path[npointprev][2]
                            sentido = 'CRECIENTE'
                            iniloop = npointprev+1
                            npointprev += 1
                        if npointprev == len(path):
                            break

                        for npoint in range(iniloop,len(path)):
                            point = path[npoint]
                            # print '    PRE {:.0f} {:.2f} {:.2f} {:.7f}'.format(npointprev, Xprev, Yprev, Mprev),
                            # print '    ACT {:.0f} {:.2f} {:.2f} {:.7f}'.format(npoint+1, point[0], point[1], point[2])
                            if(point[2] is not None):
                                if point[2] == pk:
                                    # El PK es el vértice
                                    x = point[0]
                                    y = point[1]

                                    # CALCULO DEL ACIMUT
                                    pointANT = QgsPointXY(Xprev,Yprev)
                                    pointPOS = QgsPointXY(x,y)
                                    res1 = self.calcACIMUT(pointANT,pointPOS)
                                    acim= res1[1]
                                    if acim < 0:
                                        acim += 360

                                    pkencontrado = 1
                                    if point[2]> path[(point in path)+1][2]:
                                        sentido = 'DECRECIENTE'
                                    # print 'COINCIDE CON Punto %s M=%s'%(npoint, point[2])
                                    break

                                else:
                                    # Se debe analizar si el punto es M=Null
                                    if (pk>=Mprev and pk<point[2]) or (pk<=Mprev and pk>point[2]):
                                        # El PK está entre el vértice previo y el siguiente
                                        if pk>=Mprev and pk<point[2]:
                                            sentido = 'CRECIENTE'
                                        else:
                                            sentido = 'DECRECIENTE'
                                        Psig = ogr.Geometry(ogr.wkbPoint)
                                        Psig.AddPoint(point[0], point[1])
                                        # print 'SENTIDO- %s , ENCONTRADO ENTRE Punto %s M=%s %s M=%s'%(sentido, npointprev, Mprev, npoint+1, point[2])
                                        r = (pk - Mprev) / (point[2] - Mprev)
                                        modulo = r * (Pprev.Distance(Psig))

                                        alfa = math.atan2((point[1] - Yprev ) , (point[0]  - Xprev))

                                        x = Xprev + modulo * math.cos(alfa)
                                        y = Yprev + modulo * math.sin(alfa)

                                        # CALCULO DEL ACIMUT
                                        pointANT = QgsPointXY(Xprev,Yprev)
                                        pointPOS = QgsPointXY(x,y)
                                        res1 = self.calcACIMUT(pointANT,pointPOS)
                                        acim= res1[1]
                                        # if acim < 0:
                                            # acim += 360

                                        pkencontrado = 1
                                        break
                            else:
                                # M es None
                                pass


                            # El PK no está en este segmento
                            npointprev += 1
                            npoint += 1
                            Pprev = point
                            Pprev = ogr.Geometry(ogr.wkbPoint)
                            Pprev.AddPoint(point[0], point[1])
                            Xprev = point[0]
                            Yprev = point[1]
                            Mprev = point[2]

                        npath += 1

                nfeat += 1

            if pkencontrado == 0 and features!=[]:
                # Analizamos los tramos entre paths para localizar el PK en los huecos

                listLimites.sort()
                # for limites in listLimites:
                    # print limites
                Tramo0 = 0
                Mini0 = listLimites[0][0]
                Mfin0 = listLimites[0][3]
                Xfin0 = listLimites[0][4]
                Yfin0 = listLimites[0][5]
                for limites in listLimites[1:]:
                    Mini1 = limites[0]
                    Mfin1 = limites[3]
                    Xini1 = limites[1]
                    Yini1 = limites[2]
                    if (pk>Mfin0 and pk<Mini1):
                        # Encontramos el PK en un hueco
                        # print 'Encontramos el PK en un hueco -', Mfin0, Mini1

                        Pprev = ogr.Geometry(ogr.wkbPoint)
                        Pprev.AddPoint(Xfin0, Yfin0)
                        Psig = ogr.Geometry(ogr.wkbPoint)
                        Psig.AddPoint(Xini1, Yini1)

                        r = (pk - Mfin0) / (Mini1 - Mfin0)
                        modulo = r * (Pprev.Distance(Psig))
                        alfa = math.atan2((Yini1-Yfin0) , (Xini1-Xfin0))
                        x = Xfin0 + modulo * math.cos(alfa)
                        y = Yfin0 + modulo * math.sin(alfa)
                        # print 'r=%s mod=%s alfa=%s '%(r,modulo,alfa)
                        # print 'Xfin0=%s Yfin0=%s Xini1=%s Yini1=%s'%(Xfin0, Yfin0, Xini1, Yini1)
                        res1 = self.calcACIMUT(QgsPointXY(Xfin0, Yfin0),QgsPointXY(Xini1, Yini1))
                        acim= res1[1]
                        # if acim < 0:
                            # acim += 360
                        pkencontrado = 1
                        # print x,y, acim
                        break

                    Tramo0 += 1
                    Mini0 = Mini1
                    Mfin0 = Mfin1
                    Xfin0 = limites[4]
                    Yfin0 = limites[5]
                pass


            if pkencontrado == 1:
                Xmin =  291000
                Ymin = 4205000
                Xmax =  680000
                Ymax = 4576000
                if (x < Xmin or x > Xmax or y < Ymin or y > Ymax):
                    # print 'Las coordenadas no caen en CLM'
                    QApplication.restoreOverrideCursor()
                    return 'Error: Las coordenadas no caen en CLM'
                return x,y,acim
            else:
                # print 'El PK no esta en el tramo'
                QApplication.restoreOverrideCursor()
                return 'Error: El PK no esta en el tramo'
            nfeat += 1

    '''
    def CtraPktoCoorsAcim(self, road_name, pk):
        # CtraPktoCoorsAcim(self, road_name, pk)
        #   Rutina de transformación de CARRETERA, PK a X, Y, Acim
        #   return x,y
        #   return None

        if (road_name == ""):
            return 'Error: Carretera sin nombre'
        url = self.current_configuration.environment["rest_carreteras"]
        posSPC = road_name.find(' ')
        r_name = road_name
        if posSPC != -1 :
            r_name = road_name[:posSPC+2]
            whereCONS = self.current_configuration.lrs["identificador_carretera_carreteras"] + " like '" + r_name + u"%' and Matricula <> '9000'"
        else:
            whereCONS = self.current_configuration.lrs["identificador_carretera_carreteras"] + " = '" + r_name + u"' and Matricula <> '9000'"
        # print posSPC, r_name+'oooo'
        values = {'where' : whereCONS,
        # values = {'where' :  self.current_configuration.lrs["identificador_carretera_carreteras"] + " = '" + road_name + u"'",
                  'text': '',
                  'objectIds': '',
                  'geometryType' : 'esriGeometryPolyline',
                  'returnGeometry' : 'true',
                  'returnM': 'true' ,
                  'f': 'json'}


        data = urllib.parse.urlencode(values)
        response = json.load(urllib.request.urlopen(url+data))
        try:
            features =  response["features"]
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.CtraPktoCoorsAcim LIN:384)")
            return 'Error: No hay elementos'
        nfeat = 1
        pkencontrado = 0
        acim = 360
        listLimites= []

        if len(features) == 0:
            return 'Error: Matricula Incorrecta'

        for feat in features:
            npath = 1
            if pkencontrado == 1:
                break
            # print nfeat, ' de ',len(features), ' features'
            if feat is not None:
                geometry = feat["geometry"]
                paths = geometry["paths"]
                for path in paths:
                    posini = 0
                    posfin = len(path)-1
                    while path[posini][2] == None and posini<len(path)-1:    # Buscamos el primer punto del tramo sin valor None
                        # print ('posini ',posini, path[posini][2])
                        posini+=1
                    while path[posfin][2] == None and posfin>0:              # Buscamos el último punto del tramo sin valor None
                        # print ('posfin ',posfin, path[posfin][2])
                        posfin-=1
                    if path[posini][2] == None or path[posfin][2] == None:
                        continue

                    # print ('INI-  ',path[posini][2],'  FIN-  ',path[posfin][2])
                    if path[posini][2]<path[posfin][2]: # Sentido CRECIENTE
                        limites = [path[posini][2],path[posini][0],path[posini][1],path[posfin][2],path[posfin][0],path[posfin][1]]
                    else:   # Sentido DECRECIENTE
                        limites = [path[posfin][2],path[posfin][0],path[posfin][1],path[posini][2],path[posini][0],path[posini][1]]
                    listLimites.append(limites)
                    # print '%s de %s paths - %s puntos'%(npath, len(paths), len(path))
                    # print limites
                    npointprev = 0
                    npoint = 1
                    if pkencontrado == 1:
                        break
                    Mprev = None
                    # Mprev = 0.0
                    while (Mprev == None and npointprev<len(path)):
                        Pprev = path[npointprev]
                        Pprev = ogr.Geometry(ogr.wkbPoint)
                        Pprev.AddPoint(path[npointprev][0], path[npointprev][1])
                        Xprev = path[npointprev][0]
                        Yprev = path[npointprev][1]
                        Mprev = path[npointprev][2]
                        sentido = 'CRECIENTE'
                        iniloop = npointprev+1
                        npointprev += 1
                    if npointprev == len(path):
                        break

                    for npoint in range(iniloop,len(path)):
                        point = path[npoint]
                        # print '    PRE {:.0f} {:.2f} {:.2f} {:.7f}'.format(npointprev, Xprev, Yprev, Mprev),
                        # print '    ACT {:.0f} {:.2f} {:.2f} {:.7f}'.format(npoint+1, point[0], point[1], point[2])
                        if(point[2] is not None):
                            if point[2] == pk:
                                # El PK es el vértice
                                x = point[0]
                                y = point[1]

                                # CALCULO DEL ACIMUT
                                pointANT = QgsPointXY(Xprev,Yprev)
                                pointPOS = QgsPointXY(x,y)
                                res1 = self.calcACIMUT(pointANT,pointPOS)
                                acim= res1[1]
                                if acim < 0:
                                    acim += 360

                                pkencontrado = 1
                                if point[2]> path[(point in path)+1][2]:
                                    sentido = 'DECRECIENTE'
                                # print 'COINCIDE CON Punto %s M=%s'%(npoint, point[2])
                                break

                            else:
                                # Se debe analizar si el punto es M=Null
                                if (pk>=Mprev and pk<point[2]) or (pk<=Mprev and pk>point[2]):
                                    # El PK está entre el vértice previo y el siguiente
                                    if pk>=Mprev and pk<point[2]:
                                        sentido = 'CRECIENTE'
                                    else:
                                        sentido = 'DECRECIENTE'
                                    Psig = ogr.Geometry(ogr.wkbPoint)
                                    Psig.AddPoint(point[0], point[1])
                                    # print 'SENTIDO- %s , ENCONTRADO ENTRE Punto %s M=%s %s M=%s'%(sentido, npointprev, Mprev, npoint+1, point[2])
                                    r = (pk - Mprev) / (point[2] - Mprev)
                                    modulo = r * (Pprev.Distance(Psig))

                                    alfa = math.atan2((point[1] - Yprev ) , (point[0]  - Xprev))

                                    x = Xprev + modulo * math.cos(alfa)
                                    y = Yprev + modulo * math.sin(alfa)

                                    # CALCULO DEL ACIMUT
                                    pointANT = QgsPointXY(Xprev,Yprev)
                                    pointPOS = QgsPointXY(x,y)
                                    res1 = self.calcACIMUT(pointANT,pointPOS)
                                    acim= res1[1]
                                    # if acim < 0:
                                        # acim += 360

                                    pkencontrado = 1
                                    break
                        else:
                            # M es None
                            pass


                        # El PK no está en este segmento
                        npointprev += 1
                        npoint += 1
                        Pprev = point
                        Pprev = ogr.Geometry(ogr.wkbPoint)
                        Pprev.AddPoint(point[0], point[1])
                        Xprev = point[0]
                        Yprev = point[1]
                        Mprev = point[2]

                    npath += 1

            nfeat += 1

        if pkencontrado == 0 and features!=[]:
            # Analizamos los tramos entre paths para localizar el PK en los huecos

            listLimites.sort()
            # for limites in listLimites:
                # print limites
            Tramo0 = 0
            Mini0 = listLimites[0][0]
            Mfin0 = listLimites[0][3]
            Xfin0 = listLimites[0][4]
            Yfin0 = listLimites[0][5]
            for limites in listLimites[1:]:
                Mini1 = limites[0]
                Mfin1 = limites[3]
                Xini1 = limites[1]
                Yini1 = limites[2]
                if (pk>Mfin0 and pk<Mini1):
                    # Encontramos el PK en un hueco
                    # print 'Encontramos el PK en un hueco -', Mfin0, Mini1

                    Pprev = ogr.Geometry(ogr.wkbPoint)
                    Pprev.AddPoint(Xfin0, Yfin0)
                    Psig = ogr.Geometry(ogr.wkbPoint)
                    Psig.AddPoint(Xini1, Yini1)

                    r = (pk - Mfin0) / (Mini1 - Mfin0)
                    modulo = r * (Pprev.Distance(Psig))
                    alfa = math.atan2((Yini1-Yfin0) , (Xini1-Xfin0))
                    x = Xfin0 + modulo * math.cos(alfa)
                    y = Yfin0 + modulo * math.sin(alfa)
                    # print 'r=%s mod=%s alfa=%s '%(r,modulo,alfa)
                    # print 'Xfin0=%s Yfin0=%s Xini1=%s Yini1=%s'%(Xfin0, Yfin0, Xini1, Yini1)
                    res1 = self.calcACIMUT(QgsPointXY(Xfin0, Yfin0),QgsPointXY(Xini1, Yini1))
                    acim= res1[1]
                    # if acim < 0:
                        # acim += 360
                    pkencontrado = 1
                    # print x,y, acim
                    break

                Tramo0 += 1
                Mini0 = Mini1
                Mfin0 = Mfin1
                Xfin0 = limites[4]
                Yfin0 = limites[5]
            pass


        if pkencontrado == 1:
            Xmin =  291000
            Ymin = 4205000
            Xmax =  680000
            Ymax = 4576000
            if (x < Xmin or x > Xmax or y < Ymin or y > Ymax):
                # print 'Las coordenadas no caen en CLM'
                QApplication.restoreOverrideCursor()
                return 'Error: Las coordenadas no caen en CLM'
            return x,y,acim
        else:
            # print 'El PK no esta en el tramo'
            QApplication.restoreOverrideCursor()
            return 'Error: El PK no esta en el tramo'
        nfeat += 1
    '''

    def pointToPK(self,point,iface,pintar,no9000):
        # pointToPK(self,point,iface,pintar,no9000)
        #   Devuelve diferentes datos de salida de una carretera a partir de un punto
        #       return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE]
        #   ENTRADA:
        #       point- Geometria punto (x,y)
        #       iface- Interface de la vista
        #       pintar- 'SI', 'NO'
        #       no9000= 'SI', 'NO' - SI Busca primero matriculas NO 9000
        #       noJCCM= 'SI', 'NO' - NO Busca primero matriculas Titularidad=JCCM
        #   SALIDA:
        #       0 the_road - Matricula de la carretera
        #       1 m_final - Valor M (PK) de las coordenadas.
        #       2 the_road - Matricula de la carretera ############## ¿repetida? ##############
        #       3 funcion - Funcionalidad de la via
        #       4 atributos - Conjunto compelto de atributos como los devuelve el REST
        #       5 distEJE - Distancia del punto al eje
        #       6 acimEJE - Acimut del punto perpendicular del eje
        #       7 pointEJE- Punto en el eje (coordenas XY)

        # no9000= 'SI'

        clicked_QgsPoint = QgsPointXY(point[0],point[1])
        qgs_point_geometry = QgsGeometry.fromPointXY(QgsPointXY(point[0],point[1]))

        # Hacemos una consulta a la GDB de las vías en un cuadrado de 'margin'x'margin' con entro en point
        #************************************************************************************************************************
        #************************************************************************************************************************
        #************************************************************************************************************************
        #************************************************************************************************************************
        #   TODO ESTO ESTÁ EN REVISIÓN
        #************************************************************************************************************************
        #************************************************************************************************************************
        #************************************************************************************************************************
        #************************************************************************************************************************
        # print ('functions3.py - pointToPK - linea 280')
        margin = 100        # Margen de búsqueda de viales en la GDB
        # print '{"xmin":' + str(point[0] - margin) + ', "ymin": ' + str(point[1] - margin) + ' , "xmax":' + str(point[0] + margin) + ' , "ymax": ' + str(point[1] + margin) + ' , "spatialReference": {25830}}'
        url = self.current_configuration.environment["rest_carreteras"]
        values = {'where' : '',
                  'text': '',
                  'objectIds': '',
                  'outFields': '*',
                  'geometry':'{"xmin": ' + str(point[0] - margin) + ' , "ymin": ' + str(point[1] - margin) + ' , "xmax": ' + str(point[0] + margin) + ' , "ymax": ' + str(point[1] + margin) + ' , "spatialReference":{srcVal}}',
                  'geometryType' : 'esriGeometryEnvelope',
                  'returnGeometry' : 'true',
                  'spatialRel': 'esriSpatialRelIntersects',
                  'returnM': 'true' ,
                  'f': 'json'}

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        try:
            response = json.load(urllib.request.urlopen(url+data))
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet")
            return

        features =  response["features"]    # Los distintos features encontrados en la búsqueda

        c_distance = 100000     # Distancia límite de cálculo, por debajo no devuelve datos, se reduce con todas las dist calculadas
        the_feature = None
        qgsLines = []
        the_line = None
        the_road = None
        matric = None
        funcion = None
        atributos = None
        featsProx = []
        numFeat = 1
        for feature in features:
            polyline = []
            geometry = feature["geometry"]
            attr =  feature["attributes"]
            # print (attr)
            # plan = attr['Matricula_Plan'] # Matrícula_plan del elemento
            matric = attr['Matricula']        # Matrícula del elemento
            Titu = attr['Titularidad']      # Titularidad del elemento

            funcion = attr['Funcionalidad']
            paths = geometry["paths"]
            # points = []
            for path in paths:
                for point in path:
                    polyline.append(QgsPoint(point[0],point[1]))
            gLine = QgsGeometry.fromPolyline(polyline)
            distance = gLine.distance(qgs_point_geometry)
            # print distance , matric
            featsProx.append([matric, Titu, distance, gLine, feature, attr, numFeat])

            if distance <= c_distance:
                the_road = matric
                c_distance = distance
                the_line = gLine
                the_feature = feature
                # atributos = featAttributes
                atributos = attr
            numFeat += 1

        ###############################################################
        ###### Esto se debe rehacer para dar prioridad a:        ######
        ######  - Elementos tronco sobre elementos 9000          ######
        ######  - Elementos Titularidad=JCCM sobre el resto      ######
        ###############################################################
        # Analizar si matric = 9000
        if no9000 == 'SI' and the_road == '9000':
            c_distance = 1000000
            for featP in featsProx:
                if featP[0] != '9000':
                    if featP[2] <= c_distance:
                        the_road = featP[0]
                        c_distance = featP[2]
                        the_line = featP[3]
                        the_feature = featP[4]
                        # atributos = featAttributes
                        atributos = featP[5]
                    pass

        # print featP[0], featP[1], featP[2],
        # print ''

        ###############################################################
        ###### Esto se debe rehacer                              ######
        ###############################################################

        if the_line == None:
            return None

        closest_point_geometry = the_line.nearestPoint(qgs_point_geometry) # Punto más próximo al eje mas próximo

        closest_x = closest_point_geometry.asPoint().x()
        closest_y = closest_point_geometry.asPoint().y()

        res = the_line.closestSegmentWithContext(closest_point_geometry.asPoint())

        res2 = the_line.closestSegmentWithContext(clicked_QgsPoint)

        if pintar == 'SI':
            m = self.dibujarPunto(res2[1][0],res2[1][1],iface)

        closest_point_segment =  QgsPointXY(res2[1][0],res2[1][1])
        closest_vertex = res2[2]

        try:
            codigo_linea_m = ogr.wkbLineStringM
        except:
            # print "libreria ogr error"
            codigo_linea_m = 2002

        line_ogr = ogr.Geometry(codigo_linea_m)


        c_distance = 100000
        geometry = the_feature["geometry"]
        paths = geometry["paths"]
        points = []
        last_m = None
        creciente = True

        for path in paths:
            for point in path:
                gPnt = QgsGeometry.fromPointXY(QgsPointXY(point[0],point[1]))
                if(point[2] == None):
                    QgsMessageLog.logMessage("Ojo.. valor sin M","jccm_plugin")
                    line_ogr.AddPoint(point[0],point[1])
                    #return [the_road,"Eje no calibrado"]
                else:
                    line_ogr.AddPointM(point[0],point[1],point[2])
                distance = gPnt.distance(closest_point_geometry)
                if distance < c_distance:
                    c_distance = distance
                    last_m = point[2]

        if(line_ogr.GetM(1) < line_ogr.GetM(0)):
            creciente = False
        # print "Creciente=?"
        # print creciente
        #TODO buscar los dos mas proximos y encontrar el punto intermedio de interseccion....
        #De momento solo devuelve el pk de vertice mas proximo...

        closest_vertex_anterior = closest_vertex - 1
        next_vertex = closest_vertex_anterior + 1
        if(creciente == False):
            closest_vertex_anterior = closest_vertex
            next_vertex = closest_vertex_anterior - 1


        m_anterior = line_ogr.GetM(closest_vertex_anterior)
        m_posterior = line_ogr.GetM(next_vertex)
        # print "Las emes ..."
        # print m_anterior
        # print m_posterior

        target_point = ogr.Geometry(ogr.wkbPoint)
        target_point.AddPoint(res2[1][0], res2[1][1])

        punto_anterior = ogr.Geometry(ogr.wkbPoint)
        punto_anterior.AddPoint(line_ogr.GetPoint(closest_vertex_anterior)[0],line_ogr.GetPoint(closest_vertex_anterior)[1])
        #self.dibujarPunto(line_ogr.GetPoint(closest_vertex_anterior)[0],line_ogr.GetPoint(closest_vertex_anterior)[1],iface,255,0,0)

        punto_posterior = ogr.Geometry(ogr.wkbPoint)
        punto_posterior.AddPoint(line_ogr.GetPoint(next_vertex)[0],line_ogr.GetPoint(next_vertex)[1])
        #self.dibujarPunto(line_ogr.GetPoint(next_vertex)[0],line_ogr.GetPoint(next_vertex)[1],iface,0,0,255)

        #m_final = m_anterior + ((m_posterior - m_anterior)/( punto_anterior.Distance(target_point)))

        m_final = m_anterior + (punto_anterior.Distance(target_point) / punto_posterior.Distance(punto_anterior)) * (m_posterior - m_anterior)

        # print "M final"
        # print m_final

        pointEJE = QgsPointXY(closest_x,closest_y)
        pointANT = QgsPointXY(line_ogr.GetPoint(closest_vertex_anterior)[0],line_ogr.GetPoint(closest_vertex_anterior)[1])
        pointPOS = QgsPointXY(line_ogr.GetPoint(next_vertex)[0],line_ogr.GetPoint(next_vertex)[1])

        # CALCULO DEL ACIMUT
        res = self.calcACIMUT(clicked_QgsPoint,pointEJE)
        res1 = self.calcACIMUT(pointANT,pointPOS)

        acimTRANS= res[1]
        acimEJE= res1[1]
        lado = (acimEJE - acimTRANS)
        if fabs(lado) > 180:
            if lado > 0:
                lado = -(lado-180)
            else:
                lado = -(lado+180)

        vlado = lado/90
        distEJE= res[0] * vlado
        if acimEJE < 0:
            acimEJE += 360

        # print (geometry)
        #return        0        1         2        3          4        5        6         7,        8
        return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE, pointEJE, geometry]


    def calcACIMUT(self, point1, point2):
        # calcACIMUT(self, point1, point2)
        #   Calcula el acimut y la distancia entre dos puntos point1, point2

        dist= point1.distance(point2)
        acim = point1.azimuth(point2)
        if acim < 0:
            acim += 360
        return (dist, acim)


    def pointToPKfich(self,point,iface,pintar,no9000, tipoCapa):
        # pointToPK(self,point,iface,pintar,no9000)
        #   Devuelve diferentes datos de salida de una carretera a partir de un punto
        #       return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE]
        #   ENTRADA:
        #       point- Geometria punto (x,y)
        #       iface- Interface de la vista
        #       pintar- 'SI', 'NO'
        #       no9000= 'SI', 'NO' - SI Busca primero matriculas NO 9000
        #       tipoCapa=1 Capa tipo carreteras, tipoCapa=0 Capa de lineas estandard
        #   SALIDA:
        #       0  the_road - Matricula de la carretera
        #       1  m_final - Valor M (PK) de las coordenadas.
        #       2  the_road - Matricula de la carretera ############## ¿repetida? ##############
        #       3  funcion - Funcionalidad de la via
        #       4  atributos - Conjunto compelto de atributos como los devuelve el REST
        #       5  distEJE - Distancia del punto al eje
        #       6  acimEJE - Acimut del punto perpendicular del eje
        #       7  pointEJE- Punto en el eje (coordenas XY)
        #       8  geometry- Geometria del elemento
        #       9  distINI - Distancia al inicio del elemento
        #       10 distFIN - Distancia al final del elemento

        clicked_QgsPoint = QgsPointXY(point[0],point[1])
        # qgs_point_geometry = QgsGeometry.fromPointXY(QgsPointXY(point[0],point[1]))
        qgs_point_geometry = QgsGeometry.fromPointXY(clicked_QgsPoint)

        margin = 100        # Margen de búsqueda de viales en la GDB

        layer = iface.activeLayer()
        featuresLine = layer.getFeatures()

        rectMargin = QgsRectangle(point[0] - margin, point[1] - margin, point[0] + margin, point[1] + margin)

        # points.select(feature.id())

        # SpInd = QgsSpatialIndex(featuresT)
        # closefids = SpInd.intersects(QgsRectangle(point[0] - margin,
                                                  # point[1] - margin,
                                                  # point[0] + margin,
                                                  # point[1] + margin))

        # if  len(list(closefids)) < 0:
            # return None

        # self.showJCCMessage( 'Se detectan '+ str(len(list(closefids))) + ' elementos' ,'','Identificador de Carreteras' )

        # for nearestid in closefids:
            # features = layer.getFeatures(QgsFeatureRequest(nearestid))

        c_distance = 100000     # Distancia límite de cálculo, por debajo no devuelve datos, se reduce con todas las dist calculadas
        the_feature = None
        qgsLines = []
        the_road = None
        matric = None
        funcion = None
        atributos = None
        the_lineM = None
        featsProx = []
        numFeat = 1

        message = ''

        for feature in featuresLine:
            polyline = []
            polylineM = [] ### Añadida M ###

            geom_line = feature.geometry()
            if geom_line.intersects(rectMargin):
                geometry = feature.geometry()
                attr = {}
                for field in layer.fields():
                    attr[field.name()] = feature[field.name()]
                # print (attr)

                if tipoCapa == 1:
                    matric = feature["Matricula"]        # Matrícula del elemento
                    Titu = feature["Titularidad"]      # Titularidad del elemento
                    funcion = feature["Funcionalidad"]
                else:
                    matric = 's/d'        # Matrícula del elemento
                    Titu = 's/d'      # Titularidad del elemento
                    funcion = 's/d'

                paths = []
                if geometry.isMultipart():
                    for part in geometry.asGeometryCollection():
                        paths.append(part)
                else:
                    paths.append(geometry)

                # Habría que corregir la creación de la polylineM para casos de pths invertidos
                for path in paths:
                    novertices = len(path.asPolyline())
                    for id in range(novertices):
                        pointP = path.vertexAt(id)
                        gPnt = QgsGeometry.fromPointXY(QgsPointXY(pointP.x(),pointP.y()))
                        if(pointP.m() == None):
                            QgsMessageLog.logMessage("Ojo.. valor sin M","jccm_plugin")
                            polylineM.append(QgsPoint(pointP.x(),pointP.y()))
                        else:
                            polylineM.append(QgsPoint(pointP.x(),pointP.y(),pointP.m()))

                gLineM = QgsGeometry.fromPolyline(polylineM)
                distance = gLineM.distance(qgs_point_geometry)

                featsProx.append([matric, Titu, distance, feature, attr, gLineM, numFeat])

                if distance <= c_distance:
                    the_road = matric
                    c_distance = distance
                    the_feature = feature
                    atributos = attr
                    the_lineM = gLineM
                numFeat += 1

                if tipoCapa == 1:
                    # message += 'MATRIC= '+matric+ ' DIST= '+ str(round(distance,2))+ '\n'
                    message += 'MATRIC= %s DIST= %s\n'%(matric, str(round(distance,2)))
                else:
                    message += next(iter(attr))+':'+str(next(iter(attr.values())))+ ' DIST= '+ str(round(distance,2))+ '\n'

        # Analizar si matric = 9000
        if no9000 == 'SI' and the_road == '9000':
            c_distance = 1000000
            for featP in featsProx:
                if featP[0] != '9000':
                    if featP[2] <= c_distance:
                        the_road = featP[0]
                        c_distance = featP[2]
                        the_feature = featP[3]
                        atributos = featP[4]
                        the_lineM = featP[5]
                    pass

        if the_lineM == None:
            return None

        self.showJCCMessage( message,'','Identificador de Carreteras' )

        closest_point_geometry, dist, punto_anterior, punto_posterior, m_final, distINI, distFIN = self.calculaMproximo(the_lineM, clicked_QgsPoint)

        pointEJE = QgsPointXY(closest_point_geometry.x(),closest_point_geometry.y())
        pointANT = QgsPointXY(punto_anterior.x(),punto_anterior.y())
        pointPOS = QgsPointXY(punto_posterior.x(),punto_posterior.y())

        if pintar == 'SI':
            m = self.dibujarPunto(closest_point_geometry.x(),closest_point_geometry.y(),iface)

        # CALCULO DEL ACIMUT
        res = self.calcACIMUT(clicked_QgsPoint,pointEJE)
        res1 = self.calcACIMUT(pointANT,pointPOS)

        acimTRANS= res[1]
        acimEJE= res1[1]
        lado = (acimEJE - acimTRANS)
        if fabs(lado) > 180:
            if lado > 0:
                lado = -(lado-180)
            else:
                lado = -(lado+180)

        vlado = lado/90
        distEJE= res[0] * vlado
        if acimEJE < 0:
            acimEJE += 360

        #return        0        1         2        3          4        5        6         7,        8        9       10
        return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE, pointEJE, geometry, distINI, distFIN]

    '''
    def pointToPKfich(self,point,iface,pintar,no9000, tipoCapa):
        # pointToPK(self,point,iface,pintar,no9000)
        #   Devuelve diferentes datos de salida de una carretera a partir de un punto
        #       return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE]
        #   ENTRADA:
        #       point- Geometria punto (x,y)
        #       iface- Interface de la vista
        #       pintar- 'SI', 'NO'
        #       no9000= 'SI', 'NO' - SI Busca primero matriculas NO 9000
        #       tipoCapa=1 Capa tipo carreteras, tipoCapa=0 Capa de lineas estandard
        #   SALIDA:
        #       0  the_road - Matricula de la carretera
        #       1  m_final - Valor M (PK) de las coordenadas.
        #       2  the_road - Matricula de la carretera ############## ¿repetida? ##############
        #       3  funcion - Funcionalidad de la via
        #       4  atributos - Conjunto compelto de atributos como los devuelve el REST
        #       5  distEJE - Distancia del punto al eje
        #       6  acimEJE - Acimut del punto perpendicular del eje
        #       7  pointEJE- Punto en el eje (coordenas XY)
        #       8  geometry- Geometria del elemento
        #       9  distINI - Distancia al inicio del elemento
        #       10 distFIN - Distancia al final del elemento

        clicked_QgsPoint = QgsPointXY(point[0],point[1])
        # qgs_point_geometry = QgsGeometry.fromPointXY(QgsPointXY(point[0],point[1]))
        qgs_point_geometry = QgsGeometry.fromPointXY(clicked_QgsPoint)

        margin = 100        # Margen de búsqueda de viales en la GDB

        layer = iface.activeLayer()
        featuresT = layer.getFeatures()
        SpInd = QgsSpatialIndex(featuresT)
        closefids = SpInd.intersects(QgsRectangle(point[0] - margin,
                                                  point[1] - margin,
                                                  point[0] + margin,
                                                  point[1] + margin))

        if  len(list(closefids)) < 0:
            return None

        # self.showJCCMessage( 'Se detectan '+ str(len(list(closefids))) + ' elementos' ,'','Identificador de Carreteras' )

        for nearestid in closefids:
            features = layer.getFeatures(QgsFeatureRequest(nearestid))

        c_distance = 100000     # Distancia límite de cálculo, por debajo no devuelve datos, se reduce con todas las dist calculadas
        the_feature = None
        qgsLines = []
        the_line = None
        the_road = None
        matric = None
        funcion = None
        atributos = None
        featsProx = []
        numFeat = 1

        message = ''

        for feature in features:
            polyline = []
            polylineM = [] ### Añadida M ###

            geometry = feature.geometry()
            attr = {}
            for field in layer.fields():
                attr[field.name()] = feature[field.name()]
            # print (attr)

            if tipoCapa == 1:
                matric = feature["Matricula"]        # Matrícula del elemento
                Titu = feature["Titularidad"]      # Titularidad del elemento
                funcion = feature["Funcionalidad"]
            else:
                matric = 's/d'        # Matrícula del elemento
                Titu = 's/d'      # Titularidad del elemento
                funcion = 's/d'

            paths = []
            if geometry.isMultipart():
                for part in geometry.asGeometryCollection ():
                    paths.append(part)
            else:
                paths.append(geometry)

            polyline = []
            for path in paths:
                novertices = len(path.asPolyline())
                for id in range(novertices):
                    pointP = path.vertexAt(id)
                    gPnt = QgsGeometry.fromPointXY(QgsPointXY(pointP.x(),pointP.y()))
                    if(pointP.m() == None):
                        QgsMessageLog.logMessage("Ojo.. valor sin M","jccm_plugin")
                        polylineM.append(QgsPoint(pointP.x(),pointP.y()))  ### Añadida M ###
                    else:
                        polylineM.append(QgsPoint(pointP.x(),pointP.y(),pointP.m()))  ### Añadida M ###

            gLine = QgsGeometry.fromPolyline(polyline)
            gLineM = QgsGeometry.fromPolyline(polylineM) ### Añadida M ###
            distance = gLine.distance(qgs_point_geometry)

            # print (distance , matric)
            featsProx.append([matric, Titu, distance, gLine, feature, attr, numFeat, gLineM])

            if distance <= c_distance:
                the_road = matric
                c_distance = distance
                the_line = gLine
                the_feature = feature
                atributos = attr
                the_lineM = gLineM
            numFeat += 1

            message += 'MATRIC= '+matric+ ' DIST= '+ str(round(distance,2))+ '\n'

        self.showJCCMessage( message,'','Identificador de Carreteras' )


        # Analizar si matric = 9000
        if no9000 == 'SI' and the_road == '9000':
            c_distance = 1000000
            for featP in featsProx:
                if featP[0] != '9000':
                    if featP[2] <= c_distance:
                        the_road = featP[0]
                        c_distance = featP[2]
                        the_line = featP[3]
                        the_feature = featP[4]
                        atributos = featP[5]
                        the_lineM = featP[6]    ### Añadida M ###
                    pass

        if the_line == None:
            return None

        closest_point_geometry, dist, punto_anterior, punto_posterior, m_final, distINI, distFIN = self.calculaMproximo(the_lineM, clicked_QgsPoint)

        pointEJE = QgsPointXY(closest_point_geometry.x(),closest_point_geometry.y())
        pointANT = QgsPointXY(punto_anterior.x(),punto_anterior.y())
        pointPOS = QgsPointXY(punto_posterior.x(),punto_posterior.y())

        if pintar == 'SI':
            m = self.dibujarPunto(closest_point_geometry.x(),closest_point_geometry.y(),iface)

        # CALCULO DEL ACIMUT
        res = self.calcACIMUT(clicked_QgsPoint,pointEJE)
        res1 = self.calcACIMUT(pointANT,pointPOS)

        acimTRANS= res[1]
        acimEJE= res1[1]
        lado = (acimEJE - acimTRANS)
        if fabs(lado) > 180:
            if lado > 0:
                lado = -(lado-180)
            else:
                lado = -(lado+180)

        vlado = lado/90
        distEJE= res[0] * vlado
        if acimEJE < 0:
            acimEJE += 360

        # print (geometry)
        #return        0        1         2        3          4        5        6         7,        8        9       10
        return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE, pointEJE, geometry, distINI, distFIN]
    '''

    def poligToPKINIPKFIN(self, geomPol, iface, no9000):

        # poligToPKINIPKFIN(geomPol, iface, no9000)
        #   Devuelve diferentes datos de salida de una carretera a partir de un punto
        #       return (ctraBusq, mmin, mmax)
        #   ENTRADA:
        #       geomPol- Geometria del polígono
        #       iface- Interface de la vista
        #       noJCCM= 'SI', 'NO' - NO Busca primero matriculas Titularidad=JCCM
        #   SALIDA:
        #       0 ctraBusq - Matricula de la carretera
        #       1 mmin - Valor M (PK) del mínimo PK próximo del polígono
        #       2 mmax - Valor M (PK) del máximo PK próximo del polígono
        precision = 3

        if geomPol.isMultipart():
            polygon = geomPol.asMultiPolygon()
            single = False
        else:
            polygon = geomPol.asPolygon()
            single = True


        geomXY = geomPol.asWkt().replace('MultiPolygon ','')
        # print (geomXY)

        resultINT = geomPol.poleOfInaccessibility(precision)    # Obtenemos el poleOfInaccessibility del polígono

        centerPolig = resultINT[0].asPoint()
        qgs_point_geometry = QgsGeometry.fromPointXY(QgsPointXY(centerPolig[0],centerPolig[1]))

        # Hacemos una consulta a la GDB de las vías en un cuadrado de 'margin'x'margin' con centro en centerPolig
        ####################################################################################################################################
        ######
        ######    PODEMOS BUSCAR CON BOUNDING BOX + BUFFER
        ######
        ####################################################################################################################################
        margin = resultINT[1] + 1000         # Margen de búsqueda de viales en la GDB
        url = current_configuration.environment["rest_carreteras"]
        '''
        values = {'where' : '',
                  'text': '',
                  'objectIds': '',
                  'outFields': '*',
                  ####   VER ESTO CON BOUNDING BOX
                  'geometry':'{"xmin": ' + str(centerPolig[0] - margin) + ' , "ymin": ' + str(centerPolig[1] - margin) + ' , "xmax": ' + str(centerPolig[0] + margin) + ' , "ymax": ' + str(centerPolig[1] + margin),
                  'geometryType' : 'esriGeometryEnvelope',
                  ####
                  'spatialReference': srcVal ,
                  'outSR' : srcVal,
                  'geometryPrecision': 3,
                  'returnGeometry' : 'true',
                  'spatialRel': 'esriSpatialRelIntersects',
                  'returnM': 'true' ,
                  'f': 'json'}
        '''

        values = {'where' : '',
                  'text': '',
                  'objectIds': '',
                  'outFields': '*',
                  ####   VER ESTO CON BOUNDING BOX
                  'geometry':'{"xmin": ' + str(centerPolig[0] - margin) + ' , "ymin": ' + str(centerPolig[1] - margin) + ' , "xmax": ' + str(centerPolig[0] + margin) + ' , "ymax": ' + str(centerPolig[1] + margin),
                  #'geometry':'{"xmin": ' + str(centerPolig[0] + ' , "ymin": ' + str(centerPolig[1] + ' , "xmax": ' + str(centerPolig[0] + ' , "ymax": ' + str(centerPolig[1]),
                  'geometryType' : 'esriGeometryEnvelope',
                  ####

                  ####   prueba con Poligono
                  # 'geometries' : geomPol.asWkt(),
                  # 'geometryType' : 'esriGeometryPolygon',
                  # 'distances' : 1000,
                  'bufferSR' : srcVal,
                  ####

                  'spatialReference' : srcVal,
                  'outSR' : srcVal,
                  'geometryPrecision': 3,
                  'returnGeometry' : 'true',
                  'spatialRel': 'esriSpatialRelIntersects',
                  'returnM': 'true' ,
                  'f': 'json'}



        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        print ('fun.poligToPKINIPKFIN: ',url+data)
        try:
            response = json.load(urllib.request.urlopen(url+data))
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet")
            return

        try:
            features =  response["features"]    # Los distintos features encontrados en la búsqueda
        except:
            return None, None, None, None


        c_distance = 100000     # Distancia límite de cálculo, por debajo no devuelve datos, se reduce con todas las dist calculadas
        the_feature = None
        qgsLines = []
        the_line = None
        ctraBusq = None
        matric = None
        funcion = None
        atributos = None
        featsProx = []
        numFeat = 1

        for feature in features:
            polyline = []
            polylineM = [] ### Añadida M ###

            geometry = feature["geometry"]
            attr =  feature["attributes"]
            matric = attr['Matricula']          # Matrícula del elemento
            Titu = attr['Titularidad']          # Titularidad del elemento

            funcion = attr['Funcionalidad']
            paths = geometry["paths"]
            # points = []
            for path in paths:
                for point in path:
                    polyline.append(QgsPoint(point[0],point[1]))
                    polylineM.append(QgsPoint(point[0],point[1],point[2]))  ### Añadida M ###

            gLine = QgsGeometry.fromPolyline(polyline)
            gLineM = QgsGeometry.fromPolyline(polylineM) ### Añadida M ###
            distance = gLine.distance(qgs_point_geometry) # Se calcula la distancia del centroide al elemento particular
            featsProx.append([matric, Titu, distance, gLine, feature, attr, numFeat, gLineM])

            if distance <= c_distance:
                ctraBusq = matric
                c_distance = distance
                the_line = gLine
                the_feature = feature
                atributos = attr
                the_lineM = gLineM ### Añadida M ###
            numFeat += 1

        ###############################################################
        ###### Esto se debe rehacer para dar prioridad a:        ######
        ######  - Elementos tronco sobre elementos 9000          ######
        ######  - Elementos Titularidad=JCCM sobre el resto      ######
        ######      aunque tuvieran mayor distancia              ######
        ###############################################################
        # Analizar si matric = 9000
        if no9000 == 'SI' and ctraBusq == '9000':
            c_distance = 1000000
            for featP in featsProx:             # Se analiza cada una de las feats Próximas
                if featP[0] != '9000':
                    if featP[2] <= c_distance:
                        ctraBusq = featP[0]
                        c_distance = featP[2]
                        the_line = featP[3]
                        the_feature = featP[4]
                        atributos = featP[5]
                        the_lineM = featP[6]    ### Añadida M ###
                    pass

        if the_line == None:
            return None, None, None, None


        # EMPEZAMOS A HACER LOS CÁLCULOS SOBRE LA LINEA

        cadena =''
        mmin = 1000000
        mmax = 0
        for parte in polygon:
            cadena += 'Poligono '+str(polygon.index(parte)+1)+'\n'
            i=1
            if single:
                for pto in parte:
                    cadena += " ".join([str(i),' - ',"{:.{}f}".format(pto[0], precision),' - ',"{:.{}f}".format(pto[1], precision),'\n'])
                    closest_point_geometry, dist, punto_anterior, punto_posterior, m_final, distINI, distFIN = self.calculaMproximo(the_lineM, pto)
                    # print (closest_point_geometry, dist, punto_anterior, punto_posterior, m_final)
                    if m_final == 'nan':
                        # print ('ctraBusq= ', ctraBusq,'PKINI: ', mmin, 'PKFIN: ', mmax)
                        return ctraBusq, 'Ctra sin PK', 'Ctra sin PK'
                    if m_final < mmin:
                        mmin = m_final
                    if m_final > mmax:
                        mmax = m_final
                    i += 1
            else:
                for pto in parte[0]:
                    cadena += " ".join([str(i),' - ',"{:.{}f}".format(pto[0], precision),' - ',"{:.{}f}".format(pto[1], precision),'\n'])
                    closest_point_geometry, dist, punto_anterior, punto_posterior, m_final, distINI, distFIN = self.calculaMproximo(the_lineM, pto)
                    # print (closest_point_geometry, dist, punto_anterior, punto_posterior, m_final)
                    if m_final < mmin:
                        mmin = m_final
                    if m_final > mmax:
                        mmax = m_final
                    i += 1

        pointCentroid = QgsPointXY(centerPolig[0],centerPolig[1])
        pointEJE = QgsPointXY(closest_point_geometry.x(),closest_point_geometry.y())
        pointANT = QgsPointXY(punto_anterior.x(),punto_anterior.y())
        pointPOS = QgsPointXY(punto_posterior.x(),punto_posterior.y())

        # CALCULO DEL ACIMUT
        res = self.calcACIMUT(pointCentroid,pointEJE)
        res1 = self.calcACIMUT(pointANT,pointPOS)

        acimTRANS= res[1]
        acimEJE= res1[1]
        lado = (acimEJE - acimTRANS)
        if fabs(lado) > 180:
            if lado > 0:
                lado = -(lado-180)
            else:
                lado = -(lado+180)

        vlado = lado/90
        distEJE= res[0] * vlado
        if acimEJE < 0:
            acimEJE += 360

        if mmin == 1000000:
            # print ('ctraBusq= ', ctraBusq,'PKINI: ', mmin, 'PKFIN: ', mmax)
            return ctraBusq, 'Ctra sin PK', 'Ctra sin PK', distEJE
        # print ('ctraBusq= ', ctraBusq,'PKINI: ', mmin, 'PKFIN: ', mmax, 'distEJE: ', distEJE)
        return ctraBusq, mmin, mmax, distEJE


    def calculaMproximo(self, the_lineM,  pto):
        # calculaMproximo(the_lineM,  pto)
        #   Devuelve el valor M de una geoemtría y punto
        #       return (target_point, dist, punto_anterior, punto_posterior, m_final, distINI, distFIN)
        #   ENTRADA:
        #       the_lineM - Geometria de la linea con M
        #       pto - geometría del punto
        #   SALIDA:
        #       0 target_point
        #       1 dist
        #       2 punto_anterior
        #       3 punto_posterior
        #       4 m_final
        #       5 distINI
        #       6 distFIN

        res = the_lineM.closestSegmentWithContext(pto)
        target_point =  QgsPoint(res[1][0],res[1][1])   # Punto más próximo en el eje mas próximo
        dist = res[0]                                   # Distancia del punto a la polilinea
        punto_posterior = the_lineM.vertexAt(res[2])    # N0. orden vértice posterior al pto. próximo
        m_posterior =  punto_posterior.z()              # Valor M del vértice posterior al pto. próximo
        # if m_posterior == 'nan':
            # m_final = 'noM'
            # return ('', '', '', '', m_final)
        # print ('m_posterior =', m_posterior)
        if res[2] > 0:
            punto_anterior = the_lineM.vertexAt(res[2]-1)
            m_anterior =  punto_anterior.z()
            # if m_anterior == 'nan':
                # m_final = 'noM'
                # return ('', '', '', '', m_final)
            # print ('m_anterior =', m_anterior)
            if punto_posterior.distance(punto_anterior) != 0:
                m_final = m_posterior - (punto_posterior.distance(target_point) / punto_posterior.distance(punto_anterior)) * (m_posterior - m_anterior)
            else:
                m_final = m_posterior
        else:
            m_final = m_posterior

        # print ('m_anterior:', m_anterior, ' m_posterior:', m_posterior, ' m_final:', m_final)

        distINI = the_lineM.distanceToVertex(res[2]-1)+target_point.distance(punto_anterior)
        distFIN = the_lineM.length()- distINI
        # print (the_lineM.length(), distINI, distFIN)

        return (target_point, dist, punto_anterior, punto_posterior, m_final, distINI, distFIN)


    def getValoresCampo(self, campo, filtro):
        url = self.current_configuration.environment["rest_carreteras"]
        params = {'where' : '1=1',
                  'text': '',
                  'objectIds': '',
                  'outFields': campo,
                  'orderByFields': campo,
                  'returnDistinctValues' : 'true',
                  'geometryType' : 'esriGeometryPolyline',
                  'returnGeometry' : 'false',
                 'returnM': 'false' ,
                 'f': 'json'}

        data = urllib.parse.urlencode(params)
        try:
            response = json.load(urllib.request.urlopen(url+data))
            # print (response)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.getValoresCampo LIN:904)")
            return

        features =  response["features"]

        valores = []
        for feat in features:
            valor = feat["attributes"][campo]
            valores.append(valor)

        return valores


    def getFeaturesBTAcalibrada(self,values):

        url = self.current_configuration.environment["rest_carreteras"]
        campoBusqueda = self.current_configuration.lrs["identificador_carretera_carreteras"]
        # http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?
        # values = {'where' : self.current_configuration.lrs["identificador_carretera_carreteras"] + " = '" + road_name + u"'",
        # values = {'where' : 'Matricula' + " = '" + road_name + u"'",
        # values = {'where' : u"'" + campoBusqueda + u"' = '" + road_name + u"'",
        # values = {'where' : 'Matricula_Plan' + " = '" + road_name + u"'",
                  # 'text': '',
                  # 'objectIds': '',
                  # 'geometryType' : 'esriGeometryPolyline',
                  # 'returnGeometry' : 'true',
                  # 'returnM': 'true',
                  # 'geometryPrecision': 3,
                  # 'outFields': '*',
                  # 'f': 'json'}

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        # print (url+data)
        try:
            response = json.load(urllib.request.urlopen(url+data))
            # print (response)
            features =  response["features"]
            # print (features)
            return features
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.showJCCMessageERR(result,text2="",tittle="JCCM - Error de código",)
            return []


    def getFeaturesBTAcalibradaCount(self,values):
        url = self.current_configuration.environment["rest_carreteras"]

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        req = urllib.request.Request(url, data)

        try:
            response = json.load(urllib.request.urlopen(url+data))
            return response
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.showJCCMessageERR(result,text2="",tittle="JCCM - Error de código",)
            return []


    def Zmdt(self, point,iface,pintar):
        # Obtiene la Z del modelo MDT 5m. del IGN, a partir del servicio WMS
        #       url = u'http://www.ign.es/wms-inspire/mdt?'
        # Se obtiene el dato por medio de 'request=GetFeatureInfo'

        url = u'http://www.ign.es/wms-inspire/mdt?'
        tipo = 'text/xml'
        campoXML = 'mdt:GRAY_INDEX'
        layerQueryable = 'EL.GridCoverage'
        result=self.WMSgetFeatureInfo(point,iface, pintar, url, tipo, layerQueryable)
        urlRes=result[0]
        xml_txt=result[1]

        xml_dom = parseString(xml_txt)
        Zmdt = xml_dom.getElementsByTagName(campoXML)[0].toxml()
        Zmdt = float(Zmdt.replace('<'+campoXML+'>','').replace('</'+campoXML+'>',''))
        return Zmdt


    def WMSgetFeatureInfo(self, point,iface, pintar, url, tipo, layerQueryable):
        # Obtiene un valor en un punto generico contra un getFeatureInfo, a partir del servicio WMS
        # Se obtiene el dato por medio de 'request=GetFeatureInfo'

        Xpoint=point[0]
        Ypoint=point[1]
        srs = srcVal

        params = {
                'service':'wms',
                'version':'1.1.1',
                'request':'GetFeatureInfo',
                'query_layers':layerQueryable,
                'srs':'EPSG:'+ str(srs),
                'format':tipo,
                'layers':layerQueryable,
                'bbox':str(Xpoint)+','+str(Ypoint)+','+str(Xpoint+1)+','+str(Ypoint+1),
                'width':'1',
                'height':'1',
                'info_format':tipo,
                'feature_count':'50',
                'x':'1',
                'y':'1',
                # 'exceptions':'application%2Fvnd.ogc.se_xml'
                }

        data = urllib.parse.urlencode(params)
        # print url+data
        try:
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.showJCCMessageERR(result,text2="",tittle="JCCM - Error de código",)

        xml_txt =  req.read()
        return url+data, xml_txt


    def buscaTTMMpoligono(self, listPolig):
        # Create the output Driver
        srs = srcVal
        listaProv = []
        listaMuni = []
        for polig in listPolig:
            perimetroGeom = polig.asJson(3)
            perimetroGeomdecoded = json.loads(perimetroGeom)
            
            perimetroGeomFin = {}
            for entity in perimetroGeomdecoded["coordinates"]:
                perimetroGeomFin['rings'] = entity
            # print(perimetroGeomFin)

            url = u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_Poblaciones_Municipios_WFS/MapServer/1/query?'

            params = {
                    'geometry': perimetroGeomFin,
                    'geometryType':'esriGeometryPolygon',
                    'inSR': srs,
                    'spatialRel':'esriSpatialRelIntersects',
                    'outFields':'*',
                    'returnGeometry':'false',
                    'f':'pjson'
                    }

            data = urllib.parse.urlencode(params)
            # print (url+data)
            try:
                response = json.load(urllib.request.urlopen(url+data))
                # print (response)
            except:
                QApplication.restoreOverrideCursor()
                result = self.PrintException()
                self.showJCCMessageERR(result,text2="",tittle="JCCM - Error de código",)
                return "error", "Error de código"

            if "error" in response:
                return "error", response["error"]
            
            features =  response["features"]
            attr = None
            # listAttr = []
            Municipio = 'NADA'
            Provincia = 'NADA'
            MuniNombre ='NADA'
            Municodine ='NADA'
            ProvNombre ='NADA'
            Provcodine ='NADA'
            for feature in features:
                attr =  feature["attributes"]
                codine = attr['codine']
                Nombre = attr['Nombre']
                if codine[2:5] == '000':
                    Provincia = u'%s (%s)'%(Nombre, codine[0:2])
                    ProvNombre = Nombre
                    Provcodine = codine
                    listaProv.append ([Provincia,ProvNombre,Provcodine])
                else:
                    Municipio = u'%s (%s)'%(Nombre, codine)
                    MuniNombre = Nombre
                    Municodine = codine
                    listaMuni.append ([Municipio,MuniNombre,Municodine])

        return listaProv, listaMuni


    def getJCCMMuniProv(self, point, iface, pintar):
        # Obtiene la provincioa y Municipio de un punto pinchado a partir del servicio D.G.Carreteras JCCM
        #       url = u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_Poblaciones_Municipios_WFS/MapServer/1/query?'
        #   http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_Poblaciones_Municipios_WFS/MapServer/1/query?
            # where=&
            # text=&
            # objectIds=&
            # time=&
            # geometry=x%3D589804.912%2Cy%3D4293820.724&
            # geometryType=esriGeometryPoint&
            # inSR=&
            # spatialRel=esriSpatialRelWithin&relationParam=&outFields=*&returnGeometry=false&returnTrueCurves=false&maxAllowableOffset=&geometryPrecision=&outSR=&returnIdsOnly=false&returnCountOnly=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&returnZ=false&returnM=false&gdbVersion=&returnDistinctValues=false&resultOffset=&resultRecordCount=&queryByDistance=&returnExtentsOnly=false&datumTransformation=&parameterValues=&rangeValues=&f=pjson
            #   where=1%3D1&text=&objectIds=&time=&geometry=x%3D589804.912%2Cy%3D4293820.724&geometryType=esriGeometryPoint&inSR=&spatialRel=esriSpatialRelWithin&relationParam=&outFields=*&returnGeometry=false&returnTrueCurves=false&maxAllowableOffset=&geometryPrecision=&outSR=&returnIdsOnly=false&returnCountOnly=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&returnZ=false&returnM=false&gdbVersion=&returnDistinctValues=false&resultOffset=&resultRecordCount=&queryByDistance=&returnExtentsOnly=false&datumTransformation=&parameterValues=&rangeValues=&f=pjson

        Xpoint=point[0]
        Ypoint=point[1]
        srs = srcVal

        url = u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_Poblaciones_Municipios_WFS/MapServer/1/query?'

        params = {
                'geometry':u'{"x" : %s, "y" : %s}'%("{:.3f}".format(Xpoint),"{:.3f}".format(Ypoint)),
                'geometryType':'esriGeometryPoint',
                'inSR':srs,
                # 'spatialRel':'esriSpatialRelRelation',
                'spatialRel':'esriSpatialRelWithin',
                'outFields':'*',
                'returnGeometry':'false',
                'f':'pjson'
                }

        data = urllib.parse.urlencode(params)
        try:
            response = json.load(urllib.request.urlopen(url+data))
            # print (response)
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.showJCCMessageERR(result,text2="",tittle="JCCM - Error de código",)
            return

        features =  response["features"]
        attr = None
        # listAttr = []
        Municipio = 'NADA'
        Provincia = 'NADA'
        MuniNombre ='NADA'
        Municodine ='NADA'
        ProvNombre ='NADA'
        Provcodine ='NADA'
        for feature in features:
            attr =  feature["attributes"]
            codine = attr['codine']
            Nombre = attr['Nombre']
            if codine[2:5] == '000':
                Provincia = u'%s (%s)'%(Nombre, codine[0:2])
                ProvNombre = Nombre
                Provcodine = codine
            else:
                Municipio = u'%s (%s)'%(Nombre, codine)
                MuniNombre = Nombre
                Municodine = codine

        return Municipio, Provincia, MuniNombre, Municodine, ProvNombre, Provcodine


    def getFeaturesCarretera(self,road_name):

        url = self.current_configuration.environment["rest_carreteras"]
        campoBusqueda = self.current_configuration.lrs["identificador_carretera_carreteras"]
        # http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?
        # values = {'where' : self.current_configuration.lrs["identificador_carretera_carreteras"] + " = '" + road_name + u"'",
        # values = {'where' : 'Matricula' + " = '" + road_name + u"'",
        # values = {'where' : u"'" + campoBusqueda + u"' = '" + road_name + u"'",
        values = {'where' : 'Matricula_Plan' + " = '" + road_name + u"'",
                  'text': '',
                  'objectIds': '',
                  'geometryType' : 'esriGeometryPolyline',
                  'returnGeometry' : 'true',
                  'returnM': 'true',
                  'geometryPrecision': 3,
                  'outFields': '*',
                  'f': 'json'}

        data = urllib.parse.urlencode(values)
        try:
            response = json.load(urllib.request.urlopen(url+data))
            features =  response["features"]
            return features
        # except Exception, e:
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.showJCCMessageERR(result,text2="",tittle="JCCM - Error de código",)
            return []


    def restLineFeaturesToOgrFeatures(self,restFeatures):
        features = []
        for feat in restFeatures:
            line = ogr.Geometry(ogr.wkbLineStringM)
            geometry = feat["geometry"]
            paths = geometry["paths"]
            for path in paths:
                for point in path:
                    line.AddPoint(point[0],point[1])
            features.append(line)
        return features


    def mostraEventosFromCSVLayer(self,layer, iface,campo_carretera,campo_pkini,campo_pkfin,campo_disteje,dest_path,progressBar_dlg,infolbl,dest_name,maxfeat,RECALC,FactPKINI,FactPKFIN, menu):
        # mostraEventosFromCSVLayer(self,layer, iface,campo_carretera,campo_pkini,campo_pkfin,dest_path)
        #   Crea una capa a partir de eventos CTRA, PKINI, PKFIN

        es_puntual = False
        es_disteje = False

        #Borrado del fichero y capa si existen
        layerEXIST = QgsProject.instance().mapLayersByName(dest_name)
        # print (dest_name)
        if layerEXIST:
            for layer1 in layerEXIST:
                QgsProject.instance().removeMapLayer( layer1.id() )
                # print ('borrada - ',dest_name)


        if (campo_pkfin == ""):
            es_puntual = True

        if (campo_disteje != ""):
            es_disteje = True

        es_memoria = False
        if dest_path == "" or dest_path == "en_memoria":
            es_memoria = True

        # Se crea la estructura de las capas
        if es_puntual:  # Capa Puntual
            dest_layer = self.createVectorLayer("point?crs=epsg:"+str(srcVal), dest_name)
        else:           # Capa Lineal
            # print ('Creamos una capa lineal ', dest_name)
            dest_layer = self.createVectorLayer("linestring?crs=epsg:"+str(srcVal), dest_name)

        # Creación Fichero y Capa de log
        QgsMessageLog.logMessage( "Creando archivo de log","jccm_bar")
        log_csv = self.current_configuration.lrs["default_log_folder"] + "Log.csv"
        if(es_memoria == False):
            log_csv =  os.path.splitext(dest_path)[0] +  os.path.splitext(dest_path)[1].split(".")[0] + "_log.csv"

        target  = codecs.open(log_csv, 'w+',encoding='utf-8')
        encabezado = u'"carretera";"pk_ini";"pk_fin";"dist";"result";"observaciones"'
        target.write(encabezado)
        target.write("\n")
        target.close()

        log_csv_uri = u"file:///"+ log_csv +"?type=csv&geomType=none&subsetIndex=no&delimiter=%s&watchFile=no" % (";")

        # Creación de la capa de LOG
        log_lyr = QgsVectorLayer(log_csv_uri, 'Log','delimitedtext')
        QgsProject.instance().addMapLayer(log_lyr)

        #Creación de campos de la capa SHAPE
        pr = dest_layer.dataProvider()
        dest_layer.startEditing()
        fields = layer.fields()
        attributes = []
        for field in fields:
            attributes.append(QgsField(field.name(),field.type()))
        pr.addAttributes(attributes)
        dest_layer.updateFields()
        dest_layer.commitChanges()


        nofeat = 1
        if maxfeat == 0:
            maxfeat = 99999
        features = layer.selectedFeatures()
        numfeat = len(features)

        if numfeat == 0:
            features = layer.getFeatures()
            numfeat = layer.featureCount()

        self.running = True

        if (numfeat > 600 and maxfeat > 600):
            # Debemos poner un aviso de que el cálculo puede no salir bien
            if maxfeat == 99999:
                text = u'La capa de origen tiene '+"%0.0f"%(numfeat)+' elementos.\n'
            else:
                text = u'Se ha limitado el proceso a '+"%0.0f"%(maxfeat)+' elementos de '+"%0.0f"%(numfeat)+' en total.\n'
            text +=u'Realizar este proceso con más de 600 elementos podría generar interrupciones del mismo.\n\n'
            text +=u'Se recomienda dividir el fichero de entrada en otros ficheros con un máximo de 600 elementos.\n\n'
            text +=u'               ¿DESEA CONTINUAR?'
            result = self.showJCCMessageYESNO(text,'','EXCESO DE ELEMENTOS' )
            if result != 1024: # No e ha pulsado ACEPTAR
                return
            pass

        time0 = timeit.default_timer()
        for feature in features:
            if nofeat > maxfeat:
                infolbl.setText('INFO: ('+str(nofeat)+' / '+str(numfeat)+') ALCANZADO MÁXIMO '+ str(maxfeat) )
                break

            target  = codecs.open(log_csv, 'a',encoding='utf-8')

            matricula = feature[campo_carretera]
            if not matricula:
                matricula = 'NO-CARRETERA'


            if (es_puntual):
                # print 'Evento Puntual: ('+str(nofeat)+' / '+str(numfeat),')',
                # print ' CTRA:',matricula,' PKINI:',feature[campo_pkini]

                try:
                    pk_ini = float(feature[campo_pkini])/float(FactPKINI)
                    # pk_ini = Decimal(feature[campo_pkini])/Decimal(FactPKINI)
                except:
                    pk_ini = NULL

                if pk_ini is not NULL or pk_ini == 0.0:
                    disteje = 0
                    if es_disteje:
                        try:
                            disteje = float(feature[campo_disteje])
                        except:
                            pass
                    result = self.addEventoPuntual(iface,dest_layer,matricula,pk_ini,disteje,feature,fields,log_csv)

                else:
                    result = ["Error","PK nulo"]

                resp = result[0]
                error= result[1]
                linea = u'"'+ matricula +'";'+str(pk_ini)+ ';;;'+resp+';'+error+';""'
                target.write(linea)
                target.write("\n")
                target.close()


            else:
                # print 'Evento lineal: ('+str(nofeat)+' / '+str(numfeat),')',
                # print ' CTRA:',matricula,' PKINI:',feature[campo_pkini], ' PKFIN:',feature[campo_pkfin]

                try:
                    pk_ini = float(feature[campo_pkini])/float(FactPKINI)
                    # pk_ini = Decimal(feature[campo_pkini])/Decimal(FactPKINI)
                except:
                    pk_ini = NULL

                try:
                    pk_fin = float(feature[campo_pkfin])/float(FactPKFIN)
                except:
                    pk_fin = NULL

                if pk_ini is not NULL and pk_fin is not NULL:
                    # Se añade evento lineal
                    result = self.addEventoLineal(iface,dest_layer,matricula,pk_ini,pk_fin,feature,fields,log_csv)
                else:
                    if pk_ini is NULL and pk_fin is NULL:
                        result = ["Error","PK Ini y Fin nulos"]
                    elif pk_ini is NULL:
                        result = ["Error","PK Inicial nulo"]
                    elif pk_fin is NULL:
                        result = ["Error","PK Final nulo"]

                resp = result[0]
                error= result[1]
                linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin)+ ';;'+resp+';'+error+';""'
                target.write(linea)
                target.write("\n")
                target.close()

            timeACT = timeit.default_timer()
            faltaTime = 0
            if maxfeat != 99999 and maxfeat<numfeat:
                progressBar_dlg.setValue(100*nofeat/maxfeat)
                if nofeat > 0:
                    faltaTime = (timeACT - time0)/nofeat*maxfeat-(timeACT - time0)
                infolbl.setText('INFO: ('+str(nofeat)+' / '+str(maxfeat)+') Total: '+str(numfeat)+' elementos' + '    Falta: '+str(self.timeTOhms(faltaTime))+' s.')
            else:
                progressBar_dlg.setValue(100*nofeat/numfeat)
                if nofeat > 0:
                    faltaTime = (timeACT - time0)/nofeat*numfeat-(timeACT - time0)
                infolbl.setText('INFO: ('+str(nofeat)+' / '+str(numfeat)+') '+resp+' - '+error + '    Falta: '+str(self.timeTOhms(faltaTime))+' s.')

            # self.btnCancelar.clicked.connect(self.cancelar_Calculo)
            #self.btnCancelar.clicked.connect(self.running = False)

            #https://gis.stackexchange.com/questions/137537/stopping-pyqgis-script-that-has-infinite-loop-using-keyboard
            # print 'procesando - '+str(nofeat)+'/'+str(numfeat)

            nofeat += 1


        if(es_memoria):
            QgsProject.instance().addMapLayer(dest_layer)
        else:
            pr = dest_layer.dataProvider()
            fields = pr.fields()

            field_names = []
            for field_name in fields:
                field_names.append(field_name.name())
            #print field_names

            ruta, shp_file = os.path.split(dest_path)
            shp_name = shp_file.split(".")[0]

            if os.path.isfile(dest_path):
                 for path in os.listdir(ruta):
                     ruta_tmp, file = os.path.split(path)
                     if(file.split(".")[0]  == shp_name):
                         file_path= ruta + "/" + file
                         os.remove(file_path)


            if es_puntual:
                writer = QgsVectorFileWriter(dest_path, "latin-1", fields, QgsWkbTypes.Point, pr.crs(), "ESRI Shapefile")
            else:
                writer = QgsVectorFileWriter(dest_path, "latin-1", fields, QgsWkbTypes.MultiLineStringZM, pr.crs(), "ESRI Shapefile")
            iter = dest_layer.getFeatures()
            for ft in iter:  # Bucle del conjunto de elementos
                # Se crea un nuevo elemento de cada elemento original
                new_ft = QgsFeature()
                # Asignamos una geometría
                new_ft.setGeometry(ft.geometry())
                attributes = []
                for field in field_names:
                    attributes.append(ft[field])
                #print attributes
                # Only keep the 2 selected fields :
                new_ft.setAttributes(attributes)
                # Add the feature to the writer, ie. your output shapefile :
                #print ft
                writer.addFeature(new_ft)

            del writer # Features are written when the writer is deleted
            new_layer = iface.addVectorLayer(dest_path, dest_name, "ogr")

            QgsProject.instance().addMapLayer(new_layer)

        pass


    def getFeatureForPK(self, features ,pk, tipo):

        pk_feature = None
        #print "Features: " + str(len(features))

        min0 = 100000
        max0 =-100000
        featureMin = None
        featureMax = None
        for feature in features:
            geometry = feature["geometry"]
            paths = geometry["paths"]
            puntos = []
            for path in paths:
                for point in path:
                    puntos.append(point)

            #print "puntos: " + str(len(puntos))

            creciente = True
            min = puntos[0][2]
            max = puntos[0][2]

            for point in puntos:
                if point[2] is not None and point[2] < min:
                    #####################################################
                    # error en elemento en que PKINI es igual a PKFIN
                    #####################################################
                    min = point[2]
                if point[2] is not None and point[2] > max:
                    max = point[2]
            if (min is not None and max is not None):
                if (min <= pk and pk <= max):
                    pk_feature = feature
                    #print "Feature max: " + str(min)
                    #print "Feature min: " + str(max)
                    # print ('min= ', min, '  pk= ', pk , ' max= ', max, 'FEATURE: ', feature.index(features),'/',len(features))
                    print ('min= ', min, '  pk= ', pk , ' max= ', max)
                    return pk_feature, min, max

                if min <= min0:
                    min0 = min
                    featureMin = feature
                if max >= max0:
                    max0=max
                    featureMax = feature

        if tipo == 'min' and min0 is not None:
            print ('min0= ', min0, '  pk= ', pk , ' max= ', max)
            return featureMin, min0, max
        if tipo == 'max' and max0 is not None:
            print ('min= ', min, '  pk= ', pk , ' max0= ', max0)
            return featureMax, min, max0

        print ('pk_feature:', pk_feature,'min= ', min, '  pk= ', pk , ' max= ', max, 'FEATURE: ', pk_feature.index(features),'/',len(features))
        return pk_feature, min, max


    def addEventoPuntual(self,iface,vectorlayer,matricula,pk,disteje,feature,fields,log_csv):
        # QgsMessageLog.logMessage( "Evento puntual: " + matricula +", " + str( pk), "jccm_bar")

        #run registro en el log_csv por punto...
        # ANALIZAR QUÉ PASA CON VIÑEDOS
        #http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?
        # where=Matricula_plan+%3D+%27CM-42+D+%28Av.de+los+Vi%C3%B1edos%29%27
        # &geometryType=esriGeometryEnvelope
        # &spatialRel=esriSpatialRelIntersects
        # &outFields=*
        # &returnGeometry=false
        # &returnTrueCurves=false
        # &returnIdsOnly=false&returnCountOnly=false
        # &returnZ=false
        # &returnM=false
        # &returnDistinctValues=false
        # &returnExtentsOnly=false
        # &f=html

        if (pk == NULL or pk == None or pk == ""):
            #print "Pk nulo o incorrecto"
            resp = "Error"
            error = "Pk nulo o incorrecto"
            linea = u'"'+ matricula +'";'+str(pk)+ ';'';;'+resp+';'+error+';""'
            return resp, error

        elif (matricula is NULL or matricula is None or matricula == ""):
            #print "Evento puntual sin matricula"
            resp = "Error"
            error = "Matricula incorrecta o nula"
            linea = u'"'+ matricula +'";'+str(pk)+ ';'';;'+resp+';'+error+';""'
            return resp, error

        # coords = self.CtraPktoCoorsAcim(matricula, pk)
        coords = self.CtraPktoCoorsAcim(road_name, pk, 0,'DISTPK')

        if not self.isFloat(coords[0]):
            #print "No hay datos M"
            resp = "Error"
            error = coords [7:]
            linea = u'"'+ matricula +'";'+str(pk)+ ';'';;'+resp+';'+error+';""'
            return resp, error

        pr = vectorlayer.dataProvider()
        vectorlayer.startEditing()
        # Añade un elemento
        fet = QgsFeature(vectorlayer.fields())

        fieldnames = []
        for field in fields:
           #print "fieldname = "  + field.name()
           fieldnames.append(field.name())

        # SE CALCULA EL DESPLAZADO CON EL ACIMUT
        acim = coords[2]
        if (disteje != 0 and disteje != NULL and disteje != None):
            x = coords[0] + disteje * math.cos(acim*math.pi/180)
            y = coords[1] - disteje * math.sin(acim*math.pi/180)
            # print matricula, pk, acim, disteje, disteje * math.cos(acim), disteje * math.sin(acim)
            fet.setGeometry( QgsGeometry.fromPointXY(QgsPointXY(x,y)) )
        else:
            fet.setGeometry( QgsGeometry.fromPointXY(QgsPointXY(coords[0],coords[1])) )
        fet.setAttribute("carretera", matricula)
        fet.setAttribute("pk_ini", pk)
        fet.setAttribute("acimut", acim)
        fet.setAttribute("distancia", disteje)

        for field_name in fieldnames:
            fet.setAttribute(field_name,feature[field_name])

        pr.addFeatures( [ fet ] )
        vectorlayer.updateExtents()
        vectorlayer.commitChanges()

        resp = "OK"
        error = ""
        linea = u'"'+ matricula +'";'+str(pk)+ ';'';;'+resp+';'+error+';""'
        return resp, error


    '''
    def addEventoLineal(self,iface,vectorlayer,matricula,pk_ini,pk_fin,feature_csv,fields,log_csv):
        print ("Evento lineal: " + matricula + ", " + str(pk_ini) + ", " + str(pk_fin))

        if pk_ini == pk_fin:
            resp = "Error"
            error = "PK inicial igual PK final"
            return resp, error
            pass

        features = self.getFeaturesCarretera(matricula)
        #print "Evento lineal: " + matricula + ", " + str(pk_ini) + ", " + str(pk_fin)
        line_ogr_error = None
        # target  = codecs.open(log_csv, 'a',encoding='utf-8')
        aviso = ""
        if len(features) == 0:
            #print "Matricula desconocida"
            resp = "Error"
            error = "Matricula desconocida"
            return resp, error
            # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'

        feature_ini, min, max0 = self.getFeatureForPK(features,pk_ini, 'min')
        feature_fin, min0, max = self.getFeatureForPK(features,pk_fin, 'max')

        if (feature_ini == None):
            #print "No hay features"
            resp = "Error"
            error = "PK inicial no conocido"
            return resp, error
            # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'

        if (feature_fin == None):
            #print "No hay features"
            resp = "Error"
            error = "PK final no conocido"
            return resp, error
            # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'

        if (feature_ini == feature_fin): ##SITUACIÓN IDEAL: tanto pk ini como pk fin están en el mismo elemento
            line_ogr,line_ogr_error = self.createGeometryOGR(feature_ini,pk_ini,pk_fin,"true")
            line_qgs = self.createGeometryQGS(feature_ini,pk_ini,pk_fin)
            coords1 = self.getCoordsFeaturePK(feature_ini,pk_ini)
            # print '-- Aqui se crea coords1 ',coords1[0],coords1[1],coords1[2]
            coords2 = self.getCoordsFeaturePK(feature_ini,pk_fin)
            # print '-- Aqui se crea coords2 ',coords2[0],coords2[1],coords2[2]

        else:
            if(feature_ini != None):
                # print "Distinto elemento :( , se utilia el elemento del pk inicial"
                puntos = []
                paths = feature_ini["geometry"]["paths"]
                for path in paths:
                    for point in path:
                        puntos.append(point)

                ultimo_pk = puntos[len(puntos) -1][2]
                if( puntos[0][2] > puntos[1][2]):
                    ultimo_pk = puntos[0][2]
                if(ultimo_pk == None):
                    #print "Sin embargo no tiene valor M :("
                    resp = "Error"
                    error = "Distinto elemento, pk final sin elemento, se toma el extremo final del elemento, sin embargo no tinene M"
                    return resp, error
                    # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'
                else:
                    aviso  += "Distinto elemento :( , pk final sin elemento, se toma el pk inicial y el extremo final del elemento"
                    line_ogr, line_ogr_error = self.createGeometryOGR(feature_ini,pk_ini,ultimo_pk,"true")

                    line_qgs = self.createGeometryQGS(feature_ini,pk_ini,ultimo_pk)
                    coords1 = self.getCoordsFeaturePK(feature_ini,pk_ini)
                    coords2 = self.getCoordsFeaturePK(feature_ini,ultimo_pk)

            elif (feature_ini == None and feature_fin != None):
                #print "Distinto elemento :( , pk final sin elemento, se toma el pk fin, y el extremo inicial del elemento"

                puntos = []
                paths = feature_fin["geometry"]["paths"]
                for path in paths:
                    for point in path:
                        puntos.append(point)
                primer_pk = puntos[0][2]
                if( puntos[0][2] > puntos[1][2]):
                    primer_pk = puntos[len(puntos) -1][2]

                if(primer_pk == None):
                    #print "Sin embargo no tiene valor M :("
                    resp = "Error"
                    error = "Distinto elemento, pk inicial sin elemento, se toma el extremo final del elemento, sin embargo no tinene M"
                    return resp, error
                    # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'
                else:
                    aviso  += "Distinto elemento , pk inicial sin elemento, se toma el pk fin y el extremo inicial del elemento"
                    line_ogr, line_ogr_error = self.createGeometryOGR(feature_fin,primer_pk,pk_fin,"true")
                    line_qgs = self.createGeometryQGS(feature_fin,primer_pk,pk_fin)
                    coords1 = self.getCoordsFeaturePK(feature_fin,primer_pk)
                    coords2 = self.getCoordsFeaturePK(feature_fin,pk_fin)

            else:
                return 'AVISO', 'Error en estudio'

        pk_creciente = True
        if (pk_ini > pk_fin):
            pk_creciente = False

        if (pk_creciente == True):
            #coords1 = self.pkToCoords(iface,matricula,pk_ini)
            #coords2 = self.pkToCoords(iface,matricula,pk_fin)

            if(coords1 is None or coords2 is None):
                return 'AVISO', 'Coordenadas None'
            #line_ogr = self.getRoadOgrGeometry(matricula, "true")[feat_number_ini] #geometria ogr , la necesitamos para obtener los pks de los vertices....
            #line_qgs = self.getRoadQgsGeometry(matricula)[feat_number_ini];


            point1 = QgsPointXY(coords1[0],coords1[1])
            point2 = QgsPointXY(coords2[0],coords2[1])

            response = line_qgs.closestVertex(point1)
            a_vertex = response[1]

            if(line_ogr.GetM(a_vertex) > pk_ini):
                a_vertex = response[2]
            #print a_vertex
            #print line_ogr.GetM(a_vertex)
            response = line_qgs.closestVertex(point2)
            b_vertex = response[1]
            if(line_ogr.GetM(b_vertex) > pk_fin):
                b_vertex = response[2]

            #print b_vertex
            #print line_ogr.GetM(b_vertex)
            if(a_vertex < b_vertex):
                line_qgs.insertVertex(point1[0],point1[1],a_vertex)
                line_qgs.insertVertex(point2[0],point2[1],b_vertex + 1)
            else:
                line_qgs.insertVertex(point1[0],point1[1],a_vertex)
                line_qgs.insertVertex(point2[0],point2[1],b_vertex)
            vertices = line_qgs.asPolyline()

            desde = a_vertex + 1
            hasta = b_vertex + 2

            if(a_vertex > b_vertex):
                #print u'del revés'
                desde = b_vertex + 1
                hasta = a_vertex + 2
            puntos = []

            for i in range(desde, hasta):
                puntos.append(vertices[i])

            # AQUÍ HAY QUE CALCULAR EL DESPLAZADO CON EL ACIMUT
            # gLine = QgsGeometry.fromPolyline(puntos)
            gLine = QgsGeometry.fromPolylineXY(puntos)

            pr = vectorlayer.dataProvider()
            vectorlayer.startEditing()
                # add a feature
            fet = QgsFeature(vectorlayer.fields())


            fet.setGeometry( gLine )
            fet.setAttribute("carretera", matricula)
            fet.setAttribute("pk_ini", pk_ini)
            fet.setAttribute("pk_fin", pk_fin)
            # fet.setAttribute("acimut", coords[2])


            fieldnames = []

            for field in fields:
               #print "fieldname = "  + field.name()
               fieldnames.append(field.name())

            for field_name in fieldnames:
                fet.setAttribute(field_name,feature_csv[field_name])


            if(line_ogr_error is not None or aviso != ""):
                if line_ogr_error is None:
                    line_ogr_error = ""
                resp = "AVISO"
                error = line_ogr_error+ '. ' + aviso
                # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'
            else:
                resp = "OK"
                error = ''
                # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'

            pr.addFeatures( [ fet ] )
            vectorlayer.updateExtents()
            vectorlayer.commitChanges()
            return resp, error
        else:
            #print "Pk inicial es mayor que pk final"
            linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'
            resp = "Error"
            error = "Pk inicial es mayor que pk final"
            return resp, error
    '''

    def addEventoLineal(self,iface,vectorlayer,matricula,pk_ini,pk_fin,feature_csv,fields,log_csv):
        print ("Evento lineal: " + matricula + ", " + str(pk_ini) + ", " + str(pk_fin))

        if pk_ini == pk_fin:
            resp = "Error"
            error = "PK inicial igual PK final"
            return resp, error

        features = self.getFeaturesCarretera(matricula)
        line_ogr_error = None
        aviso = ""
        if len(features) == 0:
            resp = "Error"
            error = "Matricula desconocida"
            return resp, error
            # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'
            

        ##############################################################################
        
        ######      INICIO CAMBIOS
        
        ##############################################################################
        # Calculamos el tramo de linea correspondiente a la carretera y tramo
        gLine, MminTramo, MmaxTramo, attrFinales = self.fun.getTramoCtra(matricula, pk_ini, pk_fin)

        # AQUÍ HAY QUE CALCULAR EL DESPLAZADO CON EL ACIMUT

        if gLine.isEmpty():
            resp = "Error"
            error = 'EL TRAMO NO EXISTE'
            return resp, error

        pr = vectorlayer.dataProvider()
        vectorlayer.startEditing()
        # Añadimos el feature
        fet = QgsFeature(vectorlayer.fields())

        fet.setGeometry( gLine )
        fet.setAttribute("carretera", matricula)
        fet.setAttribute("pk_ini", MminTramo)
        fet.setAttribute("pk_fin", MmaxTramo)

        ##############################################################################
        ##############################################################################

        fieldnames = []

        for field in fields:
            fieldnames.append(field.name())

        for field_name in fieldnames:
            fet.setAttribute(field_name,feature_csv[field_name])


        if(line_ogr_error is not None or aviso != ""):
            if line_ogr_error is None:
                line_ogr_error = ""
            resp = "AVISO"
            error = line_ogr_error+ '. ' + aviso
            # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'
        else:
            resp = "OK"
            error = ''
            # linea = u'"'+ matricula +'";'+str(pk_ini)+ ';'+str(pk_fin) +';;'+resp+';'+error+';""'

        pr.addFeatures( [ fet ] )
        vectorlayer.updateExtents()
        vectorlayer.commitChanges()
        return resp, error


        
        ##############################################################################
        ######      FINAL CAMBIOS
        ##############################################################################



    
    def getTramoCtra(self, road_name, pkini, pkfin):
        ####################################################################################
        ####################################################################################
        #
        # Devuelve la geometria y atributos de un tramo dado por 'road_name, pkini, pkfin'
        #           return (gLine, MminTramo, MmaxTramo, attrFinales)
        #
        ####################################################################################
        ####################################################################################

        features = self.getFeaturesCarretera(road_name)
        line_ogr_error = None
        aviso = ""

        restfeatures = self.getFeaturesCarretera(road_name)

        if len(features) == 0:
            msg = u'TRAMO DE CARRETERA DESONOCIDA\n\n'
            msg += 'CARRETERA: '+ road_name + ' - pkini: ' + str(pkini) + ' - pkfin: ' + str(pkfin)
            print (msg)
            return

        multiline = ogr.Geometry(ogr.wkbMultiLineString)

        MminTramo = 1000000
        MmaxTramo = 0

        for feat in restfeatures:
            geometry = feat["geometry"]
            paths = geometry["paths"]
            attr =  feat["attributes"]
            attrFinales = ''
            if attr['Matricula'] == '9000':
                # print (attr['Matricula'])
                continue
            # print (attr['Matricula'])
            
            for path in paths:
                line1 = ogr.Geometry(ogr.wkbLineString)
                posinpath = 0
                for point in path:
                    if posinpath < len(path)-1:
                        pointSIG = path[posinpath+1]
                    try:
                        if point[2]:
                            # El punto tiene 'M'
                            if pkini == point[2]:                           # El punto es 'pkini'
                                line1.AddPoint(point[0],point[1],point[2])
                                MminTramo = point[2]
                            
                            if pkfin == point[2]:                           # El punto es 'pkfin'
                                line1.AddPoint(point[0],point[1],point[2])
                                MmaxTramo = point[2]

                            if point[2]<pointSIG[2]:                        # Segmento PK Creciente ++++
                                if (point[2] < pkini and pkini < pointSIG[2]):    # Segmento del PKINI
                                    xINI, yINI, acimINI = self.pointMsegment(pkini, point, pointSIG)
                                    line1.AddPoint(xINI, yINI, pkini)
                                    MminTramo = pkini
                                    attrFinales = attr
                                if (point[2] < pkfin and pkfin < pointSIG[2]):    # Segmento del PKFIN
                                    xFIN, yFIN, acimFIN = self.pointMsegment(pkfin, point, pointSIG)
                                    line1.AddPoint(xFIN, yFIN, pkfin)
                                    MmaxTramo = pkfin
                                    attrFinales = attr
                            if point[2]>pointSIG[2]:                        # Segmento PK Decreciente ----
                                if (point[2] > pkini and pkini > pointSIG[2]):    # Segmento del PKINI
                                    xINI, yINI, acimINI = self.pointMsegment(pkini, point, pointSIG)
                                    line1.AddPoint(xINI, yINI, pkini)
                                    MminTramo = pkini
                                    attrFinales = attr
                                if (point[2] > pkfin and pkfin > pointSIG[2]):    # Segmento del PKFIN
                                    xFIN, yFIN, acimFIN = self.pointMsegment(pkfin, point, pointSIG)
                                    line1.AddPoint(xFIN, yFIN, pkfin)
                                    MmaxTramo = pkfin
                                    attrFinales = attr

                            if pkini < point[2] and point[2] < pkfin:         # El punto está entre 'pkini' y 'pkfin' CON 'M'
                                # El punto está entre 'pkini' y 'pkfin'
                                line1.AddPoint(point[0],point[1],point[2])
                                if point[2] <= MminTramo: MminTramo = point[2]
                                if point[2] >= MmaxTramo: MmaxTramo = point[2]
                                

                    except:
                        pass                                                  # El punto NO tiene 'M'
                    posinpath += 1
                multiline.AddGeometry(line1)

        gLine = QgsGeometry.fromWkt(multiline.ExportToWkt())
        
        print ('road_name, pkini, pkfin ', road_name, pkini, pkfin, 'MminTramo, MmaxTramo ', MminTramo, MmaxTramo)
        return (gLine, MminTramo, MmaxTramo, attrFinales, multiline)


    def pointMsegment(self, pk, point, pointSIG):
        if point[2]<=pointSIG[2]:
            m_anterior = point[2]
            m_siguiente = pointSIG[2]
            punto_anterior = ogr.Geometry(ogr.wkbPoint)
            punto_anterior.AddPoint(point[0], point[1])
            punto_siguiente = ogr.Geometry(ogr.wkbPoint)
            punto_siguiente.AddPoint(pointSIG[0], pointSIG[1])

        else:
            m_anterior = pointSIG[2]
            m_siguiente = point[2]
            punto_anterior = ogr.Geometry(ogr.wkbPoint)
            punto_anterior.AddPoint(pointSIG[0], pointSIG[1])
            punto_siguiente = ogr.Geometry(ogr.wkbPoint)
            punto_siguiente.AddPoint(point[0], point[1])

        r = (pk - m_anterior) / (m_siguiente - m_anterior)
        modulo = r * (punto_siguiente.Distance(punto_anterior))
        alfa = math.atan2((punto_siguiente.GetY() - punto_anterior.GetY() ) , (punto_siguiente.GetX()  - punto_anterior.GetX()))

        diff = pk - m_anterior

        x = punto_anterior.GetX() + modulo * math.cos(alfa)
        y = punto_anterior.GetY() + modulo * math.sin(alfa)

        # CALCULO DEL ACIMUT
        pointANT = QgsPoint(punto_anterior.GetX(),punto_anterior.GetY())
        pointPOS = QgsPoint(punto_siguiente.GetX(),punto_siguiente.GetY())
        res1 = self.calcACIMUT(pointANT,pointPOS)
        acim= res1[1]
        
        print (' pk, point[2], pointSIG[2]',pk, point[2], pointSIG[2], 'r, modulo', r, modulo )

        return (x,y,acim)


    def createVectorLayer(self,uri,name,dest='memory'):
        # createVectorLayer(self,uri,name,dest='memory')
        #   Crea una capa vectorial de careteras en memoria añadiendoles campos
        #           'carretera', 'pk_ini', 'pk_fin', 'acimut', 'distancia'
        #   Devuelve la capa vectorial
        #   return vl

        vl = QgsVectorLayer(uri, name, dest)
        pr = vl.dataProvider()


        # Enter editing mode
        vl.startEditing()

        # add fields
        pr.addAttributes( [ QgsField("carretera", QVariant.String),
                        QgsField("pk_ini", QVariant.Double),
                        QgsField("pk_fin", QVariant.Double),
                        QgsField("acimut", QVariant.Double),
                        QgsField("distancia", QVariant.Double)
                        ] )
        # Commit changes
        vl.commitChanges()
        return vl


    def createGeometryOGR(self,feature,pk_ini,pk_fin,return_M = "false"):

        #print "Creando geometria desde OGR: " + str(pk_ini) + " hasta: " + str (pk_fin)

        n = 0
        line = ogr.Geometry(ogr.wkbLineStringM)
        geometry = feature["geometry"]
        paths = geometry["paths"]
        points = []
        for path in paths:
            for point in path:
                if(return_M == "true"):
                    if(point[2] == None):
                        #print "Coordenada sin M, la saltamos...la eme"
                        n +=1
                        line.AddPoint(point[0],point[1])
                        continue
                    line.AddPointM(point[0],point[1],point[2])
                else:
                    line.AddPoint(point[0],point[1])
        if n > 0:
            QgsMessageLog.logMessage( "Feature con " + str(n) + " coordenadas sin M","jccm_bar")
            return [line,"Feature con " + str(n) + " coordenadas sin M"]
        return [line,None]


    def createGeometryQGS(self,feature,pk_ini,pk_fin):

        #print "Creando geometria QGS desde : " + str(pk_ini) + " hasta: " + str (pk_fin)

        geometry = feature["geometry"]
        paths = geometry["paths"]
        points = []
        for path in paths:
            for point in path:
                gPnt =QgsPoint(point[0],point[1])
                points.append(gPnt)
        line  = QgsGeometry.fromPolyline(points)

        return line


    def getCoordsFeaturePK(self,feat,pk):
        ################################################
        ######   SEGURO PARA EL CÁLCULO DE PK=0   ######
        ################################################
        # Sumamos 0.01 m en caso de pk = 0
        if pk == 0.0:
            pk = pk+0.00001
        ################################################
        ################################################

        n = 0
        acim = 360
        mensaje_final = ""
        line = ogr.Geometry(ogr.wkbLineStringM)
        #print "feature"
        geometry = feat["geometry"] # La geometría del elemento detectado
        paths = geometry["paths"]   # Las diferentes partes de la geometría del elemento detectado
        attr =  feat["attributes"]  # Los atributos del elemento detectado
        # print attr
        mat_plan = attr['Matricula']
        for path in paths:
            for point in path:
                if(point[2] == None):
                    n += 1
                    continue
                line.AddPointM(point[0],point[1],point[2])
        creciente = True
        if line.GetM(1) < line.GetM(0):
            creciente = False

        m_anterior = 0
        m_siguiente = 0
        if creciente == True:
            # print mat_plan +" - (partes:"+ str(len(paths))+") Creciente"
            for i in range(line.GetPointCount()):
                current_m = line.GetM(i)
                # if (pk == current_m):
                    # target_point_coords = line.GetPoint(i);
                    # point = ogr.Geometry(ogr.wkbPoint)
                    # point.AddPoint(target_point_coords[0], target_point_coords[1])
                    # return [target_point_coords[0], target_point_coords[1]]
                    # #self.zoomToGeometry(iface,point)
                    # return None
                if(current_m >= pk):
                    punto_anterior = ogr.Geometry(ogr.wkbPoint)
                    punto_anterior.AddPoint(line.GetPoint(i-1)[0], line.GetPoint(i-1)[1])

                    punto_siguiente = ogr.Geometry(ogr.wkbPoint)
                    punto_siguiente.AddPoint(line.GetPoint(i)[0], line.GetPoint(i)[1])

                    m_anterior = line.GetM(i-1)
                    m_siguiente = line.GetM(i)

                    break
        else:
            # print mat_plan +" - (partes:"+ str(len(paths))+") Decreciente"
            for i in range(line.GetPointCount()):
                current_m = line.GetM(i)
                # if (pk == current_m):
                    # target_point_coords = line.GetPoint(i);
                    # target_point_coords1 = line.GetPoint(i+1);
                    # point = ogr.Geometry(ogr.wkbPoint)
                    # point.AddPoint(target_point_coords[0], target_point_coords[1])
                    # return [target_point_coords[0], target_point_coords[1]]
                if(current_m <= pk):
                    punto_anterior = ogr.Geometry(ogr.wkbPoint)
                    punto_anterior.AddPoint(line.GetPoint(i)[0], line.GetPoint(i)[1])

                    punto_siguiente = ogr.Geometry(ogr.wkbPoint)
                    punto_siguiente.AddPoint(line.GetPoint(i-1)[0], line.GetPoint(i-1)[1])

                    m_anterior = line.GetM(i)
                    m_siguiente = line.GetM(i-1)
                    break

        if m_siguiente != m_anterior:
            r = (pk - m_anterior) / (m_siguiente - m_anterior)
            modulo = r * (punto_siguiente.Distance(punto_anterior))
            #m = (punto_siguiente[1] - punto_anterior[1]) / (punto_siguiente[0] - punto_anterior [0])
            alfa = math.atan2((punto_siguiente.GetY() - punto_anterior.GetY() ) , (punto_siguiente.GetX()  - punto_anterior.GetX()))

            diff = pk - m_anterior

            x = punto_anterior.GetX() + modulo * math.cos(alfa)
            y = punto_anterior.GetY() + modulo * math.sin(alfa)

            # CALCULO DEL ACIMUT
            pointANT = QgsPoint(punto_anterior.GetX(),punto_anterior.GetY())
            pointPOS = QgsPoint(punto_siguiente.GetX(),punto_siguiente.GetY())
            res1 = self.calcACIMUT(pointANT,pointPOS)
            acim= res1[1]
            # if acim < 0:
                # acim += 360

        else:
            QgsMessageLog.logMessage("Feature con " + str(n) +" Mal calibrada","jccm_bar")
            # print mat_plan +" - (partes:"+ str(len(paths))+") Mal calibrada"
            return None

        if n > 0:
            QgsMessageLog.logMessage(mat_plan + str(len(paths))+"Feature con " + str(n) + " coordenadas sin M","jccm_bar")
            # print mat_plan +" - (partes:"+ str(len(paths))+"Feature con " + str(n) + ") coordenadas sin M"


        # CONTROL DE COORDENADAS EN ZONA CLM
        Xmin =  291000
        Ymin = 4205000
        Xmax =  680000
        Ymax = 4576000
        if (x < Xmin or x > Xmax or y < Ymin or y > Ymax):
            return None

        # print mat_plan, pk, x, y, acim
        return [x,y,acim]


    def makeHtmlListCoord(self, geometry):

        listCoord =''
        pathNum=1
        Mant = None

        listCoordHtml = (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">'
            '<html><head><meta name="qrichtext" content="1" /><style type="text/css">'
            'p, li { white-space: pre-wrap; }'
            '</style></head><body style=" font-size:8.25pt; font-weight:400; font-style:normal;">'
            )

        try:
            paths = geometry["paths"]
            for path in paths:
                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt; font-weight:600;">'
                listCoordHtml += 'TRAMO %s/%s (%s puntos)\n'%(str(pathNum),len(paths),len(path))
                listCoordHtml += '</span></p>'
                for point in path:
                    if point[2] is not None:
                        if Mant is not None:
                            if point[2]-Mant <0:
                                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                                listCoordHtml += "  %0.2f"%(point[0])+','+"%0.2f"%(point[1])+','+" %0.5f"%(point[2])+',</span><span style=" font-size:8pt; font-weight:600; color:#ff5500;">'+"%0.5f"%(point[2]-Mant)+'</span></p>'
                            else:
                                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                                listCoordHtml += "  %0.2f"%(point[0])+','+"%0.2f"%(point[1])+','+" %0.5f"%(point[2])+','+"%0.5f"%(point[2]-Mant)+'\n'
                                listCoordHtml += '</span></p>'
                        else:
                            listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                            listCoordHtml += "  %0.2f"%(point[0])+','+"%0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'
                            listCoordHtml += '</span></p>'
                        Mant = point[2]
                    else:
                        # listCoord += ' %s,%s,%s\n'%(str(round(point[0],2)),str(round(point[1],2)),'None')
                        listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                        listCoordHtml += "  %0.2f"%(point[0])+','+" %0.2f"%(point[1])+',</span><span style=" font-size:8pt; font-weight:600; color:#ff5500;">'+" None"+'</span></p>'
                pathNum +=1
        except:
            paths = []
            if geometry.isMultipart():
                for part in geometry.asGeometryCollection ():
                    paths.append(part)
            else:
                paths.append(geometry)

            for path in paths:
                novertices = len(path.asPolyline())

                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt; font-weight:600;">'
                listCoordHtml += 'TRAMO %s/%s (%s puntos)\n'%(str(pathNum),len(paths),novertices)
                listCoordHtml += '</span></p>'

                for id in range(novertices):
                    point = path.vertexAt(id)

                    if point.m() is not None:
                        if Mant is not None:
                            if point.m()-Mant <0:
                                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                                listCoordHtml += "  %0.2f"%(point.x())+','+"%0.2f"%(point.y())+','+" %0.5f"%(point.m())+',</span><span style=" font-size:8pt; font-weight:600; color:#ff5500;">'+"%0.5f"%(point.m()-Mant)+'</span></p>'
                            else:
                                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                                listCoordHtml += "  %0.2f"%(point.x())+','+"%0.2f"%(point.y())+','+" %0.5f"%(point.m())+','+"%0.5f"%(point.m()-Mant)+'\n'
                                listCoordHtml += '</span></p>'
                        else:
                            listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                            listCoordHtml += "  %0.2f"%(point.x())+','+"%0.2f"%(point.y())+','+" %0.5f"%(point.m())+'\n'
                            listCoordHtml += '</span></p>'
                        Mant = point.m()
                    else:
                        listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                        listCoordHtml += "  %0.2f"%(point.x())+','+" %0.2f"%(point.y())+',</span><span style=" font-size:8pt; font-weight:600; color:#ff5500;">'+" None"+'</span></p>'
                pathNum +=1

        return listCoordHtml




    """  RUTINAS DE GESTION DE CAPAS DE LA VISTA
    #-------------------------------------------------------------------------------
    #    RUTINAS DE GESTION DE CAPAS DE LA VISTA
    #-------------------------------------------------------------------------------
    """

    def getLayerByName(self,name):
        layer = None
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == name:
                layer = lyr
                break
        return layer


    def getCapasCsv(self, iface):
        layers =  QgsProject.instance().mapLayers().values()
        layer_names = []
        for layer in layers:
            source = layer.source()
            if layer.type() == QgsMapLayer.VectorLayer or (source.find('type=csv') > -1):
                if layer.name() != '':
                    layer_names.append(layer.name())
        return layer_names


    def zoomELEMENTO(self, iface, capaDATOS, datoBUSCADO, ordenDATO, listaCAMPOS, ordenCAMPO, escala ):
        # Rutina que hace zoom a un elemento o elementos seleccionados en el combo (C) ASS
        #   capaDATOS, Nombre de la capa en la que se va a buscar
        #   datoBUSCADO, Puede ser un dato único o con separadores tipo ' | '
        #   ordenDATO, 0 por defecto, caso único; si es un elemento con separadores ' | ' coge el indicado 0,1,2...
        #       ej: CM-332 | EX-2016/007 | Alatoz, 0=CM-332, 1=EX-2016/007, 2=Alatoz
        #   listaCAMPOS, lista completa o parcial de atributos de la capa
        #   ordenCAMPO, posición en listaCAMPOS del campo en que buscar datoBUSCADO
        #   escala, 0 por defecto, escala al BBOX del elemento, si !=0 se hace zoom a esa escala
        canvas = iface.mapCanvas()

        allLayers = canvas.layers()
        n = len(allLayers)
        for i in range(0, n):
            if allLayers[i].name() == capaDATOS:
                break
        layer = allLayers[i]
        iface.setActiveLayer(layer)
        # iface.legendInterface().setLayerVisible(layer, True)
        QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(True)

        # Se obtiene el valor a buscar de la selección del combo
        valorBUSCADO= (datoBUSCADO.split(' | '))[ordenDATO]

        # Se obtiene el campo de la lista de campos
        campo = listaCAMPOS[ordenCAMPO]

        # Obtiene un iterador de elementos desde una expresión
        consulta = u'"'+campo+'" = \''+valorBUSCADO+'\''
        expr = QgsExpression( consulta )
        it = layer.getFeatures( QgsFeatureRequest( expr ) )

        # Se construye una lista de IDs de elementos del resultado obtenido antes
        ids = [j.id() for j in it]

        # Selecciona elementos con los ids obtenidos
        feats=layer.selectByIds( ids )


        # Zoom a los elementos seleccionados
        canvas.zoomToSelected()
        if escala != 0:
            canvas.zoomScale(escala)
            # self.zoomToGeometry(self.iface,point)
            # self.zoomToQgsFeature(self.iface,feats[0])
        pass


    """ RUTINAS DE GESTION DE DATOS CATASTRALES
    #-------------------------------------------------------------------------------
    #   RUTINAS DE GESTION DE DATOS CATASTRALES
    #-------------------------------------------------------------------------------
    """

    def consultaCatastroXYtoRC(self, x ,y ,srs):
        # consultaCatastroXYtoRC(x,y)
        #   Permite obtener la REFCAT y otros datos de la parcela a partir de las coordenadas pinchada
        #   return (REFCAT14, xml_txt, pc1, pc2, ldt)
        #   ENTRADA:
        #       x - X del punto pinchado
        #       y - Y del punto pinchado
        #       srs - Sistema Referencia de coordenadas (por defecto EPSG:25830 )
        #   SALIDA:
        #       REFCAT14 - Referencia catastral de la parcela 14 dígitos
        #       xml_txt - Contenido completo del XML de respuesta
        #       pc1 - 7 primeros dígitos de la RefCat
        #       pc2 - 7 primeros dígitos de la RefCat
        #       ldt - DIRECCIÓN (CALLE, NÚMERO, MUNICIPIO O POLÍGONO, PARCELA Y MUNICIPIO) DE LA PARCELA
        #CREADA ASS

        # url = u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_RCCOOR?'
        url = self.current_configuration.catastro_tool["url_catastro_RCCOOR"]

        params = {
            'SRS':  srs,
            'Coordenada_X':x,
            'Coordenada_Y':y}

        str_values = {}
        for k, v in params.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        print ('consultaCatastroXYtoRC - ', url+data)
        try:
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.consultaCatastroXYtoRC)")
            return ("ERROR")

        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)
        xml_dom = parseString(xml_txt)
        # print xml_txt

        try:
            cuerr = xml_dom.getElementsByTagName('cuerr')[0].toxml()
            cuerr = cuerr.replace('<cuerr>','').replace('</cuerr>','')
        except:
            cuerr = "0"
        # print "cuerr:  " + cuerr
        if (cuerr != "0"):
            cod = xml_dom.getElementsByTagName('cod')[0].toxml()
            cod = cod.replace('<cod>','').replace('</cod>','')
            des = xml_dom.getElementsByTagName('des')[0].toxml()
            des = des.replace('<des>','').replace('</des>','')
            message = "ERROR: "+ str(cod)+ "\t" + des + u"\n\n -- PROBAR A PINCHAR OTRA POSICIÓN --"
            # self.showJCCMessageERR( message,'','Identificador de Catastro' )
            QApplication.restoreOverrideCursor()
            self.showJCCMessageERR( message,'','Identificador de Catastro' )
            return (u'ERROR',message)


        for loc1 in xml.iter(u"{http://www.catastro.meh.es/}pc"):
            pc1 = loc1.find(u"{http://www.catastro.meh.es/}pc1").text
            pc2 = loc1.find(u"{http://www.catastro.meh.es/}pc2").text
            REFCAT14 = pc1 + pc2

        for loc2 in xml.iter(u"{http://www.catastro.meh.es/}coord"):
            ldt = loc2.find(u"{http://www.catastro.meh.es/}ldt").text

        return (REFCAT14, xml_txt, pc1, pc2, ldt)


    def consultaCatastroXYDISTtoRC(self, x ,y ,srs):
        # ConsultaCatastroXYDISTtoRC(x,y)
        # Consulta_RCCOOR_Distancia
        #   Permite obtener la REFCAT y otros datos de la parcela a partir de las coordenadas pinchada
        #   return (REFCAT14, xml_txt, pc1, pc2, ldt, codigo_provincia,codigo_muni)
        #   ENTRADA:
        #       x - X del punto pinchado
        #       y - Y del punto pinchado
        #       srs - Sistema Referencia de coordenadas (por defecto EPSG:25830 )
        #   SALIDA:
        #       REFCAT14 - Referencia catastral de la parcela 14 dígitos
        #       xml_txt - Contenido completo del XML de respuesta
        #       pc1 - 7 primeros dígitos de la RefCat
        #       pc2 - 7 primeros dígitos de la RefCat
        #       ldt - DIRECCIÓN (CALLE, NÚMERO, MUNICIPIO O POLÍGONO, PARCELA Y MUNICIPIO) DE LA PARCELA
        #       codigo_provincia
        #       codigo_muni
        #
        # EJEMPLO:
        # CASO RUSTICA
        # http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_RCCOOR_Distancia?SRS=EPSG:25830&Coordenada_X=639554&Coordenada_Y=4328696
        #
        # EJEMPLO:
        # CASO URBANA
        # http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_RCCOOR_Distancia?SRS=EPSG%3A25830&Coordenada_X=583476.575747&Coordenada_Y=4256365.9191
        #
        # CREADA ASS

        # url = u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_RCCOOR_Distancia?'
        url = self.current_configuration.catastro_tool["url_catastro_distancia"]

        params = {
            'SRS':  srs,
            'Coordenada_X':x,
            'Coordenada_Y':y}

        str_values = {}
        for k, v in params.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        print ('consultaCatastroXYDISTtoRC - '+url+data)
        try:
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.consultaCatastroXYDISTtoRC lin:1157)")
            return ("ERROR")


        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)
        xml_dom = parseString(xml_txt)

        listacp = []
        listacm = []
        listapc1 = []
        listapc2 = []
        listaldt = []

        cuerr = xml_dom.getElementsByTagName('cuerr')[0].toxml()
        cuerr = cuerr.replace('<cuerr>','').replace('</cuerr>','')
        # print "cuerr:  " + cuerr
        if (cuerr != "0"):
            cod = xml_dom.getElementsByTagName('cod')[0].toxml()
            cod = cod.replace('<cod>','').replace('</cod>','')
            des = xml_dom.getElementsByTagName('des')[0].toxml()
            des = des.replace('<des>','').replace('</des>','')
            message = "ERROR: "+ str(cod)+ "\t" + des + u"\n\n -- PROBAR A PINCHAR OTRA POSICIÓN --"
            # self.showJCCMessageERR( message,'','Identificador de Catastro' )
            QApplication.restoreOverrideCursor()
            self.showJCCMessageERR( message,'','Identificador de Catastro' )
            return (u'ERROR',message)

        for loc in xml.iter(u"{http://www.catastro.meh.es/}loine"):
            # cp = loc.find(u"{http://www.catastro.meh.es/}cp")
            # cm = loc.find(u"{http://www.catastro.meh.es/}cm")
            listacp.append(loc.find(u"{http://www.catastro.meh.es/}cp"))
            listacm.append(loc.find(u"{http://www.catastro.meh.es/}cm"))

        cp = listacp[0]
        cm = listacm[0]
        codigo_provincia = self.completarCeros(cp.text,2)
        codigo_muni_ine = self.completarCeros(cm.text,3)

        for loc1 in xml.iter(u"{http://www.catastro.meh.es/}pc"):
            # pc1 = loc1.find(u"{http://www.catastro.meh.es/}pc1").text
            # pc2 = loc1.find(u"{http://www.catastro.meh.es/}pc2").text
            listapc1.append(loc1.find(u"{http://www.catastro.meh.es/}pc1").text)
            listapc2.append(loc1.find(u"{http://www.catastro.meh.es/}pc2").text)
        pc1= listapc1[0]
        pc2= listapc2[0]
        REFCAT14 = pc1 + pc2

        for loc2 in xml.iter(u"{http://www.catastro.meh.es/}pcd"):
            # ldt = loc2.find(u"{http://www.catastro.meh.es/}ldt").text
            listaldt.append(loc2.find(u"{http://www.catastro.meh.es/}ldt").text)
        ldt= listaldt[0]

        # print REFCAT14, xml_txt, pc1, pc2, ldt, codigo_provincia,codigo_muni
        return (REFCAT14, xml_txt, pc1, pc2, ldt, codigo_provincia,codigo_muni_ine)


    def consultaCatastroDATPARCELA(self, REFCAT14):
        # CONSULTA DE DATOS DE PARCELA POR RC - Se debe meter en config
        #   Devuelve los datos libres de la parcela catastral
        #    ENTRADA
        #       REFCAT14 - Referencia catastral de la parcela 14 dígitos
        #    SALIDA
        #       tipoPAR,        #0 - TIPO DE PARCELA (Urbana, Rústica, Diseminado, X-Descuento)
        #       codnomPRO,      #1 - Código y nombre de provincia
        #       codnomMUN,      #2 - Código y nombre de municipio
        #       message,        #3 - Contador de BI, CONS y SUBP
        #       listaSUBP,      #4 - Listado del contenido de los datos de supparcelas
        #       listaCONSTRU,   #5 - Listado del contenido de los datos de construcciones
        #       supTOTAL,       #6 - Superficie de la parcela
        #       supCONSTR,      #7 - Superficie construida
        #       DATOSURBA,      #8 - Datos generales parcela urbana
        #       cp,             #9- Código de la provincia
        #       cm,             #10- Código del Municipio
        #       cmc,            #11- Código catastral del Municipio
        #       REFCAT,         #12- REFCAT completa (20 dígitos)
        #       cn,             #13- Tipo parcela RU, UR, DI, X
        #       cpo,            #14- Poligono
        #       cpa,            #15- Parcela
        #       cv,             #16- Codigo de la via
        #       pnp             #17- Numero de la via

        # url = u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/Consulta_DNPRC?'
        url = self.current_configuration.catastro_tool["url_catastro_DNPRC"]

        params = {
            'Provincia': '',
            'Municipio': '',
            'RC': REFCAT14}

        str_values = {}
        for k, v in params.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        print ('consultaCatastroDATPARCELA - '+url+data)
        try:
            # response = json.load(urllib.request.urlopen(url+data)
            # req = json.load(urllib.request.urlopen(url+data))
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.consultaCatastroDATPARCELA)")
            return ("ERROR")

        if req==None:
            err = u'ERROR de Respuesta de catastro -Consulta_DNPRC-'
            #self.showJCCMessage(err)
            return err

        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)
        xml_dom = parseString(xml_txt)

        # print xml_txt
        try:
            cuerr = xml_dom.getElementsByTagName('cuerr')[0].toxml()
            cuerr = cuerr.replace('<cuerr>','').replace('</cuerr>','')
        except:
            cuerr = "0"

        # print ("cuerr:  " + cuerr)
        if (cuerr != "0"):
            cod = xml_dom.getElementsByTagName('cod')[0].toxml()
            cod = cod.replace('<cod>','').replace('</cod>','')
            des = xml_dom.getElementsByTagName('des')[0].toxml()
            des = des.replace('<des>','').replace('</des>','')
            # message = "ERROR: "+ str(cod)+ "\t" + des + u"\n\n -- PROBAR A PINCHAR OTRA POSICIÓN --"
            message = "ERROR: "+ str(cod)+ "\t" + des +u"\n      -- DESCUENTOS CATASTRALES --"
            # self.showJCCMessageERR( message,'','Identificador de Catastro' )
            QApplication.restoreOverrideCursor()
            self.showJCCMessageERR( message,'','Identificador de Catastro' )
            return (u'ERROR '+message)



        # IDENTIFICAMOS DATOS CATASTRALES
        # print xml_txt
        cn = None
        cudnp = None
        cucons = None
        cucul = None

        message = u''       # Mensaje con el contenido de construcciones y subparcelas
        supTOTAL = 0        # Superficie total de la parcela
        supCONSTR = 0       # Superficie construida
        listaSUBP = ['No hay subparcelas']          # Listado del contenido de los datos de supparcelas
        listaCONSTRU = ['No hay construcciones']    # Listado del contenido de los datos de construcciones
        DATOSURBA = u''             #   Datos generales parcela urbana

        for loc in xml.iter(u"{http://www.catastro.meh.es/}idbi"):
            cn_dat = loc.find(u"{http://www.catastro.meh.es/}cn")
            if cn_dat != None:
                cn = cn_dat.text
                pass

        for loc in xml.iter(u"{http://www.catastro.meh.es/}control"):
            cudnp = loc.find(u"{http://www.catastro.meh.es/}cudnp")
            cucons = loc.find(u"{http://www.catastro.meh.es/}cucons")
            cucul = loc.find(u"{http://www.catastro.meh.es/}cucul")

        for loc in xml.iter(u"{http://www.catastro.meh.es/}rc"):
            pc1 = loc.find(u"{http://www.catastro.meh.es/}pc1").text
            pc2 = loc.find(u"{http://www.catastro.meh.es/}pc2").text
            car = loc.find(u"{http://www.catastro.meh.es/}car").text
            cc1 = loc.find(u"{http://www.catastro.meh.es/}cc1").text
            cc2 = loc.find(u"{http://www.catastro.meh.es/}cc2").text
            REFCAT = pc1 + pc2 + car + cc1 + cc2
        # print REFCAT

        cpo = '000'
        cpa = '00000'
        cv = '000'
        nv = 'XXX'
        pnp = '0000'
        if cn == 'UR':
            tipoPAR = 'URBANA'          # DATOS CATASTRALES URBANO
            listcv = xml_dom.getElementsByTagName('cv')
            if listcv: cv = listcv[0].toxml()
            cv = cv.replace('<cv>','').replace('</cv>','')
            listnv = xml_dom.getElementsByTagName('nv')
            if listnv: nv = listnv[0].toxml()
            nv = nv.replace('<nv>','').replace('</nv>','')
            listpnp = xml_dom.getElementsByTagName('pnp')
            if listpnp: pnp = listpnp[0].toxml()
            pnp = pnp.replace('<pnp>','').replace('</pnp>','')

            for loc in xml.iter(u"{http://www.catastro.meh.es/}debi"):
                luso = loc.find(u"{http://www.catastro.meh.es/}luso")
                sfc = loc.find(u"{http://www.catastro.meh.es/}sfc")
                cpt = loc.find(u"{http://www.catastro.meh.es/}cpt")
                ant = loc.find(u"{http://www.catastro.meh.es/}ant")
                if luso != None: DATOSURBA += "USO: "+ luso.text + "\n"
                if cpt != None: DATOSURBA += "Coef.Part: "+ cpt.text + "\n"
                if ant != None: DATOSURBA += "Antiguedad: "+ ant.text
                if sfc != None: supTOTAL = float(sfc.text)
                else: sfc = 0
            cpo = pc1[:4]
            cpa = pc1[4:7]


        elif cn == 'RU':
            tipoPAR = 'RUSTICA'         # DATOS CATASTRALES RUSTICA
            cpo = xml_dom.getElementsByTagName('cpo')[0].toxml()
            cpo = cpo.replace('<cpo>','').replace('</cpo>','')
            cpa = xml_dom.getElementsByTagName('cpa')[0].toxml()
            cpa = cpa.replace('<cpa>','').replace('</cpa>','')
            cpo = self.completarCeros(cpo,3)
            cpa = self.completarCeros(cpa,5)

        else:
            tipoPAR = 'S/D'             # DATOS CATASTRALES RÚSTICA/URBANA (Diseminados)



        cp = xml_dom.getElementsByTagName('cp')[0].toxml()
        cp = cp.replace('<cp>','').replace('</cp>','')
        cm = xml_dom.getElementsByTagName('cm')[0].toxml()
        cm = cm.replace('<cm>','').replace('</cm>','')
        cp = self.completarCeros(cp,2)
        cm = self.completarCeros(cm,3)

        cmc = xml_dom.getElementsByTagName('cmc')[0].toxml()
        cmc = cmc.replace('<cmc>','').replace('</cmc>','')
        cmc = self.completarCeros(cmc,3)
        np = xml_dom.getElementsByTagName('np')[0].toxml()
        np = np.replace('<np>','').replace('</np>','')
        nm = xml_dom.getElementsByTagName('nm')[0].toxml()
        nm = nm.replace('<nm>','').replace('</nm>','')
        codnomPRO = cp + "-" + np                           #Código y nombre de provincia
        codnomMUN = cm + "-" + nm + " (CODCAT:"+ cmc +")"   #Código y nombre de municipio
        # print codnomPRO
        # print codnomMUN

        if cudnp != None:
            message += u'Num.B.I.: ' + str(cudnp.text) + u'    '
            cudnpVAL = int(cudnp.text)

        if cucons != None:      # COMPROBACIÓN DE NÚMERO DE CONSTRUCCIONES

            listaCONSTRU = []
            message += u'Num.Cons: ' + str(cucons.text) + u'    '
            cuconsVAL = int(cucons.text)
            if (cuconsVAL > 0):
                # Hay varias Construcciones en la misma REFCAT
                count = 0
                # FALLA EN PARCELA 02071A50800010
                lcd=u's/d'
                es=u's/d'
                pt=u's/d'
                pu=u's/d'
                stl=u'0'

                for loc in xml.iter(u"{http://www.catastro.meh.es/}cons"):
                    CONST = u'CONSTRUCCIÓN: '
                    lcdVAL = loc.find(u"{http://www.catastro.meh.es/}lcd")
                    if lcdVAL!= None : lcd= lcdVAL.text
                    for loc1 in loc.iter(u"{http://www.catastro.meh.es/}loint"):
                        esVAL = loc1.find(u"{http://www.catastro.meh.es/}es")
                        if esVAL!= None : es= esVAL.text
                        ptVAL = loc1.find(u"{http://www.catastro.meh.es/}pt")
                        if ptVAL!= None : pt= ptVAL.text
                        puVAL = loc1.find(u"{http://www.catastro.meh.es/}pu")
                        if puVAL!= None : pu= puVAL.text
                    for loc1 in  loc.iter(u"{http://www.catastro.meh.es/}dfcons"):
                        stlVAL = loc1.find(u"{http://www.catastro.meh.es/}stl")
                        if stlVAL!= None : stl= stlVAL.text

                    CONST += u'' + lcd + '  Esca:' + es + '  Plan:' + pt + '  Puer:' + pu + '  '+ locale.format("%d", float(stl), grouping=True) + u' m2\n'
                    listaCONSTRU.append(CONST)
                    count += 1
                    supCONSTR += float(stl)
                    pass

                pass
            else:
                listaCONSTRU = ['No hay construcciones']

        if cucul != None:   # COMPROBACIÓN DE NÚMERO DE SUBPARCELAS
            listaSUBP = []
            message += u'Num.Subp: ' + str(cucul.text) + u'    '
            cuculVAL = int(cucul.text)
            if (cuculVAL > 0):
                # Hay varias Subparcelas en la misma REFCAT
                count = 0
                for loc in xml.iter(u"{http://www.catastro.meh.es/}spr"):
                    SUBP = u'SUBP: '
                    cspr = loc.find(u"{http://www.catastro.meh.es/}cspr").text
                    ccc = xml_dom.getElementsByTagName('ccc')[count].toxml()
                    ccc = ccc.replace('<ccc>','').replace('</ccc>','')
                    dcc = xml_dom.getElementsByTagName('dcc')[count].toxml()
                    dcc = dcc.replace('<dcc>','').replace('</dcc>','')
                    ip = xml_dom.getElementsByTagName('ip')[count].toxml()
                    ip = ip.replace('<ip>','').replace('</ip>','')
                    ssp = xml_dom.getElementsByTagName('ssp')[count].toxml()
                    ssp = ssp.replace('<ssp>','').replace('</ssp>','')
                    SUBP += u'' + cspr + '  ' + ccc + '  ' + dcc + '   Int.Prod:' + ip + '   Sup: ' + locale.format("%d", float(ssp), grouping=True) + u' m2\n'
                    listaSUBP.append(SUBP)
                    count += 1
                    supTOTAL += float(ssp)
                    if ccc =='VT':
                        tipoPAR = 'X-Descuento (D.P.)'
                        cn = 'X'
                    if ccc =='HG':
                        tipoPAR = u'X-Descuento (Hidrografia)'
                        cn = 'X'

                    pass
            else:
                listaSUBP = ['No hay subparcelas']

        if nv[:1] == 'D':
            tipoPAR = nv
            cn = nv[:2]

        if tipoPAR == 'S/D':
            cn = 'X'

        # print (REFCAT14, '  ', cn, tipoPAR)

        return (tipoPAR,        #0 - TIPO DE PARCELA (Urbana, Rústica, Diseminado, X-Descuento)
                codnomPRO,      #1 - Código y nombre de provincia
                codnomMUN,      #2 - Código y nombre de municipio
                message,        #3 - Contador de BI, CONS y SUBP
                listaSUBP,      #4 - Listado del contenido de los datos de supparcelas
                listaCONSTRU,   #5 - Listado del contenido de los datos de construcciones
                supTOTAL,       #6 - Superficie de la parcela
                supCONSTR,      #7 - Superficie construida
                DATOSURBA,      #8 - Datos generales parcela urbana
                cp,             #9 - Código de la provincia
                cm,             #10- Código del Municipio
                cmc,            #11- Código catastral del Municipio
                REFCAT,         #12- REFCAT completa (20 dígitos)
                cn,             #13- Tipo parcela RU, UR, DI, X
                cpo,            #14- Poligono
                cpa,            #15- Parcela
                cv,             #16- Codigo de la via
                pnp,            #17- Numero de la via
                np,             #18- Nombre de Provincia
                nm              #19- Nombre de Municipio
                )


    def cargarCapaParcelaCatastroSHP(self,rc,nombrecapa,atributos, tipo,crs):
        # cargarCapaParcelaCatastroSHP(self,rc,nombrecapa)
        #   Permite cargar desde internet el GMl de una parcela y la mete en un grupo
        #   ENTRADA:
        #       rc - Referencia catastral de la parcela
        #       nombrecapa - Nombre de la capa en la que se añadira la parcela
        #       atributos = PCAT1,PCAT2,EJERCICIO,NUM_EXP,CONTROL,COORY,VIA,NUMERO,NUMERODUP,NUMSYMBOL,AREA,FECHAALTA,FECHABAJA,MAPA,DELEGACIO,MUNICIPIO,MASA,HOJA,TIPO,PARCELA,COORX
        #       tipo='gml', tipo='shp'
        #   SALIDA:
        #       layer - layer de la parcela cargada
        #
        #CREADA ASS

        # VARIABLES

        nom_layer = nombrecapa
        # estiloCAPA = self.current_configuration.catastro_tool["dir_estilos_catastro"] + u'/PARCELAS_SELECCION.qml'
        estiloCAPA = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + u'/PARCELAS_SELECCION.qml')
        srsname = crs.replace( 'EPSG:', 'EPSG::')
        epsg = int(crs[5:])
        crs = 'crs='+ str(epsg)
        tipo_layer= 'MultiPolygon'
        dest = 'memory'
        destDir = r"c:/Temp/"
        if not os.path.exists(destDir):
            os.makedirs(destDir)

        # Creación de CAPA DE PARCELAS

        # Comprobamos si existe la capa
        layerEXIST = QgsProject.instance().mapLayersByName(nom_layer)
        if not layerEXIST or layerEXIST[0].featureCount() == 0:
            if layerEXIST and layerEXIST[0].featureCount() == 0:
                vl = layerEXIST[0]
                QgsProject.instance().removeMapLayer( vl.id() )
            # CREACIÓN DE LA CAPA
            if dest == 'memory':
                vl = QgsVectorLayer(tipo_layer+'?'+crs, nom_layer, dest)
                # vl = QgsVectorLayer(abs_file+'|'+tipo_layer+'?'+crs, nombreCAPA, "ogr")
                # qgis.utils.iface.messageBar().clearWidgets()
                # iface.messageBar().clearWidgets()
                # vl.setCrs(QgsCoordinateReferenceSystem(epsg, QgsCoordinateReferenceSystem.EpsgCrsId))
            else:
                # print dest
                if not os.path.isfile(dest):
                    print (u'NO EXISTE %s - HAY QUE CREARLO'%(dest))
                    # return
                    # pass
                # vl = QgsVectorLayer(dest, nom_layer, "ogr")
                vl = QgsVectorLayer(dest+'|'+tipo_layer+'?'+crs, nom_layer, "ogr")
                # qgis.utils.iface.messageBar().clearWidgets()
                # vl.setCrs(QgsCoordinateReferenceSystem(epsg, QgsCoordinateReferenceSystem.EpsgCrsId))


                error = QgsVectorFileWriter.writeAsVectorFormat(vl, dest, nom_layer, None, "ESRI Shapefile")
                if error == QgsVectorFileWriter.NoError:
                    print("EXITO!")
                    pass
                vl.setCrs(QgsCoordinateReferenceSystem(epsg, QgsCoordinateReferenceSystem.EpsgCrsId))

            pr = vl.dataProvider()
            vl.startEditing()

            # AÑADIMOS LOS CAMPOS
            pr.addAttributes([
                QgsField("RC14", QVariant.String),
                QgsField("PCAT1", QVariant.String),
                QgsField("PCAT2", QVariant.String),
                QgsField("EJERCICIO", QVariant.Int),
                QgsField("NUM_EXP", QVariant.Int),
                QgsField("CONTROL", QVariant.Int),
                QgsField("COORY", QVariant.Double),
                QgsField("VIA", QVariant.Int),
                QgsField("NUMERO", QVariant.Int),
                QgsField("NUMERODUP", QVariant.String),
                QgsField("NUMSYMBOL", QVariant.Int),
                QgsField("AREA", QVariant.Double),
                QgsField("FECHAALTA", QVariant.String),
                QgsField("FECHABAJA", QVariant.String),
                QgsField("MAPA", QVariant.String),
                QgsField("DELEGACIO", QVariant.Int),
                QgsField("MUNICIPIO", QVariant.Int),
                QgsField("MASA", QVariant.String),
                QgsField("HOJA", QVariant.String),
                QgsField("TIPO", QVariant.String),
                QgsField("PARCELA", QVariant.String),
                QgsField("COORX", QVariant.Double),
                QgsField("NOM_MUNI", QVariant.String),
                ])
            vl.updateFields()

            # Añade la capa a la TOC
            QgsProject.instance().addMapLayer(vl)

            # Establecemos el estilo de la capa
            vl.loadNamedStyle(estiloCAPA)

            # Commit changes y vuelve a editar
            vl.commitChanges()
            vl.startEditing()
        else:
            vl = layerEXIST[0]
            vl.startEditing()

        # Ponemos la capa arriba
        root = QgsProject.instance().layerTreeRoot()
        myvl = root.findLayer(vl.id())
        myvlclone = myvl.clone()
        parent = myvl.parent()
        root.insertChildNode(0, myvlclone)
        parent.removeChildNode(myvl)

        # Hacemos la capa visible
        QgsProject.instance().layerTreeRoot().findLayer(vl.id()).setItemVisibilityChecked(True)

        # Obtención del GML de la parcela (EJEMPLO)
        #   http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?
        #     service=wfs&
        #     version=2&
        #     request=getfeature&
        #     STOREDQUERIE_ID=GetParcel&
        #     refcat=3662001TF3136S&
        #     srsname=EPSG::25830

        # url = u'http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?'
        url = self.current_configuration.catastro_tool["url_catastro_DescGML"]

        params = {
            'service': 'wfs',
            'version': 2,
            'request': 'getfeature',
            'STOREDQUERIE_ID': 'GetParcel',
            'refcat': rc,
            'srsname': srsname
            }
        # print ('rc= ',rc)
        # print ('srsname= ',srsname)
        str_values = {}
        for k, v in params.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        sourceCAPA = url + data
        nombreGML = destDir + 'GMLprov.gml'

        response = requests.get(sourceCAPA)
        with open(nombreGML, 'wb') as file:
            file.write(response.content)
        layer = QgsVectorLayer(nombreGML, rc, 'ogr')
        layer.setCrs(QgsCoordinateReferenceSystem(epsg, QgsCoordinateReferenceSystem.EpsgCrsId))

        # Obtención de valores del GML, area, geometría, centroide
        feats = layer.getFeatures()
        areagml = 0
        for feat in feats:
            areagml = feat['areaValue']     # AREA SACADA DEL GML
            beginLifespanVersion = feat['beginLifespanVersion']     # beginLifespanVersion SACADO DEL GML
            # print ('Parcela %s - Area '%rc, areagml )
            # print 'areagml= ',areagml
            parcGML = feat.geometry()
            bbox = feat.geometry().boundingBox()
            centroid = feat.geometry().boundingBox().center()   # El centroide es el del boundingBox
            xgeom = centroid[0]
            ygeom = centroid[1]
            atributos[11] = areagml
            atributos[12] = beginLifespanVersion
            atributos[21] = xgeom
            atributos[6] = ygeom

            # Comprobamos si la parcela ya existe
            consulta = u'"PCAT1" = \''+atributos[1]+'\' and "PCAT2" = \''+atributos[2]+'\''
            expr = QgsExpression( consulta )
            it = vl.getFeatures( QgsFeatureRequest( expr ) )
            ids = [j.id() for j in it]
            # print consulta
            # print ('ENCONTRADOS '+ str(len(ids))+' CON RC= '+rc)
            if len(ids) == 0:
                # print ('añadimos la parcela '+rc[:14])
                # print 'NO EXISTE LA PARCELA '+rc
                # Añadimos la Geometría y Atributos al ELEMENTO de la capa PARCELAS
                feat1 = QgsFeature()
                feat1.setGeometry(parcGML)
                feat1.setAttributes(atributos)
                vl.addFeature(feat1)

        vl.commitChanges()
        vl.updateExtents()

        return vl, areagml, parcGML, bbox


    def consultaCatastroCodProvtoProvincia(self,codigo_provincia):
        # consultaCatastroCodProvtoProvincia(self,codigo_provincia)
        #   Devuelve el Nombre de la Provincia a partir del codigo
        #   return nombre_prov
        # url = u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaProvincia?'
        url = self.current_configuration.catastro_tool["url_catastro_Provincia"]

        print ('consultaCatastroCodProvtoProvincia -'+ url)
        try:
            req = urllib.request.urlopen(url)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.consultaCatastroCodProvtoProvincia lin:1762)")
            return ("ERROR")
        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)


        nombre_prov = 'NOMBRE_PROV'

        for prov in xml.iter(u"{http://www.catastro.meh.es/}prov"):
            # print prov.find(u"{http://www.catastro.meh.es/}cpine").text , prov.find(u"{http://www.catastro.meh.es/}np").text
            if(prov.find(u"{http://www.catastro.meh.es/}cpine").text == codigo_provincia):
                nombre_prov = prov.find(u"{http://www.catastro.meh.es/}np").text
                break
        # print ('codigo_provincia = ', codigo_provincia, '  nombre_prov = ', nombre_prov, '(fun.consultaCatastroCodProvtoProvincia lin:1774)')
        return nombre_prov


    def consultaCatastroCodMunitoMunicipio(self,nombre_prov, codigo_muni):
        # consultaCatastroCodMunitoMunicipio(self,nombre_prov, codigo_muni)
        #   Devuelve el Nombre del Municipio a partir de la Provincia del codigo_muni
        #   return nombre_muni

        # url = u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaMunicipio?'
        url = self.current_configuration.catastro_tool["url_catastro_municipio"]

        params = {
            'Provincia' : nombre_prov.encode("utf-8", errors="ignore"),
            'Municipio' : ''
            }
        data = urllib.parse.urlencode(params)
        # print ('consultaCatastroCodMunitoMunicipio -'+ url+data)
        try:
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.consultaCatastroCodMunitoMunicipio lin:1865)")
            return ("ERROR")
        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)

        # print ('nombre_prov = '+nombre_prov, '  codigo_muni = '+codigo_muni, '(fun.consultaCatastroCodMunitoMunicipio lin:1869)')

        nombre_muni = 'NOMBRE_MUNI'
        cmc = '000'

        for muni in xml.iter(u"{http://www.catastro.meh.es/}muni"):
            loine = muni.find(u"{http://www.catastro.meh.es/}loine")
            nombre_muni = muni.find(u"{http://www.catastro.meh.es/}nm").text
            cm = loine.find(u"{http://www.catastro.meh.es/}cm")
            cm = self.completarCeros(cm.text,3)
            locat = muni.find(u"{http://www.catastro.meh.es/}locat")
            cmc = locat.find(u"{http://www.catastro.meh.es/}cmc")
            cmc = self.completarCeros(cmc.text,3)
            # print (nombre_muni, cm, cmc)
            if(cm == codigo_muni):
                break
        # print ('ENTRADA: ', nombre_prov, codigo_muni)
        # print ('SALIDA: ', nombre_muni, cmc)
        return nombre_muni, cmc


    def cargaCatastroMuni(self, cp, cmc, nombre_muni, origenData, year, iface, mess):
        # Permite descargarse las capas de catastro de Polígonos y Parcelas conforme a Inspire
        # cp = '02' Código de Provincia
        # cmc = '008' Código de Municipio Catastral
        # nombre_muni =
        # origenData = 'web' o 'dir'
        # year = 'WEB', o Año a cargar si es desde diretorio
        # iface = interface
        # mess = True, False - Aparecen o no los mensajes de avisos
        
        # URL PARCELAS       'http://www.catastro.minhap.es/INSPIRE/CadastralParcels/02/02006-ALCADOZO/A.ES.SDGC.CP.02006.zip'
        # URL DIRECCIONES    'http://www.catastro.minhap.es/INSPIRE/Addresses/02/02005-ALBOREA/A.ES.SDGC.AD.02005.zip'
        # URL CONSTRUCCIONES 'http://www.catastro.minhap.es/INSPIRE/Buildings/02/02004-ALBATANA/A.ES.SDGC.BU.02004.zip'
        
        ##-------------------------------------------------------------------------------------------------------------------##
        srs =  iface.mapCanvas().mapSettings().destinationCrs().authid()

        if origenData == 'web':
            year = 'WEB'

        if(cmc == None):
            QApplication.restoreOverrideCursor()
            message = u"TÉRMINO MUNICIPAL NO DETECTADO"+ u"\n\n -- PROBAR A PINCHAR OTRA POSICIÓN --"
            self.showJCCMessage( message,'','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return 'ERROR', 'ERROR'

        codigo_muni_final = self.completarCeros(cmc,3)
        codigo = self.completarCeros(cp,2) + codigo_muni_final

        root = QgsProject.instance().layerTreeRoot()
        nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (" +year + ")"
        grupoBUSCAT = root.findGroup(nombregrupo)
        if grupoBUSCAT is None:
        
            message = u"Se van a cargar las capas del \n Catastro del año {} de {} - ({})\n\n -- LA OPERACIÓN TARDARÁ UNOS MINUTOS --".format(year,nombre_muni, codigo)
            if mess == True:
                if origenData == 'web':
                    message = u"Se van a cargar desde la Sede Electrónica de Catastro \n las capas del catastro actual \n del T. M.  {} - ({})\n\n -- LA OPERACIÓN TARDARÁ UNOS MINUTOS --".format(nombre_muni, codigo)
            
                QApplication.restoreOverrideCursor()                
                resp = self.showJCCMessageYESNO( message,'','Capas de Catastro' )
                if resp == 4194304: # Se ha pulsado cancelar
                    QApplication.restoreOverrideCursor()
                    iface.mainWindow().statusBar().clearMessage()
                    return 'ERROR', 'ERROR'
                QApplication.setOverrideCursor(Qt.WaitCursor)

        else:
            QApplication.restoreOverrideCursor()
            if mess == True:
                message = u"Ya están cargadas las Capas del Catastro de \n" + nombre_muni + " (" + codigo + ")"
                self.showJCCMessage( message,'','Capas de Catastro' )
                iface.mainWindow().statusBar().clearMessage()
            capaCatPol = "CAT- POL- " + nombre_muni+ " - " + codigo
            capaCatPar = "CAT- PAR- " + nombre_muni+ " - " + codigo
            return capaCatPol, capaCatPar
        
        progress = u'Cargando datos desde CATASTRO {codigo} - {nombre_muni}...'.format(codigo=codigo, nombre_muni=nombre_muni)
        iface.mainWindow().statusBar().showMessage(progress)        

        resumen_capas = []
        if (codigo_muni_final != None):
            
            if origenData == 'web':
                # ------- CARGA DE CAPAS DE CATASTRO DESDE SEDE ELECTRÓNICA DE CATASTRO ---------
                # result = self.fun.cargaCatastroMuni(codigo_provincia, codigo_muni_final, nombre_muni)
        
                listURLS = [
                    'http://www.catastro.minhap.es/INSPIRE/CadastralParcels/02/02006-ALCADOZO/A.ES.SDGC.CP.02006.zip',
                    'http://www.catastro.minhap.es/INSPIRE/Addresses       /02/02005-ALBOREA /A.ES.SDGC.AD.02005.zip',
                    'http://www.catastro.minhap.es/INSPIRE/Buildings       /02/02004-ALBATANA/A.ES.SDGC.BU.02004.zip'
                    ]
                messagePRUEBA = u"Se van a cargar las capas del catastro actual \n del T. M. ({}) {}".format(cp,cmc)
                print (u"Se van a cargar las capas del catastro actual \n del T. M. ({}) {}".format(cp,cmc))

                cpcmc= cp+cmc
                tipoDESC = 'CadastralParcels'
                codDESC = 'CP'

                #web xml de datos
                #http://www.catastro.minhap.es/INSPIRE/CadastralParcels/02/ES.SDGC.CP.atom_02.xml
                url = 'http://www.catastro.minhap.es/INSPIRE/{tipoD}/{prov}/ES.SDGC.{codD}.atom_{prov}.xml' .format(tipoD=tipoDESC, codD=codDESC, prov=cp)
                # url = 'http://www.catastro.minhap.es/INSPIRE/{tipoD}/{prov}/{cmc}-{nombre_muni}/ES.SDGC.{codD}.atom_{prov}.xml' .format(tipoD=tipoDESC, codD=codDESC, prov=cp, cmc=cmc, nombre_muni=nombre_muni)
                # xmldoc = minidom.parse(urllib2.urlopen(url))
                xmldoc = minidom.parse(urllib.request.urlopen(url))
                itemlist = xmldoc.getElementsByTagName('link')
                zip_file_url = ''
                for s in itemlist:
                    zip_file_url_tm = s.attributes['href'].value
                    # print zip_file_url_tm
                    if zip_file_url_tm.find(cmc) != -1:
                        zip_file_url = zip_file_url_tm
                        # print 'ENCONTRADO: ', zip_file_url
                        break

                print ('cargaCatastroMuni - '+zip_file_url)
                try:
                    zip_file_url = self.convertTOurl(zip_file_url)
                except:
                    QApplication.restoreOverrideCursor()
                    resp = self.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -','','Consulta a Catastro' )
                    iface.mainWindow().statusBar().clearMessage()
                    return 'ERROR', 'ERROR'

                dest = u'c:/temp/catastro_temp/'
                if not os.path.exists(dest):
                    os.makedirs(dest)

                filelist = []
                try:
                    print ('Descargado el fichero de '+ cpcmc +' - '+ nombre_muni+ '\n')
                    url = urllib.request.urlopen(zip_file_url)
                    z = zipfile.ZipFile(io.BytesIO(url.read()))
                    z.extractall(dest)
                    for file in z.namelist():
                        # filelist.append(file[4:])
                        filelist.append(file)
                        # print file[4:]
                    result = 'OK'

                except Exception as e:
                    print ('No se puede descargar el fichero de '+ cpcmc +' - '+ nombre_muni+ '\n'+ str(e))
                    QApplication.restoreOverrideCursor()
                    result = 'ERROR'

                # dest = result[1]
                epsg = int(srs[5:])
                crs = 'crs='+ srs.lower()
                tipo_layer= 'Polygon'
                abs_path = []

                for file in filelist:
                    if file.endswith(".gml"):
                        abs_file = dest+file
                        
                        # Establecemos el nombre y estilo de la capa
                        if file.find('cadastralzoning') != -1:
                            # Capa de Poligonos
                            nombreCAPA = "CAT- POL- " + nombre_muni+ " - " + codigo
                            estiloCAPA = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + 'CAT_POLIGONO_WEB.qml')
                            capaCatPol = nombreCAPA
                        else:
                            # Capa de Parcelas
                            nombreCAPA = "CAT- PAR- " + nombre_muni+ " - " + codigo
                            estiloCAPA = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + 'CAT_PARCELA_WEB.qml')
                            capaCatPar = nombreCAPA

                        # vl = QgsVectorLayer(abs_file+'|'+tipo_layer+'?'+crs, nombreCAPA, "ogr")
                        vl = QgsVectorLayer(abs_file, nombreCAPA, "ogr")
                        print ('SE CARGA - ', nombreCAPA, abs_file)
                        vl.loadNamedStyle(estiloCAPA)
                        QgsProject.instance().addMapLayer(vl, False)
                        resumen_capas.append(vl)
                        
            else:
                # ------- CARGA DE CAPAS DE CATASTRO DESDE DIRECTORIO ---------
                # CAPAS DE CATASTRO DE URBANA
                ################################################################################################
                ################################################################################################
                #               REVISAR LA CARGA DESDE DIRECTORIO
                ################################################################################################
                ################################################################################################
                for capa in self.current_configuration.catastro_tool["capas_urbanas"]:
                    # year = str(self.current_configuration.catastro_tool["year"])
                    provincia_text = self.getProvinciaText(codigo_provincia)
                    if(provincia_text == None):
                        QApplication.restoreOverrideCursor()
                        QgsMessageLog.logMessage( "Provincia no perteneciente a Castilla La Mancha","jccm_bar")
                        iface.mainWindow().statusBar().clearMessage()
                        return
                    source = self.current_configuration.catastro_tool["dir_shps"] + year + u"/" + provincia_text + u"/" + codigo_provincia + codigo_muni_final + u"u/" + capa["capa"]
                    nombre = "CAT-" + capa["nombre"] + nombre_muni + " " + year
                    estilo = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + capa["estilo"])
                    capa_cargada = self.getSHP(self.iface, source, nombre, estilo)
                    if(capa_cargada != None):
                        QgsMapLayerRegistry.instance().addMapLayer(capa_cargada, False)
                        resumen_capas.append(capa_cargada)
      
                    pass

                # CAPAS DE CATASTRO DE RÚSTICA                                   
                for capa in self.current_configuration.catastro_tool["capas_rusticas"]:
                    year = str(self.current_configuration.catastro_tool["year"])
                    provincia_text = self.getProvinciaText(codigo_provincia)
                    if(provincia_text == None):
                        QApplication.restoreOverrideCursor()
                        QgsMessageLog.logMessage( "Provincia no perteneciente a Castilla La Mancha","jccm_bar")
                        iface.mainWindow().statusBar().clearMessage()
                        return
                    source = self.current_configuration.catastro_tool["dir_shps"] + year + u"/" + provincia_text + u"/" + codigo_provincia + codigo_muni_final + u"r/" + capa["capa"]
                    nombre = "CAT-" + capa["nombre"] + nombre_muni + " " + year
                    estilo = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + capa["estilo"])
                    capa_cargada = self.getSHP(self.iface, source, nombre, estilo)
                    if(capa_cargada != None):
                        QgsMapLayerRegistry.instance().addMapLayer(capa_cargada, False)
                        resumen_capas.append(capa_cargada)
                ################################################################################################
                ################################################################################################
                pass

            if not resumen_capas:
                # Se comprueba si la lista de capas de catastro está vacía
                QApplication.restoreOverrideCursor()
                message = "No hay ficheros de capas del catastro \n" + nombregrupo
                QApplication.restoreOverrideCursor()
                self.showJCCMessageERR( message,'','Carga de capas de Catastro' )
                iface.mainWindow().statusBar().clearMessage()
                return
            
            grupoCAT = root.insertGroup(self.current_configuration.catastro_tool["pos_toc"], nombregrupo)

            for capa in resumen_capas:
                grupoCAT.insertChildNode(0, QgsLayerTreeLayer(capa))
            return capaCatPol, capaCatPar


        ##-------------------------------------------------------------------------------------------------------------------##

    '''
    def cargaCatastroMuniPROJ(self, result, dest, filelist, srs, nombre_muni, codigo, resumen_capas):
        # dest = result[1]
        epsg = int(srs[5:])
        crs = 'crs='+ srs.lower()
        tipo_layer= 'Polygon'
        abs_path = []

        # for file in result[2]:
        for file in filelist:
            if file.endswith(".gml"):
                abs_file = dest+file
                print (abs_file)
                # Establecemos el nombre y estilo de la capa
                if file.find('cadastralzoning') != -1:
                    # Capa de Poligonos
                    nombreCAPA = "CAT- POL- " + nombre_muni+ " - " + codigo
                    # estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + 'CAT_POLIGONO_WEB.qml')
                    estiloCAPA = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + 'CAT_POLIGONO_WEB.qml')
                    
                else:
                    # Capa de Parcelas
                    nombreCAPA = "CAT- PAR- " + nombre_muni+ " - " + codigo
                    # estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + 'CAT_PARCELA_WEB.qml')
                    estiloCAPA = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + 'CAT_PARCELA_WEB.qml')

                # vl = QgsVectorLayer(abs_file+'|'+tipo_layer+'?'+crs, nombreCAPA, "ogr")
                print ('CARGO - ', nombreCAPA)
                vl = QgsVectorLayer(abs_file, nombreCAPA, "ogr")
                vl.loadNamedStyle(estiloCAPA)
                QgsProject.instance().addMapLayer(vl, False)
                resumen_capas.append(vl)
        return resumen_capas
    '''

    def getProvinciasCatastro(self):
        # url = u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaProvincia?'
        url = self.current_configuration.catastro_tool['url_catastro_Provincia']

        print ('getProvinciasCatastro - ', url)
        try:
            req = urllib.request.urlopen(url)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.getProvinciasCatastro lin:155)")
            return 'nocat'

        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)

        lista_provincias = []
        lista_cpine = []

        for prov in xml.iter(u"{http://www.catastro.meh.es/}prov"):
            np = prov.find(u"{http://www.catastro.meh.es/}np")
            cpine = prov.find(u"{http://www.catastro.meh.es/}cpine")
            lista_provincias.append(np.text)
            lista_cpine.append(cpine.text)
            # print (cpine.text,',', np.text)

        return lista_provincias, lista_cpine


    def getProvinciaCode(self,provincia):
        # getProvinciaCode(self,provincia)
        #   Devuelve el código catastral de Provincia
        #   return codigo_provincia

        # url = u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaProvincia?'
        url = self.current_configuration.catastro_tool['url_catastro_Provincia']

        print ('getProvinciaCode - ',url)
        try:
            req = urllib.request.urlopen(url)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.getProvinciaCode lin:1842)")
            return 'nocat'

        try:
            xml_txt =  req.read()
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a catastro")
            return

        xml = ElementTree.fromstring(xml_txt)

        codigo_provincia = ''

        for prov in xml.iter(u"{http://www.catastro.meh.es/}prov"):
           if(prov.find(u"{http://www.catastro.meh.es/}np").text == provincia):
               codigo_provincia = prov.find(u"{http://www.catastro.meh.es/}cpine").text
        return codigo_provincia


    def getMunicipiosCatastro(self, provincia):
        # url = 'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaMunicipio?'
        url = self.current_configuration.catastro_tool["url_catastro_municipio"]

        params = {'Provincia' : provincia,
                  'Municipio' : ''
                  }

        data = urllib.parse.urlencode(params)

        print ('getMunicipiosCatastro - ', url+data)
        try:
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            self.fun.showJCCMessage(u"Error de conexión a internet (catastroBuscador.updateCombos lin:547)")
            return 'nocat'

        try:
            xml_txt =  req.read()
        except:
            self.fun.showJCCMessage(u"Error de conexión a catastro en LISTA MUNICIPIOS")
            return
        xml = ElementTree.fromstring(xml_txt)
        # print (xml_txt)

        lista_municipios = []

        for muni in xml.iter(u"{http://www.catastro.meh.es/}muni"):
            nm = muni.find(u"{http://www.catastro.meh.es/}nm")
            locat = muni.find(u"{http://www.catastro.meh.es/}locat")
            cd = locat.find(u"{http://www.catastro.meh.es/}cd")
            cmc = locat.find(u"{http://www.catastro.meh.es/}cmc")
            loine = muni.find(u"{http://www.catastro.meh.es/}loine")
            cm = loine.find(u"{http://www.catastro.meh.es/}cm")
            lista_municipios.append(nm.text)
            # print (cmc.text, cm.text, nm.text)
            # print (cd.text,',',cmc.text,',',self.completarCeros(cd.text,2)+self.completarCeros(cmc.text,3),',',cm.text,',',nm.text)

        return lista_municipios


    def getMuniCode(self,nombre_prov, nombre_muni):
        # getMuniCode(self,nombre_prov, nombre_muni)
        #   Devuelve el código catastral del Muhicipio
        #   return codigo_muni

        # url = u'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/ConsultaMunicipio?'
        url = self.current_configuration.catastro_tool["url_catastro_municipio"]

        params = [
            ('Provincia',nombre_prov.encode("utf-8", errors="ignore")),
            ('Municipio',nombre_muni.encode("utf-8", errors="ignore"))
            ]
        data = urllib.parse.urlencode(params)
        print ('getMuniCode - ', url+data)
        try:
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.getMuniCode lin:1877)")
            return

        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)

        codigo_muni = ''

        #print xml_txt
        for muni in xml.iter(u"{http://www.catastro.meh.es/}muni"):
           if(muni.find(u"{http://www.catastro.meh.es/}nm").text == nombre_muni):
               locat = muni.find(u"{http://www.catastro.meh.es/}locat")
               cmc = locat.find(u"{http://www.catastro.meh.es/}cmc")
               codigo_muni = cmc.text
        return codigo_muni

        
    def consultaCatastroDATProMunPolPar(self, Provincia, Municipio, Poligono, Parcela):
        #    Obtenemos datos de la parcela con entrada de polígono y parcela
        # http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/Consulta_DNPPP?
        # http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/Consulta_DNPPP?Provincia=CUENCA&Municipio=EL VALLE DE ALTOMIRA&Poligono=27&Parcela=112

        params = [
            ('Provincia', Provincia),
            ('Municipio', Municipio),
            ('Poligono', Poligono),
            ('Parcela', Parcela)
            ]
    
        url = self.current_configuration.catastro_tool["url_catastro_DNPPP"]
        # url = 'http://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCallejero.asmx/Consulta_DNPPP?'
              
        data = urllib.parse.urlencode(params)
        print ('consultaCatastroDATPARCELA - ', url+data)
        try:
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.consultaCatastroDATPARCELA lin:3917)")
            return ('ERROR', 'Error de conexión a internet (fun.consultaCatastroDATPARCELA lin:3917)')

        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)

        try:
            cuerr = "0"
            for loc in xml.iter(u"{http://www.catastro.meh.es/}control"):
                cuerr = loc.find(u"{http://www.catastro.meh.es/}cuerr").text
        except:
            cuerr = "0"
            
        print ('cuerr =', cuerr )

        # print ("cuerr:  " + cuerr)
        rclist = []
        if (cuerr != "0"):
            for loc in xml.iter(u"{http://www.catastro.meh.es/}err"):
                cod = loc.find(u"{http://www.catastro.meh.es/}cod").text
                des = loc.find(u"{http://www.catastro.meh.es/}des").text
                message = "ERROR: "+ str(cod)+ "\t" + des
                QApplication.restoreOverrideCursor()
                self.showJCCMessageERR( message,'','Identificador de Catastro' )
            return (u'ERROR' , str(cod)+ "\t" + des)
        else:
            for loc in xml.iter(u"{http://www.catastro.meh.es/}rc"):
                pc1 = loc.find(u"{http://www.catastro.meh.es/}pc1").text
                pc2 = loc.find(u"{http://www.catastro.meh.es/}pc2").text
                car = loc.find(u"{http://www.catastro.meh.es/}car").text
                cc1 = loc.find(u"{http://www.catastro.meh.es/}cc1").text
                cc2 = loc.find(u"{http://www.catastro.meh.es/}cc2").text
                rc = pc1+pc2
                rclist.append(rc)
            return (rclist, 'OK', xml_txt)
            
        
    def getPointFromRC(self,iface,rc):
        # Función traida desde jclm_bar_dialog2
        srs =  srcVal

        params = [
            ('SRS', 'EPSG:'+ str(srs) ),
            ('RC',rc),
            ('Provincia',''),
            ('Municipio','') ]

        # url = self.current_configuration.environment["url_catastro_rc"]
        url = self.current_configuration.catastro_tool["url_catastro_rc"]
        data = urllib.parse.urlencode(params)
        # print ('getPointFromRC - ', url+data)
        try:
            req = urllib.request.urlopen(url+data)
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet (fun.getPointFromRC lin:1931)")
            return

        xml_txt =  req.read()
        xml = ElementTree.fromstring(xml_txt)

        # print xml_txt
        x = None
        y = None
        for elem in xml.iter(u"{http://www.catastro.meh.es/}xcen"):
            x = float(elem.text)
        for elem in xml.iter(u"{http://www.catastro.meh.es/}ycen"):
            y = float(elem.text)
        for elem in xml.iter(u"{http://www.catastro.meh.es/}ldt"):
            ldt = elem.text
        if (x is None or y is None):
            for elem in xml.iter(u"{http://www.catastro.meh.es/}des"):
                error = elem.text
                QApplication.restoreOverrideCursor()
                return ["Error",error]
        else:
            source = osr.SpatialReference()
            source.ImportFromEPSG(srs)
            target_qg = iface.mapCanvas().mapSettings().destinationCrs()
            target_txt = target_qg.authid()
            target_id = target_txt.split(":")[1]
            target = osr.SpatialReference()
            target.ImportFromEPSG(int(target_id))

            transform = osr.CoordinateTransformation(source, target)
            point = ogr.Geometry(ogr.wkbPoint)
            point.AddPoint(x,y)
            point.Transform(transform)

            return ["OK",point,ldt]

        pass

    """
    #-------------------------------------------------------------------------------
    #                  CATASTRO. BUSCADOR
    #-------------------------------------------------------------------------------
    """

    def addRCtoListClicked(self, menu):
        rc = menu.ref_catastral.text().upper()

        # Se comprueba si la RC existe ya en la lista
        if len(menu.listaRCs.findItems(rc, Qt.MatchExactly)) > 0:
            # print 'Ya existe la RC ', rc
            return

        # Se comprueba si la RC tiene 14 dígitos
        if len(rc)!=14:
            if len(rc)>14:
                rc = rc[:14]
                text = u'LA REFERENCIA CATASTRAL DEBE SER DE 14 POSICIONES\n'
                text+= u' SE TRUNCA A 14 DÍGITOS-  '+rc
                self.showJCCMessage(text)
            else:
                text = u'LA REFERENCIA CATASTRAL TIENE MENOS DE 14 POSICIONES'
                self.showJCCMessage(text)
                return

        point = None
        # Esto comprueba la existencia de la referencia catastral
        point_response = self.getPointFromRC(menu.iface,rc)

        if point_response is not None and point_response[0] == "Error":
            self.showJCCMessage(point_response[1])
        elif point_response is not None:
            point = point_response[1]
            ldt =  point_response[2]
        if point is not None:
            puntoData = [point, rc]
            menu.listaRCs.addItem(rc)
        pass

        self.setVar.setValue("JCCM_carreteras/last/lastRC14Select", menu.ref_catastral.text().upper())


    def addToListRusticaButtonClicked(self, menu):
        provincia_selected = menu.combo_provincia.currentText()
        # provincia_code = self.getProvinciaCode(provincia_selected)
        municipio_selected = menu.combo_tmuni.currentText()
        # municipio_code = self.getMuniCode(provincia_selected, municipio_selected)
        poligono = menu.poligono.text()
        parcela = menu.parcela.text()

        # Comprobamos si existe la parcela y obtenemos la RC
        result = self.consultaCatastroDATProMunPolPar(provincia_selected, municipio_selected, poligono, parcela)
        
        if result[0] != 'ERROR':
            rclist = result[0]
        else:
            return
        
        if len(rclist) > 0:
            listaRefs = ''
            listaRCsPROV = []
            for rc in rclist:
                # Se comprueba si la RC existe ya en la lista
                if len(menu.listaRCs.findItems(rc, Qt.MatchExactly)) > 0:
                    return

                point = None
                point_response = self.getPointFromRC(menu.iface, rc)
                if point_response is not None and point_response[0] == "Error":
                    self.showJCCMessage(point_response[1])
                elif point_response is not None:
                    point = point_response[1]
                    ldt =  point_response[2]
                    listaRefs += rc + ' - ' +ldt + '\n'
                    # print (ldt)
                if point is not None:
                    puntoData = [point, rc]
                    listaRCsPROV.append(rc)
                    
            if len(rclist) > 1:
                ### AQUÍ HABRÍA QUE SELECCIONAR LAS PARCELAS DESEADAS ###
                self.showJCCMessage(listaRefs)

            for rc in listaRCsPROV:
                menu.listaRCs.addItem(rc)

            self.setVar.setValue("JCCM_carreteras/last/lastProvSelect", menu.combo_provincia.currentText())
            self.setVar.setValue("JCCM_carreteras/last/lastMuniSelect", menu.combo_tmuni.currentText())
            self.setVar.setValue("JCCM_carreteras/last/lastNPOLSelect", menu.poligono.text())
            self.setVar.setValue("JCCM_carreteras/last/lastNPARSelect", menu.parcela.text())


    def zoomToCurrentList(self, close, tipoCARGA, menu):
        # Carga todas las parcelas de la lista de RC y les añade los atributos
        # tipoCARGA = 'CAPAPAR' # tipoCARGA = 'CAPAPAR' - Carga las parcelas en una capa única
        # tipoCARGA = 'CAPAIND' # tipoCARGA = 'CAPAIND' - Carga las parcelas en capas individuales

        QApplication.setOverrideCursor(Qt.WaitCursor)

        self.setVar.setValue("JCCM_carreteras/last/lastProvSelect", menu.combo_provincia.currentText())
        self.setVar.setValue("JCCM_carreteras/last/lastMuniSelect", menu.combo_tmuni.currentText())

        current_lista_rc =  [str(menu.listaRCs.item(i).text()) for i in range(menu.listaRCs.count())]
        # print 'current_lista_rc - ', len(current_lista_rc), ' elementos'
        if len(current_lista_rc) < 1:
            self.showJCCMessage("No hay elementos en la lista")
            QApplication.restoreOverrideCursor()
            return

        # Comprobamos si existe la capa
        nom_layer = 'PARCELAS CATASTRALES'
        srs =  menu.iface.mapCanvas().mapSettings().destinationCrs().authid()
        src= 'crs='+ srs
        tipo_layer= "Polygon"
        layerEXIST = QgsProject.instance().mapLayersByName(nom_layer)

        if not layerEXIST:
            # CREACIÓN DE LA CAPA
            vl = QgsVectorLayer(tipo_layer+'?'+src, nom_layer, 'memory')
        else:
            vl = layerEXIST[0]
            # La capa existe pero está vacía
            if vl.featureCount() == 0:
                QgsProject.instance().removeMapLayer( vl.id() )
                vl = QgsVectorLayer(tipo_layer+'?'+src, nom_layer, 'memory')
        layers = []
        geometries = []
        bbox = None

        listaParcErr=[]
        textMsgINI = 'CARGANDO PARCELAS CATASTRALES...'+'\n'
        menu.txeAVISOS.setText(textMsgINI)
        for rc in current_lista_rc:
            pc1= rc[:7]
            pc2= rc[7:14]
            progress = 'Cargando Parcela %s de %s - %s ...'%(str(current_lista_rc.index(rc)+1), str(len(current_lista_rc)), rc)
            menu.iface.mainWindow().statusBar().showMessage(progress)

            # Comprobamos si la parcela ya existe en la capa
                # Obtiene un iterador de elementos desde una expresión
            consulta = u'"PCAT1" = \''+pc1+'\' and "PCAT2" = \''+pc2+'\''
            expr = QgsExpression( consulta )
            it = vl.getFeatures( QgsFeatureRequest( expr ) )
            ids = [j.id() for j in it]

            if len(ids) == 0:
                # print (rc + ' NO EXISTE, SE CARGA')
                result = self.getPointFromRC(menu.iface,rc)
                result1 = self.consultaCatastroDATPARCELA(rc)

                # xp = round(float(result[0]), 2)
                # yp = round(float(result[1]), 2)
                xp = result[0]
                yp = result[1]
                ldt= result[2]

                if result1[:5] == "ERROR":
                    # Recibe error porque no hay Respuesta de catastro -Consulta_DNPRC-
                    message = result1
                    listaSUBP = result1
                    listaCONSTRU = result1
                    QApplication.restoreOverrideCursor()
                    menu.iface.mainWindow().statusBar().clearMessage()

                else:
                    codnomPRO = result1[1]      #1 - Código y nombre de provincia
                    codnomMUN = result1[2]      #2 - Código y nombre de municipio
                    message = result1[3]        #3 - Contador de BI, CONS y SUBP
                    listaSUBP = result1[4]      #4 - Listado del contenido de los datos de supparcelas
                    listaCONSTRU = result1[5]   #5 - Listado del contenido de los datos de construcciones
                    supTOTAL = result1[6]       #6 - Superficie de la parcela
                    supCONSTR = result1[7]      #7 - Superficie construida
                    DATOSURBA = result1[8]      #8- Datos generales parcela urbana
                    cp = result1[9]             #9- Código de la provincia
                    cm = result1[10]            #10- Código del Municipio
                    cmc = result1[11]           #11- Código del Municipio
                    REFCAT = result1[12]        #12- REFCAT completa (20 dígitos)
                    tipoPAR = result1[13]       #13- Tipo parcela R, U, D, X
                    cpo = result1[14]           #14- Poligono
                    cpa = result1[15]           #15- Parcela
                    cv =  result1[16]           #16- Codigo de la via
                    pnp = result1[17]           #17- Numero de la via
                    np = result1[18]            #18- Nombre de Provincia
                    nm = result1[19]            #19- Nombre de Municipio

                #           RC14,PCAT1,PCAT2,EJERCICIO,NUM_EXP,CONTROL,COORY    ,VIA,NUMERO,NUMERODUP,NUMSYMBOL,AREA    ,FECHAALTA,FECHABAJA,MAPA ,DELEGACIO,MUNICIPIO,MASA,HOJA    ,TIPO   ,PARCELA,COORX    ,NOM_MUNI]
                #atributos=[rc  ,pc1  ,pc2  ,0        ,0      ,0      ,0        ,0  ,0     ,0        ,0        ,0       ,0        ,0        ,0    ,cp       ,cmc      ,cpo ,HOJA    ,tipoPAR,cpa    ,0        ,nom_muni]
                atributos =[rc  ,pc1  ,pc2  ,0        ,0      ,0      ,yp       ,cv ,pnp   ,0        ,0        ,supTOTAL,0        ,0        ,0    ,cp       ,cmc      ,cpo ,pc2     ,tipoPAR,cpa    ,xp       ,nm      ]

                if tipoCARGA == 'CAPAIND':
                    # Esta opcion genera una capa independiente para cada parcela, en el grupo 'PARCELAS CATASTRALES'
                    result = self.cargarCapaParcelaCatastro(rc,nom_layer, atributos, 'shp',srs)
                    if result[0] != u'ERROR':
                        layer = result[0]
                        layers.append(layer)
                    else:
                        return
                else:
                    # Esta opcion genera o añade las parcelas a una capa unica llamada 'PARCELAS CATASTRALES'

                    # AÑADIR LA CAPA INDIVIDUAL DE LA PARCELA
                    tipolayer = 'shp'
                    MAPA=0
                    HOJA='XXXXXX'

                    result = self.cargarCapaParcelaCatastroSHP(rc,nom_layer, atributos, 'shp', srs)

                    if result == 'ERROR':
                        # La RC no tiene geometría
                        listaParcErr.append(rc)
                        textMsg = rc.encode("utf-8")+ u' SIN GEOMETRÍA'
                        menu.txeAVISOS.append(textMsg)
                        continue
                    newbox = result[3]

                    if bbox == None:
                        bbox = newbox
                    else:
                        ## DA ERROR LA RC 02074A01909000
                        if(newbox.xMinimum() < bbox.xMinimum()):
                            bbox.setXMinimum(newbox.xMinimum())
                        if(newbox.yMinimum() < bbox.yMinimum()):
                            bbox.setYMinimum(newbox.yMinimum())
                        if(newbox.xMaximum() > bbox.xMaximum()):
                            bbox.setXMaximum(newbox.xMaximum())
                        if(newbox.yMaximum() > bbox.yMaximum()):
                            bbox.setYMaximum(newbox.yMaximum())

            else:
                if tipoCARGA == 'CAPAIND':
                    # print rc + ' EXISTE, SOLO ZOOM'
                    layerBUSQ = QgsProject.instance().mapLayersByName('PARCELA_'+rc)
                    if layerBUSQ:
                        layer = layerBUSQ[0]
                        layers.append(layer)
                else:
                    ########################################################
                    #  Estudiar QUE PASA CUANDO LAS PARCELAS YA ESTÁN
                    ########################################################
                    for feat in it:
                        newbox = feat.geometry().boundingBox()
                        if bbox == None:
                            bbox = newbox
                        else:
                            if(newbox.xMinimum() < bbox.xMinimum()):
                                bbox.setXMinimum(newbox.xMinimum())
                            if(newbox.yMinimum() < bbox.yMinimum()):
                                bbox.setYMinimum(newbox.yMinimum())
                            if(newbox.xMaximum() > bbox.xMaximum()):
                                bbox.setXMaximum(newbox.xMaximum())
                            if(newbox.yMaximum() > bbox.yMaximum()):
                                bbox.setYMaximum(newbox.yMaximum())

        if tipoCARGA == 'CAPAIND':
            # Zoom a las capas INDIVIDUALES añadidas
            self.zoomToListLayer(layers,menu.iface)
        else:
            # Zoom a los elementos (parcelas) añadidos
            if bbox is not None:
                ## ERROR CON 02074A01909000
                menu.iface.mapCanvas().zoomToFeatureExtent(bbox)
                menu.iface.mapCanvas().refresh()

            if len(listaParcErr)>0:
                QApplication.restoreOverrideCursor()
                menu.setFixedSize(750, 440)
                menu.btnCargaMasiva.setEnabled(True)
                menu.btnIrCargaMasiva.setEnabled(False)
                menu.combo_tabla.setEnabled(False)
                menu.combo_REFCAT.setEnabled(False)
                text = u'La SEC no devuelve geometría para la(s) parcela(s)\n'
                textMsg = u'%s Parcelas SIN GEOMETRÍA'%str(len(listaParcErr))
                menu.txeAVISOS.append(textMsg)
                for rc in listaParcErr:
                    text += rc +u'\n'
                self.showJCCMessage(text)
                close = False

        if close == True:
            #Cerrar el cuadro de diálogo
            menu.close()

        progress = '-FINALIZADO- %s Parcelas Cargadas'%(str(len(current_lista_rc)))
        menu.iface.mainWindow().statusBar().showMessage(progress)
        QApplication.restoreOverrideCursor()


    def quitarSelectedItemsList(self, menu, tipoMenu):
        # Se borran los elementos seleccionados en la lista de RC
        listItems=menu.listaRCs.selectedItems()
        if not listItems: return
        for item in listItems:
            index = menu.listaRCs.row(item)
            menu.listaRCs.takeItem(index)

        if tipoMenu == 'INF':
            pass


    def limpiarListaClicked(self, menu):
        # Se borran todos los elementos en la lista de RC
        current_lista_rc =  [str(menu.listaRCs.item(i).text()) for i in range(menu.listaRCs.count())]
        for i in range(len(current_lista_rc)):
            menu.listaRCs.takeItem(0)


    def updateCombos(self, menu):
        provincia_selected = menu.combo_provincia.currentText()
        provincia_code = self.getProvinciaCode(provincia_selected)

        provincia_selected = provincia_selected.encode('utf-8', errors='ignore')
        municipios = self.getMunicipiosCatastro(provincia_selected)

        menu.combo_tmuni.clear()
        menu.combo_tmuni.addItems(municipios)
        lastMuniSelect = self.setVar.value("JCCM_carreteras/last/lastMuniSelect")
        if lastMuniSelect in municipios:
            menu.combo_tmuni.setCurrentIndex(municipios.index(lastMuniSelect))


    """
    #-------------------------------------------------------------------------------
    #                  EXPTES EXPROPIACIONES
    #-------------------------------------------------------------------------------
    """

    def creaEXPTE(self, menu):
        ## SE CREA EL EXPEDIENTE A PARTIR DE DATOS EXISTENTES EN 'MENU'

        # Directorio de trabajo de Informes de expropiaciones
        dirINFEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerINFOEXPROexptes")
        if dirINFEXPRO is None:
            dirINFEXPRO=configuration().expropiacion["EXPlayerINFOEXPROexptes"]

        #  Datos de expediente y directorios
        Expte = menu.EX_NUMEXPRO.text()
        anoLast = Expte[3:7]
        # print (Expte,anoLast.isnumeric(), Expte[-3:], Expte[-3:].isnumeric(), Expte[:2], len(Expte))
        if not anoLast.isnumeric() or not Expte[-3:].isnumeric() or Expte[:3] != 'EX-' or len(Expte) != 10:
            text = 'El valor de expediente ' + Expte + ' es incorrecto.\n\n'
            text +='Debe ser del tipo EX-AAAAnnn\n'
            text +='    AAAA es el año (p.e. 2020)\n'
            text +='    nnn es el n de expte. (p.e. 023)'
            self.showJCCMessageERR(text,"",tittle="JCCM",)
            return ('ERROR')

        dirExpteAno = dirINFEXPRO + u'Año_' + str(anoLast)
        dirExpte = dirExpteAno + u'/' + Expte

        text = u'¿Crear directorio para el expediente - ' + Expte +' ?\n\n'+ dirExpte
        result = self.showJCCMessageYESNO(text, '', 'JCCM')

        # Creación del directorio
        if not os.path.exists(dirExpte) and result == 1024:
            try:
                os.makedirs(dirExpte)
            except:
                text = u'ES IMPOSIBLE CREAR EL DIRECTORIO:\n'+dirExpte
                self.showJCCMessageERR(text,"",tittle="JCCM",)
                return ('ERROR')
                pass
            
        # Creación del fichero de intercambio
        self.creaFICHintercambio(dirExpte, menu)
        
        return dirExpte


    def creaFICHintercambio(self, dirExpte, menu):
        # Se crea el fichero en el directorio
        listaVAL = []
        listaVAL.append(menu.EX_NUMEXPRO.text()[3:10])                                          # 00 NUMEXPRO;2020033
        listaVAL.append(self.datoNumVacio(menu.EX_REGISTRO.text()))                             # 01 REGISTRO;79945
        # listaVAL.append("    #"+menu.EX_FECHA.date().toString('dd/MM/yyyy')+"#")                # 02 FECHA; Expte remisión; 01/01/2020
        listaVAL.append("    #"+menu.EX_FECHA.date().toString('MM/dd/yyyy')+"#")                # 02 FECHA; Expte remisión; 01/01/2020
        listaVAL.append("'"+self.datoTextVacio(menu.EX_SOLICITANTE.currentText())+"'")          # 03 SOLICITANTE;FRANCISCO MANGANESO HELIO
        listaVAL.append("'"+self.datoTextVacio(menu.EX_INTERESADO.currentText())+"'")           # 04 INTERESADO;ARTURO SELENIO RUBIDIO
        listaVAL.append("'-'")                                                                  # 05 DNI;123456789
        listaVAL.append("'-'")                                                                  # 06 NOMBRE;HEREDEROS
        listaVAL.append("'-'")                                                                  # 07 DOMICILIO;C/ ELEMENTOS, 27
        listaVAL.append("'-'")                                                                  # 08 CODIGOPOST;02630
        listaVAL.append("'-'")                                                                  # 09 TLFNO;987654321
        listaVAL.append("'-'")                                                                  # 10 POBLACION;BONETE
        listaVAL.append("'"+self.datoTextVacio(menu.EX_CARRETERA.text())+"'")                   # 11 CARRETERA;CM3209
        listaVAL.append(self.datoNumVacio(menu.EX_KILOMETRO.text()))                            # 12 KILOMETRO;0
        listaVAL.append(self.datoNumVacio(menu.EX_KILOMET2.text()))                             # 13 KILOMET2;16124
        listaVAL.append("'"+self.datoTextVacio(menu.EX_MARGEN.currentText())+"'")               # 14 MARGEN;IZQDA
        listaVAL.append("'"+self.datoTextVacio(menu.EX_OBSERVAPK.text())+"'")                   # 15 OBSERVAPK;ESTE ES UN FICHERO DE PRUEBA
        listaVAL.append("'"+self.datoTextVacio(menu.EX_TIPO.toPlainText())+"'")                 # 16 TIPO;Solicitud de comprobación de posible invasión de parcela catastral
        listaVAL.append("'-'")                                                                  # 17 ARCHIVO;PENDIENTE
        listaVAL.append("'"+self.datoTextVacio(self.datoINICIALES(menu.EX_INGENIERO.currentText()))+"'") # 18 IG;ASS
        listaVAL.append("'"+self.datoTextVacio(menu.EX_INGENIERO.currentText())+"'")            # 19 INGENIERO;Agustín Solabre Suarez
        listaVAL.append("'-'")                                                                  # 20 ADMIN;sl
        listaVAL.append("'"+self.datoTextVacio(self.datochbTOSINO(menu.EX_ESTAARCHIVADO))+"'")  # 21 ESTAARCHIVADO;FALSO
        listaVAL.append("'-'")                                                                  # 22 FECHAARCHIVO;02/01/2020
        listaVAL.append("'"+self.datoTextVacio(menu.EX_EXPTE_EXPROPIACION.text())+"'")          # 23 EXPTE_EXPROPIACION;CN-AB-96/115
        listaVAL.append("'"+self.datoTextVacio(menu.EX_EXPTES_RELACIONADOS.text())+"'")         # 24 EXPTES_RELACIONADOS;CN-AB-96/115-M
        listaVAL.append("'"+self.datoTextVacio(menu.EX_NOMBRE_TRAMO.text())+"'")                # 25 NOMBRE_TRAMO;EjeManchuela_Villamalea_A31 (Tramo 2)
        listaVAL.append("'"+self.datoTextVacio(menu.EX_DECR_ACUERDO_RESOLUCION.text())+"'")     # 26 DECR_ACUERDO_RESOLUCION;30-OCTUBRE-06
        listaVAL.append("'"+self.datoTextVacio(menu.EX_ACTAS_PREVIAS.text())+"'")               # 27 ACTAS_PREVIAS;jun-07
        listaVAL.append("'"+self.datoTextVacio(menu.EX_REMISION_CATASTRAL.text())+"'")          # 28 REMISION_CATASTRAL;25/03/2019
        listaVAL.append("'"+self.datoTextVacio(menu.EX_NUMORDEN.text())+"'")                    # 29 NUMORDEN;73-131
        listaVAL.append("'"+self.datoTextVacio(menu.EX_POLIGONO.text())+"'")                    # 30 POLIGONO;4-3
        listaVAL.append("'"+self.datoTextVacio(menu.EX_PARCELAS.text())+"'")                    # 31 PARCELAS;583-376
        listaVAL.append("'"+self.datoTextVacio(menu.EX_TM.text())+"'")                          # 32 TM;BONETE
        listaVAL.append("'"+self.datoTextVacio(menu.EX_TIPO_EXPEDIENTE.currentText())+"'")      # 33 TIPO_EXPEDIENTE;NO INVASION
        listaVAL.append("'-'")                                                                  # 34 FECHAINFORME;02/01/2020
        listaVAL.append("'"+self.datoTextVacio(menu.EX_TITULO_EXPROPIACION.toPlainText())+"'")  # 35 TITULO_EXPROPIACION;ACONDICIONAMIENTO CTRA B-11 (CM-3209), P.K. 0 AL 16,124. MONTEALEGRE-BONETE-ESTACION DE BONETE
        listaVAL.append("'-'")                                                                  # 36 EX_EXPTE_OBRA_RELACIONADO;
        listaVAL.append("'"+self.datoTextVacio(menu.EX_REF_CATASTRAL.text())+"'")               # 37 REF_CATASTRAL;400016BWJ9140S
        # listaVAL.append("    #"+menu.EX_FECHA_ULTIMO_TRAMITE.date().toString('dd/MM/yyyy')+"#") # 38 FECHA_ULTIMO_TRAMITE;04/09/2018
        listaVAL.append("    #"+menu.EX_FECHA_ULTIMO_TRAMITE.date().toString('MM/dd/yyyy')+"#") # 38 FECHA_ULTIMO_TRAMITE;04/09/2018
        listaVAL.append("'"+self.datoTextVacio(menu.EX_TRAMITE_EXPROPIACION.text())+"'")        # 39 TRAMITE_EXPROPIACION;ARCHIVADO
        listaVAL.append("'"+self.datoTextVacio(menu.EX_CORREOELEC.toPlainText())+"'")           # 40 CORREOELEC;COSA@VAINA.ES

        # Creamos el fichero
        fich_csv = dirExpte + "/" + menu.EX_NUMEXPRO.text() + '.txt'
        target  = codecs.open(fich_csv, 'w+',encoding='mbcs')

        count = 1
        for l in listaVAL:
            if count < len(listaVAL):
                try:
                    target.write(str(l)+',')
                    target.write("\r\n")
                except:
                    target.write('-- DATOS ERRONEOS --,')
                    target.write("\r\n")
            else:
                target.write(str(l))
            count += 1
        pass
        target.close()

        # Mensaje final
        text = 'Se ha creado un fichero de intercambio en el directorio:\n\n'
        text += dirExpte +'\n\n'
        self.showJCCMessageERR(text,"",tittle="JCCM",)


    ### --------------------------------------------------------------------------------------------------------------------------------------------
    ### --------------------------------------------------------------------------------------------------------------------------------------------
    ### --------------------------------------------------------------------------------------------------------------------------------------------
    ### -------------------------------------   POR AQUÍ    ----------------------------------------------------------------------------------------
    ### --------------------------------------------------------------------------------------------------------------------------------------------
    ### --------------------------------------------------------------------------------------------------------------------------------------------

    def crea_gmlfile(self, layer_origen, nomCAPA, gml_salida_file, src, menu):
        # Transforma la información de la geometría de una capa al estándar de Catastro en formato GML.
        #   layer_origen:      Capa con la geometría de origen
        #   gml_salida_file:   Dirección del archivo en formato GML a sobreescribir con el resultado
        #   src:               Sistema de Referencia de Coordendas de la capa origen. Según cógigos  EPSG
        #       SRC_DICT=['25828', '25829', '25830', '25831']
        
        # Comprueba que plantillacatastro.py existe en el directorio actual
        print ('layer_origen - ', layer_origen)
        print ('nomCAPA - ', nomCAPA)
        print ('gml_salida_file - ', gml_salida_file)
        print ('src - ', src)
        print ('menu - ', menu)
        
        try:
            from .plantillacatastro import SRC_DICT, PLANTILLA_1, PLANTILLA_2, PLANTILLA_3, PLANTILLA_4, PLANTILLA_5
        except ImportError:
            sys.exit('ERROR functions3.crea_gmlfile: No se encuentra el script plantilla "plantillacatastro" en el directorio')
            mess= u'ERROR functions3.crea_gmlfile: \nNo se encuentra el script plantilla "plantillacatastro" en el directorio'
            self.showJCCMessageERR( mess)
            return
        
        if menu != '':
            menu.progressBar.setValue(0)
            menu.lblINFO.show() == True
            menu.lblINFO.setText("")
            localid = menu.lneLOCALID.text()
            ini_localid=int(menu.lneLOCALID_2.text())
        else:
            localid = '[RC14]'
            ini_localid = 1

        layer = layer_origen[0]
                
        text = (
            # u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600; text-decoration: underline;">Generar GML para catastro desde capa de Poligonos</span></p>'+
            # u'<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; text-decoration: underline;"><br /></p>'+
            # u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" text-decoration: underline;">DATOS DE ENTRADA:</span></p>'+
            # u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">CAPA DE ENTRADA:</span></p>'+
            # u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">   {}</p>'.format(layer.name())+
            # u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:7.8pt; font-weight:600;">SRC:</span><span style=" font-size:7.8pt;"> {}</span></p>'.format(str(src))+
            # u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">FICHERO GML SALIDA:</span></p>'+
            # u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">   {}</p>'.format(gml_salida_file)
            )

        if src not in SRC_DICT:     # Comprueba que el SRC es correcto
            mess= u'ERROR: El código SRC ({}) indicado es incorrecto.'.format(src)
            mess+= u'\n ' + 'Los SRC permitidos son 25828, 25829, 25830 o 25831'
            self.showJCCMessageERR( mess)
            # sys.exit()
            return
        

        with open(gml_salida_file, 'w') as filegml:
            filegml.writelines(PLANTILLA_1) # Añade el encabezamiento al GML

            nfeat = 0
            
            if menu != '':
                if menu.chbELEMSELEC.isChecked():
                    feats = layer.selectedFeatures()
                    numfeats = layer.selectedFeatureCount()
                    if numfeats == 0:
                        feats = layer.getFeatures()
                        numfeats = layer.featureCount()                 
                else:
                    feats = layer.getFeatures()
                    numfeats = layer.featureCount()

                campoNamespace = menu.cbx_campoNMSPC.currentText()
            else:
            ### --------------------------------------------------------------------------------------------------------------------------------------------
            ### --------------------------------------------------------------------------------------------------------------------------------------------
                feats = layer.selectedFeatures()
                numfeats = layer.selectedFeatureCount()
                if numfeats == 0:
                    feats = layer.getFeatures()
                    numfeats = layer.featureCount()                 

                campoNamespace = 'cat_nmspc'

            ### --------------------------------------------------------------------------------------------------------------------------------------------
            ### --------------------------------------------------------------------------------------------------------------------------------------------

            text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">LOCALID= {} - INI= {}</p>'.format(localid, ini_localid)
            text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">NAMESPACE= {}</p>'.format(campoNamespace)
            text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">TOTAL selec. {} de {} geometría(s).</p>'.format(numfeats, layer.featureCount())
            fracfeats = 0
            if localid.find('[') != -1:
                campoLocalid = localid[localid.find('[')+1:localid.find(']')]

            for feature in feats:
                numidf = self.completarCeros(str(ini_localid),3)
                
                attrs = feature.attributes()
                valCampoLocalid = feature[campoLocalid]
                localidf = str(valCampoLocalid)

                valCampoNamespace = feature[campoNamespace]
                nmspcf = str(valCampoNamespace)
                if nmspcf != 'ES.SDGC.CP':
                    nmspcf = 'ES.LOCAL.CP'
                
                if localid.find('{NUM}')!=-1 and nmspcf == 'ES.LOCAL.CP':   # Solo se numeran las parcelas 'ES.LOCAL.CP'
                    localidf += '_{NUM}'.format(NUM=numidf)
                    
                if len(localidf) == 14 and nmspcf == 'ES.SDGC.CP':          # Se comprueba si la RC puede ser de 14 caracteres, incluso, si existe
                    pass
                else:                                                       # Si no es RC se asigna   nmspcf = 'ES.LOCAL.CP'
                    nmspcf = 'ES.LOCAL.CP'
                    ini_localid +=1
                # ini_localid +=1

                filegml.writelines(PLANTILLA_2.format(nmspc=nmspcf, localid=localidf)) # Añade el encabezamiento de cada Feature al GML

                geom = feature.geometry()
                
                if geom is None: continue           # Si es una geometría vacía, se continua
                
                area = geom.area()
                nfeat += 1
                text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">{} S= {:.4f} m2.</p>'.format(localidf, area)
                
                filegml.writelines(str(area))       # Añade el área al GML
                filegml.writelines(PLANTILLA_3.format(src=src,nmspc=nmspcf,localid=localidf)) # Añade la parte anterior a las coordenadas de cada feature al GML
                
                if geom.wkbType() == 3:
                    n = self.describe_polygon(feature, localidf, nmspcf, src, filegml)
                    
                elif geom.wkbType() == 6:
                    n = self.describe_multipolygon(feature, localidf, nmspcf, src, filegml)
                   
                if menu != '':
                    prog = 100 * nfeat/numfeats
                    menu.progressBar.setValue(prog)

                text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">--Vértices: {}</p>'.format(n)

                filegml.writelines(PLANTILLA_4.format(localidf=localidf,nmspc=nmspcf))     # Añade la parte posterior a las coordenadas de cada feature al GML
                fracfeats += 1/numfeats

            filegml.writelines(PLANTILLA_5)     # Añade el final al GML

        
        # Carga del GML en la TOC
        if menu != '':
            if menu.chbCARGAGML.isChecked():
                ### --------------------------------------------------------------------------------------------------------------------------------------------
                ### --------------------------------------------------------------------------------------------------------------------------------------------
                ##      REVISAR NOMBRE DE CAPA
                # nomCAPA = localidf = localid.format(NUM='TODAS')
                ### --------------------------------------------------------------------------------------------------------------------------------------------
                ### --------------------------------------------------------------------------------------------------------------------------------------------
                #nomCAPA =  'FICHERO'
                crs = QgsCoordinateReferenceSystem(int(src),QgsCoordinateReferenceSystem.EpsgCrsId)
                layer = QgsVectorLayer(gml_salida_file, nomCAPA+"_GML" , 'ogr')
                layer.setCrs(crs,True)
                QgsProject.instance().addMapLayer(layer, False)
                root = QgsProject.instance().layerTreeRoot()   
                nombregrupo="PARCELAS CATASTRALES"
                grupoBUSCAT = root.findGroup(nombregrupo)
                if grupoBUSCAT is None:
                    grupoBUSCAT = root.insertGroup(0, nombregrupo)
                grupoBUSCAT.insertChildNode(0, QgsLayerTreeLayer(layer)) 
                pass            
            menu.close()
        else:
            crs = QgsCoordinateReferenceSystem(int(src),QgsCoordinateReferenceSystem.EpsgCrsId)
            layer = QgsVectorLayer(gml_salida_file, nomCAPA+"_GML" , 'ogr')
            layer.setCrs(crs,True)
            QgsProject.instance().addMapLayer(layer, False)
            root = QgsProject.instance().layerTreeRoot()   
            nombregrupo="PARCELAS CATASTRALES"
            grupoBUSCAT = root.findGroup(nombregrupo)
            if grupoBUSCAT is None:
                grupoBUSCAT = root.insertGroup(0, nombregrupo)
            grupoBUSCAT.insertChildNode(0, QgsLayerTreeLayer(layer)) 


    def describe_polygon(self, feature_polygon, localidf, nmspclocalid, src, filegml):
        geometry_multipolygon = QgsGeometry.fromMultiPolygonXY([feature_polygon.geometry().asPolygon()])
        feature_multipolygon = QgsFeature()
        feature_multipolygon.setGeometry(geometry_multipolygon)
        n = self.describe_multipolygon(feature_multipolygon, localidf, nmspclocalid, src, filegml)
        return n
                
            
    def describe_multipolygon(self, feature_multipolygon, localidf, nmspclocalid, src, filegml):
        perimetro = feature_multipolygon.geometry()
        n=0
        poligon =0
        for polygon_1 in range(len(perimetro.asMultiPolygon())):
            poligon +=1
            filegml.writelines('''          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_'''+nmspclocalid+'.'+localidf+'" srsName="urn:ogc:def:crs:EPSG:'+src+'''">
              <gml:patches>
                <gml:PolygonPatch>''')
            # <gml:Surface gml:id="Surface_'''+nmspclocalid+'.'+localidf+'.'+"Polygon_%04d"%(polygon_1+1, )+'" srsName="urn:ogc:def:crs:EPSG'+src+'''">
            filegml.writelines('\n')
            ring=0  
            for ring_1 in range(len(perimetro.asMultiPolygon()[polygon_1])):
                ring +=1
                if ring_1==0:
                    filegml.writelines('''                  <gml:exterior>''')
                    filegml.writelines('\n')
                else:
                    filegml.writelines('''                  <gml:interior>''')
                    filegml.writelines('\n')
                points_number = len(perimetro.asMultiPolygon()[polygon_1][ring_1])
                filegml.writelines('''                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="'''+str(points_number)+'''">'''+'\n')
                for point_1 in range(points_number):
                    n+=1
                    filegml.writelines("{:.2f} {:.2f}".format(perimetro.asMultiPolygon()[polygon_1][ring_1][point_1].x(), perimetro.asMultiPolygon()[polygon_1][ring_1][point_1].y()))
                    if point_1 != points_number-1:
                        filegml.writelines(("   ")+'\n')
                filegml.writelines('''
                      </gml:posList>
                    </gml:LinearRing>
                  ''')
                if ring_1==0:
                    filegml.writelines('''</gml:exterior>''')
                    filegml.writelines('\n')
                else:
                    filegml.writelines('''</gml:interior>''')
                    filegml.writelines('\n')
            filegml.writelines('''                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>''')
            filegml.writelines('\n')
        return n
            

    ### --------------------------------------------------------------------------------------------------------------------------------------------
    ### --------------------------------------------------------------------------------------------------------------------------------------------
    ### --------------------------------------------------------------------------------------------------------------------------------------------
    ### --------------------------------------------------------------------------------------------------------------------------------------------
    ### --------------------------------------------------------------------------------------------------------------------------------------------
    ### --------------------------------------------------------------------------------------------------------------------------------------------



    def datoTextVacio(self,dato):
        if dato == '':
            return "-"
        else:
            return dato


    def datoNumVacio(self,dato):
        if dato == '':
            return 0
        else:
            return int(float(dato))


    def datoINICIALES(self, dato):
        if dato != '':
            iniciales = ''
            for word in dato.split():
                iniciales += word[0]
            return iniciales.upper()
        else:
            return '-'


    def datochbTOSINO(self, chb):
        if chb.isChecked():
            return 'SI'
        else:
            return 'NO'


    """
    #-------------------------------------------------------------------------------
    #                  VARIAS
    #-------------------------------------------------------------------------------
    """

    def wait(self, duration=2.0):
        QApplication.processEvents() # clear current event queue
        time.sleep(duration) # this will block gui updates


    def convertTOurl(self, text):
        text = unicode(text.replace(u" ", u"%20" ))
        text = unicode(text.replace(u"(", u"%28" ))
        text = unicode(text.replace(u")", u"%29" ))
        text = unicode(text.replace(u"Ñ", u"%C3%91" ))
        text = unicode(text.replace(u"Á", u"%C3%81" ))
        text = unicode(text.replace(u"É", u"%C3%89" ))
        text = unicode(text.replace(u"Í", u"%C3%8D" ))
        text = unicode(text.replace(u"Ó", u"%C3%93" ))
        text = unicode(text.replace(u"Ú", u"%C3%9A" ))
        text = unicode(text.replace(u"ñ", u"%C3%B1" ))
        text = unicode(text.replace(u"á", u"%C3%A1" ))
        text = unicode(text.replace(u"é", u"%C3%A9" ))
        text = unicode(text.replace(u"í", u"%C3%AD" ))
        text = unicode(text.replace(u"ó", u"%C3%B3" ))
        text = unicode(text.replace(u"ú", u"%C3%BA" ))


        listORIG = ['ñ','Ñ','á','é','í','ó','ú','ü','Ü']
        listDEST = ['%C3%B1','%C3%91','%C3%A1','%C3%A9','%C3%AD','%C3%B3','%C3%BA','%C3%BC','%C3%9C']
        textURL = text
        # print textURL
        return textURL


    def buscaFichUnd(self, listUnd, Fich):
        # La rutina permite buscar el fichero 'Fich' en las diferentes unidades 'listUnd' en el orden de la lista de unidadesº
            # Devueve el path completo con unidad del fichero 'path' y la unidad 'unit'
            # path = buscaFichUnd(['z:', 'u:', 'c:'], '/cartografia/datos_Q/QSIG/GRUPOS_CAPAS/012 EXPRO PATRIMONIO - CASILLAS.qlr')
            # print ('Encontrado en :', path[0])

        # Quitamos a Fich la unidad
        FichCapado = Fich[2:]
        FileNotFind = True
        it =0
        while FileNotFind and it < len(listUnd):
            unit = listUnd[it]
            path = unit + FichCapado
            result = os.path.exists(path)
            if result == True:
                FileNotFind = False
                break
            # print (it, ' No se encuentra :', path)
            it += 1

        if FileNotFind == True:
            return None
        else:
            # print ('Encontrado :', path, unit)
            return path, unit


    def getListLayerGPKG(self, file, tipos):
        listLayers = []
        # print (file)
        if not os.path.isfile(file):
            return listLayers
        for layer in ogr.Open(file):
            nameLayer = layer.GetName()
            # print(nameLayer)
            try:
                feature0 = layer[1]
                geometry = feature0.GetGeometryRef()
                if geometry is not None:
                    tipoGeom = geometry.GetGeometryName()
                    # print(u'   Tipo:  '+ tipoGeom)
                    if tipoGeom in tipos:
                        listLayers.append(nameLayer)
                # else:
                    # print(u'   NO TIENE GEOMETRÍA')
            except:
                # print(u'   NO TIENE NINGUN ELEMENTO')
                pass

        return listLayers

##############
##############
##############
##############

