# -*- coding: utf-8 -*-
"""
/***************************************************************************
herrExpro_BUSCEXPTES.py
                                 A QGIS plugin
                             -------------------
        begin                : 2017-01-25
        git sha              : $Format:%H$
        copyright            : (C) A.Solabre 2017
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

"""
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QSettings
from PyQt5.QtWidgets import QDialog
from PyQt5 import uic

from qgis.core import QgsProject, QgsExpression, QgsFeatureRequest
from qgis.utils import iface

import sys
import os
from osgeo import ogr, osr, gdal

import urllib
import json
from time import sleep

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES


"""
### IMPORTADO DE dxfparcela2gmlcatastro.py ###
try:
    from osgeo import ogr, osr, gdal
    
except ImportError:
    sys.exit('ERROR: Paquetes GDAL/OGR no encontrados. Compruebe que están instalados correctamente')

except ImportError:
    sys.exit('ERROR: No se encuentra el script plantilla "plantillacatastro" en el directorio')
### FIN IMPORTACION DE dxfparcela2gmlcatastro.py ###
"""

# DATOS DE LA APLICACION
#------------------------
# capaINFEXPRO = 'Informes de Expropiaciones'
capaINFEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerINFOEXPRO")
if capaINFEXPRO is None:
    capaINFEXPRO=configuration().expropiacion["EXPlayerINFOEXPRO"]
camposINFEXPRO = ['EX_NUM','EX_TMUNIC','CTRA', 'RC14']

# dirINFEXPRO = 'P:/Documentacion/Expropiaciones/'
dirINFEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerINFOEXPROexptes")
if dirINFEXPRO is None:
    dirINFEXPRO=configuration().expropiacion["EXPlayerINFOEXPROexptes"]
campodirINFEXPRO = ''
# print (dirINFEXPRO)

# capaEXPEXPRO = 'LIMITES DE EXPROPIACION'
capaEXPEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerLIMEXPRO")
if capaEXPEXPRO is None:
    capaEXPEXPRO=configuration().expropiacion["EXPlayerLIMEXPRO"]
camposEXPEXPRO = ['CTRA', 'EXPTE1', 'NOM_TRAMO']

# dirEXPEXPRO = 'v:/cartografia/datos/EXPROPIACIONES/02_ALBACETE/'
dirEXPEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerLIMEXPROexptes")
if dirEXPEXPRO is None:
    dirEXPEXPRO=configuration().expropiacion["EXPlayerLIMEXPROexptes"]
camposEXPEXPRO = ['CTRA', 'EXPTE1', 'NOM_TRAMO']
campodirEXPEXPRO = 'DIR_DOC'
print (dirEXPEXPRO)


# capaBINMUEBLES = 'CASILLAS P.C.'
capaBINMUEBLES = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerParcPATRI")
if capaBINMUEBLES is None:
    capaBINMUEBLES=configuration().expropiacion["EXPlayerParcPATRI"]
camposBINMUEBLES = ['TNO_MUNIC', 'N_INVENT', 'CTRA_NUE', 'PK_NUE', ]

# dirBINMUEBLES = 'v:/cartografia/datos/Casillas_PC_OFICINAS_DESTACAMENTOS_ALMACENES/'
dirBINMUEBLES = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerParcPATRIexptes")
if dirBINMUEBLES is None:
    dirBINMUEBLES=configuration().expropiacion["EXPlayerParcPATRIexptes"]
campodirBINMUEBLES = 'DIR_DOC'
textoLOG = u''


# CAPAS A ACTIVAR
#------------------------
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_buscaexptes.ui'))

class herrExpro_buscaexptes(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
    # Clase para el submenu herrExpro_generaGML.ui
    
        """Constructor."""
        super(herrExpro_buscaexptes, self).__init__(parent)
        # Se establece el menu de usuario desde el diseñador
        # despues de ejecutar 'setupUI', puedes acceder a cualquier objeto del diseño haciendo
        # self.<objectname>, y puedes usar slots de autoconexión - ver
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        
        self.setupUi(self)
        
        self.iface = iface
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.fun = Functions()
        self.setVar = QSettings()
        
        self.btnINFEXPRO.setEnabled(True)
        self.btnEXPEXPRO.setEnabled(True)
        self.btnBINMUEBLES.setEnabled(True)
        self.qlbINFEXPRODOC.setEnabled(True)
        self.qlbEXPEXPRODOC.setEnabled(True)
        self.qlbBINMUEBLESDOC.setEnabled(True)
        self.qptLOG.setPlainText(textoLOG)
        self.qptLOG.setEnabled(True)

        # Rellenar combo PROVINCIA
        self.cbxPROVINCIA.addItems(['AB','CR','CU','GU','TO','todos'])
          
        self.rellenaCOMBOS()

        self.btnCANCELA.clicked.connect(self.cancela)
        self.btnINFEXPRO.clicked.connect(self.buscarINFOEXPRO)
        self.btnEXPEXPRO.clicked.connect(self.buscarEXPEXPRO)       
        self.btnBINMUEBLES.clicked.connect(self.buscarBINMUEBLES)

        self.cbxINFOEXPRO.currentIndexChanged.connect(self.irdocINFEXPRODOC)
        self.cbxEXPEXPRO.currentIndexChanged.connect(self.irdocEXPEXPRODOC)
        self.cbxBINMUEBLES.currentIndexChanged.connect(self.irdocBINMUEBLESDOC)
        self.cbxPROVINCIA.currentIndexChanged.connect(self.rellenaCOMBOS)

        """ VER SI SE PUEDE METER TODO EN UNA RUTINA self.irdocVERDOC
        self.cbxEXPEXPRO.currentIndexChanged.connect(self.irdocVERDOC(
            self.cbxEXPEXPRO.currentText(),1,capaEXPEXPRO, camposEXPEXPRO, 1, 'Layer', dirEXPEXPRO, self.qlbEXPEXPRODOC))
        """
        
        self.tbwSELECTEDEXPTES.hide() == True
        
    def rellenaCOMBOS(self):
        # Rellenar combo INFOSEXPRO
        self.cbxINFOEXPRO.clear()
        listaDatos = self.getDATOSLAYER(capaINFEXPRO, camposINFEXPRO, True)
        self.cbxINFOEXPRO.addItems(listaDatos)
        lastINFOEXPRO = self.setVar.value("JCCM_carreteras/EXPRlastINFOEXPRO")
        if lastINFOEXPRO in listaDatos:
            self.cbxINFOEXPRO.setCurrentIndex(listaDatos.index(lastINFOEXPRO))

        # Si la capa no está cargada, desactiva el botón correspondiente
        if (self.cbxINFOEXPRO.currentText()[:5] == 'FALTA'):
            self.btnINFEXPRO.setEnabled(False)
            self.qlbINFEXPRODOC.setText(u'No hay DIR')    
            self.qlbINFEXPRODOC.setEnabled(False)
        else: 
            self.irdocINFEXPRODOC()
            self.btnINFEXPRO.setEnabled(True)
                
        # Rellenar combo EXPEXPRO
        self.cbxEXPEXPRO.clear()
        listEXPEXPRO = self.getDATOSLAYER(capaEXPEXPRO, camposEXPEXPRO, False)
        self.cbxEXPEXPRO.addItems(listEXPEXPRO)
        lastEXPEXPRO = self.setVar.value("JCCM_carreteras/EXPRlastEXPEXPRO")
        
        if lastEXPEXPRO in listEXPEXPRO:
            self.cbxEXPEXPRO.setCurrentIndex(listEXPEXPRO.index(lastEXPEXPRO))
        
        # Si la capa no está cargada, desactiva el botón correspondiente
        if (self.cbxEXPEXPRO.currentText()[:5] == 'FALTA'):
            self.btnEXPEXPRO.setEnabled(False)
            self.qlbEXPEXPRODOC.setText(u'No hay DIR') 
            self.qlbEXPEXPRODOC.setEnabled(False)
        else: 
            self.irdocEXPEXPRODOC()
            """ VER SI SE PUEDE METER TODO EN UNA RUTINA self.irdocVERDOC
            # lisVAREXPEXPRO = [self.cbxEXPEXPRO.currentText(), 1, capaEXPEXPRO, camposEXPEXPRO, 1, 'Layer', dirEXPEXPRO, self.qlbEXPEXPRODOC]
            self.irdocVERDOC(
                self.cbxEXPEXPRO.currentText(),1,capaEXPEXPRO, camposEXPEXPRO, 1, 'Layer', dirEXPEXPRO, self.qlbEXPEXPRODOC)
            """
            self.btnEXPEXPRO.setEnabled(True)
            # self.qlbEXPEXPRODOC.setEnabled(True)

        # Rellenar combo BINMUEBLES
        self.cbxBINMUEBLES.clear()
        listBINMUEBLES = self.getDATOSLAYER(capaBINMUEBLES, camposBINMUEBLES, False)
        self.cbxBINMUEBLES.addItems(listBINMUEBLES)
        lastBINMUEBLES = self.setVar.value("JCCM_carreteras/EXPRlastBINMUEBLES")
        
        if lastBINMUEBLES in listBINMUEBLES:
            self.cbxBINMUEBLES.setCurrentIndex(listBINMUEBLES.index(lastBINMUEBLES))
        
        # Si la capa no está cargada, desactiva el botón correspondiente
        if (self.cbxBINMUEBLES.currentText()[:5] == 'FALTA'):
            self.btnBINMUEBLES.setEnabled(False)
            self.qlbBINMUEBLESDOC.setText(u'No hay DIR')  
            self.qlbBINMUEBLESDOC.setEnabled(False)
        else: 
            self.irdocBINMUEBLESDOC()
            self.btnBINMUEBLES.setEnabled(True)
    
        
    def getDATOSLAYER(self,capaDATOS,listacampos,descendente):
        listaDATOS = []
        layer = self.fun.getLayerByName(capaDATOS)
        
        # Adaptamos el sistema de codificación a ISO-8859-14 ##########   SE QUITA ESTO     ###########
        # codeSource = "ISO-8859-14"

        if not layer:
            textoLOG = u'FALTA CAPA ' + capaDATOS
            self.qptLOG.appendPlainText(textoLOG)
            # print  u'FALTA CAPA ' + capaDATOS
            return [u'FALTA CAPA ' + capaDATOS]
        else:
            # print u'Code System ACTUAL= ',layer.name(), layer.dataProvider().encoding()  
            # layer.setProviderEncoding(codeSource)     ##########   SE QUITA ESTO     ###########
            layer.dataProvider().encoding()


        QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(True)
        for feat in layer.getFeatures():
            if ((self.cbxPROVINCIA.currentText() == feat['PROVINCIA']) or (self.cbxPROVINCIA.currentText() == 'todos')):
                val =''
                count=0
                for campo in listacampos:  
                    val1 = feat[campo]
                    if not val1: 
                        val1 = '(s/d)'
                    if (isinstance(val1,int) or isinstance(val1,float)):
                        val += str(val1)
                    else:
                        val += val1
                    count +=1
                    if (count < len(listacampos)):
                        val += u' | '

                # print val + u' Añadido'
                # listaDATOS.append(val.encode('UTF-8','strict'))
                # listaDATOS.append(val.encode('latin8','strict'))
                # listaDATOS.append(val.encode('ISO-8859-14','strict'))
                # listaDATOS.append(val.encode('ISO-8859-14','strict').decode('utf-8'))
                # listaDATOS.append(str(val.encode('ISO-8859-14','')))
                listaDATOS.append(val)
        listaDATOS = list(set(listaDATOS))
        
        # Ordenamos las listas correspondientes
        if descendente==True:
            listaDATOS.sort(reverse=True)
        else:
            listaDATOS.sort()

        if len(listaDATOS) == 0:
            return [u'FALTAN DATOS DE CAPA ' + capaDATOS]
        return listaDATOS

        
    def buscarINFOEXPRO(self):
        self.close()    

        # VARIABLES
        capaDATOS = capaINFEXPRO
        datoBUSCADO = self.cbxINFOEXPRO.currentText()
        ordenDATO = 0
        listaCAMPOS = camposINFEXPRO
        ordenCAMPO = 0

        self.fun.zoomELEMENTO(iface, capaDATOS, datoBUSCADO, ordenDATO, listaCAMPOS, ordenCAMPO, 0 )


    def buscarEXPEXPRO(self):
        self.close()    

        # VARIABLES
        capaDATOS = capaEXPEXPRO
        datoBUSCADO = self.cbxEXPEXPRO.currentText()
        ordenDATO = 1
        listaCAMPOS = camposEXPEXPRO
        ordenCAMPO = 1

        self.fun.zoomELEMENTO(iface, capaDATOS, datoBUSCADO, ordenDATO, listaCAMPOS, ordenCAMPO, 0 )

       
    def buscarBINMUEBLES(self):
        self.close()    

        # VARIABLES
        capaDATOS = capaBINMUEBLES
        datoBUSCADO = self.cbxBINMUEBLES.currentText()
        ordenDATO = 1
        listaCAMPOS = camposBINMUEBLES
        ordenCAMPO = 1

        self.fun.zoomELEMENTO(iface, capaDATOS, datoBUSCADO, ordenDATO, listaCAMPOS, ordenCAMPO , 1000 )


    def irdocINFEXPRODOC(self):
        if (self.cbxINFOEXPRO.currentText()[:5] != 'FALTA'):
            if (self.cbxINFOEXPRO.count() >0):
                datoBUSCADO = self.cbxINFOEXPRO.currentText()
                self.setVar.setValue("JCCM_carreteras/EXPRlastINFOEXPRO", datoBUSCADO)
                valorBUSCADO= (datoBUSCADO.split(' | '))[0]
                valorBUSCADO = (valorBUSCADO.replace( u'/', ''))
                valorBUSCADO =valorBUSCADO[:10]
                ano = u'Año_'+valorBUSCADO[3:7]+u'/'
                if not valorBUSCADO:
                    valorBUSCADO =''                

                fichero = dirINFEXPRO+ano+valorBUSCADO+u'/'
                if not os.path.exists(fichero):
                    self.qlbINFEXPRODOC.setEnabled(False)
                    textoLOG = u'FALTA DIR-INFEXPRODOC ' + fichero
                    self.qptLOG.appendPlainText(textoLOG)
                    self.qlbINFEXPRODOC.setText(u'No hay DIR')            
                else:
                    self.qlbINFEXPRODOC.setEnabled(True)
                    fichero='file:///'+fichero
                    texto = self.tr(
                        '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'+fichero+'"><span style=" font-size:10pt; text-decoration: underline; color:#0000ff;">Ir a DOC</p>'
                        )
                    self.qlbINFEXPRODOC.setText(texto)
                
                # print unicode(fichero)
                pass


    def irdocEXPEXPRODOC(self):    
        if (self.cbxEXPEXPRO.currentText()[:5] != 'FALTA'):
            if (self.cbxEXPEXPRO.count() >0):
                datoBUSCADO = self.cbxEXPEXPRO.currentText()
                self.setVar.setValue("JCCM_carreteras/EXPRlastEXPEXPRO", datoBUSCADO)
                valorBUSCADO= (datoBUSCADO.split(' | '))[1]
                
                layer = self.fun.getLayerByName(capaEXPEXPRO)
                campo = camposEXPEXPRO[1]
                consulta = u'"'+campo+'" = \''+valorBUSCADO+'\''
                expr = QgsExpression( consulta )
                it = layer.getFeatures( QgsFeatureRequest( expr ) )
                ids = [j.id() for j in it]
                feats=layer.selectByIds(ids)

                feature = layer.selectedFeatures()[0]

                valEXPEXPRODOC = feature[campodirEXPEXPRO]
                if not valEXPEXPRODOC:
                    valEXPEXPRODOC =''
                fichero = dirEXPEXPRO+valEXPEXPRODOC+u'/'
                if not os.path.exists(fichero):
                    self.qlbEXPEXPRODOC.setEnabled(False)
                    textoLOG = u'FALTA DIR-EXPEXPRODOC ' + fichero
                    self.qptLOG.appendPlainText(textoLOG)           
                    self.qlbEXPEXPRODOC.setText(u'No hay DIR')            
                else:
                    self.qlbEXPEXPRODOC.setEnabled(True)
                    fichero='file:///'+fichero
                    texto = self.tr(
                        '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'+fichero+'"><span style=" font-size:10pt; text-decoration: underline; color:#0000ff;">Ir a DOC</p>'
                        )
                    self.qlbEXPEXPRODOC.setText(texto)
                
                pass


    def irdocBINMUEBLESDOC(self):    
        if (self.cbxBINMUEBLES.currentText()[:5] != 'FALTA'):
            if (self.cbxBINMUEBLES.count() >0):
                datoBUSCADO = self.cbxBINMUEBLES.currentText()
                self.setVar.setValue("JCCM_carreteras/EXPRlastBINMUEBLES", datoBUSCADO)

                valorBUSCADO= (datoBUSCADO.split(' | '))[1]
                
                layer = self.fun.getLayerByName(capaBINMUEBLES)
                campo = camposBINMUEBLES[1]
                consulta = u'"'+campo+'" = \''+valorBUSCADO+'\''
                expr = QgsExpression( consulta )
                it = layer.getFeatures( QgsFeatureRequest( expr ) )
                ids = [j.id() for j in it]
                feats=layer.selectByIds(ids)

                feature = layer.selectedFeatures()[0]
                valBINMUEBLES = feature[campodirBINMUEBLES]
                if not valBINMUEBLES:
                    valBINMUEBLES =''                
                fichero = dirBINMUEBLES+valBINMUEBLES+u'/'
                if not os.path.exists(fichero):
                    self.qlbBINMUEBLESDOC.setEnabled(False)
                    textoLOG = u'FALTA DIR-BINMUEBLES ' + fichero
                    self.qptLOG.appendPlainText(textoLOG)           
                    self.qlbBINMUEBLESDOC.setText(u'No hay DIR')          
                else:
                    self.qlbBINMUEBLESDOC.setEnabled(True)
                    fichero='file:///'+fichero
                    texto = self.tr(
                        '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'+fichero+'"><span style=" font-size:10pt; text-decoration: underline; color:#0000ff;">Ir a DOC</p>'
                        )
                    self.qlbBINMUEBLESDOC.setText(texto)
                
                pass       


    def irdocVERDOC(self, datoBUSCADO, ordenDATBUS, capaDOCS, camposBUSDOCS, ordenCAMBUS, campoDIR, dirDOCS, Qlabel):
        valorBUSCADO= (datoBUSCADO.split(' | '))[ordenDATBUS]
        
        layer = self.fun.getLayerByName(capaDOCS)
        campo = camposBUSDOCS[ordenCAMBUS]
        consulta = u'"'+campo+'" = \''+valorBUSCADO+'\''
        expr = QgsExpression( consulta )
        it = layer.getFeatures( QgsFeatureRequest( expr ) )
        ids = [j.id() for j in it]
        feats=layer.setSelectedFeatures( ids )

        feature = layer.selectedFeatures()[0]
        valDOC = feature[campoDIR]
        
        fichero = 'file:///'+dirDOCS+valDOC+u'/'
        texto = self.tr(
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'+fichero+'"><span style=" font-size:10pt; text-decoration: underline; color:#0000ff;">Ir a DOC</p>'
            )
        Qlabel.setEnabled(True)
        Qlabel.setText(texto)
        
        pass

        
    def cancela(self):
        self.close()
        pass
        
            
### --------------------------------------------------------------------------------------------------------------------------------------------
### --------------------------------------------------------------------------------------------------------------------------------------------
### -----------------------------   RESTOS DE COSILLAS   ---------------------------------------------------------
### --------------------------------------------------------------------------------------------------------------------------------------------
### --------------------------------------------------------------------------------------------------------------------------------------------