﻿"""
/***************************************************************************
Name:            catastrotools.py
Purpose:

        -------------------
        begin                : 2016-06-07
        git sha              : $Format:%H$
        copyright            : (C) 2016 by JCCM. Dirección General de Carreteras
        Codigo Original      : Jon Garrido (ALAUDA) - HASTA V 1.26
        Codigo Corregido     : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt5.QtGui import QCursor
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QDialog

from qgis.gui import QgsMapTool
from qgis.core import QgsFeature, QgsProject, QgsVectorLayer, QgsLayerTreeLayer

import urllib

from xml.etree import cElementTree as ElementTree
from xml.dom import minidom 
from xml.dom.minidom import parseString

from osgeo import ogr, osr

import os
import json
import locale
from time import sleep

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES


# Cargamos la clase del menú dialogo de Parcela catastral
from .parcela_catastral import parcela_catastralDialog


locale.setlocale(locale.LC_ALL, 'ESP')

class catastroTool(QgsMapTool):
    # Carga del catastro de todo un municipio pinchado
    # Cambiamos los parametros que mandan el codigo ine para obtener el catastral
    # Se manda un mesnsaje que diga que se va a abrir la capa
    #       falta un aviso si no existe la capa o no hay acceso al repositorio, pero todo se andará
    def __init__(self,canvas,conf_catastro_tool,url_catastro_municipios,iface,action):
    
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.conf_catastro_tool = conf_catastro_tool
        self.fun = Functions()
        cursor = QCursor()
        cursor.setShape(Qt.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        self.url_catastro_municipios = url_catastro_municipios
        QApplication.restoreOverrideCursor()
        
        # from catastroparcelaWFS import catastroToolWFS

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        pass

    def canvasReleaseEvent(self, event):
        # ICONO DE ESPERA
        QApplication.setOverrideCursor(Qt.WaitCursor)
        progress = 'Cargando datos desde CATASTRO {txt}...'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)        
        
        year = str(self.conf_catastro_tool["year"])
        origenData = 'Dir'
        if not os.path.exists(self.conf_catastro_tool["dir_shps"] +   year + u"/"):
            origenData = 'web'

        # --------------- QUITAR ESTO ---------------
        # FORZAMOS ORIGENDATA a hacerlo desde web
        origenData = 'web'
        # --------------- QUITAR ESTO ---------------

        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        srs =  self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        
        # CONSULTA DE RC POR COORDENADAS DIST - Se mete en functions.py
        try:
            result = self.fun.consultaCatastroXYDISTtoRC(point[0], point[1] ,srs)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(catastrotools-114- self.fun.consultaCatastroXYDISTtoRC)','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return
        if result[0] == u'ERROR':
            return
        codigo_provincia = result[5]
        codigo_muni_ine = result[6]
        
        # CONSULTA DE NOMBRE PROVINCIA DESDE COD_PROV - Se mete en functions.py
        try:
            nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(catastrotools-133- self.fun.consultaCatastroCodProvtoProvincia)','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return

        # CONSULTA DE LOS MUNICIPIOS DE LA PROVINCIA
        try:
            result = self.fun.consultaCatastroCodMunitoMunicipio(nombre_prov, codigo_muni_ine)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(catastrotools-158 except1- self.fun.consultaCatastroCodMunitoMunicipio lin:159)','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return

        if result[0] == "ERROR":
            QApplication.restoreOverrideCursor()
            resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(catastrotools-164 except2- self.fun.consultaCatastroCodMunitoMunicipio)','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return

        nombre_muni = result[0]
        codigo_muni = result[1]
        nombre_muni = str(nombre_muni)
        year = str(self.conf_catastro_tool["year"])
        
        self.fun.cargaCatastroMuni(codigo_provincia, codigo_muni, nombre_muni, origenData, year, self.iface, mess = True)
        '''
        ## -------------------------------------------------------------------------------------------------------------------##
        if origenData == 'web':
            year = 'WEB'

        if(codigo_muni == None):
            QApplication.restoreOverrideCursor()
            message = u"TÉRMINO MUNICIPAL NO DETECTADO"+ u"\n\n -- PROBAR A PINCHAR OTRA POSICIÓN --"
            self.fun.showJCCMessage( message,'','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return

        codigo_muni_final = self.fun.completarCeros(codigo_muni,3)
        

        codigo = self.fun.completarCeros(codigo_provincia,2) + codigo_muni_final

        root = QgsProject.instance().layerTreeRoot()
        nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (" +year + ")"
        grupoBUSCAT = root.findGroup(nombregrupo)
        if grupoBUSCAT is None:
        
            message = u"Se van a cargar las capas del \n Catastro del año {} de {} - ({})\n\n -- LA OPERACIÓN TARDARÁ UNOS MINUTOS --".format(year,nombre_muni, codigo)
            if origenData == 'web':
                message = u"Se van a cargar desde la Sede Electrónica de Catastro \n las capas del catastro actual \n del T. M.  {} - ({})\n\n -- LA OPERACIÓN TARDARÁ UNOS MINUTOS --".format(nombre_muni, codigo)
            
            QApplication.restoreOverrideCursor()                
            resp = self.fun.showJCCMessageYESNO( message,'','Capas de Catastro' )
            if resp == 4194304: # Se ha pulsado cancelar
                QApplication.restoreOverrideCursor()
                self.iface.mainWindow().statusBar().clearMessage()
                return
            QApplication.setOverrideCursor(Qt.WaitCursor)

        else:
            QApplication.restoreOverrideCursor()
            message = u"Ya están cargadas las Capas del Catastro de \n" + nombre_muni + " (" + codigo + ")"
            self.fun.showJCCMessage( message,'','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return
        
        progress = u'Cargando datos desde CATASTRO {codigo} - {nombre_muni}...'.format(codigo=codigo, nombre_muni=nombre_muni)
        self.iface.mainWindow().statusBar().showMessage(progress)        
        
        resumen_capas = []
        if (codigo_muni_final != None):
            
            if origenData == 'web':
                # ------- CARGA DE CAPAS DE CATASTRO DESDE SEDE ELECTRÓNICA DE CATASTRO ---------
                result = self.fun.cargaCatastroMuni(codigo_provincia, codigo_muni_final, nombre_muni)
                codigo_muni_final

                dest = result[1]
                epsg = int(srs[5:])
                crs = 'crs='+ srs.lower()
                tipo_layer= 'Polygon'
                abs_path = []

                for file in result[2]:
                    if file.endswith(".gml"):
                        abs_file = result[1]+file
                        
                        # Establecemos el nombre y estilo de la capa
                        if file.find('cadastralzoning') != -1:
                            # Capa de Poligonos
                            nombreCAPA = "CAT- POL- " + nombre_muni+ " - " + codigo
                            estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + 'CAT_POLIGONO_WEB.qml')
                        else:
                            # Capa de Parcelas
                            nombreCAPA = "CAT- PAR- " + nombre_muni+ " - " + codigo
                            estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + 'CAT_PARCELA_WEB.qml')

                        # vl = QgsVectorLayer(abs_file+'|'+tipo_layer+'?'+crs, nombreCAPA, "ogr")
                        vl = QgsVectorLayer(abs_file, nombreCAPA, "ogr")
                        vl.loadNamedStyle(estiloCAPA)
                        QgsProject.instance().addMapLayer(vl, False)
                        resumen_capas.append(vl)
            ## -------------------------------------------------------------------------------------------------------------------##

            else:
                # ------- CARGA DE CAPAS DE CATASTRO DESDE DIRECTORIO ---------
                # CAPAS DE CATASTRO DE URBANA
                for capa in self.conf_catastro_tool["capas_urbanas"]:
                    # year = str(self.conf_catastro_tool["year"])
                    provincia_text = self.getProvinciaText(codigo_provincia)
                    if(provincia_text == None):
                        QApplication.restoreOverrideCursor()
                        QgsMessageLog.logMessage( "Provincia no perteneciente a Castilla La Mancha","jccm_bar")
                        self.iface.mainWindow().statusBar().clearMessage()
                        return
                    source = self.conf_catastro_tool["dir_shps"] +   year + u"/" + provincia_text + u"/" + codigo_provincia + codigo_muni_final + u"u/" + capa["capa"]
                    nombre = "CAT-" + capa["nombre"] + nombre_muni + " " + year
                    estilo = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + capa["estilo"])
                    capa_cargada = self.fun.getSHP(self.iface, source, nombre, estilo)
                    if(capa_cargada != None):
                        QgsMapLayerRegistry.instance().addMapLayer(capa_cargada, False)
                        resumen_capas.append(capa_cargada)
      
                    pass

                # CAPAS DE CATASTRO DE RÚSTICA                                   
                for capa in self.conf_catastro_tool["capas_rusticas"]:
                    year = str(self.conf_catastro_tool["year"])
                    provincia_text = self.getProvinciaText(codigo_provincia)
                    if(provincia_text == None):
                        QApplication.restoreOverrideCursor()
                        QgsMessageLog.logMessage( "Provincia no perteneciente a Castilla La Mancha","jccm_bar")
                        self.iface.mainWindow().statusBar().clearMessage()
                        return
                    source = self.conf_catastro_tool["dir_shps"] +   year + u"/" + provincia_text + u"/" + codigo_provincia + codigo_muni_final + u"r/" + capa["capa"]
                    nombre = "CAT-" + capa["nombre"] + nombre_muni + " " + year
                    estilo = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + capa["estilo"])
                    capa_cargada = self.fun.getSHP(self.iface, source, nombre, estilo)
                    if(capa_cargada != None):
                        QgsMapLayerRegistry.instance().addMapLayer(capa_cargada, False)
                        resumen_capas.append(capa_cargada)
                        
            if not resumen_capas:
                # Se comprueba si la lista de capas de catastro está vacía
                QApplication.restoreOverrideCursor()
                message = "No hay ficheros de capas del catastro \n" + nombregrupo
                QApplication.restoreOverrideCursor()
                self.fun.showJCCMessageERR( message,'','Carga de capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                return
            
            grupoCAT = root.insertGroup(self.conf_catastro_tool["pos_toc"], nombregrupo)

            for capa in resumen_capas:
                grupoCAT.insertChildNode(0, QgsLayerTreeLayer(capa))
        '''
        QApplication.restoreOverrideCursor()
        self.iface.mainWindow().statusBar().clearMessage()



    '''
    def canvasReleaseEvent(self, event):
        # ICONO DE ESPERA
        QApplication.setOverrideCursor(Qt.WaitCursor)
        progress = 'Cargando datos desde CATASTRO {txt}...'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)        
        
        year = str(self.conf_catastro_tool["year"])
        origenData = 'Dir'
        if not os.path.exists(self.conf_catastro_tool["dir_shps"] +   year + u"/"):
            origenData = 'web'

        # --------------- QUITAR ESTO ---------------
        # FORZAMOS ORIGENDATA a hacerlo desde web
        origenData = 'web'
        # --------------- QUITAR ESTO ---------------

        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        srs =  self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        
        # CONSULTA DE RC POR COORDENADAS DIST - Se mete en functions.py
        try:
            result = self.fun.consultaCatastroXYDISTtoRC(point[0], point[1] ,srs)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(catastrotools-114- self.fun.consultaCatastroXYDISTtoRC)','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return
        if result[0] == u'ERROR':
            return
        codigo_provincia = result[5]
        codigo_muni_ine = result[6]
        # print 'codigo_provincia=', codigo_provincia, 'codigo_muni=', codigo_muni
        # print 'RESULT DE consultaCatastroXYDISTtoRC'
       
        
        # CONSULTA DE NOMBRE PROVINCIA DESDE COD_PROV - Se mete en functions.py
        try:
            nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(catastrotools-133- self.fun.consultaCatastroCodProvtoProvincia)','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return


        # CONSULTA DE LOS MUNICIPIOS DE LA PROVINCIA
        try:
            result = self.fun.consultaCatastroCodMunitoMunicipio(nombre_prov, codigo_muni_ine)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(catastrotools-158 except1- self.fun.consultaCatastroCodMunitoMunicipio lin:159)','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return

        if result[0] == "ERROR":
            QApplication.restoreOverrideCursor()
            resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(catastrotools-164 except2- self.fun.consultaCatastroCodMunitoMunicipio)','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return

        nombre_muni = result[0]
        codigo_muni = result[1]
        nombre_muni = str(nombre_muni)
        year = str(self.conf_catastro_tool["year"])
        
        if origenData == 'web':
            year = 'WEB'

        if(codigo_muni == None):
            QApplication.restoreOverrideCursor()
            message = u"TÉRMINO MUNICIPAL NO DETECTADO"+ u"\n\n -- PROBAR A PINCHAR OTRA POSICIÓN --"
            self.fun.showJCCMessage( message,'','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return

        codigo_muni_final = self.fun.completarCeros(codigo_muni,3)
        

        codigo = self.fun.completarCeros(codigo_provincia,2) + codigo_muni_final

        root = QgsProject.instance().layerTreeRoot()
        nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (" +year + ")"
        grupoBUSCAT = root.findGroup(nombregrupo)
        if grupoBUSCAT is None:
        
            message = u"Se van a cargar las capas del \n Catastro del año {} de {} - ({})\n\n -- LA OPERACIÓN TARDARÁ UNOS MINUTOS --".format(year,nombre_muni, codigo)
            if origenData == 'web':
                message = u"Se van a cargar desde la Sede Electrónica de Catastro \n las capas del catastro actual \n del T. M.  {} - ({})\n\n -- LA OPERACIÓN TARDARÁ UNOS MINUTOS --".format(nombre_muni, codigo)
            
            QApplication.restoreOverrideCursor()                
            resp = self.fun.showJCCMessageYESNO( message,'','Capas de Catastro' )
            if resp == 4194304: # Se ha pulsado cancelar
                QApplication.restoreOverrideCursor()
                self.iface.mainWindow().statusBar().clearMessage()
                return
            QApplication.setOverrideCursor(Qt.WaitCursor)

        else:
            QApplication.restoreOverrideCursor()
            message = u"Ya están cargadas las Capas del Catastro de \n" + nombre_muni + " (" + codigo + ")"
            self.fun.showJCCMessage( message,'','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return
        
        progress = u'Cargando datos desde CATASTRO {codigo} - {nombre_muni}...'.format(codigo=codigo, nombre_muni=nombre_muni)
        self.iface.mainWindow().statusBar().showMessage(progress)        
        
        resumen_capas = []
        if (codigo_muni_final != None):
            
            if origenData == 'web':
                # ------- CARGA DE CAPAS DE CATASTRO DESDE SEDE ELECTRÓNICA DE CATASTRO ---------
                result = self.fun.cargaCatastroMuni(codigo_provincia, codigo_muni_final, nombre_muni)
                codigo_muni_final

                dest = result[1]
                epsg = int(srs[5:])
                crs = 'crs='+ srs.lower()
                tipo_layer= 'Polygon'
                abs_path = []

                for file in result[2]:
                    if file.endswith(".gml"):
                        abs_file = result[1]+file
                        
                        # Establecemos el nombre y estilo de la capa
                        if file.find('cadastralzoning') != -1:
                            # Capa de Poligonos
                            nombreCAPA = "CAT- POL- " + nombre_muni+ " - " + codigo
                            estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + 'CAT_POLIGONO_WEB.qml')
                        else:
                            # Capa de Parcelas
                            nombreCAPA = "CAT- PAR- " + nombre_muni+ " - " + codigo
                            estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + 'CAT_PARCELA_WEB.qml')

                        # vl = QgsVectorLayer(abs_file+'|'+tipo_layer+'?'+crs, nombreCAPA, "ogr")
                        vl = QgsVectorLayer(abs_file, nombreCAPA, "ogr")
                        vl.loadNamedStyle(estiloCAPA)
                        QgsProject.instance().addMapLayer(vl, False)
                        resumen_capas.append(vl)

            else:
                # ------- CARGA DE CAPAS DE CATASTRO DESDE DIRECTORIO ---------
                # CAPAS DE CATASTRO DE URBANA
                for capa in self.conf_catastro_tool["capas_urbanas"]:
                    # year = str(self.conf_catastro_tool["year"])
                    provincia_text = self.getProvinciaText(codigo_provincia)
                    if(provincia_text == None):
                        QApplication.restoreOverrideCursor()
                        QgsMessageLog.logMessage( "Provincia no perteneciente a Castilla La Mancha","jccm_bar")
                        self.iface.mainWindow().statusBar().clearMessage()
                        return
                    source = self.conf_catastro_tool["dir_shps"] +   year + u"/" + provincia_text + u"/" + codigo_provincia + codigo_muni_final + u"u/" + capa["capa"]
                    nombre = "CAT-" + capa["nombre"] + nombre_muni + " " + year
                    estilo = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + capa["estilo"])
                    capa_cargada = self.fun.getSHP(self.iface, source, nombre, estilo)
                    if(capa_cargada != None):
                        QgsMapLayerRegistry.instance().addMapLayer(capa_cargada, False)
                        resumen_capas.append(capa_cargada)
      
                    pass

                # CAPAS DE CATASTRO DE RÚSTICA                                   
                for capa in self.conf_catastro_tool["capas_rusticas"]:
                    year = str(self.conf_catastro_tool["year"])
                    provincia_text = self.getProvinciaText(codigo_provincia)
                    if(provincia_text == None):
                        QApplication.restoreOverrideCursor()
                        QgsMessageLog.logMessage( "Provincia no perteneciente a Castilla La Mancha","jccm_bar")
                        self.iface.mainWindow().statusBar().clearMessage()
                        return
                    source = self.conf_catastro_tool["dir_shps"] +   year + u"/" + provincia_text + u"/" + codigo_provincia + codigo_muni_final + u"r/" + capa["capa"]
                    nombre = "CAT-" + capa["nombre"] + nombre_muni + " " + year
                    estilo = os.path.join(os.path.dirname(__file__), self.conf_catastro_tool["dir_estilos_catastro"] + capa["estilo"])
                    capa_cargada = self.fun.getSHP(self.iface, source, nombre, estilo)
                    if(capa_cargada != None):
                        QgsMapLayerRegistry.instance().addMapLayer(capa_cargada, False)
                        resumen_capas.append(capa_cargada)
                        
            if not resumen_capas:
                # Se comprueba si la lista de capas de catastro está vacía
                QApplication.restoreOverrideCursor()
                message = "No hay ficheros de capas del catastro \n" + nombregrupo
                QApplication.restoreOverrideCursor()
                self.fun.showJCCMessageERR( message,'','Carga de capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                return
            
            grupoCAT = root.insertGroup(self.conf_catastro_tool["pos_toc"], nombregrupo)

            for capa in resumen_capas:
                grupoCAT.insertChildNode(0, QgsLayerTreeLayer(capa))
                
        QApplication.restoreOverrideCursor()
        self.iface.mainWindow().statusBar().clearMessage()
    '''
       

    def activate(self):
        pass

    def deactivate(self):
        # self.action.setChecked(False)
        pass

    def isZoomTool(self):
        return False

    def isTransient(self):
        return False

    def isEditTool(self):
        return False
        
    def getProvinciaText(self,cp):
        #print cp
        if cp == "02":
            return "ALBACETE"
        elif cp == "13":
            return "CIUDAD_REAL"
        elif cp == "16":
            return "CUENCA"
        elif cp == "45":
            return "TOLEDO"
        elif cp == "19":
            return "GUADALAJARA"
        else:
            return "OTRA"

            
class catastroToolINF(QgsMapTool):
        # Funcion creada por ASS
        # -----------  PERMITE IDENTIFICAR UNA PARCELA CATASTRAL AL PINCHARLA  -----------

    def __init__(self,canvas,conf_catastro_tool,url_catastro_municipios,iface,action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.conf_catastro_tool = conf_catastro_tool
        self.fun = Functions()
        cursor = QCursor()
        cursor.setShape(Qt.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        self.url_catastro_municipios = url_catastro_municipios
        self.dlg = parcela_catastralDialog(iface)
        QApplication.restoreOverrideCursor()

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        pass

    def canvasReleaseEvent(self, event):
        # ICONO DE ESPERA
        QApplication.setOverrideCursor(Qt.WaitCursor)
        progress = 'Cargando parcela catastral {txt}...'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)    

        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        srs =  self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        
        # CONSULTA DE RC POR COORDENADAS - Se mete en functions.py
        try:
            result = self.fun.consultaCatastroXYtoRC(point[0], point[1] ,srs)
            # result = self.fun.consultaCatastroXYDISTtoRC(point[0], point[1] ,srs)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return
        
        # print result[0]
        if result[0] == u'ERROR' or result[0] == 'E' or result[0] is None:
            QApplication.restoreOverrideCursor()
            # resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -','','Capas de Catastro' )
            self.iface.mainWindow().statusBar().clearMessage()
            return

        REFCAT14 = result[0]
        xml_txt = result [1] 
        pc1 = result [2]
        pc2 = result [3]
        ldt = result [4]
        cp = ''
        cm = ''
        
        # print (pc1,pc2,' ',pc1[5],' ',pc2[3])
        if pc1[5] =='A' or  pc1[5] =='B':
            # Obtencion de tipoPAR en caso de parcelas de RC rústica
            if pc2[3] =='9':
                tipoPAR =  u'X-Descuento'
            else:
                tipoPAR =  u'RU-Rústica'
            cpo = pc1[6]+pc2[0:2]
            cpa = pc2[2:7]
            HOJA= pc1[0:6]
        else:
            # Obtencion de tipoPAR en caso de parcelas de RC urbana y diseminados
            if ldt[0:14] == 'TN DISEMINADOS':
                tipoPAR =  u'DI- Diseminado'
            else:
                tipoPAR = u'UR-Urbana'
            cpo = pc1[0:5]
            cpa = pc1[5:7]
            HOJA = pc2
        
        # print tipoPAR
        # print result[0]
        # print pc1+pc2 +' '+ ldt
        
        # tipoPAR = 'N'        #0 - TIPO DE PARCELA (Urbana, Rústica)
        codnomPRO = ''       #1 - Código y nombre de provincia
        codnomMUN = ''       #2 - Código y nombre de municipio
        message = ''         #3 - Contador de BI, CONS y SUBP
        listaSUBP = ''       #4 - Listado del contenido de los datos de supparcelas
        listaCONSTRU = ''    #5 - Listado del contenido de los datos de construcciones
        supTOTAL = 0         #6 - Superficie de la parcela
        supCONSTR = 0        #7 - Superficie construida
        DATOSURBA = ''       #8- Datos generales parcela urbana
        cp = ''              #9- Código de la provincia
        cm = ''              #10- Código del Municipio
        cmc = ''             #11- Código del Municipio
        REFCAT = REFCAT14    #12- REFCAT completa (20 dígitos)
        cn = 'N'             #13- Tipo parcela R, U, D, X
        cv =  ''             #16- Codigo de la via
        pnp = ''             #17- Numero de la via

      
        # Se ejecuta la consulta a catastro datos dado un RC
        result = self.fun.consultaCatastroDATPARCELA(REFCAT14)
        # print (result)
        
        if result[:5] == "ERROR": 
            # Recibe error porque no hay Respuesta de catastro -Consulta_DNPRC-
            message = result
            listaSUBP = result
            listaCONSTRU = result

            # result = self.fun.consultaCODCATMUNI(cp, cm)
            # if result[0] != "ERROR":
                # cmc = result[0]
                # nm = result[1]
                # np = ''
                # # print result
            # else:
                # QApplication.restoreOverrideCursor()
                # self.iface.mainWindow().statusBar().clearMessage()
                # return
            QApplication.restoreOverrideCursor()
            self.iface.mainWindow().statusBar().clearMessage()

        else:
            codnomPRO = result[1]      #1 - Código y nombre de provincia
            codnomMUN = result[2]      #2 - Código y nombre de municipio
            message = result[3]        #3 - Contador de BI, CONS y SUBP
            listaSUBP = result[4]      #4 - Listado del contenido de los datos de supparcelas
            listaCONSTRU = result[5]   #5 - Listado del contenido de los datos de construcciones
            supTOTAL = result[6]       #6 - Superficie de la parcela
            supCONSTR = result[7]      #7 - Superficie construida
            DATOSURBA = result[8]      #8- Datos generales parcela urbana
            cp = result[9]             #9- Código de la provincia
            cm = result[10]            #10- Código del Municipio
            cmc = result[11]           #11- Código del Municipio
            REFCAT = result[12]        #12- REFCAT completa (20 dígitos)
            cn = result[13]            #13- Tipo parcela R, U, D, X
            cpo = result[14]           #14- Poligono
            cpa = result[15]           #15- Parcela
            cv =  result[16]           #16- Codigo de la via
            pnp = result[17]           #17- Numero de la via
            np = result[18]            #18- Nombre de Provincia
            nm = result[19]            #19- Nombre de Municipio

        # Confeccionamos la URL de info catastral en SEC
        # url ANTIGUA
        # https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCConCiud.aspx?
            # del=2&mun=81&RefC=02081A141090010000IY
        # url ACTUAL (ene/2019)
        # https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCConCiud.aspx?
            # UrbRus=R&RefC=02075B012106870000RW&esBice=&RCBice1=&RCBice2=&DenoBice=&from=OVCBusqueda&pest=rc&RCCompleta=02075B01210687&final=&del=2&mun=75
        url = u'https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCConCiud.aspx?'
        params = {
            'del': cp,
            'mun': cmc,
            'RefC': REFCAT}
        str_values = {}
        for k, v in params.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
            
        # data = urllib.urlencode(params)
        urlSEC= url+data
        print (urlSEC)

        # AÑADIR LA CAPA INDIVIDUAL DE LA PARCELA
        nombregrupo = "PARCELAS CATASTRALES"            #Esto solo es interesante para la carga en grupo
        nombrecapa = "PARCELAS CATASTRALES"
        tipolayer = 'shp'
        MAPA=0
        HOJA='XXXXXX'
        
        #           RC14    ,PCAT1 ,PCAT2,EJERCICIO,NUM_EXP,CONTROL,COORY,VIA,NUMERO,NUMERODUP,NUMSYMBOL,AREA,FECHAALTA,FECHABAJA,MAPA,DELEGACIO,MUNICIPIO,MASA,HOJA,TIPO  ,PARCELA,COORX, NOM_MUNI 
        atributos =[REFCAT14, pc1  ,pc2  ,0        ,0      ,0      ,0    ,cv ,pnp   ,0        ,0        ,0   ,0        ,0        ,MAPA,cp       ,cmc      ,cpo ,pc2 ,cn    ,cpa    ,0    , nm      ]
        result = self.fun.cargarCapaParcelaCatastroSHP(REFCAT14,nombrecapa, atributos, 'shp', srs)
        
        if result[0] =='ERROR':
            QApplication.restoreOverrideCursor()
            return
        layer = result[0]
        # feature = layer.getFeatures().next()
        supTOTAL = result[1]
        # print 'supTOTAL= ', supTOTAL
        
        #Creación de la lista de valores a enviar al menú dialogo Parcela Catastral
        listaVALORES = [REFCAT14,       #0 - REFCAT de 14 posiciones
                        tipoPAR,        #1 - TIPO DE PARCELA (Urbana, Rústica)
                        codnomPRO,      #2 - Código y nombre de provincia
                        codnomMUN,      #3 - Código y nombre de municipio
                        ldt,            #4 - Situación de la Parcela
                        message,        #5 - Contador de BI, CONS y SUBP
                        listaSUBP,      #6 - Listado del contenido de los datos de supparcelas
                        listaCONSTRU,   #7 - Listado del contenido de los datos de construcciones
                        supTOTAL,       #8 - Superficie de la parcela
                        supCONSTR,      #9 - Superficie construida
                        DATOSURBA,      #10- Datos generales parcela urbana
                        urlSEC,         #11- URL de Enlace a la SEC de la parcela
                        REFCAT          #12- REFCAT de 20 posiciones
                        ]
                        # tenemos que seguir metiendo datos
                        
        # Se lanza el cuadro de diálogo de parcela
        result = self.rundialogparcela(listaVALORES)
        QApplication.restoreOverrideCursor()
        self.iface.mainWindow().statusBar().clearMessage()
        pass

    def activate(self):
        pass

    def deactivate(self):
        # self.action.setChecked(False)
        pass

    def isZoomTool(self):
        return False

    def isTransient(self):
        return False

    def isEditTool(self):
        return False

    def getProvinciaText(self,cp):
        #print cp
        if cp == "02":
            return "ALBACETE"
        elif cp == "13":
            return "CIUDAD_REAL"
        elif cp == "16":
            return "CUENCA"
        elif cp == "45":
            return "TOLEDO"
        elif cp == "19":
            return "GUADALAJARA"
        else:
            return "OTRA"

    def rundialogparcela(self,listaVAL):
        #Rutina de introducción de datos en el menú Parcela Catastral y apertura del menú
        
        self.dlg.valREFCAT.setText(listaVAL[0])
        self.dlg.valTIPO.setText(listaVAL[1])
        self.dlg.valPROVINCIA.setText(listaVAL[2])
        self.dlg.valMUNICIPIO.setText(listaVAL[3])
        self.dlg.valSITUACION.setText(listaVAL[4])
        self.dlg.valCUENTAS.setText(listaVAL[5])
        self.dlg.valSUBPARC.setText(''.join(listaVAL[6]))
        self.dlg.valCONSTRU.setText(''.join(listaVAL[7]))
        
        # SOLO QGIS 2.14
        # self.dlg.valSUPTOTAL.setText(u'SUP: '+locale.format("%d", listaVAL[8], grouping=True)+u' m2')
        # SOLO QGIS 2.18.27
        self.dlg.valSUPTOTAL.setText(u'SUP: %s m2'%str(listaVAL[8]))
        
        # self.dlg.valSUPCONS.setText(u'SUP.Const: '+locale.format("%d", listaVAL[9], grouping=True)+u' m2')
        self.dlg.valSUPCONS.setText(u'SUP.Const: %s m2'%str(listaVAL[9]))
        self.dlg.lblDATOSURBA.setText(listaVAL[10])
        self.dlg.enlaceWEB.setText(u'<html><head/><body><p><a href="'+listaVAL[11]+
            u'"><span style=" text-decoration: underline; color:#0000ff;">'+listaVAL[12]+
            u'</span></a></p></body></html>')
        # https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCConCiud.aspx?UrbRus=R&RefC=02075B012106870000RW&esBice=&RCBice1=&RCBice2=&DenoBice=&from=OVCBusqueda&pest=rc&RCCompleta=02075B01210687&final=&del=2&mun=75
        QApplication.restoreOverrideCursor()
        result = self.dlg.exec_()
        

        # See if OK was pressed
        if result:
            # Do something useful here - delete the line containing pass and
            # substitute with your code.
            pass

'''
class catastroToolWMSHIST(QgsMapTool):
        # Funcion creada por ASS
        # PERMITE CARGAR EL CATASTRO DE UNA DETERMINADA FECHA

        #Parámetro TIME
        # Este WMS incorpora un parámetro propio TIME para poder dar un servicio histórico de la cartografía catastral el formato de este parámetro es:
        # TIME = YYYY-MM-DD (siendo: YYYY el año, MM el mes y DD el día)
        #   Ejemplo de petición del servicio WMS con cartografía a la fecha del 23 de octubre de 2003
        #   http://ovc.catastro.meh.es/Cartografia/WMS/ServidorWMS.aspx?TIME=2003-10-23& . 
        #   Solo está disponible la cartografía histórica desde que se tiene cartografía en formato digital (no anterior al año 2002).
        
    def __init__(self,canvas,catastro_toolWMSHIST,url_catastro_municipios,iface,action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.conf_catastro_tool = conf_catastro_tool
        self.fun = Functions()
        cursor = QCursor()
        cursor.setShape(Qt.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        self.url_catastro_municipios = url_catastro_municipios
        self.dlg = parcela_catastralDialog(iface)
        QApplication.restoreOverrideCursor()
'''




