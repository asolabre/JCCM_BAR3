# -*- coding: utf-8 -*-
####################################################################################
# Obtenemos la Geometría del elemento pinchado de una capa de polígono
####################################################################################

from PyQt5.QtGui import QIcon, QCursor
from PyQt5.QtCore import Qt, QRect
from PyQt5.QtWidgets import QApplication, QMessageBox, QDialogButtonBox, QLabel, QTableWidget, QTextEdit, QTableWidgetItem

from qgis.gui import QgsDialog, QgsMapTool
from qgis.core import QgsWkbTypes, QgsGeometry, QgsPoint, QgsPointXY, QgsLineString

# from osgeo import gdal, osr, ogr
from osgeo import ogr
import urllib
import json

from math import fabs

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
current_configuration = configuration()

precision= 3 # Precisión de coordenadas y superficies

class jccm_poligGetPKINIPKFIN(QgsMapTool):

    def __init__(self, canvas, iface, action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas    
        self.fun = Functions()
        cursor = QCursor()
        cursor.setShape(Qt.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        pass

        
    def canvasReleaseEvent(self, event): 
        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        
        coordMouse = "{:.{}f}, {:.{}f}".format(point.x(), precision, point.y(), precision)

        layer = self.iface.activeLayer()
        text2=''
        tittle="ERROR"
        if layer is None:
            text = u'Seleccione una capa de Polígonos'
            self.fun.showJCCMessageERR( text,text2,tittle)
            return
        if layer.type() != 0:
            text = u"La capa '"+ layer.name()  + u"' es de tipo "+str(layer.type())+'. NO VECTORIAL\n\n'
            text += u"SELECCIONE UNA CAPA DE POLÍGONOS"
            self.fun.showJCCMessageERR( text,text2,tittle)
            return
        geomTypeString=QgsWkbTypes.displayString(int(layer.wkbType()))
        tipos = ['POLYGON','MULTIPOLYGON','POLYGONZ','MULTIPOLYGONZ','POLYGONM','MULTIPOLYGONM','POLYGONZM','MULTIPOLYGONZM','POLYGON25D','MULTIPOLYGON25D']

        if geomTypeString.upper() not in tipos:
            text = u"La capa '"+ layer.name()  + u"' es de tipo " + geomTypeString+u'\n\n'
            text += u"SELECCIONE UNA CAPA DE POLÍGONOS"
            self.fun.showJCCMessageERR( text,text2,tittle)
            return

        fields = layer.fields()  
        field_names = [field.name() for field in fields]
        capa = layer.name() + ' -  TIPO: '+ geomTypeString

        # print geomTypeString, 'CAPA: ', layer.name()
        
        feats = [ feat for feat in layer.getFeatures() ]
        geo_pt = QgsGeometry.fromPointXY(QgsPointXY(point.x(), point.y()))
        id = -1

        camposATTRS = []
        listaGeometria =  'SISTEMA DE COORDENADAS: '+self.iface.mapCanvas().mapSettings().destinationCrs().authid() + u'\n'
        QApplication.setOverrideCursor(Qt.WaitCursor)
        for feat in feats:
            if geo_pt.within(feat.geometry()):

                geom = feat.geometry()
                ctra, pkini, pkfin = self.fun.poligToPKINIPKFIN(geom, self.iface,'NO')
                print ( 'result : ',ctra, pkini, pkfin)

                id = feat.id()
            
                try:
                    elemId = str(id)+' - '+ field_names[0]+' - '+ str(feat.attribute(field_names[0]))
                except:
                    elemId = str(id)+' - '+ field_names[0]+' - '+ (feat.attribute(field_names[0])).decode('utf-8')
                
                for campo in field_names:
                    try:
                        valor = str(feat.attribute(campo))
                    except:
                        valor = '--- UNICODE ---'
                    elem  = campo + ':' +valor
                    
                    camposATTRS.append(elem)
                
                listaGeometria +=  u"Area = %d m2" % geom.area() + u'\n'
                listaGeometria +=  u"Perímetro = %d m" % geom.length() + u'\n'
                if geom.isMultipart():
                    polygon = geom.asMultiPolygon()
                    single = False
                else:
                    polygon = geom.asPolygon()
                    single = True
                
                listaGeometria += self.geomGetLista(polygon, single)
                    
                break
                
        if id == -1:
            QApplication.restoreOverrideCursor()
            text = u"No hay geometría en la posición del cursor"
            self.fun.showJCCMessageERR( text,text2, tittle)
            return
        
        text=u"DATOS DE POLÍGONO"
        self.showDialog(text,listaGeometria,camposATTRS, coordMouse, capa, elemId, ctra, pkini, pkfin, "JCCM")
        
        
    def showDialog(self, text,listaGeometria,listaDatos, coordMouse, capa, elemId, ctra, pkini, pkfin, tittle="JCCM"):
        main_window = self.iface.mainWindow()
        dialog = QgsDialog(main_window,
                           fl=Qt.WindowFlags(),
                           buttons=QDialogButtonBox.NoButton,
                           orientation=Qt.Vertical)
        dialog.setWindowTitle("LISTADO DE COORDENADAS")
        dialog.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        dialog.resize(530, 420)
        
        # Etiquetas
        labelCoordPinch = QLabel(dialog)
        labelCoordPinch.setGeometry(QRect(5, 5, 510, 20))
        labelCoordPinch.setAlignment(Qt.AlignBottom | Qt.AlignLeft)
        labelCoordPinch.setText("COORDENADAS CURSOR: " + coordMouse)
        labelCapa = QLabel(dialog)
        labelCapa.setGeometry(QRect(5, 25, 510, 20))
        labelCapa.setAlignment(Qt.AlignBottom | Qt.AlignLeft)
        labelCapa.setText("CAPA: " + capa)
        labelElemento = QLabel(dialog)
        labelElemento.setGeometry(QRect(5, 45, 510, 20))
        labelElemento.setAlignment(Qt.AlignBottom | Qt.AlignLeft)
        labelElemento.setText("ELEMENTO: " + elemId)
        labelCtraPks = QLabel(dialog)
        labelCtraPks.setGeometry(QRect(230, 45, 510, 20))
        labelCtraPks.setAlignment(Qt.AlignBottom | Qt.AlignLeft)
        if ctra == None:
            labelCtraPks.setText(' --- ')
        else:
            if pkini == 'Ctra sin PK' or  pkfin == 'Ctra sin PK':
                labelCtraPks.setText('Ctra: {}  PKINI: {}  PKFIN: {}'.format(ctra, 'Ctra sin PK', 'Ctra sin PK'))
            else:
                labelCtraPks.setText('Ctra: {}  PKINI: {:.3f}  PKFIN: {:.3f}'.format(ctra, pkini, pkfin))
        
        
        # Tabla de atributos
        tableWidget = QTableWidget(dialog)
        tableWidget.setGeometry(QRect(5, 65, 270, 340))
        tableWidget.setObjectName("tableWidget")
        tableWidget.setColumnCount(2)
        tableWidget.setRowCount(len(listaDatos))
        tableWidget.setColumnWidth( 0, 100)
        tableWidget.setColumnWidth( 1, 300)
        tableWidget.setHorizontalHeaderLabels (['CAMPO      ', 'VALOR ATRIBUTO    '])
        j=0
        for data in listaDatos:
            dataDescomp = data.split(':')
            tableWidget.setItem(j, 0,  QTableWidgetItem(dataDescomp[0]))
            tableWidget.setItem(j, 1, QTableWidgetItem(dataDescomp[1]))
            j+=1

        # Listado de Coordenadas
        textEdit = QTextEdit(dialog)
        textEdit.setGeometry(QRect(280, 65, 245, 340))
        textEdit.setObjectName("textEdit")
        textEdit.setText(listaGeometria)
        
        QApplication.restoreOverrideCursor()
        dialog.show()

        
    def geomGetLista(self, geomWKT, single):
        cadena =''
        for parte in geomWKT:
          cadena += 'Poligono '+str(geomWKT.index(parte)+1)+'\n'
          i=1
          if single:
              for pto in parte:
                cadena += " ".join([str(i),' - ',"{:.{}f}".format(pto[0], precision),' - ',"{:.{}f}".format(pto[1], precision),'\n'])
                i += 1
          else:
              for pto in parte[0]:
                cadena += " ".join([str(i),' - ',"{:.{}f}".format(pto[0], precision),' - ',"{:.{}f}".format(pto[1], precision),'\n'])
                i += 1          
        return cadena


    '''
    def poligToPKINIPKFIN(self, geomPol, iface, no9000):
    
        # poligToPKINIPKFIN(geomPol, iface, no9000)
        #   Devuelve diferentes datos de salida de una carretera a partir de un punto
        #       return (the_road, mmin, mmax)
        #   ENTRADA:
        #       geomPol- Geometria del polígono
        #       iface- Interface de la vista
        #       noJCCM= 'SI', 'NO' - NO Busca primero matriculas Titularidad=JCCM
        #   SALIDA:
        #       0 the_road - Matricula de la carretera
        #       1 mmin - Valor M (PK) del mínimo PK próximo del polígono
        #       2 mmax - Valor M (PK) del máximo PK próximo del polígono

        resultINT = geomPol.poleOfInaccessibility(precision)    # Obtenemos el poleOfInaccessibility del polígono
        
        centerPolig = resultINT[0].asPoint()
        qgs_point_geometry = QgsGeometry.fromPointXY(QgsPointXY(centerPolig[0],centerPolig[1]))

        # Hacemos una consulta a la GDB de las vías en un cuadrado de 'margin'x'margin' con centro en centerPolig
        margin = resultINT[1] + 200         # Margen de búsqueda de viales en la GDB
        url = current_configuration.environment["rest_carreteras"]
        values = {'where' : '',
                  'text': '',
                  'objectIds': '',
                  'outFields': '*',
                  'geometry':'{"xmin": ' + str(centerPolig[0] - margin) + ' , "ymin": ' + str(centerPolig[1] - margin) + ' , "xmax": ' + str(centerPolig[0] + margin) + ' , "ymax": ' + str(centerPolig[1] + margin) + ' , "spatialReference":{srcVal}}',
                  'geometryType' : 'esriGeometryEnvelope',
                  'returnGeometry' : 'true',
                  'spatialRel': 'esriSpatialRelIntersects',
                  'returnM': 'true' ,
                  'f': 'json'}

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        try:
            response = json.load(urllib.request.urlopen(url+data))
        except:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet")
            return
            
        features =  response["features"]    # Los distintos features encontrados en la búsqueda

        c_distance = 100000     # Distancia límite de cálculo, por debajo no devuelve datos, se reduce con todas las dist calculadas
        the_feature = None
        qgsLines = []
        the_line = None
        the_road = None
        matric = None
        funcion = None
        atributos = None
        featsProx = []
        numFeat = 1
        for feature in features:
            polyline = []
            polylineM = [] ### Añadida M ###

            geometry = feature["geometry"]
            attr =  feature["attributes"]
            matric = attr['Matricula']          # Matrícula del elemento
            Titu = attr['Titularidad']          # Titularidad del elemento
            
            funcion = attr['Funcionalidad']
            paths = geometry["paths"]
            # points = []
            for path in paths:
                for point in path:
                    polyline.append(QgsPoint(point[0],point[1]))
                    polylineM.append(QgsPoint(point[0],point[1],point[2]))  ### Añadida M ###
                    
            gLine = QgsGeometry.fromPolyline(polyline)
            gLineM = QgsGeometry.fromPolyline(polylineM) ### Añadida M ###
            distance = gLine.distance(qgs_point_geometry) # Se calcula la distancia del centroide al elemento particular
            featsProx.append([matric, Titu, distance, gLine, feature, attr, numFeat, gLineM])
            
            if distance <= c_distance:
                the_road = matric
                c_distance = distance
                the_line = gLine
                the_feature = feature
                # atributos = featAttributes
                atributos = attr
                the_lineM = gLineM ### Añadida M ###
            numFeat += 1
            
        ###############################################################
        ###### Esto se debe rehacer para dar prioridad a:        ######
        ######  - Elementos tronco sobre elementos 9000          ######
        ######  - Elementos Titularidad=JCCM sobre el resto      ######
        ######      aunque tuvieran mayor distancia              ######
        ###############################################################
        # Analizar si matric = 9000
        if no9000 == 'SI' and the_road == '9000':
            c_distance = 1000000
            for featP in featsProx:             # Se analiza cada una de las feats Próximas
                if featP[0] != '9000':
                    if featP[2] <= c_distance:
                        the_road = featP[0]
                        c_distance = featP[2]
                        the_line = featP[3]
                        the_feature = featP[4]
                        atributos = featP[5]
                        the_lineM = featP[6]    ### Añadida M ###
                    pass
                    
        if the_line == None:
            return None


        # EMPEZAMOS A HACER LOS CÁLCULOS SOBRE LA LINEA
        
        if geomPol.isMultipart():
            polygon = geomPol.asMultiPolygon()
            single = False
        else:
            polygon = geomPol.asPolygon()
            single = True

        # self.listadoLineM(the_lineM)
        # self.listadoLineM(the_lns)
        
        cadena =''
        mmin = 10000000
        mmax = 0
        for parte in polygon:
            cadena += 'Poligono '+str(polygon.index(parte)+1)+'\n'
            i=1
            if single:
                for pto in parte:
                    cadena += " ".join([str(i),' - ',"{:.{}f}".format(pto[0], precision),' - ',"{:.{}f}".format(pto[1], precision),'\n'])
                    closest_point_geometry, dist, punto_anterior, punto_posterior, m_final = self.calculaMproximo(the_lineM, pto)
                    # print (closest_point_geometry, dist, punto_anterior, punto_posterior, m_final)
                    if m_final == 'nan':
                        return the_road, 'Ctra sin PK', 'Ctra sin PK'
                    if m_final < mmin:
                        mmin = m_final
                    if m_final > mmax:
                        mmax = m_final
                    i += 1
            else:
                for pto in parte[0]:
                    cadena += " ".join([str(i),' - ',"{:.{}f}".format(pto[0], precision),' - ',"{:.{}f}".format(pto[1], precision),'\n'])
                    closest_point_geometry, dist, punto_anterior, punto_posterior, m_final = self.calculaMproximo(the_lineM, pto)
                    # print (closest_point_geometry, dist, punto_anterior, punto_posterior, m_final)
                    if m_final < mmin:
                        mmin = m_final
                    if m_final > mmax:
                        mmax = m_final
                    i += 1

        if mmin == 10000000:
            return the_road, 'Ctra sin PK', 'Ctra sin PK'
        print ('PKINI: ', mmin, 'PKFIN: ', mmax)
        return the_road, mmin, mmax


    def calculaMproximo(self, the_lineM,  pto):
        
        res = the_lineM.closestSegmentWithContext(pto)
        target_point =  QgsPoint(res[1][0],res[1][1])   # Punto más próximo en el eje mas próximo
        dist = res[0]                                   # Distancia del punto a la polilinea
        punto_posterior = the_lineM.vertexAt(res[2])    # N0. orden vértice posterior al pto. próximo
        m_posterior =  punto_posterior.z()              # Valor M del vértice posterior al pto. próximo
        # if m_posterior == 'nan':
            # m_final = 'noM'
            # return ('', '', '', '', m_final)
        # print ('m_posterior =', m_posterior)
        if res[2] > 0:
            punto_anterior = the_lineM.vertexAt(res[2]-1)
            m_anterior =  punto_anterior.z()
            # if m_anterior == 'nan':
                # m_final = 'noM'
                # return ('', '', '', '', m_final)
            # print ('m_anterior =', m_anterior)
            if punto_posterior.distance(punto_anterior) != 0:
                m_final = m_posterior - (punto_posterior.distance(target_point) / punto_posterior.distance(punto_anterior)) * (m_posterior - m_anterior)
            else:
                m_final = m_posterior
        else:
            m_final = m_posterior

        # print ('m_anterior:', m_anterior, ' m_posterior:', m_posterior, ' m_final:', m_final)
        
        return (target_point, dist, punto_anterior, punto_posterior, m_final)
    '''


        
    def listadoLine (self, lineM):
        norden = 1
        lineaGeom = lineM.asMultiPolyline()
        # lineaGeom = QgsGeometry.fromWkt(lineM.to_linestringm_wkt())
        n = len(lineaGeom)
        for i in range(n):
            # print (i, "{:.{}f}".format(lineaGeom[i][0], precision), "{:.{}f}".format(lineaGeom[i][1], precision))
            # print (i, "{:.{}f}".format(lineaGeom[i][0], precision), "{:.{}f}".format(lineaGeom[i][1], precision), "{:.{}f}".format(lineaGeom[i][2], precision) )
            # print ( " ".join([str(norden),' - ',"{:.{}f}".format(pto[0], precision),' - ',"{:.{}f}".format(pto[1], precision),'\n']))
            pass

        
    def listadoLineM (self, lineM):
        ## https://www.qgis.org/api/classQgsGeometry.html ##
        ## https://gis.stackexchange.com/questions/224665/qgis-extract-nodes-with-m-values-for-linear-referencing
        norden = 1
        lineaGeom = lineM.asWkt()
        print (lineaGeom)

        
        
        
        
