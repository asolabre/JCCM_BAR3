﻿# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           PK_info_dialog.py
Purpose:

        --------------------------------------------------------------------
        begin                : 2019-09-03
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt, QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu, QFileDialog

from PyQt5 import QtGui, QtCore, uic
from PyQt5.QtWidgets import QDialog

import os, glob, io, codecs
from osgeo import gdal, osr, ogr
import time

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .PK_info_panel import info_panel

QT_VERSION=5
os.environ['QT_API'] = 'pyqt5'

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/PK_info.ui'))
# dw  = uic.loadUi( os.path.join(os.path.dirname(__file__), './menus/PK_dockGeometry.ui') )


class Form_PK_info(QDialog, FORM_CLASS):
    # def __init__(self, canvas, iface, parent=None):
    def __init__(self, canvas, iface, carretera_pk, parent=None):
        super(Form_PK_info, self).__init__(parent)
        # super(Form_PK_info(geometria), self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.fun = Functions()
        self.current_configuration = configuration()
        geometry = carretera_pk[8]
        atributos = carretera_pk[4]
        ctra = atributos['Matricula_Plan']
                
        self.setFixedSize(540, 160)
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        
       
        self.botonDcha = 'R'
        self.botonAbajo = 'D'
        self.pkProx = 0
        self.intervalo = 10.00

        # Se localizan los datos de GEOMETRÍA y AFOROS EN LA GDB
        listGDB = [
            "V:\SIGCLM\APPJCCM\Datos\sig_reg_ctras.gdb",
            "V:\SIGCLM\APPJCCM\Datos\sig_reg_ctras_AB.gdb",
            "U:\SIGCLM\APPJCCM\Datos\sig_reg_ctras.gdb",
            "U:\SIGCLM\APPJCCM\Datos\sig_reg_ctras_AB.gdb"]
        #GDB = "U:\SIGCLM\APPJCCM\Datos\sig_reg_ctras_AB.gdb"
        GDBCLASS = "GEOMETRIA"
        GDB = self.fun.buscaUnidadesGDB(listGDB, GDBCLASS)
        
        if GDB == "":
            self.btnAbrirDcha.setVisible(0)
            pass
        
        # self.btnAbrirDcha.clicked.connect(lambda: self.botonPanelDcha(GDB))
        self.btnAbrirDcha.hide()
        self.btnAbrirAbajo.clicked.connect(lambda: self.botonAmpliarAbajo())
        self.btnVerCota.clicked.connect(lambda: self.botonVerCota())
        self.btnLISTCOORD.clicked.connect(lambda: self.botonLISTCOORD(geometry))
        self.btnGuardaCSV.clicked.connect(lambda: self.botonGuardaCSV(geometry,ctra))
        self.btnGuardaSHP.clicked.connect(lambda: self.botonGuardaSHP(geometry,ctra))
        self.chkGuardarM.setChecked(False)
        self.btnGuardaSHP.hide()
        # self.chkGuardarM.hide()
        
            
        # dw.btnRetrocedePK.hide()
        # dw.btnAvanzaPK.hide()
        # dw.btnRetrocedePK.setEnabled(True)
        # dw.btnAvanzaPK.setEnabled(True)

        
    def botonAmpliarAbajo(self):
        if self.botonAbajo == 'D':
            self.setFixedSize(540, 400)
            self.btnAbrirAbajo.setArrowType(Qt.UpArrow)
            self.botonAbajo = 'U'
        elif self.botonAbajo == 'U':
            self.setFixedSize(540, 160)
            self.btnAbrirAbajo.setArrowType(QtCore.Qt.DownArrow)
            self.botonAbajo = 'D'
            # self.btnAbrirDcha.setArrowType(QtCore.Qt.RightArrow)
            # self.botonDcha = 'R'

            
    def botonLISTCOORD(self, geometry):
        self.txbLISTGEOM.setHtml(self.fun.makeHtmlListCoord(geometry))
        self.setFixedSize(860, 400)


    '''
    def makeHtmlListCoord(self, geometry):

        listCoord =''
        pathNum=1
        Mant = None
        
        listCoordHtml = (
            '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">'
            '<html><head><meta name="qrichtext" content="1" /><style type="text/css">'
            'p, li { white-space: pre-wrap; }'
            '</style></head><body style=" font-size:8.25pt; font-weight:400; font-style:normal;">'
            )

        try:
            paths = geometry["paths"]
            for path in paths:
                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt; font-weight:600;">'
                listCoordHtml += 'TRAMO %s/%s (%s puntos)\n'%(str(pathNum),len(paths),len(path))
                listCoordHtml += '</span></p>'
                for point in path:
                    if point[2] is not None:
                        if Mant is not None:
                            if point[2]-Mant <0: 
                                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                                listCoordHtml += "  %0.2f"%(point[0])+','+"%0.2f"%(point[1])+','+" %0.5f"%(point[2])+',</span><span style=" font-size:8pt; font-weight:600; color:#ff5500;">'+"%0.5f"%(point[2]-Mant)+'</span></p>'
                            else:
                                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                                listCoordHtml += "  %0.2f"%(point[0])+','+"%0.2f"%(point[1])+','+" %0.5f"%(point[2])+','+"%0.5f"%(point[2]-Mant)+'\n'
                                listCoordHtml += '</span></p>'
                        else:
                            listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                            listCoordHtml += "  %0.2f"%(point[0])+','+"%0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'
                            listCoordHtml += '</span></p>'
                        Mant = point[2]
                    else:
                        # listCoord += ' %s,%s,%s\n'%(str(round(point[0],2)),str(round(point[1],2)),'None')
                        listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                        listCoordHtml += "  %0.2f"%(point[0])+','+" %0.2f"%(point[1])+',</span><span style=" font-size:8pt; font-weight:600; color:#ff5500;">'+" None"+'</span></p>'
                pathNum +=1
        except:
            paths = []
            if geometry.isMultipart():
                for part in geometry.asGeometryCollection ():
                    paths.append(part)
            else:
                paths.append(geometry)
            
            for path in paths:
                novertices = len(path.asPolyline())
            
                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt; font-weight:600;">'
                listCoordHtml += 'TRAMO %s/%s (%s puntos)\n'%(str(pathNum),len(paths),novertices)
                listCoordHtml += '</span></p>'
                
                for id in range(novertices):
                    point = path.vertexAt(id)
                    
                    if point.m() is not None:
                        if Mant is not None:
                            if point.m()-Mant <0: 
                                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                                listCoordHtml += "  %0.2f"%(point.x())+','+"%0.2f"%(point.y())+','+" %0.5f"%(point.m())+',</span><span style=" font-size:8pt; font-weight:600; color:#ff5500;">'+"%0.5f"%(point.m()-Mant)+'</span></p>'
                            else:
                                listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                                listCoordHtml += "  %0.2f"%(point.x())+','+"%0.2f"%(point.y())+','+" %0.5f"%(point.m())+','+"%0.5f"%(point.m()-Mant)+'\n'
                                listCoordHtml += '</span></p>'
                        else:
                            listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                            listCoordHtml += "  %0.2f"%(point.x())+','+"%0.2f"%(point.y())+','+" %0.5f"%(point.m())+'\n'
                            listCoordHtml += '</span></p>'
                        Mant = point.m()
                    else:
                        listCoordHtml += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                        listCoordHtml += "  %0.2f"%(point.x())+','+" %0.2f"%(point.y())+',</span><span style=" font-size:8pt; font-weight:600; color:#ff5500;">'+" None"+'</span></p>'
                pathNum +=1

        return listCoordHtml
        '''
        
    def botonGuardaCSV(self, geometry, ctra):
        nom_fich_csv = u"C:/temp/" + ctra.replace('-','')+'_geom'
        ext = "*.csv"
        dirfile, tipofile = QFileDialog.getSaveFileName(self, "Fichero CSV de salida", nom_fich_csv, ext)
        if dirfile == None or dirfile == "":
            dirfile = nom_fich_csv
            self.fun.showJCCMessage(u"No se guarda el fichero CSV")
            return
        # Comprobamos que existe el directorio y si no se crea
        if not os.path.exists(os.path.dirname(dirfile)):
            os.makedirs(os.path.dirname(dirfile))
        
        target  = open(dirfile, 'w+',encoding='utf-8')
        if self.chkGuardarM.isChecked():
            encabezado = u'"num";"x";"y";"pk";"dif"'
        else:
            encabezado = u'"num";"x";"y";"pk"'
        
        target.write(encabezado+"\n")

        paths = geometry["paths"]
        listCoord =''
        punto = 1
        pathNum=1
        Mant = None
        for path in paths:
            datoPath = 'TRAMO %s/%s (%s puntos)\n'%(str(pathNum),len(paths),len(path))
            target.write(datoPath)
            for point in path:
                if point[2] is not None:
                    if Mant is not None:
                        if self.chkGuardarM.isChecked():
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+','+" %0.5f"%(point[2]-Mant)+'\n'
                        else:
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'
                        target.write(listCoord)
                    else:
                        if self.chkGuardarM.isChecked():
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+', 0.0'+'\n'
                        else:
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'
                        
                        target.write(listCoord)
                    Mant = point[2]
                else:
                    listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" None"+'\n'
                    target.write(listCoord)
                punto += 1
            pathNum +=1
            
        target.close()
        textInfo = u"GUARDADO CSV\n\n"+dirfile
        self.fun.showJCCMessage(textInfo)

        
    def botonGuardaSHP(self, geometry):
        self.fun.showJCCMessage(u"GUARDAMOS UN SHP")
        pass

        
    def botonPanelDcha(self, GDB):
        # if self.botonDcha == 'R':
        
        bar = QProgressBar()
        bar.setRange(0,0)
        # iface.mainWindow().statusBar().showMessage('Cargando datos...')
        iface.mainWindow().statusBar().addWidget(bar)
        ctraBUSQ  =  self.Matricula.text()
        pk = float(self.Pk.text())

        self.botonDcha = 'L'
        self.botonAbajo = 'U'
        
        # iface.mainWindow().addDockWidget(Qt.RightDockWidgetArea, dw)

        # self.pkGetGeometria(ctraBUSQ, pk, dw, GDB)
        # self.pkGetAforos(ctraBUSQ, pk, dw, GDB)

        iface.mainWindow().statusBar().removeWidget(bar)
        # iface.mainWindow().statusBar().clearMessage()
        # self.fun.trabajando(u'--- CERRAR ---', busy)
        # dw.show()
        # dw.btnRetrocedePK.clicked.connect(lambda: self.RetrocedePK(GDB))
        # dw.btnAvanzaPK.clicked.connect(lambda: self.AvanzaPK(GDB))


        # return pkProx

        
    def botonVerCota(self):
        # Zmdt = self.fun.Zmdt((float(self.XE),float(self.YE)), self.iface, pintar='NO')
        XE = float(self.XE.text())
        YE = float(self.YE.text())
        Zmdt = self.fun.Zmdt((XE,YE), self.iface, pintar='NO')
        self.cotaEje.setText(str(round(Zmdt,3)))
        self.ZE.setText(str(round(Zmdt,3)))
        pass
        
            
    def cancel(self):
        self.reject()

        
    def pkGetGeometria(self, ctraBUSQ, pk, dw, GDB):

        GDBCLASS = "GEOMETRIA"
        LAYNOM = "GEOMETRIA"
        LAYTIPE = "ogr"
        attrs = ['s/d']
        
        # Esto solo vale para buscar en un fichero SHP con la misma estructura que la GDB
        # filSHP = u'u:\BBDD AGENDA\CONSULTAS_BBDD208\GEOMETRIA_CTRA_TRA.shp'
        filSHP = ""
        
        if GDB == "" and filSHP == "":
            print (' LO SIENTO LA GDB o LA CLASE NO EXISTE ')
        else:
            if filSHP == "":
                QApplication.setOverrideCursor(Qt.WaitCursor)
                attrs = self.fun.getGeomCTRA(ctraBUSQ, pk, GDB, GDBCLASS, LAYNOM, LAYTIPE)
                const = 0
                self.close()
            else:
                QApplication.setOverrideCursor(Qt.WaitCursor)
                attrs = self.fun.getGeomCTRA_SHP(ctraBUSQ, pk, filSHP, LAYNOM, LAYTIPE)
                const = 0
                self.close()

        if attrs[0] == 's/d':
            print ('NO SE LOCALIZAN DATOS')

            dw.G_nocarriles.setText("s/d")              
            dw.G_Plataforma.setText("s/d")                
            dw.G_ArcenI.setText("s/d")                
            dw.G_CalzadaT.setText("s/d")              
            dw.G_ArcenD.setText("s/d")                
            dw.G_RadioC.setText("s/d")               
            dw.G_Peralte.setText("s/d")               
            dw.G_Pendiente.setText("s/d")
            dw.G_UTM_Z.setText("s/d")
            self.pkProx = pk

            
        else:
            # print 'CTRA= %s (%s) - PK= %s+%s' %(attrs[0],attrs[4], int(attrs[7]), int(attrs[8]))
            # print 'Plataforma= %s carriles, %s - %s - %s' %(int(attrs[13]),str(attrs[16]/10),str(attrs[18]/10),str(attrs[19]/10))
            # print 'IdSubred=%s - IdCtra=%s - idMatricula=%s - Tramo=%s' %(attrs[1],attrs[2],attrs[3],attrs[4])
            # print 'Radio=%s - Peralte=%s - Pendiente=%s - Alzado=%s - '%(attrs[20],attrs[21]/10,attrs[22]/10,attrs[23])
            # for att in attrs:
                # print att

            dw.G_nocarriles.setText(str(int(attrs[13])))
            dw.G_Plataforma.setText(str(attrs[15]/10))                
            dw.G_ArcenI.setText(str(attrs[16]/10))                
            dw.G_CalzadaT.setText(str(attrs[18]/10))              
            dw.G_ArcenD.setText(str(attrs[19]/10))                
            dw.G_RadioC.setText(str(attrs[20]))               
            dw.G_Peralte.setText(str(attrs[21]/10))               
            dw.G_Pendiente.setText(str(attrs[22]/10))          
            dw.G_UTM_Z.setText(str(attrs[12]))
            self.pkProx = attrs[7]+attrs[8]/1000
        
        dw.Carretera.setText('<font size = 5 color = black font-style = bold><p align="center">'+ctraBUSQ+'</p></font>')
        dw.Pk.setText('<font size = 5 color = black font-style = bold><p align="center">PK: '+self.fun.mostrarPK(self.pkProx,2)+'</p></font>')
        # print 'En - pkGetGeometria ', self.pkProx
            
        QApplication.restoreOverrideCursor()
        # LISTADO DE ATRIBUTOS ( variable attrs)
        #Nombre: 0 Carretera
        #Nombre: 1 IdSubred
        #Nombre: 2 IdCtra
        #Nombre: 3 idMatricula
        #Nombre: 4 Tramo
        #Nombre: 5 A_Tramos_IdTramo
        #Nombre: 6 Geometria_IdTramo
        #Nombre: 7 PKHito
        #Nombre: 8 PKDist
        #Nombre: 9 Distancia
        #Nombre: 10 UTM_X
        #Nombre: 11 UTM_Y
        #Nombre: 12 UTM_Z
        #Nombre: 13 N_de_Carriles
        #Nombre: 14 Plataforma
        #Nombre: 15 Plataforma_total
        #Nombre: 16 Arcen_Izquierdo
        #Nombre: 17 Calzada
        #Nombre: 18 Calzada_Total
        #Nombre: 19 Arcen_Derecho
        #Nombre: 20 Radio_de_Curvatura
        #Nombre: 21 Peralte
        #Nombre: 22 Pendiente
        #Nombre: 23 Alzado
        #Nombre: 24 Visibilidad_Directa
        #Nombre: 25 Visibilidad_Inversa
        #Nombre: 26 IdtramoContrario
        #Nombre: 27 DistCalzadaContraria
        #Nombre: 28 Mediana
        #Nombre: 29 Galibo_izquierdo
        #Nombre: 30 Galibo_derecho
        #Nombre: 31 GLAT
        #Nombre: 32 GLON
        #Nombre: 33 PROVINCIA
        #Nombre: 34 FECHA
        #Nombre: 35 FUENTE
        #Nombre: 36 UTM_X
        #Nombre: 37 UTM_Y
        #Nombre: 38 UTM_Z

    def pkGetAforos(self, ctraBUSQ, pk, dw, GDB):

        GDBCLASS = "AFOROS_tramificacion"
        LAYNOM = "AFOROS"
        LAYTIPE = "ogr"
        attrs = ['s/d']

        filSHP = ""
       
        if GDB == "" and filSHP == "":
            print (' LO SIENTO LA GDB o LA CLASE NO EXISTE ')
        else:
            if filSHP == "":
                QApplication.setOverrideCursor(Qt.WaitCursor)
                attrs = self.fun.getAforoCTRA(ctraBUSQ, pk, GDB, GDBCLASS, LAYNOM, LAYTIPE)
                const = 0
                self.close()
            else:
                QApplication.setOverrideCursor(Qt.WaitCursor)
                attrs = self.fun.getGeomCTRA_SHP(ctraBUSQ, pk, filSHP, LAYNOM, LAYTIPE)
                const = 0
                self.close()
                

        if attrs[0] == 's/d':
            print ('NO SE LOCALIZAN DATOS')

            dw.A_IMD.setText("s/d")              
            dw.A_porcPes.setText("s/d")                
            pass
            
        else:
            dw.A_IMD.setText(str(attrs[8]))              
            dw.A_porcPes.setText("{:.{}f}".format( attrs[9],3)+'%')
            pass
        
        QApplication.restoreOverrideCursor()
        
        # Nombre: 0 idEstacion
        # Nombre: 1 Provincia
        # Nombre: 2 EstacionTi
        # Nombre: 3 Carretera
        # Nombre: 4 Pk_estacio
        # Nombre: 5 Ubicacion
        # Nombre: 6 KMi
        # Nombre: 7 KMf
        # Nombre: 8 IMD17
        # Nombre: 9 PESADOS17
        # Nombre:10 Tramificac
        # Nombre:11 Shape_Length        

        
    def setLabelColors(window, base):
        t = '<property name="palette"><palette><active>'
        t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>255</green><blue>255</blue></color></brush></colorrole>'
        t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '</active><inactive>'
        t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>255</green><blue>255</blue></color></brush></colorrole>'
        t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '</inactive><disabled>'
        t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '</disabled></palette></property>'
        return t

    def RetrocedePK(self, GDB):
        ctraBUSQ = self.fun.Extract_PlainText(dw.Carretera)
        #pk = self.fun.Extract_PlainText(dw.Pk).replace('PK: ','').replace('+','')
        pk = self.pkProx
        self.pkProx = pk - (self.intervalo/1000)
        print (u'RETROCEDE A CTRA %s - PK %s - INT %s'%(ctraBUSQ,self.pkProx, self.intervalo))
        self.pkGetGeometria(ctraBUSQ, self.pkProx, dw, GDB)
        # return pkBUSQ
        pass
        
    def AvanzaPK(self, GDB):
        ctraBUSQ = self.fun.Extract_PlainText(dw.Carretera)
        #pk = self.fun.Extract_PlainText(dw.Pk).replace('PK: ','').replace('+','')
        pk = self.pkProx
        self.pkProx = pk + (self.intervalo/1000)
        print (u'RETROCEDE A CTRA %s - PK %s - INT %s'%(ctraBUSQ,self.pkProx, self.intervalo))
        self.pkGetGeometria(ctraBUSQ, self.pkProx, dw, GDB)
        # return pkBUSQ
        pass
        
        
'''
    # CAMBIO DE COLOR DEL FONDO DEL QLABEL
    # https://stackoverflow.com/questions/2749798/qlabel-set-color-of-text-and-background
    # SISTEMA 1
    myLabel= QLabel()
    myLabel.setAutoFillBackground(True) # This is important!!
    color  = QtGui.QColor(233, 10, 150)
    alpha  = 140
    values = "{r}, {g}, {b}, {a}".format(r = color.red(),
                                         g = color.green(),
                                         b = color.blue(),
                                         a = alpha
                                         )
    myLabel.setStyleSheet("QLabel { background-color: rgba("+values+"); }")

    # SISTEMA 2
    QPalette sample_palette;
    sample_palette.setColor(QPalette::Window, Qt::white);
    sample_palette.setColor(QPalette::WindowText, Qt::blue);

    sample_label->setAutoFillBackground(true);
    sample_label->setPalette(sample_palette);
    sample_label->setText("What ever text");


    def botonAmpliarDcha(self):
        if self.botonDcha == 'R':
            ctraBUSQ  =  self.Matricula.text()
            pk = float(self.Pk.text())
            self.pkGetGeometria(ctraBUSQ, pk)

            self.setFixedSize(740, 425)
            self.btnAbrirDcha.setArrowType(QtCore.Qt.LeftArrow)
            self.botonDcha = 'L'
            self.btnAbrirAbajo.setArrowType(QtCore.Qt.UpArrow)
            self.botonAbajo = 'U'
        elif self.botonDcha == 'L':
            self.setFixedSize(540, 160)
            self.btnAbrirAbajo.setArrowType(QtCore.Qt.DownArrow)
            self.botonAbajo = 'D'
            # self.btnAbrirDcha.setArrowType(QtCore.Qt.RightArrow)
            # self.botonDcha = 'R'

'''