# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrCTRAS_catalogo.py
                                 A QGIS plugin
                             -------------------
        begin                : 2018-03-24
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.
 *
 *   Based in 'Quick Export' pluggin
 *                                                                         *
 ***************************************************************************/
"""

from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import QSettings, QCoreApplication, QTranslator, qVersion, Qt
from PyQt5.QtWidgets import QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox, QFileDialog
from PyQt5 import uic

from qgis.gui import QgsMessageBar
from qgis.core import QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication
from qgis.utils import iface
from qgis.PyQt.QtPrintSupport import QPrinter


import os
from osgeo import ogr, osr
import urllib
import json
from time import sleep
import glob, codecs
from functools import partial
import shutil
import datetime
import locale
import tempfile
import sys
import subprocess
import csv

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_catalogo.ui'))


class herrCTRAS_catalogo(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrCTRAS_catalogo, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.logo.setPixmap(QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))
        
        self.fun = Functions()
        self.current_configuration = configuration()
        
        self.plugin_dir = os.path.dirname(__file__)
        # self.QgisVersion = QGis.QGIS_VERSION_INT
        self.QgisVersion = Qgis.QGIS_VERSION_INT

        # PDF print options
        self.maxLinesPerPage = 40
        self.maxAttributesBeforeSmallFontSize = 15
        self.orientation = QPrinter.Landscape
        self.pageSize = QPrinter.A4

        # CSS template file
        self.cssPath = os.path.join(
            self.plugin_dir,
            "templates/table.css"
        )

        self.txeOUTFIELDS.setText('Matricula, idMatricula, Provincia, Origen, Destino,PkINI,PkFin,Long_Km')
        self.txeOrderByFields.setText('Titularidad, idOrdenCtra, Funcionalidad, Matricula, PkINI, Provincia')
        
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)    
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        self.btnSeleccionfich.clicked.connect(self.salida_file_click)
        #    VER ESTO ##################################################################################################
        
        # self.chbALLLAYERS.connect(self.chbALLLAYERS, SIGNAL("stateChanged(int)"), self.cambiatxeOUTFIELDS)

        #    VER ESTO ##################################################################################################
        self.buttonBoxOK.clicked.connect(self.catalogoGDB)
        self.strPrecision = "{:."+str(self.spnPRECISION.value())+"f}"
        
        # COMBOS DESPLEGABLES
        #  Combo Funcionalidad
        lista_Valores = self.fun.getValoresCampo('Funcionalidad','')
        self.cbxFuncionalidad.clear()
        if lista_Valores is not None:
            # self.cbxFuncionalidad.addItems('%')
            self.cbxFuncionalidad.addItem("Todo")
            self.cbxFuncionalidad.addItems(lista_Valores)
        #  Combo Titularidad
        lista_Valores = self.fun.getValoresCampo('Titularidad','')
        self.cbxTitularidad.clear()
        if lista_Valores is not None:
            # self.cbxTitularidad.addItems('%')
            self.cbxTitularidad.addItem("Todo")
            self.cbxTitularidad.addItems(lista_Valores)
            if 'JCCM' in lista_Valores:
                self.cbxTitularidad.setCurrentIndex(1+lista_Valores.index('JCCM'))
        #  Combo Provincia
        lista_Valores = self.fun.getValoresCampo('Provincia','')
        self.cbxProvincia.clear()
        if lista_Valores is not None:
            # self.cbxProvincia.addItems('%')
            self.cbxProvincia.addItem("Todo")
            self.cbxProvincia.addItems(lista_Valores)
            if 'Albacete' in lista_Valores:
                # self.cbxProvincia.setCurrentIndex(1+lista_Valores.index('Albacete'))
                pass
        #  Combo Matricula
        
        lista_Valores = self.fun.getValoresCampo('Matricula','')
        self.cbxMatricula.clear()
        if lista_Valores is not None:
            # lista_Valores.append("%")
            lista_Valores.insert(0, "%")
            # self.cbxMatricula.addItems(u"%")
            self.cbxMatricula.addItems(lista_Valores)

            
    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()

        
    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        # return text.encode('utf-8')
        return text.encode('ISO-8859-14')
        

    def cambiatxeOUTFIELDS(self):
        if self.chbALLLAYERS.isChecked():
            self.txeOUTFIELDS.setEnabled(False)
        else:
            self.txeOUTFIELDS.setEnabled(True)
            

    def salida_file_click(self):
        dirFile = self.lneFICHsalida.text()
        fileTipe = self.cbxTipoExport.currentText()
        ext = "*.csv"
        if fileTipe!= 'IMPRESORA':
            filename, tipofile = QFileDialog.getSaveFileName(self, "Fichero GML de salida", dirFile, ext)
            print (filename, tipofile)
            if filename != None and filename != "":
                self.lneFICHsalida.setText(filename)
            else:
                filename = dirFile
            # Comprobamos que existe el directorio y si no se crea
            if not os.path.exists(os.path.dirname(filename)):
                os.makedirs(os.path.dirname(filename))              

            
    def catalogoGDB(self):
        fileTipe = self.cbxTipoExport.currentText()
        if fileTipe == 'IMPRESORA':
            fileTipe = 'printer'
        if fileTipe == u'Solo CSV':
            fileTipe = 'csv'
        
        valcbxTitularidad = self.cbxTitularidad.currentText()
        valcbxFuncionalidad = self.cbxFuncionalidad.currentText()
        valcbxProvincia = self.cbxProvincia.currentText()
        if valcbxTitularidad == "Todo":
            valcbxTitularidad = '%'
        if valcbxFuncionalidad == "Todo":
            valcbxFuncionalidad = '%'
        if valcbxProvincia == "Todo":
            valcbxProvincia = '%'
            
        whereTXT = '('  
        whereTXT+= ' Titularidad LIKE '+"'"+valcbxTitularidad+"'"
        whereTXT+= ' AND Funcionalidad LIKE '+"'"+valcbxFuncionalidad+"'"
        whereTXT+= ' AND Provincia LIKE '+"'"+valcbxProvincia+"')"
        whereTXT+= ' AND Matricula LIKE '+"'"+self.cbxMatricula.currentText()+"'"
        
        if self.chbMATR9000.isChecked():
            whereTXT+= ' AND Matricula <>'+ "'9000'"

        outfields = '*'
        self.listCamposCOMP = ['OBJECTID', 'idMatricula','Matricula','Longitud','PkINI','PkFin','Matricula_Plan',
            'Titularidad','Funcionalidad','Tipologia_DobleC','Tipologia_UnaC','Denominacion',
            'Long_Km','idOrdenCtra','Origen','Destino','Provincia','Shape.STLength()']      
        if self.chbALLLAYERS.isChecked():
            self.listCampos = self.listCamposCOMP
        else:
            self.listCampos = self.txeOUTFIELDS.toPlainText().replace(' ', '').split(',')
            
        # orderByFields = "Titularidad, Funcionalidad, Matricula, PkINI"
        orderByFields = self.txeOrderByFields.toPlainText()
        self.listCamposOrder = orderByFields.replace(' ', '').split(',')
            
        # Comprobamos CAMPOS INCLUIDOS en la salida
        listBorrar = []
        for campo in self.listCampos:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCampos.remove(campo)

        # Comprobamos CAMPOS INCLUIDOS en la lista de orden de campos
        listBorrar = []
        for campo in self.listCamposOrder:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCamposOrder.remove(campo)
        orderByFields = ",".join(self.listCamposOrder)
            
        self.lblINFO.setText('INFO: Leyendo url .....')
        
        TipoExport = self.cbxTipoExport.currentText()

        # QUERY AL WFS Plan_Carreteras_BTA_WFS para contar elementos
        # values = {
                  # 'where' : whereTXT,
                  # 'text': '',
                  # 'objectIds': '',
                  # 'returnCountOnly': True,
                  # 'outFields': outfields,
                  # 'orderByFields' : orderByFields,
                  # 'geometryPrecision' : 6
                  # 'f': 'json'}
        # print url+data


        # QUERY AL WFS Plan_Carreteras_BTA_WFS 
        url = self.current_configuration.environment["rest_carreteras"]

        values = {'where' : whereTXT,
                  'text': '',
                  'objectIds': '',
                  'geometryType' : 'esriGeometryPolyline',
                  'returnGeometry' : False,
                  'returnM': False,
                  'outFields': outfields,
                  'orderByFields' : orderByFields,
                  # 'geometryPrecision' : 6
                  'f': 'json'}
        
        restfeatures = self.fun.getFeaturesBTAcalibrada(values)
       
        numfeats = len(restfeatures)
        nfeat = 0
        if numfeats==0:
            # self.fun.showJCCMessage(u"Error de conexión a internet (catalogoGDB LIN:288")
            return

        # FICHEROS Y CAPAS
        fich_csv = self.lneFICHsalida.text()
        fich = self.lneFICHsalida.text().replace('csv', fileTipe)
        
        QgsMessageLog.logMessage( "Creando archivo de log","jccm_bar")
        
        # ESCRIBIMOS ENCABEZADOS FICHERO 'CSV'
        target  = codecs.open(fich_csv, 'w+',encoding='utf-8')
        encabezado = ''
        for campo in self.listCamposCOMP:
            encabezado += campo + u';'

        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        encabezado += 'Long_Total;'
        # self.listCampos.append('Long_Total')
        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        
        target.write(encabezado)
        target.write("\n")
        
        # ESCRIBIMOS LISTA DE DATOS
        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        countFeat = 0
        Long_Total = 0
        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---

        for feat in restfeatures:
            attributes = feat["attributes"]
            # print attributes
            # COMPROBAMOS DOBLE VIA
            grabar = True
            if not self.chbDOBLEVIA.isChecked():
                if attributes['Tipologia_DobleC'] == 'ATV' or attributes['Tipologia_DobleC'] == 'ATP':
                    ctraCalzada = attributes['Matricula_Plan'].split(u' ')
                    if len(ctraCalzada)>1:
                        if attributes['Matricula_Plan'].split(u' ')[1] == 'D' or attributes['Matricula_Plan'].split(u' ')[1] == 'd':
                            grabar = False
                        pass

            if grabar:  # En caso de DOBLE VIA desmarcado, solo grabamos CALZADA D
                datos = u''
                for attr in self.listCamposCOMP:
                    dat = u''
                    if isinstance(attributes[attr], str):
                        dat = attributes[attr]
                    elif isinstance(attributes[attr], unicode):
                        dat = attributes[attr]
                    elif isinstance(attributes[attr], int):
                        dat = str(attributes[attr])
                    elif isinstance(attributes[attr], float):
                        dat = (self.strPrecision.format(attributes[attr]))

                    datos += (dat + u';')
                        
                # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
                if attributes['Long_Km'] is not None:
                    Long_Total += attributes['Long_Km']
                if countFeat+1 < len(restfeatures):
                    if attributes['Matricula_Plan'] != restfeatures[countFeat+1]["attributes"]['Matricula_Plan']:
                        # print True
                        datos += (self.strPrecision.format(Long_Total) + u';')
                        Long_Total = 0
                    else:
                        # print False
                        datos += u'-;'
                else:
                    # print 'Final'
                    datos += (self.strPrecision.format(Long_Total) + u';')
                # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
    
                   
                target.write(datos)
                target.write("\n")
                nfeat +=1
                prog = 50 * nfeat/numfeats
                self.progressBar.setValue(prog)
                self.lblINFO.setText(u'INFO: Añadiendo a CSV registro ' + str(nfeat) +'/' +str(numfeats))
            
            countFeat += 1
        
        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        self.listCampos.append('Long_Total')
        self.listCamposCOMP.append ('Long_Total')
        
        target.close()
        
        fich_csv_uri = u"file:///"+ fich_csv +"?type=csv&geomType=none&subsetIndex=no&delimiter=%s&watchFile=no" % (";")
        #print fich_csv_uri
        
        abstract = ''
        if self.cbxTitularidad.currentText() != '%':
                    abstract += u'Titularidad - %s / '%self.cbxTitularidad.currentText()
        if self.cbxFuncionalidad.currentText() != '%':
                    abstract += u'Funcionalidad - %s / '%self.cbxFuncionalidad.currentText()
        if self.cbxProvincia.currentText() != '%':
                    abstract += u'Provincia - %s / '%self.cbxProvincia.currentText()

        # Esto crea la capa CSV
        #   Si existe la capa se debe borrar
        nomcapa = u'CATALOGO CARRETERAS'
        csv_lyrLIST = QgsProject.instance().mapLayersByName(nomcapa)
        if len(csv_lyrLIST) >0:
            for csv_lyr in csv_lyrLIST:
                QgsProject.instance().removeMapLayer(csv_lyr.id())
        csv_lyr = QgsVectorLayer(fich_csv_uri, nomcapa,'delimitedtext')
        # csv_lyr.setAbstract (abstract)
        QgsProject.instance().addMapLayer(csv_lyr, False)
        
        # Colocamos la capa arriba del todo
        root = QgsProject.instance().layerTreeRoot()
        root.insertLayer(0, csv_lyr)
        self.iface.setActiveLayer(csv_lyr)

        self.tbrURLCOMPLETA.setHtml(self.creaHTML(''))
        pass
        
        self.exportLayer(fileTipe, fich)
        
        # Abrir el fichero resultante
        if os.path.exists(self.exportedFile):
            os.startfile(self.exportedFile)
        else:
            self.iface.messageBar().pushMessage('Parece que no se ha creado el fichero ' +self.exportedFile, u'JCCM Carreteras', QgsMessageBar.WARNING, 5)

        self.lblINFO.setText('INFO:')
        self.progressBar.setValue(0)
        self.close


    def exportLayer(self, etype='csv', fich=''):
        # Se exporta la tabla de atributos de la tabla seleccionada al tipo de fichero elegido

        # Establece propiedades del tipo de salida
        self.etype = etype
        self.exportHiddenAttributes = False
        self.csvDelimiter = '\t'
        
        # Cojemos la capa activa
        layer = self.iface.activeLayer()
        msg= None

        # Comprobamos si la capa es valida para exportar
        if layer and layer.type() == QgsMapLayer.VectorLayer and hasattr(layer, 'providerType'):

            # Se acude al método adecuado según el tipo seleccionado
            if etype != 'printer':
               
                ePath = fich
                self.exportedFile = fich

                if etype == 'csv':
                    msg = u'La capa ha sido cargada adecuadamente.'
                    status = 'info'
                    
                elif etype == 'html':
                    msg, status = self.exportLayerToHtml(layer, fich, False, 'html')
                    
                elif etype == 'pdf':
                    msg, status = self.exportLayerToPdf(layer)

            else:
                msg, status = self.exportLayerToPdf(layer, True)

        else:
            msg = u'Selecciona primero una capa vectorial'
            status = 'warning'

            
    def exportLayerToHtml(self, layer, ePath=None, cutPages=False, etype=None):
        '''
        Exporta la capa a HTML
        usando una plantilla y leyendo los datos
        desde la capa seleccionada
        '''
        # VALORES ENCABEZADOS
        title = u'CATÁLOGO DE CARRETERAS'

        campoGrupo  = u'Funcionalidad'
        ######################################################################
        #                             CONTROL                                #
        ######################################################################
        campoGrupo1 = u'Titularidad'
        campoSumaGrupo = u'Long_Km'
        udSuma = u'Km'

        # DEFINICIONES DE REDES (Funcionalidad)
        listaTitulos = [
            {'Grupo' : u'Autopistas Peaje', 'Titulo' : u'RED ESTATALES - Autopistas Peaje', 'Color' : u'rgb(90, 110, 255)'},
            {'Grupo' : u'Autopistas', 'Titulo' : u'RED ESTATALES - Autopistas', 'Color' : u'rgb(90, 110, 255)'},
            {'Grupo' : u'Convencionales', 'Titulo' : u'RED ESTATALES - Convencionales', 'Color' : u'rgb(255, 90, 90)'},
            {'Grupo' : u'Básica alta capacidad', 'Titulo' : u'RED REGIONAL - BÁSICA ALTA CAPACIDAD', 'Color' : u'rgb(255, 115, 223)'},
            {'Grupo' : u'Básica', 'Titulo' : u'RED REGIONAL - BÁSICA', 'Color' : u'rgb(255, 170, 0)'},
            {'Grupo' : u'Comarcal', 'Titulo' : u'RED REGIONAL - COMARCAL', 'Color' : u'rgb(85, 255, 0)'},
            {'Grupo' : u'Local', 'Titulo' : u'RED REGIONAL - LOCAL', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Travesía', 'Titulo' : u'RED REGIONAL - TRAVESÍAS (RED LOCAL)', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Ramal', 'Titulo' : u'RED REGIONAL - RAMALES (RED LOCAL)', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Enlace', 'Titulo' : u'RED REGIONAL - ENLACES', 'Color' : u'rgb(200, 200, 200)'},
            {'Grupo' : u'Diputación', 'Titulo' : u'RED DIPUTACIÓN PROVINCIAL', 'Color' : u'rgb(254, 254, 254)'}
            ]
        
        QApplication.setOverrideCursor(Qt.WaitCursor)

        # Leemos el fichero de plantilla
        tplPath = os.path.join(
            self.plugin_dir,
            "templates/htmlTemplate.tpl"
        )
        fin = open(tplPath)
        data = fin.read()
        fin.close()

        # Se obtienen los datos de la capa
        layerData, nb = self.getLayerData(layer)
        
        # Obtenemos los tipos de cada campo
        fields = layer.fields()
        tipoCampos = []
        for field in fields:
            tipoCampos.append(field.typeName())

            
        # Nombres de campos de la capa
        fieldNames = layerData[0]
        nbAttr = len(fieldNames)
        numcampoGrupo  = fieldNames.index(campoGrupo )

        ######################################################################
        #                             CONTROL                                #
        ######################################################################
        numcampoGrupo1 = fieldNames.index(campoGrupo1)
        numcampoSumaGrupo = fieldNames.index(campoSumaGrupo )
        
        # Calculamos posiciones de los campos a listar
        numColumnas = u'"'+str(len(self.listCampos))+u'"'
        poslistCampos = []
        for campo in self.listCampos:
            poslistCampos.append(self.listCamposCOMP.index(campo))
   
        
        # Creamos el contenido de 'tbody' con los datos de atributos de los elementos
        valcampoGrupo = ''
        tbody = ''
        i = 6 # num lineas
        page = 1
        totalGrup = 0
        totalGlobal = 0
        table = 0
        attrValues = layerData[1:]
        

        # Escribir la tabla de contenido como HTML
        for values in attrValues:
            prog = 50 +50 * attrValues.index(values)/len(attrValues)
            self.progressBar.setValue(prog)
            self.lblINFO.setText(u'INFO: Añadiendo a -'+etype+'- registro ' + str(attrValues.index(values)) +'/' +str(len(attrValues)))
            ######################################################################
            #                             CONTROL                                #
            ######################################################################
            valorTestigo = values[numcampoGrupo]
            if valorTestigo == u'Básica alta capacidad' and values[numcampoGrupo1] == 'Estatal':
                valorTestigo = u'Autopistas'
            if valorTestigo == u'Básica' and values[numcampoGrupo1] == 'Estatal':
                valorTestigo = u'Convencionales'
            if values[numcampoGrupo1] == u'Diputación':
                valorTestigo = u'Diputación'

            if valorTestigo != valcampoGrupo:
                ######################################################################
                #                             CONTROL                                #
                ######################################################################
                if table != 0:
                    # print totalGlobal,
                    # Escribimos un pie por grupo finalizando la tabla
                    tbody+='                <tr>\n'
                    tbody+='                    <th colspan=%s align="right" style="background: %s">    TOTAL %s -- %s %s</th>'%(numColumnas, 'rgb(255, 255, 255)', tituloGrupo, '{:.3f}'.format(totalGrup), udSuma)
                    tbody+='                </tr>\n'
                    tbody+='            </tbody>\n'
                    tbody+='        </table>\n'
                    totalGlobal += totalGrup
                    totalGrup = 0
                    i += 2
                table+=1
                thead = ''
                ######################################################################
                #                             CONTROL                                #
                ######################################################################
                # valcampoGrupo = values[numcampoGrupo]
                valcampoGrupo = valorTestigo
                tituloGrupo = ''
                colBck = 'rgb(200, 200, 200)'
                for dataGrupos in listaTitulos:
                    if dataGrupos['Grupo'] == valcampoGrupo:
                        tituloGrupo = dataGrupos['Titulo']
                        colBck = dataGrupos["Color"]

                thead+='        <table>\n'
                thead+='            <tbody>\n'
                thead+='                <tr>\n'
                thead+='                    <th colspan=%s align="left" style="background: %s">%s</th>'%(numColumnas, colBck, tituloGrupo)
                thead+='                </tr>\n\n'
                thead+='                <tr>\n'
                i += 3
                for field in self.listCampos:
                    thead+= '                    <th style="background: %s">%s</th>\n' %(colBck, field)
                thead+= '                </tr>\n\n'
                tbody+= thead
                
            # Se crea la lista de valores de cada registro           
            valuesLista = []
            tbody+= '                <tr>\n'
            for pos in poslistCampos:
                if tipoCampos[pos] == 'integer':
                    try:
                        valueTD = "{:.0f}".format(float(values[pos]))
                        tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                    except:
                        valueTD = valueTD = values[pos]
                elif tipoCampos[pos] == 'double':
                    try:
                        valueTD = "{:.3f}".format(float(values[pos]))
                        tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                    except:
                        valueTD = valueTD = values[pos]
                elif self.listCamposCOMP[pos] == 'Long_Total' and self.fun.isFloat(values[pos]):
                    valueTD = "{:.3f}".format(float(values[pos]))
                    tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                else:
                    valueTD = values[pos]
                    tbody+= '                    <td align="left">' + valueTD + '</td>\n'
            tbody+= '                    </td>\n'
            tbody+= '                </tr>\n\n'
            
            try:
                totalGrup += float(values[numcampoSumaGrupo])

            except:
                pass
            i+=1
            if i == self.maxLinesPerPage and cutPages and self.QgisVersion > 10900:
                i = 3
                tbody+= '</table>\n\n'
                tbody+= '<span>Page %s</span>' % page
                tbody+= '<div class="saltopagina"></div>\n\n'
                tbody+= '<table><thead>' + thead + '</thead><tbody>'
                page+=1

                
        # LÍNEAS FINALES
        totalGlobal += totalGrup

        tbody+='                <tr>\n'
        tbody+='                    <th colspan=%s align="right" style="background: %s">    TOTAL %s -- %s %s</th>'%(numColumnas, 'rgb(255, 255, 255)', tituloGrupo, '{:.3f}'.format(totalGrup), udSuma)
        tbody+='                </tr>\n'
        tbody+='                <tr>\n'
        tbody+='                    <th colspan=%s align="right" style="background: %s">    TOTAL %s -- %s %s</th>'%(numColumnas, 'rgb(255, 255, 255)', u'GENERAL', '{:.3f}'.format(totalGlobal), udSuma)
        tbody+='                </tr>\n'
        tbody+='            </tbody>\n'
        tbody+='        </table>\n'
        
        # Get creation date
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x %X"
        today = datetime.datetime.today()
        date = today.strftime(date_format)
        dt_date = u'JCCM. Dirección General de Carreteras '

        # Icono, Titulo, Resumen, número de Carreteras
        fileIcono = u'python/plugins/jccm_bar3/iconos/jccm.jpg'
        dirPYTJCCM = QgsApplication.qgisSettingsDirPath()
        fileIcono = os.path.normpath(os.path.join(os.path.dirname(dirPYTJCCM), fileIcono))
        dt_icono = '<img src="%s" border="0" width="100" height="80">'%fileIcono
        dt_title = u''
        dt_abstract = u'Datos'
        dt_info = u'Información'
        
        try:
            abstract = layer.abstract()
        except:
            abstract = ''
            if self.cbxTitularidad.currentText() != '%':
                        abstract += u'Titularidad - %s / '%self.cbxTitularidad.currentText()
            if self.cbxFuncionalidad.currentText() != '%':
                        abstract += u'Funcionalidad - %s / '%self.cbxFuncionalidad.currentText()
            if self.cbxProvincia.currentText() != '%':
                        abstract += u'Provincia - %s / '%self.cbxProvincia.currentText()

        info = u'TOTAL %s Carreteras - %s Km'%(format(str(nb)), format(totalGlobal)) 

        # Adapt style if needed
        style = ''
        # Get CSS style from table.css
        with open(self.cssPath, 'r') as content_file:
            style = content_file.read()
        if nbAttr > self.maxAttributesBeforeSmallFontSize:
            # style+= 'th, td {font-size:small;}'
            style+= 'th, td {font-size:10px;}'


        # Replace values
        data = data.replace('$icono', dt_icono)
        data = data.replace('$dt_title', dt_title)
        data = data.replace('$title', title)
        data = data.replace('$dt_abstract', dt_abstract)
        data = data.replace('$abstract', abstract)
        data = data.replace('$dt_info', dt_info)
        data = data.replace('$info', info)
        data = data.replace('$tbody', tbody)
        data = data.replace('$dt_date', dt_date)
        data = data.replace('$date', date)
        data = data.replace('$style', style)
        data = data.replace('$totalPages', "Pag. %s" % page)

        # File path
        if not ePath:
            ePath = self.exportedFile

        try:
            # write html content
            f = open(ePath, 'w')
            # f.write(data.encode('utf-8'))
            f.write(data)
            f.close()

        # except IOError, e:
        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación')
            status = 'critical'
        finally:
            msg = QApplication.translate("quickExport", u'La capa ha sido adecuadamente exportada')
            status = 'info'

        QApplication.restoreOverrideCursor()

        return msg, status


    def exportLayerToPdf(self, layer, doPrint=False):
        '''
        Exports the layer to PDF
        First export to HTML then convert to PDF.
        If not output file given, send directly to the printer
        '''

        # Create temporary file path
        temp = tempfile.NamedTemporaryFile()
        try:
            # Create temporary HTML file
            tPath = "%s.html" % temp.name
            msg, status = self.exportLayerToHtml(layer, tPath, True, 'pdf')

            # Create a web view and fill it with the html file content
            web = QWebView()
            web.load(QUrl(tPath))

            # Print only when HTML content is loaded
            def printIt():
                #~ web.show()
                # Open the printer dialog if needed
                if doPrint:
                    dialog = QPrintDialog()
                    if dialog.exec_() == QDialog.Accepted:
                        printer = dialog.printer()
                    else:
                        return
                # No print, only PDF export
                else:
                    # Set page options for PDF
                    printer = QPrinter()
                    printer.setPageSize(self.pageSize)
                    printer.setOrientation(self.orientation)
                    printer.setFontEmbeddingEnabled(True)
                    printer.setColorMode(QPrinter.Color)
                    # set output file name in case of PDF export
                    printer.setOutputFileName(self.exportedFile)

                # Set some metadata
                printer.setCreator(u"QGIS - Complemento JCCM Carreteras")
                printer.setDocName(u"Exportado - %s" % layer.title() and layer.title() or layer.name())

                # Print
                web.print_(printer)

            web.loadFinished[bool].connect(printIt)

        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'critical'
        finally:
            # Automatically cleans up the file
            temp.close()
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'info'
            
        return msg, status

        
        
        
    def getLayerData(self, layer):
        '''
        Get fields and data from
        a vector layer
        '''
        data = []

        # Get layer fields names
        fields = layer.fields()
        fieldNames = [
            field.name() for i, field in enumerate(fields)
            ]
        data.append(fieldNames)

        # Get selected features or all features
        if layer.selectedFeatureCount():
            nb = layer.selectedFeatureCount()
        else:
            nb = layer.featureCount()



        # Get layer fields data

        # QGIS >= 2.0
        if self.QgisVersion > 10900:
            if layer.selectedFeatureCount():
                features = layer.selectedFeatures()
            else:
                features = layer.getFeatures()
            for feat in features:
                # Get attribute data
                values = [
                    self.displayAttributeValue(a) for i, a in enumerate(feat.attributes())
                    # if layer.editType(i) != QgsVectorLayer.Hidden
                    # or self.exportHiddenAttributes
                ]
                data.append(values)

        # QGIS 1.8
        else:
            provider = layer.dataProvider()
            allAttrs = provider.attributeIndexes()
            provider.select(allAttrs, QgsRectangle(), False)
            layer.select(allAttrs, QgsRectangle(), False)
            if layer.selectedFeatureCount():
                items = layer.selectedFeatures()
            else:
                items = layer
            for feat in items:
                attrs = feat.attributeMap()
                values = [
                    self.displayAttributeValue(v) for k,v in attrs.iteritems()
                    if layer.editType(k) != QgsVectorLayer.Hidden
                    or self.exportHiddenAttributes
                ]
                data.append(values)

        return data, nb
       

    def displayAttributeValue(self, value):
        '''
        Convert QGIS attribute data into readable values
        '''
        # QGIS version
        isQgis2 = self.QgisVersion > 10900

        # Get locale date representation
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_FMT)
            datetime_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x"
            datetime_format = "%x %X"

        # Convert value depending of type
        if hasattr(value, 'toPyDate'):
            output = value.toPyDate().strftime(date_format)
        elif hasattr(value, 'toPyDateTime'):
            output = value.toPyDateTime().strftime(datetime_format)
        else:
            output = u"%s" % value if isQgis2 else u"%s" % value.toString()

        return output
   

    def creaHTML(self, url):
        textHTML = u'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">'
        textHTML+= u'<html><head><meta name="qrichtext" content="1" /><style type="text/css">'
        textHTML+= u'p, li { white-space: pre-wrap; }'
        textHTML+= u'</style></head><body style=" font-family:'+"'MS Shell Dlg 2'"+'; font-size:8.25pt; font-weight:400; font-style:normal;">'
        textHTML+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'
        # textHTML+= u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?where=Matricula_Plan+LIKE+%27%25%27&amp;text=&amp;objectIds=&amp;time=&amp;geometry=&amp;geometryType=esriGeometryEnvelope&amp;inSR=&amp;spatialRel=esriSpatialRelIntersects&amp;relationParam=&amp;outFields=*&amp;returnGeometry=true&amp;returnTrueCurves=false&amp;maxAllowableOffset=&amp;geometryPrecision=&amp;outSR=&amp;returnIdsOnly=false&amp;returnCountOnly=true&amp;orderByFields=&amp;groupByFieldsForStatistics=&amp;outStatistics=&amp;returnZ=false&amp;returnM=true&amp;gdbVersion=&amp;returnDistinctValues=false&amp;resultOffset=&amp;resultRecordCount=&amp;queryByDistance=&amp;returnExtentsOnly=false&amp;datumTransformation=&amp;parameterValues=&amp;rangeValues=&amp;f=pjson">'
        textHTML+= url
        textHTML+= u'<span style=" font-size:8pt; text-decoration: underline; color:#0000ff;">'
        # textHTML+= u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?where=Matricula_Plan+LIKE+%27%25%27&amp;text=&amp;objectIds=&amp;time=&amp;geometry=&amp;geometryType=esriGeometryEnvelope&amp;inSR=&amp;spatialRel=esriSpatialRelIntersects&amp;relationParam=&amp;outFields=*&amp;returnGeometry=true&amp;returnTrueCurves=false&amp;maxAllowableOffset=&amp;geometryPrecision=&amp;outSR=&amp;returnIdsOnly=false&amp;returnCountOnly=true&amp;orderByFields=&amp;groupByFieldsForStatistics=&amp;outStatistics=&amp;returnZ=false&amp;returnM=true&amp;gdbVersion=&amp;returnDistinctValues=false&amp;resultOffset=&amp;resultRecordCount=&amp;queryByDistance=&amp;returnExtentsOnly=false&amp;datumTransformation=&amp;parameterValues=&amp;rangeValues=&amp;f=pjson'
        textHTML+= url
        textHTML+= u'</span></a></p></body></html>'
        return textHTML
        

'''
        # Funcion de Query a GEOBTA
        # --- EJEMPLO ---
        # http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?
        # --- VALORES ---
        # where=Matricula_Plan+LIKE+%27%25%27&
        # text=&
        # objectIds=&
        # time=&
        # geometry=&
        # geometryType=esriGeometryEnvelope&
        # inSR=&
        # spatialRel=esriSpatialRelIntersects&
        # relationParam=&
        # outFields=*&
        # returnGeometry=true&
        # returnTrueCurves=false&
        # maxAllowableOffset=&
        # geometryPrecision=&
        # outSR=&
        # returnIdsOnly=false&
        # returnCountOnly=true&
        # orderByFields=&
        # groupByFieldsForStatistics=&
        # outStatistics=&
        # returnZ=false&
        # returnM=true&
        # gdbVersion=&
        # returnDistinctValues=false&
        # resultOffset=&
        # resultRecordCount=&
        # queryByDistance=&
        # returnExtentsOnly=false&
        # datumTransformation=&
        # parameterValues=&
        # rangeValues=&
        # f=pjson
'''