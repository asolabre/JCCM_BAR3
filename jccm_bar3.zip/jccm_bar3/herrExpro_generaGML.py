# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrExpro_generaGML.py
                                 A QGIS plugin
 herrExpro
                             -------------------
        begin                : 2017-01-25
        git sha              : $Format:%H$
        copyright            : (C) A.Solabre 2017
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

RUTINA crea_gml IMPORTADA DESDE
        dxfparcela2gmlcatastro.py
        -------------------------
Autor en origen:
Patricio Soriano :: SIGdeletras.com
Adaptada:
    A.Solabre
Fuentes:
    - Marcos Manuel Ortega :: Indavelopers :: DXFPARCELA2GMLCATASTRO (plugin)
    - Andrés V. O. :: SEC4QGIS (plugin)
Descripción:
El script genera el correspondiente fichero GML de las parcelas catastrales según las
    especificaciones de Castastro.
Especificaciones:
    - http://www.catastro.minhap.gob.es/esp/formatos_intercambio.asp
Requisistos:
    - Es necesario tener instalado Python y el módulo GDAL
Ejemplos:
    - python dxfgmlcatastro.py archivocad.dxf gmlsalida.gml 25831
"""
from PyQt5.QtWidgets import QDialog, QFileDialog
from PyQt5.QtGui import QIcon
from PyQt5 import uic
from PyQt5.QtCore import QSettings, Qt
from qgis.core import Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication, QgsGeometry, QgsFeature, QgsCoordinateReferenceSystem, QgsProject, QgsLayerTreeLayer, QgsWkbTypes

import sys
import os
from osgeo import ogr, osr, gdal
import qgis.utils

import urllib
import json
from time import sleep

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES

current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.environment["EPSG"]

### IMPORTADO DE dxfparcela2gmlcatastro.py ###
try:
    from osgeo import ogr, osr, gdal
    
except ImportError:
    sys.exit('ERROR: Paquetes GDAL/OGR no encontrados. Compruebe que están instalados correctamente')

# Comprueba que plantillacatastro.py existe en el directorio actual
try:
    from .plantillacatastro import *

except ImportError:
    sys.exit('ERROR: No se encuentra el script plantilla "plantillacatastro" en el directorio')
### FIN IMPORTACION DE dxfparcela2gmlcatastro.py ###
    
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_generaGML.ui'))

class herrExpro_generaGML(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
    # Clase para el submenu herrExpro_generaGML.ui
    
        """Constructor."""
        super(herrExpro_generaGML, self).__init__(parent)
        # Se establece el menu de usuario desde el diseñador
        #   despues de ejecutar 'setupUI', puedes acceder a cualquier objeto del diseño haciendo
        #   self.<objectname>, y puedes usar slots de autoconexión - ver
        #    http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        #    #widgets-and-dialogs-with-auto-connect

        self.setupUi(self)
        
        self.iface = iface;
        self.fun = Functions()
        self.setVar = QSettings()
        
        lista_CAPAS = self.getCAPAS()
        self.cbxCapaentrada.currentIndexChanged.connect(self.actualizarCampos) # ACTUALIZA CAMPOS SI CAMBIAS LA TABLA SELECCIONADA
        self.cbx_campos.currentIndexChanged.connect(self.anadirCampoLOCALID) # ACTUALIZA EL CAMPO DE LOCALID SI CAMBIAS LA TABLA SELECCIONADA
        
        self.cbxCapaentrada.clear()
        self.cbxCapaentrada.addItems(lista_CAPAS)
        lastCapaParaGML = self.setVar.value("JCCM_carreteras/last/lastCapaParaGML")
        if lastCapaParaGML in lista_CAPAS:
            self.cbxCapaentrada.setCurrentIndex(lista_CAPAS.index(lastCapaParaGML))
        self.lastDirGML = self.setVar.value("JCCM_carreteras/last/lastDirGML")
        if self.lastDirGML is None:
            self.lastDirGML = 'C:/temp/fichero.gml'
        self.srcExtORI = '.gml'
        self.lneGMLsalida.setText(self.lastDirGML)
        
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.btnAnadirCampoLCID.clicked.connect(self.anadirCampoLOCALID)
        self.btnGENERAGML.clicked.connect(self.generaGML)
        self.btnCANCELA.clicked.connect(self.cancela)
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.btnSeleccionfich.clicked.connect(self.gml_salida_file_click)
        self.lblINFO.hide() == True

        
    def getCAPAS(self):
        capas = []
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayer.VectorLayer:
                if layer.wkbType() == QgsWkbTypes.Polygon:
                    feat=layer.featureCount()
                    featsel=layer.selectedFeatureCount()
                    capas.append(layer.name())
                if layer.wkbType() == QgsWkbTypes.MultiPolygon:
                    feat=layer.featureCount()
                    featsel=layer.selectedFeatureCount()
                    capas.append(layer.name())

        return capas
        
        
    def actualizarCampos(self):
        layername = self.cbxCapaentrada.currentText()
        if layername == "":
            self.fun.showJCCMessage("Debes cargar una capa SHP de POLÍGONOS en la tabla de contenidos")
            return None
        selected_table = self.fun.getLayerByName(layername)
        fields = selected_table.fields()
        text_fields = []
        numeric_fields = [""]
        for field in fields:
            text_fields.append(field.name())
        
        self.cbx_campos.clear()
        self.cbx_campos.addItems(text_fields)
        self.anadirCampoLOCALID()
        # self.actualizarValoresMuestra()
        
        self.cbx_campoNMSPC.clear()
        self.cbx_campoNMSPC.addItems(text_fields)
        
        campoLOCALIDtipo = 'RC14'
        campoNMSPCtipo   = 'CAT_NMSPC'
        if campoLOCALIDtipo in text_fields:
            self.cbx_campos.setCurrentIndex(text_fields.index(campoLOCALIDtipo))
        if campoNMSPCtipo in text_fields:
            self.cbx_campoNMSPC.setCurrentIndex(text_fields.index(campoNMSPCtipo))
        
        # MODIFICAR NOMBRE DE FICHERO
        srcDir, srcFilExtName = os.path.split(self.lneGMLsalida.text())
        srcFilName, srcExt = os.path.splitext(srcFilExtName)
        resultFiledir = srcDir+'/'+layername+srcExt
        self.lneGMLsalida.setText(resultFiledir)

        
    def anadirCampoLOCALID(self):
        campoADD = self.cbx_campos.currentText()
        self.lneLOCALID.setText('['+campoADD+']'+'_{NUM}')
      
        
    def generaGML(self):
        self.setVar.setValue("JCCM_carreteras/last/lastCapaParaGML", self.cbxCapaentrada.currentText())
        self.setVar.setValue("JCCM_carreteras/last/lastDirGML", self.lneGMLsalida.text())

        gml_salida_file= self.lneGMLsalida.text()
        gmlDir, gmlFilExtName = os.path.split(gml_salida_file)
        gmlFilName, gmlExt = os.path.splitext(gmlFilExtName)
        nomCAPA = str(gmlFilName)
        
        layer_origen = QgsProject.instance().mapLayersByName(self.cbxCapaentrada.currentText())
        # src='25830'
        self.crea_gml(layer_origen, nomCAPA, gml_salida_file, str(srcVal))
        pass


    def cancela(self):
        self.close()
        pass

        
    def gml_salida_file_click(self):
        gml_salida_file= self.lneGMLsalida.text()
        ext = "*.gml"
        filename, tipofile = QFileDialog.getSaveFileName(self, "Fichero GML de salida", gml_salida_file, ext)
        print (filename, tipofile)
        if filename != None and filename != "":
            self.lneGMLsalida.setText(filename)
        else:
            filename = gml_salida_file
        # Comprobamos que existe el directorio y si no, se crea
        if not os.path.exists(os.path.dirname(filename)):
            os.makedirs(os.path.dirname(filename))
            
        
    def crea_gml(self,layer_origen, nomCAPA, gml_salida_file, src):
        # Transforma la información de la geometría de una capa al estándar de Catastro en formato GML.
        #   layer_origen:      Capa con la geometría de origen
        #   gml_salida_file:   Dirección del archivo en formato GML a sobreescribir con el resultado
        #   src:               Sistema de Referencia de Coordendas de la capa origen. Según cógigos  EPSG
        

        self.progressBar.setValue(0)
        layer = layer_origen[0]
        localid = self.lneLOCALID.text()
        ini_localid=int(self.lneLOCALID_2.text())
        self.lblINFO.show() == True
        self.lblINFO.setText("")
                
        # SRC_DICT=['25828', '25829', '25830', '25831']
        text = (
            u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600; text-decoration: underline;">Generar GML para catastro desde capa de Poligonos</span></p>'+
            u'<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; text-decoration: underline;"><br /></p>'+
            u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" text-decoration: underline;">DATOS DE ENTRADA:</span></p>'+
            u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">CAPA DE ENTRADA:</span></p>'+
            u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">   {}</p>'.format(layer.name())+
            u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:7.8pt; font-weight:600;">SRC:</span><span style=" font-size:7.8pt;"> {}</span></p>'.format(src)+
            u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">FICHERO GML SALIDA:</span></p>'+
            u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">   {}</p>'.format(gml_salida_file)

            )

        if src not in SRC_DICT:     # Comprueba que el SRC es correcto
            mess= u'ERROR: El código SRC ({}) indicado es incorrecto.'.format(src)
            mess+= u'\n ' + 'Los SRC permitidos son 25828, 25829, 25830 o 25831'
            self.fun.showJCCMessageERR( mess)
            # sys.exit()
            return
        

        with open(gml_salida_file, 'w') as filegml:
            filegml.writelines(PLANTILLA_1) # Añade el encabezamiento al GML

            nfeat = 0
            
            if self.chbELEMSELEC.isChecked():
                feats = layer.selectedFeatures()
                numfeats = layer.selectedFeatureCount()
                if numfeats == 0:
                    feats = layer.getFeatures()
                    numfeats = layer.featureCount()                 
            else:
                feats = layer.getFeatures()
                numfeats = layer.featureCount()

            campoNamespace = self.cbx_campoNMSPC.currentText()

            text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">LOCALID= {} - INI= {}</p>'.format(localid, ini_localid)
            text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">NAMESPACE= {}</p>'.format(campoNamespace)
            text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">TOTAL selec. {} de {} geometría(s).</p>'.format(numfeats, layer.featureCount())
            fracfeats = 0
            if localid.find('[') != -1:
                campoLocalid = localid[localid.find('[')+1:localid.find(']')]

            for feature in feats:
                numidf = self.fun.completarCeros(str(ini_localid),3)
                
                attrs = feature.attributes()
                valCampoLocalid = feature[campoLocalid]
                localidf = str(valCampoLocalid)

                valCampoNamespace = feature[campoNamespace]
                nmspcf = str(valCampoNamespace)
                if nmspcf != 'ES.SDGC.CP':
                    nmspcf = 'ES.LOCAL.CP'
                
                if localid.find('{NUM}')!=-1 and nmspcf == 'ES.LOCAL.CP':   # Solo se numeran las parcelas 'ES.LOCAL.CP'
                    localidf += '_{NUM}'.format(NUM=numidf)
                    
                if len(localidf) == 14 and nmspcf == 'ES.SDGC.CP':          # Se comprueba si la RC puede ser de 14 caracteres, incluso, si existe
                    pass
                else:                                                       # Si no es RC se asigna   nmspcf = 'ES.LOCAL.CP'
                    nmspcf = 'ES.LOCAL.CP'
                    ini_localid +=1
                # ini_localid +=1

                filegml.writelines(PLANTILLA_2.format(nmspc=nmspcf, localid=localidf)) # Añade el encabezamiento de cada Feature al GML

                geom = feature.geometry()
                
                if geom is None: continue           # Si es una geometría vacía, se continua
                
                area = geom.area()
                nfeat += 1
                text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">{} S= {:.4f} m2.</p>'.format(localidf, area)
                
                filegml.writelines(str(area))       # Añade el área al GML
                filegml.writelines(PLANTILLA_3.format(src=src,nmspc=nmspcf,localid=localidf)) # Añade la parte anterior a las coordenadas de cada feature al GML
                
                if geom.wkbType() == 3:
                    n = self.describe_polygon(feature, localidf, nmspcf, src, filegml)
                    
                elif geom.wkbType() == 6:
                    n = self.describe_multipolygon(feature, localidf, nmspcf, src, filegml)
                   
                prog = 100 * nfeat/numfeats
                self.progressBar.setValue(prog)

                text+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">--Vértices: {}</p>'.format(n)

                filegml.writelines(PLANTILLA_4.format(localidf=localidf,nmspc=nmspcf))     # Añade la parte posterior a las coordenadas de cada feature al GML
                fracfeats += 1/numfeats

            filegml.writelines(PLANTILLA_5)     # Añade el final al GML

        
        # Carga del GML en la TOC
        if self.chbCARGAGML.isChecked():
            ### --------------------------------------------------------------------------------------------------------------------------------------------
            ### --------------------------------------------------------------------------------------------------------------------------------------------
            ##      REVISAR NOMBRE DE CAPA
            # nomCAPA = localidf = localid.format(NUM='TODAS')
            ### --------------------------------------------------------------------------------------------------------------------------------------------
            ### --------------------------------------------------------------------------------------------------------------------------------------------
            #nomCAPA =  'FICHERO'
            crs = QgsCoordinateReferenceSystem(int(src),QgsCoordinateReferenceSystem.EpsgCrsId)
            layer = QgsVectorLayer(gml_salida_file, nomCAPA+"_GML" , 'ogr')
            layer.setCrs(crs,True)
            QgsProject.instance().addMapLayer(layer, False)
            root = QgsProject.instance().layerTreeRoot()   
            nombregrupo="PARCELAS CATASTRALES"
            grupoBUSCAT = root.findGroup(nombregrupo)
            if grupoBUSCAT is None:
                grupoBUSCAT = root.insertGroup(0, nombregrupo)
            grupoBUSCAT.insertChildNode(0, QgsLayerTreeLayer(layer)) 
            pass            
        self.close()


    def describe_polygon(self, feature_polygon, localidf, nmspclocalid, src, filegml):
        geometry_multipolygon = QgsGeometry.fromMultiPolygonXY([feature_polygon.geometry().asPolygon()])
        feature_multipolygon = QgsFeature()
        feature_multipolygon.setGeometry(geometry_multipolygon)
        n = self.describe_multipolygon(feature_multipolygon, localidf, nmspclocalid, src, filegml)
        return n
                
            
    def describe_multipolygon(self, feature_multipolygon, localidf, nmspclocalid, src, filegml):
        perimetro = feature_multipolygon.geometry()
        n=0
        poligon =0
        for polygon_1 in range(len(perimetro.asMultiPolygon())):
            poligon +=1
            filegml.writelines('''          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_'''+nmspclocalid+'.'+localidf+'" srsName="urn:ogc:def:crs:EPSG:'+src+'''">
              <gml:patches>
                <gml:PolygonPatch>''')
            # <gml:Surface gml:id="Surface_'''+nmspclocalid+'.'+localidf+'.'+"Polygon_%04d"%(polygon_1+1, )+'" srsName="urn:ogc:def:crs:EPSG'+src+'''">
            filegml.writelines('\n')
            ring=0  
            for ring_1 in range(len(perimetro.asMultiPolygon()[polygon_1])):
                ring +=1
                if ring_1==0:
                    filegml.writelines('''                  <gml:exterior>''')
                    filegml.writelines('\n')
                else:
                    filegml.writelines('''                  <gml:interior>''')
                    filegml.writelines('\n')
                points_number = len(perimetro.asMultiPolygon()[polygon_1][ring_1])
                filegml.writelines('''                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="'''+str(points_number)+'''">'''+'\n')
                for point_1 in range(points_number):
                    n+=1
                    filegml.writelines("{:.2f} {:.2f}".format(perimetro.asMultiPolygon()[polygon_1][ring_1][point_1].x(), perimetro.asMultiPolygon()[polygon_1][ring_1][point_1].y()))
                    if point_1 != points_number-1:
                        filegml.writelines(("   ")+'\n')
                filegml.writelines('''
                      </gml:posList>
                    </gml:LinearRing>
                  ''')
                if ring_1==0:
                    filegml.writelines('''</gml:exterior>''')
                    filegml.writelines('\n')
                else:
                    filegml.writelines('''</gml:interior>''')
                    filegml.writelines('\n')
            filegml.writelines('''                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>''')
            filegml.writelines('\n')
        return n
            
            
    '''       
    def get_ayudabutGENERAGML_text(self):
        text =self.tr(
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8.25pt; font-weight:600; text-decoration: underline;">AYUDA</span></p>'
            '<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8.25pt; font-weight:600; text-decoration: underline;"><br /></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:7.8pt; text-decoration: underline;">Generar GML desde un Fichero de poligonos</span></p>'
            '<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:7.8pt;"><br /></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:7.8pt;">Esta herramienta permite generar un GML conforme a las especificaciones de catastro de rustica, con vistas a remitirlo a traves de una VGA (Validacion Grafica Alternativa)</span></p>'
            '<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:7.8pt;"><br /></p>'
            '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:7.8pt;">Debe tener una capa de entrada, unos elementos seleccionados y se guarda una capa GML de salida.</span></p>'
            )
        return text
     '''               
