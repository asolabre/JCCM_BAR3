# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrCTRAS_controlCalidadGDB.py
                                 A QGIS plugin
 jcml_bar
                             -------------------
        begin                : 2019-02-14
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import QSettings, QCoreApplication, QTranslator, qVersion, Qt
from PyQt5.QtWidgets import QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox, QFileDialog
from PyQt5 import uic

from qgis.gui import QgsMessageBar
from qgis.core import QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication
from qgis.utils import iface
from qgis.PyQt.QtPrintSupport import QPrinter

import os
from osgeo import ogr, osr
import urllib
import json
from time import sleep
import glob, codecs
from functools import partial
import shutil
import datetime
import locale
import tempfile
import sys
import subprocess
import csv

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES

from .GDBDominios import GDBdominios

current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.environment["EPSG"]


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_controlCalidadGDB.ui'))


class herrCTRAS_controlCalidadGDB(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrCTRAS_controlCalidadGDB, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.logo.setPixmap(QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))
        
        self.fun = Functions()
        self.GDBDom = GDBdominios()
        self.current_configuration = configuration()
        self.Sett = Settings()
        global tipoUser
        
        # Comprobamos el rol del usuario
        userSIG, tipoUser = self.Sett.entrarUser()
        
        self.plugin_dir = os.path.dirname(__file__)
        # self.QgisVersion = QGis.QGIS_VERSION_INT
        self.QgisVersion = Qgis.QGIS_VERSION_INT


        # PDF print options
        self.maxLinesPerPage = 40
        self.maxAttributesBeforeSmallFontSize = 15
        self.orientation = QPrinter.Landscape
        self.pageSize = QPrinter.A4

        # CSS template file
        self.cssPath = os.path.join(
            self.plugin_dir,
            "templates/table.css"
        )

        self.gpbVista.setVisible(False)
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)    
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        self.btnSeleccionfich.clicked.connect(self.salida_file_click)
        # self.chbALLLAYERS.connect(self.chbALLLAYERS, SIGNAL("stateChanged(int)"), self.cambiatxeOUTFIELDS)
        self.buttonBoxOK.clicked.connect(self.catalogoGDB)
        self.strPrecision = "{:."+str(self.spnPRECISION.value())+"f}"
        
        # COMBOS DESPLEGABLES
        #  Combo Funcionalidad
        lista_Valores = self.fun.getValoresCampo('Funcionalidad','')
        valpredet = "Todo"
        ################################################################################
                                        ####    CONTROL   ####
        ################################################################################
        if tipoUser == 'ADMINISTRADOR':
            # valpredet = u'Básica'
            pass
        ################################################################################
                                        ####    CONTROL   ####
        ################################################################################
        self.cbxFuncionalidad.clear()
        if lista_Valores is not None:
            # self.cbxFuncionalidad.addItems('%')
            self.cbxFuncionalidad.addItem("Todo")
            self.cbxFuncionalidad.addItems(lista_Valores)
            if valpredet in lista_Valores:
                self.cbxFuncionalidad.setCurrentIndex(1+lista_Valores.index(valpredet))
            
        #  Combo Titularidad
        lista_Valores = self.fun.getValoresCampo('Titularidad','')
        valpredet = u'JCCM'
        self.cbxTitularidad.clear()
        if lista_Valores is not None:
            # self.cbxTitularidad.addItems('%')
            self.cbxTitularidad.addItem("Todo")
            self.cbxTitularidad.addItems(lista_Valores)
            if valpredet in lista_Valores:
                self.cbxTitularidad.setCurrentIndex(1+lista_Valores.index(valpredet))
                
        #  Combo Provincia
        lista_Valores = self.fun.getValoresCampo('Provincia','')
        valpredet = "Todo"
        ################################################################################
                                        ####    CONTROL   ####
        ################################################################################
        if tipoUser == 'ADMINISTRADOR':
            valpredet = u'Toledo'
        ################################################################################
                                        ####    CONTROL   ####
        ################################################################################
        self.cbxProvincia.clear()
        if lista_Valores is not None:
            # self.cbxProvincia.addItems('%')
            self.cbxProvincia.addItem("Todo")
            self.cbxProvincia.addItems(lista_Valores)
            if valpredet in lista_Valores:
                self.cbxProvincia.setCurrentIndex(1+lista_Valores.index(valpredet))
                
        if self.cbx_dominios.isChecked():
            listaCamposDOM = ['Titularidad','Funcionalidad','Tipologia_DobleC','Tipologia_UnaC','idOrdenCtra']
 
            # for varCampo in listaCamposDOM:
                # for dom in self.GDBDom.[varCampo]:
                    # print dom,
                # print   
            # for dom in self.GDBDom.Titularidad:
                # print dom,
            # print
            # for dom in self.GDBDom.Funcionalidad:
                # print dom,
            # print
            # for dom in self.GDBDom.Tipologia_DobleC:
                # print dom,
            # print
            # for dom in self.GDBDom.Tipologia_UnaC:
                # print dom,
            # print
            # for dom in self.GDBDom.idOrdenCtra:
                # print dom,' - ', self.GDBDom.idOrdenCtra[dom]
            # print
            
    def closeEvent(self, event):
        # print 'Pulsado X'
        QApplication.restoreOverrideCursor()
        
            
    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        # return text.encode('utf-8')
        return text.encode('ISO-8859-14')
        

    def salida_file_click(self):
        #print u"Fichero y directorio de salida"
        dirFile = os.path.dirname(self.lneFICHsalida.text())

        if fileTipe!= 'IMPRESORA':
            # filename = QFileDialog.getSaveFileName(self, "Fichero GML de salida", "", "*."+fileTipe)
            filename = QFileDialog.getSaveFileName(self, "Fichero GML de salida", dirFile, "*.csv")
            if filename != None and filename != "":
                # self.lneFICHsalida.setText(filename)
                self.lneFICHsalida.setText(filename[0])

            
    def catalogoGDB(self):
        fileTipe = self.cbxTipoExport.currentText()
        if fileTipe == 'IMPRESORA':
            fileTipe = 'printer'
        if fileTipe == u'Solo CSV':
            fileTipe = 'csv'
        
        valcbxTitularidad = self.cbxTitularidad.currentText()
        valcbxFuncionalidad = self.cbxFuncionalidad.currentText()
        valcbxProvincia = self.cbxProvincia.currentText()
        if valcbxTitularidad == "Todo":
            valcbxTitularidad = '%'
        if valcbxFuncionalidad == "Todo":
            valcbxFuncionalidad = '%'
        if valcbxProvincia == "Todo":
            valcbxProvincia = '%'
            
        whereTXT = '('  
        whereTXT+= ' Titularidad LIKE '+"'"+valcbxTitularidad+"'"
        whereTXT+= ' AND Funcionalidad LIKE '+"'"+valcbxFuncionalidad+"'"
        whereTXT+= ' AND Provincia LIKE '+"'"+valcbxProvincia+"')"
        # whereTXT+= ' AND Matricula LIKE '+"'"+self.cbxMatricula.currentText()+"'"
        
        if self.chbMATR9000.isChecked():
            whereTXT+= ' AND Matricula <>'+ "'9000'"

        # COMPROBACIÓN DE CONTROLES PARA AÑADIR CAMPOS CONTROL
        self.listCamposCTRL = []
        chkDominios = False
        if self.cbx_idmatricula.isChecked():
            self.listCamposCTRL.append('idMatr')
        if self.cbx_calibracion.isChecked():
            self.listCamposCTRL.append('calib_sentido')
        if self.cbx_longPks.isChecked():
            self.listCamposCTRL.append('long_PI_PF_KM')
        if self.cbx_dominios.isChecked():
            chkDominios = True
            # self.listCamposCTRL.append('long_PI_PF_KM')
            pass
            
        
            
        # CAMPOS A PONER EN ENCABEZAMIENTOS
        outfields = '*'
        self.listCamposCOMP = ['OBJECTID', 'idMatricula','Matricula','Longitud','PkINI','PkFin','Matricula_Plan',
            'Titularidad','Funcionalidad','Tipologia_DobleC','Tipologia_UnaC','Denominacion',
            'Long_Km','idOrdenCtra','Origen','Destino','Provincia','Shape.STLength()']
            
        self.listCampos = ['OBJECTID', 'Matricula', 'idMatricula', 'Funcionalidad','Provincia', 'Origen', 'Destino','Longitud','PkINI','PkFin','Long_Km']
        self.listCamposCOMP += self.listCamposCTRL
        if chkDominios == True:
            self.listCampos+=['Tipologia_DobleC','Tipologia_UnaC','idOrdenCtra']
            
        self.listCampos += self.listCamposCTRL
            
        self.listCamposOrder = ['Titularidad', 'idOrdenCtra', 'Funcionalidad', 'Matricula', 'PkINI', 'Provincia']

        
        # Comprobamos CAMPOS INCLUIDOS en la salida
        listBorrar = []
        for campo in self.listCampos:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCampos.remove(campo)


        # Comprobamos CAMPOS INCLUIDOS en la lista de orden de campos
        listBorrar = []
        for campo in self.listCamposOrder:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCamposOrder.remove(campo)
        orderByFields = ",".join(self.listCamposOrder)
            
        self.lblINFO.setText('INFO: Leyendo url .....')
        
        TipoExport = self.cbxTipoExport.currentText()

        
        # QUERY AL WFS Plan_Carreteras_BTA_WFS -- PARCIAL --
        url = self.current_configuration.environment["rest_carreteras"]
        
        values = {'where' : whereTXT,
                  'text': '',
                  'objectIds': '',
                  # 'geometryType' : 'esriGeometryPolyline',
                  'returnGeometry' : False,
                  'returnM': False,
                  'outFields': outfields,
                  'orderByFields' : orderByFields,
                  'f': 'json'}
        
        restfeatures = self.fun.getFeaturesBTAcalibrada(values)
        
        # str_values = {}
        # for k, v in values.items():
            # str_values[k] = unicode(v).encode('utf-8')
        # data = urllib.urlencode(str_values)
        # self.tbrURLCOMPLETA.setHtml(self.creaHTML(url+data))
        
        # print url+data
        # restfeatures = self.fun.getFeaturesBTAcalibrada(values)
        # print restfeatures
       
        numfeats = len(restfeatures)
        nfeat = 0
        if numfeats==0:
            # self.fun.showJCCMessage(u"Error de conexión a internet (catalogoGDB LIN:349")
            return

        # FICHEROS Y CAPAS
        fich_csv = self.lneFICHsalida.text()
        # Comprobamos que existe el directorio y si no se crea
        dirCsv,nameFichCsv = os.path.split(fich_csv)
        # print dirCsv
        if not os.path.exists(dirCsv):
            os.makedirs(dirCsv)
        fich = self.lneFICHsalida.text().replace('csv', fileTipe)
        
        QgsMessageLog.logMessage( "Creando archivo de log","jccm_bar")
        
        # ESCRIBIMOS ENCABEZADOS FICHERO 'CSV'
        target  = codecs.open(fich_csv, 'w+',encoding='utf-8')
        encabezado = ''
        for campo in self.listCamposCOMP:
            encabezado += campo + u';'
        
        
        target.write(encabezado)
        target.write("\n")
        
        # ESCRIBIMOS LISTA DE DATOS
        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        countFeat = 0

        for feat in restfeatures:
            attributes = feat["attributes"]
            datErr = False
            # COMPROBAMOS DOBLE VIA
            grabar = True
            if not self.chbDOBLEVIA.isChecked():
                if attributes['Tipologia_DobleC'] == 'ATV' or attributes['Tipologia_DobleC'] == 'ATP':
                    ctraCalzada = attributes['Matricula_Plan'].split(u' ')
                    if len(ctraCalzada)>1:
                        if attributes['Matricula_Plan'].split(u' ')[1] == 'D' or attributes['Matricula_Plan'].split(u' ')[1] == 'd':
                            grabar = False
                        pass

            
            if grabar:  # En caso de DOBLE VIA desmarcado, solo grabamos CALZADA D
                datos = u''
                for attr in self.listCamposCOMP:
                    if attr not in self.listCamposCTRL:
                        dat = u''
                        if isinstance(attributes[attr], str):
                            dat = attributes[attr]
                        elif isinstance(attributes[attr], unicode):
                            dat = attributes[attr]
                        elif isinstance(attributes[attr], int):
                            dat = str(attributes[attr])
                        elif isinstance(attributes[attr], float):
                            # print attr, attributes[attr], 'float', ("{:.3f}".format(attributes[attr]))
                            dat = (self.strPrecision.format(attributes[attr]))
                            # self.strPrecision = "{:.3f}"

                        # --- SE REALIZA EL CONTROL DE DOMINIOS ---
                        if self.cbx_dominios.isChecked():
                            if attr == 'Titularidad':
                                if dat not in self.GDBDom.Titularidad:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Funcionalidad':
                                if dat not in self.GDBDom.Funcionalidad:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Tipologia_DobleC':
                                if dat not in self.GDBDom.Tipologia_DobleC:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Tipologia_UnaC':
                                if dat not in self.GDBDom.Tipologia_UnaC:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Provincia':
                                if dat not in self.GDBDom.Provincia:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'idOrdenCtra':
                                # Comprobamos la concordancia entre 'Funcionalidad' e 'idOrdenCtra'
                                dataFunc = attributes['Funcionalidad']
                                if dataFunc != self.GDBDom.idOrdenCtra[dat]:
                                    dat = '(x) '+dat
                                    datErr = True
                                    
                        datos += (dat + u';')


                # --- SE REALIZA EL CONTROL DE DATOS ---
                if self.cbx_idmatricula.isChecked():
                    idMatBusq = attributes['idMatricula']
                    result = self.ControlAtributos(idMatBusq)
                    if result != 'OK':
                        datErr = True
                    datos += result + u';'
                
                if self.cbx_calibracion.isChecked() or self.cbx_longPks.isChecked():
                    objIdBusq = attributes['OBJECTID']
                    result = self.ControlGeometrico(objIdBusq)
                    for resp in result:
                        if resp!='OK':
                            datErr = True
                    if self.cbx_calibracion.isChecked():
                        datos += result[0] + u';'
                    if self.cbx_longPks.isChecked():
                        datos += result[1] + u';'
                
                '''
                for campoCTRL in self.listCamposCTRL:
                    if campoCTRL == 'idMatr':
                    idMatBusq = attributes['idMatricula']
                    result = self.Control_idMatr(idMatBusq)
                    if result != 'OK':
                        datErr = True
                        
                    if campoCTRL == 'calib_sentido':
                        objIdBusq = attributes['OBJECTID']
                        result = self.Control_calibr(objIdBusq)
                        if result != 'OK':
                            datErr = True
                        
                    if campoCTRL == 'long_PI_PF_KM':
                        objIdBusq = attributes['OBJECTID']
                        result = self.Control_longPks(objIdBusq)
                        if result != 'OK':
                            datErr = True
                   
                    datos += result + u';'
                '''    

        ################################################################################
                                        ####    CONTROL   ####
        ################################################################################
        # --- AÑADIENDO LINEA AL FICHERO ---
                if datErr == True or self.chbTODOSELEMEN.isChecked():
                    # print datos
                    target.write(datos)
                    target.write("\n")
                nfeat +=1
                prog = 50 * nfeat/numfeats
                self.progressBar.setValue(prog)
                self.lblINFO.setText(u'INFO: Añadiendo a CSV registro ' + str(nfeat) +'/' +str(numfeats))
        ################################################################################
                                        ####    CONTROL   ####
        ################################################################################            
        target.close()
        
        fich_csv_uri = u"file:///"+ fich_csv +"?type=csv&geomType=none&subsetIndex=no&delimiter=%s&watchFile=no" % (";")
        #print fich_csv_uri
        
        abstract = ''
        if self.cbxTitularidad.currentText() != '%':
                    abstract += u'Titularidad - %s / '%self.cbxTitularidad.currentText()
        if self.cbxFuncionalidad.currentText() != '%':
                    abstract += u'Funcionalidad - %s / '%self.cbxFuncionalidad.currentText()
        if self.cbxProvincia.currentText() != '%':
                    abstract += u'Provincia - %s / '%self.cbxProvincia.currentText()

        # Esto crea la capa CSV
        #   Si existe la capa se debe borrar
        nomcapa = u'CATALOGO CARRETERAS CTRL'
        csv_lyrLIST = QgsProject.instance().mapLayersByName(nomcapa)
        if len(csv_lyrLIST) >0:
            for csv_lyr in csv_lyrLIST:
                QgsProject.instance().removeMapLayer(csv_lyr.id())
        csv_lyr = QgsVectorLayer(fich_csv_uri, nomcapa,'delimitedtext')
        # csv_lyr.setAbstract (abstract)
        QgsProject.instance().addMapLayer(csv_lyr, False)

        # Colocamos la capa arriba del todo
        root = QgsProject.instance().layerTreeRoot()
        root.insertLayer(0, csv_lyr)
        self.iface.setActiveLayer(csv_lyr)

       
        self.tbrURLCOMPLETA.setHtml(self.creaHTML(''))
        pass
        
        self.exportLayer(fileTipe, fich)
        
        # Abrir el fichero resultante
        if os.path.exists(self.exportedFile):
            os.startfile(self.exportedFile)
        else:
            self.iface.messageBar().pushMessage('Parece que no se ha creado el fichero ' +self.exportedFile, u'JCCM Carreteras', QgsMessageBar.WARNING, 5)

        self.lblINFO.setText('INFO:')
        self.progressBar.setValue(0)
        self.close

        
    def ControlAtributos(self,idMatBusq):
        # QUERY AL WFS Plan_Carreteras_BTA_WFS para contar elementos con el 'idMatBusq'
        url = self.current_configuration.environment["rest_carreteras"]
        values = {
                  'where' : ' idMatricula = '+str(idMatBusq),
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': True,
                  'f': 'json'}
        # print url+data

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        self.tbrURLCOMPLETA.setHtml(self.creaHTML(url+data))
        # print url+data
        respuesta = self.fun.getFeaturesBTAcalibradaCount(values)
        if respuesta['count'] > 1:
            return str(respuesta['count'])
        else:
            return 'OK'
        pass
          

    def ControlGeometrico(self, objIdBusq):
        # CONTROL GEOMETRICO TODO EN UNO
        # QUERY AL WFS Plan_Carreteras_BTA_WFS para obtener la geometría'
        url = self.current_configuration.environment["rest_carreteras"]
        values = {
                  'where' : ' OBJECTID = '+str(objIdBusq),
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': False,
                  'outFields': '*',
                  'returnGeometry' : 'true',
                  'returnM': 'true' ,
                  'f': 'json'}
                  
        # print (url+data)
        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        # data = urllib.urlencode(str_values)
        data = urllib.parse.urlencode(str_values)
        # req = urllib2.Request(url, data)
        req = urllib.request.urlopen(url+data)
        
        try:
            response = json.load(urllib.request.urlopen(url+data))
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.showJCCMessageERR(result,text2="",tittle="JCCM - Error de código",)
            return

        features =  response["features"]    # Los distintos features encontrados en la búsqueda
        # print (features)

        ####################################
        ##      CONTROL CALIBRACIÓN       ##
        ####################################
        datResult = 'F:'+str(len(features))
        FaltaM = False
        Sentido = 'D'
        Inversion = False
        ctrlCalib = 'OK'
        ctrlCalib1= ''
        #########################################
        ##  CONTROL LONG,PKINI,PKFIN,LONGPK    ##
        #########################################
        longMal = False
        PKiniMal = False
        PKfinMal = False
        longKMMal = False
        ctrlLongPks = 'OK'
        ctrlLongPks1= ''            

        for feature in features:
            geometry = feature["geometry"]
            attributes =  feature["attributes"]

            ####################################
            ##      CONTROL CALIBRACIÓN       ##
            ####################################
            if self.cbx_calibracion.isChecked():
                datResult += ' P:'+str(len(geometry["paths"]))
                Mant = geometry["paths"][0][0][2]
                if Mant is None:
                    FaltaM = True
                else:
                    for path in geometry["paths"]:
                        # print '  Numero Puntos: ', len(path)
                        datResult += ' O:'+str(len(path))
                        for point in path:
                            if type(point[2]) == int or type(point[2]) == float:                        
                                if (point[2]<Mant) and (Inversion == False):
                                    Inversion == True
                                elif point[2]<Mant:
                                    Sentido='I'
                                Mant = point[2]
                            else:
                                FaltaM = True
                        
                if abs(attributes['Longitud']-attributes['Shape.STLength()'])>0.01:
                    longMal = True
                    Longitud = attributes['Shape.STLength()']
                    pass

            #########################################
            ##  CONTROL LONG,PKINI,PKFIN,LONGPK    ##
            #########################################
            if self.cbx_longPks.isChecked():
                PKinimin = 999999
                PKfinmax = 0
                for path in geometry["paths"]:
                    # datResult += ' O:'+str(len(path))
                    for point in path:
                        if point[2] is not None:
                            if point[2]<PKinimin:
                                PKinimin=point[2]
                            if point[2]>PKfinmax:
                                PKfinmax=point[2]
                if attributes['PkINI'] is not None:
                    if abs(PKinimin - attributes['PkINI'])>0.001:    
                        PKiniMal = True
                else:
                    PKiniMal = True
                    
                if attributes['PkFin'] is not None:
                    if abs(PKfinmax-attributes['PkFin'])>0.001:    
                        PKfinMal = True
                else:
                    PKfinMal = True
                    
                LongKMCalc=PKfinmax-PKinimin
                if attributes['Long_Km'] is not None:
                    if abs(LongKMCalc-attributes['Long_Km'])>0.001:    
                        longKMMal = True
                else:
                    longKMMal = True
                    
        ####################################
        ##      CONTROL CALIBRACIÓN       ##
        ####################################
        if FaltaM == True:
            ctrlCalib1 = 'FaltaM/'
        else:
            ctrlCalib1 = '-/'
        if Sentido == 'I':
            ctrlCalib1 += 'SenInv/'
        else:
            ctrlCalib1 += '-/'
        if Inversion == True:
            ctrlCalib1 += 'Inversion'
        else:
            ctrlCalib1 += '-'
        if ctrlCalib1 != '-/-/-':
            ctrlCalib = ctrlCalib1
            
        #########################################
        ##  CONTROL LONG,PKINI,PKFIN,LONGPK    ##
        #########################################
        if longMal == True:
            ctrlLongPks1 = "{:.3f}".format(Longitud)+'/'
            #"{:.3f}".format(Longitud)
        else:
            ctrlLongPks1 = '-/'
        if PKiniMal == True:
            ctrlLongPks1 += "{:.3f}".format(PKinimin)+'/'
        else:
            ctrlLongPks1 += '-/'
        if PKfinMal == True:
            ctrlLongPks1 += "{:.3f}".format(PKfinmax)+'/'
        else:
            ctrlLongPks1 += '-/'
        if longKMMal == True:
            ctrlLongPks1 += "{:.3f}".format(LongKMCalc)
        else:
            ctrlLongPks1 += '-'
        if ctrlLongPks1 != '-/-/-/-':
            ctrlLongPks = ctrlLongPks1

        return ctrlCalib, ctrlLongPks

        ########################################################################
        ##                  FINAL  CONTROL  CALIDAD                           ##
        ########################################################################
    
            
    def exportLayer(self, etype='csv', fich=''):
        # Se exporta la tabla de atributos de la tabla seleccionada al tipo de fichero elegido

        # Establece propiedades del tipo de salida
        self.etype = etype
        self.exportHiddenAttributes = False
        self.csvDelimiter = '\t'
        
        # Cojemos la capa activa
        layer = self.iface.activeLayer()
        msg= None

        # Comprobamos si la capa es valida para exportar
        if layer and layer.type() == QgsMapLayer.VectorLayer and hasattr(layer, 'providerType'):

            # Se acude al método adecuado según el tipo seleccionado
            if etype != 'printer':
               
                ePath = fich
                self.exportedFile = fich

                if etype == 'csv':
                    self.lblINFO.setText(u'INFO: Capa CSV exportada adecuadamente')
                    msg = u'La capa ha sido cargada adecuadamente.'
                    status = 'info'
                    
                elif etype == 'html':
                    self.lblINFO.setText(u'INFO: Exportando datos de CSV a HTML ')
                    msg, status = self.exportLayerToHtml(layer, fich, False, 'html')
                    
                elif etype == 'pdf':
                    self.lblINFO.setText(u'INFO: Exportando datos de CSV a PDF ')
                    msg, status = self.exportLayerToPdf(layer)

            else:
                msg, status = self.exportLayerToPdf(layer, True)

        else:
            self.lblINFO.setText(u'INFO: Falta seleccionar una capa vectorial')
            msg = u'Selecciona primero una capa vectorial'
            status = 'warning'

            
    def exportLayerToHtml(self, layer, ePath=None, cutPages=False, etype=None):
        '''
        Exporta la capa a HTML
        usando una plantilla y leyendo los datos
        desde la capa seleccionada
        '''
        self.lblINFO.setText(u'INFO: Exportando datos de CSV a HTML ')
        
        # VALORES ENCABEZADOS
        title = u'CATÁLOGO DE CARRETERAS - CONTROL DE CALIDAD'

        campoGrupo = u'Funcionalidad'
        campoGrupo1 = u'Titularidad'

        campoSumaGrupo = u'Long_Km'
        udSuma = u'Km'

        # DEFINICIONES DE REDES (Funcionalidad)
        listaTitulos = [
            {'Grupo' : u'Autopistas Peaje', 'Titulo' : u'RED ESTATALES - Autopistas Peaje', 'Color' : u'rgb(90, 110, 255)'},
            {'Grupo' : u'Autopistas', 'Titulo' : u'RED ESTATALES - Autopistas', 'Color' : u'rgb(90, 110, 255)'},
            {'Grupo' : u'Convencionales', 'Titulo' : u'RED ESTATALES - Convencionales', 'Color' : u'rgb(255, 90, 90)'},
            {'Grupo' : u'Básica alta capacidad', 'Titulo' : u'RED REGIONAL - BÁSICA ALTA CAPACIDAD', 'Color' : u'rgb(255, 115, 223)'},
            {'Grupo' : u'Básica', 'Titulo' : u'RED REGIONAL - BÁSICA', 'Color' : u'rgb(255, 170, 0)'},
            {'Grupo' : u'Comarcal', 'Titulo' : u'RED REGIONAL - COMARCAL', 'Color' : u'rgb(85, 255, 0)'},
            {'Grupo' : u'Local', 'Titulo' : u'RED REGIONAL - LOCAL', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Travesía', 'Titulo' : u'RED REGIONAL - TRAVESÍAS (RED LOCAL)', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Ramal', 'Titulo' : u'RED REGIONAL - RAMALES (RED LOCAL)', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Enlace', 'Titulo' : u'RED REGIONAL - ENLACES', 'Color' : u'rgb(200, 200, 200)'},
            {'Grupo' : u'Diputación', 'Titulo' : u'RED DIPUTACIÓN PROVINCIAL', 'Color' : u'rgb(254, 254, 254)'}
            ]
        
        QApplication.setOverrideCursor(Qt.WaitCursor)

        # Leemos el fichero de plantilla
        tplPath = os.path.join(
            self.plugin_dir,
            "templates/htmlTemplate.tpl"
        )
        fin = open(tplPath)
        # data = fin.read().decode('utf-8')
        data = fin.read()
        fin.close()

        # Se obtienen los datos de la capa
        layerData, nb = self.getLayerData(layer)
        
        # Obtenemos los tipos de cada campo
        fields = layer.fields()
        tipoCampos = []
        for field in fields:
            tipoCampos.append(field.typeName())

            
        # Nombres de campos de la capa
        fieldNames = layerData[0]
        nbAttr = len(fieldNames)
        numcampoGrupo = fieldNames.index(campoGrupo )
        numcampoGrupo1 = fieldNames.index(campoGrupo1)
        numcampoSumaGrupo = fieldNames.index(campoSumaGrupo )
        
        # Calculamos posiciones de los campos a listar
        numColumnas = u'"'+str(len(self.listCampos))+u'"'
        numColumnasDat  = u'"'+str(len(self.listCampos)-len(self.listCamposCTRL))+u'"'
        numColumnasCtrl = u'"'+str(len(self.listCamposCTRL))+u'"'
        poslistCampos = []
        poslistCamposCTRL = []
        for campo in self.listCampos:
            poslistCampos.append(self.listCamposCOMP.index(campo))
        for campo in self.listCamposCTRL:
            poslistCamposCTRL.append(self.listCamposCOMP.index(campo))
   
        
        # Creamos el contenido de 'tbody' con los datos de atributos de los elementos
        valcampoGrupo = ''
        tbody = ''
        i = 6 # num lineas
        page = 1
        totalGrup = 0
        totalGlobal = 0
        table = 0
        attrValues = layerData[1:]
        

        # Escribir la tabla de contenido como HTML
        for values in attrValues:
            prog = 50 +50 * attrValues.index(values)/len(attrValues)
            self.progressBar.setValue(prog)
            self.lblINFO.setText(u'INFO: Añadiendo a -'+etype+'- registro ' + str(attrValues.index(values)) +'/' +str(len(attrValues)))
            
            valorTestigo = values[numcampoGrupo]
            if valorTestigo == u'Básica alta capacidad' and values[numcampoGrupo1] == 'Estatal':
                valorTestigo = u'Autopistas'
            if valorTestigo == u'Básica' and values[numcampoGrupo1] == 'Estatal':
                valorTestigo = u'Convencionales'
            if values[numcampoGrupo1] == u'Diputación':
                valorTestigo = u'Diputación'

            if valorTestigo != valcampoGrupo:
                if table != 0:
                    # tbody+='            </tbody>\n'
                    # tbody+='        </table>\n'
                    totalGlobal += totalGrup
                    totalGrup = 0
                    i += 2
                thead = ''
                if table == 0:
                    thead+='        <table>\n'
                    thead+='            <tbody>\n'
                table+=1
                # valcampoGrupo = values[numcampoGrupo]
                valcampoGrupo = valorTestigo
                tituloGrupo = ''
                colBck = 'rgb(200, 200, 200)'
                colBlanco = 'rgb(250, 250, 250)'
                colError = 'rgb(255, 150, 150)'
                for dataGrupos in listaTitulos:
                    if dataGrupos['Grupo'] == valcampoGrupo:
                        tituloGrupo = dataGrupos['Titulo']
                        colBck = dataGrupos["Color"]
                thead+='                <tr>\n'
                thead+='                    <th colspan=%s align="left" style="background: %s">%s</th>\n'%(numColumnasDat, colBck, tituloGrupo)
                thead+='                    <th colspan=%s align="left" style="background: %s">%s</th>\n'%(numColumnasCtrl, colBlanco, 'CONTROL')
                thead+='                </tr>\n\n'
                thead+='                <tr>\n'
                i += 3

                # GENERAR ENCABEZADO DE CADA GRUPO DE DATOS
                for field in self.listCampos:
                    if self.listCampos.index(field)<(len(self.listCampos)-len(self.listCamposCTRL)):
                        thead+= '                    <th style="background: %s">%s</th>\n' %(colBck, field)
                    else:
                        thead+= '                    <th style="background: %s">%s</th>\n' %(colBlanco, field)
                    
                thead+= '                </tr>\n\n'
                tbody+= thead
                
            # Se crea la lista de valores de cada registro           
            valuesLista = []
            tbody+= '                <tr>\n'
            for pos in poslistCampos:
                # Caso de que se trate de datos del CONTROL DE CALIDAD
                if pos in poslistCamposCTRL:
                    valueTD = values[pos]
                    if valueTD == 'OK':
                        tbody+= '                    <td align="left">' + valueTD + '</td>\n'
                    else:
                        tbody+= '                    <td align="left" style="background: %s">%s</td>\n'%(colError,valueTD)
                
                else:
                # Caso de que se trate de datos NORMALES
                    if tipoCampos[pos] == 'integer':
                        try:
                            valueTD = "{:.0f}".format(float(values[pos]))
                            tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                        except:
                            valueTD = valueTD = values[pos]
                    elif tipoCampos[pos] == 'double':
                        try:
                            valueTD = "{:.3f}".format(float(values[pos]))
                            tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                        except:
                            valueTD = valueTD = values[pos]
                    else:
                        valueTD = values[pos]
                        if valueTD[:3] != '(x)':
                            tbody+= '                    <td align="left">' + valueTD + '</td>\n'
                        else:
                            tbody+= '                    <td align="left" style="background: %s">%s</td>\n'%(colError,valueTD)

            tbody+= '                    </td>\n'
            tbody+= '                </tr>\n\n'


            
            try:
                totalGrup += float(values[numcampoSumaGrupo])

            except:
                pass
            i+=1
            if i == self.maxLinesPerPage and cutPages and self.QgisVersion > 10900:
                i = 3
                tbody+= '</table>\n\n'
                tbody+= '<span>Page %s</span>' % page
                # tbody+= '<div style="page-break-after:always;border: 0px solid white;"></div>\n'
                tbody+= '<div class="saltopagina"></div>\n\n'
                tbody+= '<table><thead>' + thead + '</thead><tbody>'
                page+=1

                
        # LÍNEAS FINALES
        totalGlobal += totalGrup
        tbody+='            </tbody>\n'
        tbody+='        </table>\n'
        
        # Get creation date
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x %X"
        today = datetime.datetime.today()
        date = today.strftime(date_format)
        dt_date = u'JCCM. Dirección General de Carreteras '

        # Icono, Titulo, Resumen, número de Carreteras
        fileIcono = u'python/plugins/jccm_bar3/iconos/jccm.jpg'
        dirPYTJCCM = QgsApplication.qgisSettingsDirPath()
        fileIcono = os.path.normpath(os.path.join(os.path.dirname(dirPYTJCCM), fileIcono))
        dt_icono = '<img src="%s" border="0" width="100" height="80">'%fileIcono
        dt_title = u''
        dt_abstract = u'Datos'
        dt_info = u'Información'
        # abstract = layer.abstract() and str(layer.abstract()) or '-'
        abstract = layer.abstract()
        info = u'TOTAL %s Carreteras - %s Km'%(format(str(nb)), format(totalGlobal)) 
        
        # tbody1 = ListaIndices()

        # Adapt style if needed
        style = ''
        # Get CSS style from table.css
        with open(self.cssPath, 'r') as content_file:
            style = content_file.read()
        if nbAttr > self.maxAttributesBeforeSmallFontSize:
            # style+= 'th, td {font-size:x-small;}'
            style+= 'th, td {font-size:10px;}'

        # Replace values
        data = data.replace('$icono', dt_icono)
        data = data.replace('$dt_title', dt_title)
        data = data.replace('$title', title)
        data = data.replace('$dt_abstract', dt_abstract)
        data = data.replace('$abstract', abstract)
        data = data.replace('$dt_info', dt_info)
        data = data.replace('$info', info)
        data = data.replace('$tbody', tbody)
        # data = data.replace('$tbody1', tbody1)
        data = data.replace('$dt_date', dt_date)
        data = data.replace('$date', date)
        data = data.replace('$style', style)
        data = data.replace('$totalPages', "Pag. %s" % page)

        # File path
        if not ePath:
            ePath = self.exportedFile

        try:
            # write html content
            f = open(ePath, 'w')
            # f.write(data.encode('utf-8'))
            f.write(data)
            f.close()

        # except IOError, e:
        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación')
            status = 'critical'
        finally:
            msg = QApplication.translate("quickExport", u'La capa ha sido adecuadamente exportada')
            status = 'info'

        QApplication.restoreOverrideCursor()

        return msg, status


    def ListaIndices(self):
        numColumnas = 4
        colBck = 'rgb(200, 200, 200)'
        tituloGrupo= u'Lista de CÓDIGOS'
        tbody1+='                <tr>\n'
        tbody1+='                    <th colspan=%s align="left" style="background: %s">%s</th>\n'%(numColumnasDat, colBck, tituloGrupo)
        tbody1+='                </tr>\n\n'
        return tbody1
        pass
        
        
    def exportLayerToPdf(self, layer, doPrint=False):
        '''
        Exports the layer to PDF
        First export to HTML then convert to PDF.
        If not output file given, send directly to the printer
        '''

        # Create temporary file path
        temp = tempfile.NamedTemporaryFile()
        try:
            # Create temporary HTML file
            tPath = "%s.html" % temp.name
            
            msg, status = self.exportLayerToHtml(layer, tPath, True, 'pdf')

            # Create a web view and fill it with the html file content
            web = QWebView()
            web.load(QUrl(tPath))

            # Print only when HTML content is loaded
            def printIt():
                #~ web.show()
                # Open the printer dialog if needed
                if doPrint:
                    dialog = QPrintDialog()
                    if dialog.exec_() == QDialog.Accepted:
                        printer = dialog.printer()
                    else:
                        return
                # No print, only PDF export
                else:
                    # Set page options for PDF
                    printer = QPrinter()
                    printer.setPageSize(self.pageSize)
                    printer.setOrientation(self.orientation)
                    printer.setFontEmbeddingEnabled(True)
                    printer.setColorMode(QPrinter.Color)
                    # set output file name in case of PDF export
                    printer.setOutputFileName(self.exportedFile)

                # Set some metadata
                printer.setCreator(u"QGIS - Complemento JCCM Carreteras")
                printer.setDocName(u"Exportado - %s" % layer.title() and layer.title() or layer.name())

                # Print
                web.print_(printer)

                # Try to remove temporary html file created before
                # try:
                    # os.remove(tPath)
                # except OSError, e:
                    # print "Error al borrar el fichero temporal: %s)" % tPath

            # Only print when the HTML content has been loaded in the QWebView
            web.loadFinished[bool].connect(printIt)

        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'critical'
        finally:
            # Automatically cleans up the file
            temp.close()
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'info'
            
        return msg, status

        
        
        
    def getLayerData(self, layer):
        '''
        Get fields and data from
        a vector layer
        '''
        data = []

        # Get layer fields names
        fields = layer.fields()
        if self.QgisVersion > 10900:
            fieldNames = [
                field.name() for i, field in enumerate(fields)
                # if layer.editType(i) != QgsVectorLayer.Hidden
                # or self.exportHiddenAttributes
            ]
        else:
            fieldNames = [
                str(fields[i].name()) for i in fields
                # if layer.editType(i) != QgsVectorLayer.Hidden
                # or self.exportHiddenAttributes
            ]
        data.append(fieldNames)

        # Get selected features or all features
        if layer.selectedFeatureCount():
            nb = layer.selectedFeatureCount()
        else:
            nb = layer.featureCount()



        # Get layer fields data

        # QGIS >= 2.0
        if self.QgisVersion > 10900:
            if layer.selectedFeatureCount():
                features = layer.selectedFeatures()
            else:
                features = layer.getFeatures()
            for feat in features:
                # Get attribute data
                values = [
                    self.displayAttributeValue(a) for i, a in enumerate(feat.attributes())
                    # if layer.editType(i) != QgsVectorLayer.Hidden
                    # or self.exportHiddenAttributes
                ]
                data.append(values)

        # QGIS 1.8
        else:
            provider = layer.dataProvider()
            allAttrs = provider.attributeIndexes()
            provider.select(allAttrs, QgsRectangle(), False)
            layer.select(allAttrs, QgsRectangle(), False)
            if layer.selectedFeatureCount():
                items = layer.selectedFeatures()
            else:
                items = layer
            for feat in items:
                attrs = feat.attributeMap()
                values = [
                    self.displayAttributeValue(v) for k,v in attrs.items()
                    # if layer.editType(k) != QgsVectorLayer.Hidden
                    # or self.exportHiddenAttributes
                ]
                data.append(values)

        return data, nb
       

    def displayAttributeValue(self, value):
        '''
        Convert QGIS attribute data into readable values
        '''
        # QGIS version
        isQgis2 = self.QgisVersion > 10900

        # Get locale date representation
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_FMT)
            datetime_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x"
            datetime_format = "%x %X"

        # Convert value depending of type
        if hasattr(value, 'toPyDate'):
            output = value.toPyDate().strftime(date_format)
        elif hasattr(value, 'toPyDateTime'):
            output = value.toPyDateTime().strftime(datetime_format)
        else:
            output = u"%s" % value if isQgis2 else u"%s" % value.toString()

        return output

       
    '''
    def chooseExportFilePath(self, etype='csv', fich=''):
        # Method to allow the user to choose a file path
        # to store the exported attribute table

        msg = ''
        status = 'info'
        abort = False

        # Get data corresponding to chosen file type
        etypeDic = {
            'csv': {'fileType': 'CSV (*.csv *.txt)', 'lastFileSetting': 'lastExportedCsvFile'},
            'html': {'fileType': 'HTML (*.html *.htm)', 'lastFileSetting': 'lastExportedHtmlFile'},
            'pdf': {'fileType': 'PDF (*.pdf)', 'lastFileSetting': 'lastExportedPdfFile'}
        }

        # Get last exported file path
        s = QSettings()
        lastFile = s.value(
            "quickExport/%s" % etypeDic[etype]['lastFileSetting'],
            '',
            type=str
        )

        # Let the user choose new file path
        if fich == '':
            ePath = QFileDialog.getSaveFileName (
                None,
                QApplication.translate("JCCM Carreteras", "Elige el fichero de destino"),
                lastFile,
                etypeDic[etype]['fileType']
                )
        else:
            ePath = fich

        if not ePath and self.hasMessageBar:
            msg = QApplication.translate("JCCM Carreterast", "Exportación cancelada")
            status = 'info'
            abort = True
            return msg, status, abort, ePath

        # Delete file if exists (question already asked above)
        if os.path.exists(unicode(ePath)):
            try:
                os.remove(unicode(ePath))
            except OSError, e:
                msg = QApplication.translate("quickExport", "El fichero no se puede borrar")
                if sys.platform == "win32":
                    # it seems the return error is not unicode in windows !
                    errorMsg = e.strerror.decode('mbcs')
                else:
                    errorMsg = e.strerror
                msg+= QApplication.translate("quickExport", "Error: {}").format(errorMsg)
                status = 'critical'
                abort = True
                return msg, status, abort, ePath

        # Save file path in QGIS settings
        s.setValue(
            "quickExport/%s" % etypeDic[etype]['lastFileSetting'],
            str(ePath)
        )
        self.exportedFile = ePath

        return msg, status, abort, ePath
    '''
    

    def creaHTML(self, url):
        textHTML = u'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">'
        textHTML+= u'<html><head><meta name="qrichtext" content="1" /><style type="text/css">'
        textHTML+= u'p, li { white-space: pre-wrap; }'
        textHTML+= u'</style></head><body style=" font-family:'+"'MS Shell Dlg 2'"+'; font-size:8.25pt; font-weight:400; font-style:normal;">'
        textHTML+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'
        # textHTML+= u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?where=Matricula_Plan+LIKE+%27%25%27&amp;text=&amp;objectIds=&amp;time=&amp;geometry=&amp;geometryType=esriGeometryEnvelope&amp;inSR=&amp;spatialRel=esriSpatialRelIntersects&amp;relationParam=&amp;outFields=*&amp;returnGeometry=true&amp;returnTrueCurves=false&amp;maxAllowableOffset=&amp;geometryPrecision=&amp;outSR=&amp;returnIdsOnly=false&amp;returnCountOnly=true&amp;orderByFields=&amp;groupByFieldsForStatistics=&amp;outStatistics=&amp;returnZ=false&amp;returnM=true&amp;gdbVersion=&amp;returnDistinctValues=false&amp;resultOffset=&amp;resultRecordCount=&amp;queryByDistance=&amp;returnExtentsOnly=false&amp;datumTransformation=&amp;parameterValues=&amp;rangeValues=&amp;f=pjson">'
        textHTML+= url
        textHTML+= u'<span style=" font-size:8pt; text-decoration: underline; color:#0000ff;">'
        # textHTML+= u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?where=Matricula_Plan+LIKE+%27%25%27&amp;text=&amp;objectIds=&amp;time=&amp;geometry=&amp;geometryType=esriGeometryEnvelope&amp;inSR=&amp;spatialRel=esriSpatialRelIntersects&amp;relationParam=&amp;outFields=*&amp;returnGeometry=true&amp;returnTrueCurves=false&amp;maxAllowableOffset=&amp;geometryPrecision=&amp;outSR=&amp;returnIdsOnly=false&amp;returnCountOnly=true&amp;orderByFields=&amp;groupByFieldsForStatistics=&amp;outStatistics=&amp;returnZ=false&amp;returnM=true&amp;gdbVersion=&amp;returnDistinctValues=false&amp;resultOffset=&amp;resultRecordCount=&amp;queryByDistance=&amp;returnExtentsOnly=false&amp;datumTransformation=&amp;parameterValues=&amp;rangeValues=&amp;f=pjson'
        textHTML+= url
        textHTML+= u'</span></a></p></body></html>'
        return textHTML
        

'''
################################################################################
                                ####   RESTOS  ####
################################################################################    

    def Control_calibr(self, objIdBusq):
        # QUERY AL WFS Plan_Carreteras_BTA_WFS para obtener la geometría'
        values = {
                  'where' : ' OBJECTID = '+str(objIdBusq),
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': False,
                  'outFields': '*',
                  'returnGeometry' : 'true',
                  'returnM': 'true' ,
                  'f': 'json'}
                  
        # print url+data
        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.urlencode(str_values)
        url = self.current_configuration.environment["rest_carreteras"]
        req = urllib2.Request(url, data)
        try:
            response = json.load(urllib2.urlopen(req))
        except urllib2.HTTPError as e:
            if e.code == 407:
                QApplication.restoreOverrideCursor()
                self.showJCCMessage(u"PROBLEMAS DE CONEXIÓN POR PROXY, CONSULTE CON INFORMÁTICA")
                return
        except urllib2.URLError as e:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet")
            return

        features =  response["features"]    # Los distintos features encontrados en la búsqueda
        # print feature
        datResult = 'F:'+str(len(features))
        FaltaM = False
        Sentido = 'D'
        Inversion = False
        ctrlCalib = 'OK'
        ctrlCalib1= ''
        for feature in features:
            geometry = feature["geometry"]
            # print geometry
            attr =  feature["attributes"]
            # print 'Numero Tramos: ', len(geometry["paths"])
            datResult += ' P:'+str(len(geometry["paths"]))
            Mant = geometry["paths"][0][0][2]
            if Mant is None:
                FaltaM = True
            for path in geometry["paths"]:
                # print '  Numero Puntos: ', len(path)
                datResult += ' O:'+str(len(path))
                for point in path:
                    if point[2] is None:
                        FaltaM = True
                    if point[2] < Mant and Inversion == False:
                        Inversion == True
                    if point[2]<Mant:
                        Sentido='I'
                    Mant = point[2]

        if FaltaM == True:
            ctrlCalib1 = 'FaltaM/'
        else:
            ctrlCalib1 = '-/'

        if Sentido == 'I':
            ctrlCalib1 += 'SenInv/'
        else:
            ctrlCalib1 += '-/'
        
        if Inversion == True:
            ctrlCalib1 += 'Inversion'
        else:
            ctrlCalib1 += '-'
        
        if ctrlCalib1 != '-/-/-':
            ctrlCalib = ctrlCalib1

        return ctrlCalib


    def Control_longPks(self, objIdBusq):
        from shapely.wkb import loads
        # QUERY AL WFS Plan_Carreteras_BTA_WFS para obtener la geometría'
        values = {
                  'where' : ' OBJECTID = '+str(objIdBusq),
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': False,
                  'outFields': '*',
                  'returnGeometry' : 'true',
                  'returnM': 'true' ,
                  'f': 'json'}
                  
        # print url+data
        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.urlencode(str_values)
        url = self.current_configuration.environment["rest_carreteras"]
        req = urllib2.Request(url, data)
        try:
            response = json.load(urllib2.urlopen(req))
        except urllib2.HTTPError as e:
            if e.code == 407:
                QApplication.restoreOverrideCursor()
                self.showJCCMessage(u"PROBLEMAS DE CONEXIÓN POR PROXY, CONSULTE CON INFORMÁTICA")
                return
        except urllib2.URLError as e:
            QApplication.restoreOverrideCursor()
            self.showJCCMessage(u"Error de conexión a internet")
            return

        features =  response["features"]    # Los distintos features encontrados en la búsqueda
        # print feature
        # datResult = 'F:'+str(len(features))
        longMal = False
        PKiniMal = False
        PKfinMal = False
        longKMMal = False
        # Sentido = 'D'
        # Inversion = False
        ctrlLongPks = 'OK'
        ctrlLongPks1= ''        
        
        for feature in features:
            geometry = feature["geometry"]
            # print geometry
            # line = loads(geometry)
            # longCalc = line.length
            attributes =  feature["attributes"]
            
            if abs(attributes['Longitud']-attributes['Shape.STLength()'])>0.01:
                longMal = True
                Longitud = attributes['Shape.STLength()']
                pass

            PKinimin = 999999
            PKfinmax = 0
            for path in geometry["paths"]:
                # datResult += ' O:'+str(len(path))
                for point in path:
                    if point[2] is not None:
                        if point[2]<PKinimin:
                            PKinimin=point[2]
                        if point[2]>PKfinmax:
                            PKfinmax=point[2]
            if abs(PKinimin - attributes['PkINI'])>0.001:    
                PKiniMal = True
                
            if abs(PKfinmax-attributes['PkFin'])>0.001:    
                PKfinMal = True
                
            LongKMCalc=PKfinmax-PKinimin
            if abs(LongKMCalc-attributes['Long_Km'])>0.001:    
                longKMMal = True
                
            
        ################################################################################
                                        ####    AQUÍ LA CHICHA  ####
        ################################################################################    

        # Valores para Return
        if longMal == True:
            ctrlLongPks1 = str(Longitud)+'/'
        else:
            ctrlLongPks1 = '-/'

        if PKiniMal == True:
            ctrlLongPks1 += str(PKinimin)+'/'
        else:
            ctrlLongPks1 += '-/'
        
        if PKfinMal == True:
            ctrlLongPks1 += str(PKfinmax)+'/'
        else:
            ctrlLongPks1 += '-/'
        
        if longKMMal == True:
            ctrlLongPks1 += str(LongKMCalc)
        else:
            ctrlLongPks1 += '-'
            
        if ctrlLongPks1 != '-/-/-/-':
            ctrlLongPks = ctrlLongPks1

        return ctrlLongPks







    # def cambiatxeOUTFIELDS(self):
        # if self.chbALLLAYERS.isChecked():
            # self.txeOUTFIELDS.setEnabled(False)
        # else:
            # self.txeOUTFIELDS.setEnabled(True)
            



        # Funcion de Query a GEOBTA
        # --- EJEMPLO ---
        # http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?
        # --- VALORES ---
        # where=Matricula_Plan+LIKE+%27%25%27&
        # text=&
        # objectIds=&
        # time=&
        # geometry=&
        # geometryType=esriGeometryEnvelope&
        # inSR=&
        # spatialRel=esriSpatialRelIntersects&
        # relationParam=&
        # outFields=*&
        # returnGeometry=true&
        # returnTrueCurves=false&
        # maxAllowableOffset=&
        # geometryPrecision=&
        # outSR=&
        # returnIdsOnly=false&
        # returnCountOnly=true&
        # orderByFields=&
        # groupByFieldsForStatistics=&
        # outStatistics=&
        # returnZ=false&
        # returnM=true&
        # gdbVersion=&
        # returnDistinctValues=false&
        # resultOffset=&
        # resultRecordCount=&
        # queryByDistance=&
        # returnExtentsOnly=false&
        # datumTransformation=&
        # parameterValues=&
        # rangeValues=&
        # f=pjson
'''