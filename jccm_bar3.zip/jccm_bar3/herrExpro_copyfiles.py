# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrExpro_copyfiles.py
                                 A QGIS plugin
 herrExpro
                             -------------------
        begin                : 2017-01-25
        git sha              : $Format:%H$
        copyright            : (C) A.Solabre 2017
        email                : gis.carreteras@jccm.es
 ***************************************************************************/
"""
from PyQt5.QtCore import Qt,  QSettings
from PyQt5.QtWidgets import QApplication
from qgis.gui import QgsMessageBar
from qgis.core import Qgis

import os, time, fnmatch
import shutil
import datetime
import sys
from stat import *
from os.path import isfile, join

# 1- Creamos variables
# 1A- EXISTE EL DIRECTORIO ORIGEN?
# 2- Obtenemos datos (tamano, fecha) del SHP origen O DE TODOS
# 3- Buscamos SHP destino similares en dir destino
# 4- Existe si diferente tamano y fecha -> copia seg
# 5- Existe igual tamano y fecha -> NO copia seg
# 6- No existe -> copia seg

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

udConfig = u'U:'
sys.path.append(udConfig + '/cartografia/datos_Q/QSIG/config/')

class copyFiles():

    def __init__(self, iface, parent=None):
        self.fun = Functions()
        self.iface = iface
        self.current_configuration = configuration()
        self.qs = QSettings();


        # files = configuration.ficherosCopySeg
        # dstDir = configuration.dstDirCopySeg
        # extList = configuration.extListCopySeg
        files = []
        extList = []
        
        # Se comprueba si existe configuración usuario de ficheros de copia seguridad
        grupoCopyExpro = "JCCM_carreteras/JCCM_EXPRO/EXP_COPYSEG"
        self.qs.beginGroup(grupoCopyExpro)
        listGrupoCopyExpro = self.qs.childKeys()
        self.qs.endGroup()
        if len(listGrupoCopyExpro) == 0:
            for data in self.current_configuration.ficherosCopySeg:
                # self.qlwFicherosCopySeg.addItem(data)
                files.append(data)
            for data in self.current_configuration.extListCopySeg:
                # self.qlwExtListCopySeg.addItem(data)
                extList.append(data)
            dstDir = self.current_configuration.dstDirCopySeg
        else:
            # Se cargan las variables al menú desde configuración usuario
            for dato in listGrupoCopyExpro:
                # print (dato)
                if dato[0:15] == 'EXP_COPYSEGfile':
                    varChild = grupoCopyExpro+"/"+dato
                    valVar = self.qs.value(varChild)
                    files.append(valVar)
                elif dato == 'EXP_COPYSEGext':
                    valVar = self.qs.value(grupoCopyExpro+"/"+dato)
                    for ext in valVar:
                        extList.append(ext)
                elif dato == 'EXP_COPYSEGdirdst':
                    dstDir = self.qs.value(grupoCopyExpro+"/"+dato)
        
        
        QApplication.setOverrideCursor(Qt.WaitCursor)
        progress = 'Copia de seguridad de Ficheros de EXPROPIACIONES...'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)

        # Presenta un messagebar de información
        iface.messageBar().pushMessage(u'Copia de seguridad de Ficheros de EXPROPIACIONES', u'', level=Qgis.Info, duration=0 )
        
        # Comprobamos que existe el directorio y si no se crea
        # print dstDir
        ################################################################################
        ####                           CONTROL                                      ####
        ####        ver que pasa con las unidades si no existen                     ####
        ################################################################################
        unidstDir = dstDir[:2]
        if not os.path.exists(unidstDir):
            # print 'NO EXISTE UNIDAD %s, DONDE GUARDO LA COSA?'%unidstDir
            text = u'NO EXISTE UNIDAD %s\n\nESTUDIAR DÓNDE SE GUARDA LA COPIA DE SEGURIDAD \n\n%s'%(unidstDir,dstDir)
            self.fun.showJCCMessage(text)
            QApplication.restoreOverrideCursor()
            self.iface.mainWindow().statusBar().showMessage('')
            return
        else:
            if not os.path.exists(dstDir):
                os.makedirs(dstDir)
            
        # Creamos el directorio destino si no existe
        if not os.path.exists(dstDir):
            os.makedirs(dstDir)
        srcDir = ''
        dstDir +=u'/'
        
        textMsg = u'FICHEROS COPIADOS: \n--------------------\n\n' 
        for srcFile in files:
            print (srcFile)
            copiarfile = 0

            if os.path.isfile(srcFile):
                # 1A- EXISTE EL FICHERO ORIGEN
                # Datos del fichero origen SRC
                stSrc = os.stat(srcFile)
                srcSIZE = stSrc[ST_SIZE]                                    # Tamaño del fichero
                srcDATEM = time.asctime(time.localtime(stSrc[ST_MTIME]))    # Fecha del fichero en TXT
                srcDATEMt = stSrc[ST_MTIME]                                 # Fecha del fichero
                # srcDir = os.path.dirname(srcFile)
                srcDir, srcFilExtName = os.path.split(srcFile)
                srcFilName, srcExt = os.path.splitext(srcFilExtName)
                print ('  stSrc ', stSrc, '\n', 'srcSIZE ', srcSIZE, '\n', 'srcDATEM ', srcDATEM, '\n', 'srcDATEMt ', srcDATEMt, '\n')
                
                fileModerno = 0
                
                for dstFilExt in extList:
                    if srcExt == dstFilExt:
                        for f in fnmatch.filter(os.listdir(dstDir),srcFilName+ u'*'+dstFilExt):
                            progress = 'Comprobando - '+f
                            self.iface.mainWindow().statusBar().showMessage(progress)  
                            filcopSIZE = stSrc = os.stat(join(dstDir, f))[ST_SIZE]
                            filcopDATEM = time.asctime(time.localtime(os.stat(join(dstDir, f))[ST_MTIME]))
                            filcopDATEMt = os.stat(join(dstDir, f))[ST_MTIME]
                            # filcopDATEMt = # Hay que obtener el fichero mas moderno de 
                            print ('  f ', f, '\n', 'filcopSIZE ', filcopSIZE, '\n', 'filcopDATEM ', filcopDATEM, '\n', 'filcopDATEMt ', filcopDATEMt, 'copiarfile =', copiarfile, '\n')
                            
                            #############   REVISAR ESTO DE LAS FECHAS      #############
                            
                            if filcopDATEMt > fileModerno:  #
                               fileModerno = filcopDATEMt
                               
                        if (fileModerno < srcDATEMt):
                            copiarfile = 1
                        
                        print ('dstFilExt', dstFilExt, u"  len(fnmatch.filter(os.listdir(dstDir),srcFilName+ u'*'+dstFilExt)) = ", len(fnmatch.filter(os.listdir(dstDir),srcFilName+ u'*'+dstFilExt)))
                        print ('  copiarfile =', copiarfile)
                        if len(fnmatch.filter(os.listdir(dstDir),srcFilName+ u'*'+dstFilExt)) == 0:
                            copiarfile = 1

                if copiarfile == 1:
                    # HACEMOS COPIA DE SEGURIDAD
                    # print 'HACEMOS COPIA DE SEGURIDAD'
                    textMsg += u' + COPIADO - ' + srcFile +u'\n\n'
                    t= datetime.datetime.now()
                    fechor = t.strftime('%Y%m%d%H%M')

                    # filename_ext = os.path.basename(srcDir+srcFilName+'.shp')
                    # dstFilName, dstFilExt = os.path.splitext(srcFile)
                    dstFilName = srcFilName+'_'+fechor

                    for dstFilExt in extList:
                        # print srcFilName,dstFilExt
                        # print dstDir,dstFilName+dstFilExt
                        # shutil.copy(srcFilName+dstFilExt, dstDir+dstFilName+dstFilExt)
                        # print '  ORIGEN  - ',srcDir+'/'+srcFilName+dstFilExt
                        # print '  DESTINO - ',dstDir+dstFilName+dstFilExt
                        if os.path.exists(srcDir+'/'+srcFilName+dstFilExt):
                            shutil.copy(srcDir+'/'+srcFilName+dstFilExt, dstDir+dstFilName+dstFilExt)
                else:
                    # print ' - NO se copia'
                    # print u'LA COPIA DE SEGURIDAD ES ACTUAL'
                    textMsg += u' - NO COPIADO, ES ACTUAL - ' + srcFile + u'\n\n' 
                    self.iface.mainWindow().statusBar().clearMessage()

            else:
                # 1B- NO EXISTE EL FICHERO ORIGEN
                textMsg += u' - NO EXISTE FICHERO ORIGEN - ' + srcFile +u'\n\n'

        # Muestra del mensaje de resultado y cierre del messagebar
        QApplication.restoreOverrideCursor()
        progress = 'Copiados Ficheros de EXPROPIACIONES'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)
        self.fun.showJCCMessage(textMsg, '','JCCM - Copia de Seguridad de ficheros')
        
        iface.messageBar().clearWidgets()
        
