# -*- coding: utf-8 -*-

"""
/***************************************************************************
 catastroBuscador.py
                                 A QGIS plugin

                             -------------------
        begin                : 2016-06-06
        git sha              : $Format:%H$
        Codigo Original      : Jon Garrido (ALAUDA) - HASTA V 1.26
        Codigo Corregido     : Agustín Solabre Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt5.QtGui import QIcon, QPixmap, QTextCursor
from PyQt5.QtCore import QSettings, Qt
from PyQt5.QtWidgets import QDialog, QApplication, QInputDialog, QLineEdit
from PyQt5 import uic

from qgis.core import QgsProject, QgsVectorLayer, QgsExpression, QgsFeatureRequest
from qgis.gui import QgsDialog

import os
import urllib
from xml.etree import cElementTree as ElementTree
from osgeo import ogr, osr
from osgeo import ogr, osr, gdal
import datetime

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/jccm_bar_buscadorcatastral.ui'))

tipoCARGA = 'CAPAPAR'
        # tipoCARGA = 'CAPAPAR' # tipoCARGA = 'CAPAPAR' - Carga las parcelas en una capa única 
        # tipoCARGA = 'CAPAIND' # tipoCARGA = 'CAPAIND' - Carga las parcelas en capas individuales

current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.environment["EPSG"]
    
class catastroBuscador(QDialog, FORM_CLASS):

    def __init__(self, iface,parent=None):
        """Constructor."""
        super(catastroBuscador, self).__init__(parent)
        self.setupUi(self)
        self.current_configuration = configuration()
        self.setVar = QSettings()
        self.fun = Functions()
        self.iface = iface
        menu = self
        
        self.logo.setPixmap(QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.setFixedSize(750, 282)
        self.lblNOCATASTRO.hide()

            
        '''
            FUNCIONES COINCIDENTES CON herrExpro_informes_invasionDP.py
        '''
        # lista_provincias = self.fun.getProvinciasCatastro()
        lista_provincias, lista_cpine = self.fun.getProvinciasCatastro()
        self.combo_provincia.clear()
        if lista_provincias is not None and lista_provincias != 'nocat':
            self.combo_provincia.addItems(lista_provincias)
            lastProvSelect = self.setVar.value("JCCM_carreteras/last/lastProvSelect")
            if lastProvSelect in lista_provincias:
                self.combo_provincia.setCurrentIndex(lista_provincias.index(lastProvSelect))
        else:
            self.lblNOCATASTRO.show()
            # self.close()
            return None
            
        # Se colocan los valores por defecto con el último valor tecleado
        #----------------------------------------------------------------------
        lastRC14Select = self.setVar.value("JCCM_carreteras/last/lastRC14Select")
        self.ref_catastral.setText(lastRC14Select)
        lastNPOLSelect = self.setVar.value("JCCM_carreteras/last/lastNPOLSelect")
        self.poligono.setText(lastNPOLSelect)
        lastNPARSelect = self.setVar.value("JCCM_carreteras/last/lastNPARSelect")
        self.parcela.setText(lastNPARSelect)

        self.fun.updateCombos(self) # Actualiza el combo Municipios a los de la Provincia
        
        self.addToListRCButton.clicked.connect(lambda: self.fun.addRCtoListClicked(self))
        self.addToListRusticaButton.clicked.connect(lambda: self.fun.addToListRusticaButtonClicked(self))
        self.zoomYCerrarButton.clicked.connect(lambda: self.fun.zoomToCurrentList(True, tipoCARGA, self))
        self.quitarItemButton.clicked.connect(lambda: self.fun.quitarSelectedItemsList(self, 'BUSC'))
        self.limpiarListaButton.clicked.connect(lambda: self.fun.limpiarListaClicked(self))
        
        # self.combo_provincia.currentIndexChanged.connect(self.provincia_updated)
        self.combo_provincia.currentIndexChanged.connect(lambda: self.fun.updateCombos(self))


        self.btnCargaMasiva.clicked.connect(self.cargaMasiva)
        self.combo_tabla.currentIndexChanged.connect(self.actualizarCampos) # Revisar esto y tal vez quitar el botón ACTUALIZAR CAMPOS
        self.btnIrCargaMasiva.clicked.connect(self.IrCargaMasiva)
        self.btnGeneraConsMasivaCAT.clicked.connect(self.GeneraConsMasivaCAT)
        
        # Acciones con ENTER en textlines
        self.ref_catastral.returnPressed.connect(lambda: self.fun.addRCtoListClicked(self))
        self.parcela.returnPressed.connect(lambda: self.fun.addToListRusticaButtonClicked(self))

        self.lblFichDest.hide()
        
        QApplication.restoreOverrideCursor()

        if configuration.custom_configuration != "":
            import imp
            try:
                custom_file = configuration.custom_configuration
                foo = imp.load_source('custom_config', custom_file)
                custom_config =  foo.custom_config()
                self.current_configuration = custom_config
            except:
                #QgsMessageLog.logMessage( "Archivo no encontrado, se carga configuracion por defecto..","jccm_bar")
                pass


    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()
        self.close()

               
    '''
    ***************************************************************************/
    ***    FUNCIONES PARA CARGA MASIVA   ***
    ***************************************************************************/
    '''
    
    def cargaMasiva(self):
        capas_csv = self.fun.getCapasCsv(self.iface)
        if len(capas_csv) == 0:
            self.fun.showJCCMessage('No hay ninguna capa vectorial o tabla con RefCat para cargar')
            return
        self.setFixedSize(750, 440)
        self.btnCargaMasiva.setEnabled(False)
        self.btnIrCargaMasiva.setEnabled(True)
        self.combo_tabla.setEnabled(True)
        self.combo_REFCAT.setEnabled(True)
        self.combo_tabla.clear()
        self.combo_tabla.addItems(capas_csv)
        self.combo_tabla.setEditable(False)
        self.combo_tabla.setCurrentIndex(0)


    def actualizarCampos(self):
        layername = self.combo_tabla.currentText()
        if layername == "":
            # self.fun.showJCCMessage("Debes cargar una capa csv en la tabla de contenidos")
            return None
        selected_table = self.fun.getLayerByName(layername)
        fields = selected_table.fields()
        list_fields = ['']
        for field in fields:
            # print field.type(), field.name()
            if (field.type() == 10): # Solo campos alfanuméricos
                list_fields.append(field.name())
        
        self.combo_REFCAT.clear()
        self.combo_REFCAT.addItems(list_fields)
        for field in list_fields:
            if field != '':
                self.combo_REFCAT.setCurrentIndex(list_fields.index(field))
                break
        

    def IrCargaMasiva(self):
        menu = self
        campo_REFCAT = self.combo_REFCAT.currentText()
        layername = self.combo_tabla.currentText()
        selected_table = self.fun.getLayerByName(layername)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        if campo_REFCAT != "" and (selected_table is not None):
            self.obtenerRCFromLayer(selected_table,self.iface,campo_REFCAT,menu)
            QApplication.restoreOverrideCursor()   
        else:
            QApplication.restoreOverrideCursor()
            self.fun.showJCCMessage(u'Seleccione una TABLA y un CAMPO')
            return

            
    def GeneraConsMasivaCAT(self):
        # Analiamos si la lista de REFCAT tiene alguna entrada
        current_lista_rc =  [str(self.listaRCs.item(i).text()) for i in range(self.listaRCs.count())]
        if len(current_lista_rc) < 1:
            self.fun.showJCCMessage("No hay elementos en la lista")
            QApplication.restoreOverrideCursor()   
            return
        
        # Creación de fichero de consulta XML
        ###############################################################
        ###                  CONTROL    qué fichero                 ###
        ###############################################################
        xml_salida_file= 'c:/temp/CATASTRO_ENVIO.XML'
        now = datetime.datetime.now()
        fecha = now.strftime("%d/%m/%y")
        
        # Introducir FINALIDAD
        qid = QInputDialog()
        qid.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))

        title = "CONSULTA MASIVA CATASTRO - FINALIDAD -"
        label = "FINALIDAD: --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---"
        mode = QLineEdit.Normal
        default = "CONSULTA COLINDANTES A CARRETERA "
        finalidad, ok = QInputDialog.getText(qid, title, label, mode, default)
        if ok == False:
            QApplication.restoreOverrideCursor()
            return
        
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        filexml = open(xml_salida_file, 'w')
        PLANTILLA_1  = u'<?xml version="1.0" encoding="UTF-8"?>\n'
        PLANTILLA_1 += u'   <LISTADATOS>\n'
        PLANTILLA_1 += u'       <FEC>%s</FEC>\n'%fecha
        PLANTILLA_1 += u'       <FIN>%s</FIN>\n'%finalidad
        filexml.writelines(PLANTILLA_1) # Añade el encabezamiento al GML

            
        for rc in current_lista_rc:
            linXml = u'       <DAT><RC>%s</RC></DAT>\n'%rc
            filexml.writelines(linXml) # Añade el dato RC al XML

        PLANTILLA_2 = u'   </LISTADATOS>\n'
        filexml.writelines(PLANTILLA_2) # Añade el final al XML
        self.lblFichDest.setText('Fichero destino:   '+xml_salida_file)
        self.lblFichDest.show()
        
        QApplication.restoreOverrideCursor()   

            
    def obtenerRCFromLayer(self, layer, iface, campo_REFCAT, menu):
        # print 'EMPEZAMOS A CARGAR LAS RC'
        features = layer.getFeatures()
        numfeat = layer.featureCount()
        listaParcelas = []
        cuentaParcelas = 0
        textMsg = ''
        textMsgINI = 'CARGANDO PARCELAS CATASTRALES...'+'\n'
        self.txeAVISOS.setText(textMsgINI)
        # print 'layer= ',layer.name(), ' campo_REFCAT= ',campo_REFCAT, ' numfeat= ', numfeat
        for feature in features:
            QApplication.processEvents()
            rc = feature[campo_REFCAT]
            if not rc:
                rc = 'NO-PARCELA'
            else:
                # print ('rc=', rc)
                point = None
                rc = rc[0:14].upper()
                if len(self.listaRCs.findItems(rc, Qt.MatchExactly)) == 0:
                    # Esto comprueba la existencia de la referencia catastral
                    point_response = self.fun.getPointFromRC(self.iface,rc)
                    if point_response is not None and point_response[0] == "Error":
                        textMsg = rc+ ' '+ point_response[1]
                        self.txeAVISOS.append(textMsg)
                    elif point_response is not None:
                            # textMsg = rc.encode("utf-8")+ ' OK'
                            textMsg = rc + u' OK'
                            listaParcelas.append(rc)
                            self.listaRCs.addItem(rc)
                            cuentaParcelas += 1
                            self.txeAVISOS.append(textMsg)
                else:
                    # textMsg = rc.encode("utf-8")+ ' REPETIDA'
                    textMsg = rc + ' REPETIDA'
                    self.txeAVISOS.append(textMsg)

            # Se coloca el cursos rl final del mensaje
            cursor = self.txeAVISOS.textCursor()
            cursor.movePosition(QTextCursor.End)
            self.txeAVISOS.setTextCursor(cursor)

        textMsg1 = u'   %s de %s RefCat  válidas leídas'%(cuentaParcelas, numfeat)
        self.txeAVISOS.append(textMsg1)
        

        if cuentaParcelas >0:
            # QApplication.restoreOverrideCursor()                    
            return listaParcelas
        else:
            self.fun.showJCCMessage(u'No se ha añadido ninguna RefCat de un total de %s registros'%(numfeat))
            # QApplication.restoreOverrideCursor()                    
            return
    
