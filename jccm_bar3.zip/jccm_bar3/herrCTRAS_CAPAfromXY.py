﻿"""
-------------------------------------------------------------------------------
Name:        jccmCTRAS_CAPAfromXY.py
Purpose:

Author:           A. Solabre (JCCM)
Comienzo:         25/01/2019
Traducción QGIS3: 29/3/2020


-------------------------------------------------------------------------------
"""

from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import Qt, QVariant
from PyQt5.QtWidgets import QDialog, QFileDialog
from PyQt5 import uic
from qgis.core import Qgis, QgsProject, QgsMapLayer, QgsWkbTypes, QgsVectorLayer, QgsField, QgsMessageLog, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsGeometry, QgsPointXY, QgsVectorFileWriter
from qgis.utils import qgsfunction, reloadPlugin, iface

import os, glob, codecs
from os.path import basename
from osgeo import ogr, osr
from time import sleep

# import urllib2
import urllib
import json
from xml.etree import cElementTree as ElementTree

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

current_configuration = configuration()


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_CAPAfromXY.ui'))


# VARIABLES
srcVal = current_configuration.environment["EPSG"]

class herrCTRAS_CAPAfromXY(QDialog, FORM_CLASS):

    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrCTRAS_CAPAfromXY, self).__init__(parent)
        
        self.setupUi(self)
        self.iface = iface;
        self.fun = Functions()
        self.canvas = self.iface.mapCanvas()
        
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.logo.setPixmap(QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))
        self.chbXYCapaPol.hide()
        self.combo_tabla.currentIndexChanged.connect(self.actualizarCampos) # Revisar esto y tal vez quitar el botón ACTUALIZAR CAMPOS
        self.chbXYCapaPun.clicked.connect(self.actualizarCampos)

        capas_csv = self.getCapasCsv(self.iface)
        self.combo_tabla.clear()
        self.combo_tabla.addItems(capas_csv)
        self.combo_tabla.setEditable(True)
        self.combo_tabla.setCurrentIndex(1)
 
        self.lblCampoX.setEnabled(False)
        self.lblCampoY.setEnabled(False)
        self.combo_XP.setEnabled(False)
        self.combo_YP.setEnabled(False)

        # BOTONES
        self.btnGENERAR.clicked.connect(self.jccmCTRAS_CAPAfromXY_calc)
        self.destino_button.clicked.connect(self.seleccionar_destino)
        self.btnCancelar.hide()

        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)    
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')
        maxfeat = 0
        self.chbMaxFeat.clicked.connect(self.cambiaMaxFeat)
        self.chbXYCapaPun.clicked.connect(self.cambiaCapaCampos)
     

    def getCapasCsv(self, iface):
        ################################################################################
        ####          HAY QUE COMPROBAR QUE LA CAPA ES DE PUNTOS O ES TABLA         ####
        ################################################################################     
        # layers = iface.mapCanvas().layers()
        layers = QgsProject.instance().mapLayers().values()
        layer_names = []
        for layer in layers:
            source = layer.source()
            if layer.type() == QgsMapLayer.VectorLayer or (source.find('type=csv') != -1): 
                # print type(layer).__name__, layer.name() , layer.wkbType()

                if layer.name() != '':
                    if layer.wkbType()==QgsWkbTypes.Point or layer.wkbType()==QgsWkbTypes.Point25D or (source.find('type=csv') != -1):
                        layer_names.append(layer.name())
        return layer_names

    def seleccionar_destino(self):
        namefile = self.layername.text()
        filename = QFileDialog.getSaveFileName(self, "Guardar archivo de destino", namefile, "*.shp")
        if filename[0] != '':
            self.layername.setText(filename[0])
     
    def cambiaMaxFeat(self):
        if self.chbMaxFeat.isChecked():
            self.lneMaxFeat.setEnabled(True)
        else:
            self.lneMaxFeat.setEnabled(False)
        pass
        

    def cambiaCapaCampos(self):
        if self.chbXYCapaPun.isChecked():
            self.lblCampoX.setEnabled(False)
            self.lblCampoY.setEnabled(False)
            self.combo_XP.setEnabled(False)
            self.combo_YP.setEnabled(False)
        else:
            self.lblCampoX.setEnabled(True)
            self.lblCampoY.setEnabled(True)
            self.combo_XP.setEnabled(True)
            self.combo_YP.setEnabled(True)
        pass
        

    def actualizarCampos(self):
        layername = self.combo_tabla.currentText()
        if layername == "":
            return None
        selected_table = self.fun.getLayerByName(layername)
        fields = selected_table.fields() 
        ################################################################################
        ####              HAY QUE REVISAR QUE LOS CAMPOS SEAN NUMÉRICOS             ####
        ####    SE PUEDE TRATAR DE BUSCAR SEÑALES DE QUE LOS CAMPOS CONTIENEN X,Y   ####
        ################################################################################

        list_fields = ['']
        for field in fields:
            # print field.name(), field.typeName()
            # if( field.typeName() == "double" or field.typeName() == "Double" or field.typeName() == "int" or field.typeName() == "integer" or field.typeName() == "Integer" or field.typeName() == "Real" or field.typeName() == "Integer64"):
                list_fields.append(field.name())
        
        self.combo_XP.clear()
        self.combo_XP.addItems(list_fields)
        self.combo_YP.clear()
        self.combo_YP.addItems(list_fields)

        # Colocamos el primer field no vacío
        for field in list_fields:
            if field != '':
                self.combo_XP.setCurrentIndex(list_fields.index(field))
                self.combo_YP.setCurrentIndex(list_fields.index(field))
                break

        
    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        pass

    def jccmCTRAS_CAPAfromXY_calc(self):
        # RUTINA DE CÁLCULO DE UN FICHERO X,Y A CARRETERA,PK
        # DERIVADO DESDE fun.mostraEventosFromCSVLayer(...)
        #           y    fun.addEventoPuntual(...)
        # def mostraEventosFromCSVLayer(self,layer, iface,campo_carretera,campo_pkini,campo_pkfin,campo_disteje,dest_path,progressBar_dlg,infolbl,dest_name,maxfeat,RECALC,FactPKINI,FactPKFIN, menu):
        # def addEventoPuntual(self,iface,vectorlayer,matricula,pk,disteje,feature,fields,log_csv):
        ################################################################################
        ####          HAY QUE COMPROBAR QUE LA CAPA ES DE PUNTOS O ES TABLA         ####
        ################################################################################        
    
        iface= self.iface

        capaPUNTOS = self.combo_tabla.currentText()
        campo_XP = self.combo_XP.currentText()
        campo_YP = self.combo_YP.currentText()
        capaPUNTOSres = self.lneNomCapaDestino.text()

        dir_logCSV = u'C:/TEMP/'

        dest_path = self.layername.text()
        dest_name = self.lneNomCapaDestino.text()

        if self.chbMaxFeat.isChecked():
            maxfeat = int(self.lneMaxFeat.text())
        else:
            maxfeat = 0
        progressBar_dlg = self.progressBar
        infolbl = self.lblINFO
        infolbl.setText('INFO: COMENZANDO LECTURA DE ARCHIVO...')


        layer = self.fun.getLayerByName(capaPUNTOS)
        dest_name = capaPUNTOSres
        
        if dest_path == 'en memoria':
            es_memoria = True
        else:
            es_memoria = False
        
        if self.chbXYCapaPun.isChecked() or (campo_XP != "" and campo_YP != ""):
            coorGEOM = False
            if self.chbXYCapaPun.isChecked():
                coorGEOM = True
            # CREACIÓN DE UNA CAPA VECTORIAL DE DESTINO EN MEMORIA AÑADIENDOLE LOS CAMPOS RESULTADO
            dest_layer = QgsVectorLayer("point?crs=epsg:"+str(srcVal), dest_name, 'memory')
            pr = dest_layer.dataProvider()
            dest_layer.startEditing()
            # Añadir CAMPOS
            #    "carretera", "pk_calc", "distancia", "acimut", "XE", "YE","idmatricula"
            ################################################################################
            ####    HAY QUE ANALIZAR SI ESTOS CAMPOS EXISTEN EN LA CAPA DE PUNTOS X,Y   ####
            ################################################################################
            pr.addAttributes( [ QgsField("carretera", QVariant.String),
                                QgsField("pk_calc",    QVariant.Double),
                                QgsField("distancia",  QVariant.Double),
                                QgsField("acimut",     QVariant.Double),
                                QgsField("XE",         QVariant.Double), 
                                QgsField("YE",         QVariant.Double),
                                QgsField("idmatricula",QVariant.Int)
                                ] )
            if coorGEOM == True:
                pr.addAttributes( [
                                QgsField("XP",         QVariant.Double), 
                                QgsField("YP",         QVariant.Double)
                                ] )
                
            dest_layer.commitChanges()
            
            # CREACIÓN DE UN LOG DE RESULTADOS
            log_csv = dir_logCSV + "Log_XYtoPK.csv"
            
            if(es_memoria == False):
                log_csv =  os.path.splitext(dest_path)[0] +  os.path.splitext(dest_path)[1].split(".")[0] + "_log.csv"

            QgsMessageLog.logMessage( "Creando archivo de log","jccm_bar")
            
            target  = codecs.open(log_csv, 'w+',encoding='utf-8')
            # encabezado = u'"carretera";"pk";"distancia";"result";"observaciones"'
            encabezado = u'XP; YP; CTRA; PK; result; observaciones'
            target.write(encabezado)
            target.write("\n")
            target.close()
            
            # Esto crea la capa de LOG
            log_csv_uri = u"file:///"+ log_csv +"?type=csv&geomType=none&subsetIndex=no&delimiter=%s&watchFile=no" % (";")
            log_lyr = QgsVectorLayer(log_csv_uri, 'Log_XYtoPK','delimitedtext')
            QgsProject.instance().addMapLayer(log_lyr)

            # SE AÑADEN AL FICHERO DESTINO LOS OTROS CAMPOS DEL FICHERO ORIGEN
            pr = dest_layer.dataProvider()
            dest_layer.startEditing()
            fields = layer.fields()
            attributes = []
            for field in fields:
                attributes.append(QgsField(field.name(),field.type()))
            pr.addAttributes(attributes)
            dest_layer.updateFields()
            dest_layer.commitChanges()

            # COMENZAMOS A LEER TODOS LOS REGISTROS DEL FICHERO ORIGEN
            nofeat = 1
            if maxfeat == 0:
                maxfeat = 99999
            features = layer.selectedFeatures()
            numfeat = len(features)

            # print 'numfeat = ' + str(numfeat)
            if numfeat == 0:
                features = layer.getFeatures()
                numfeat = layer.featureCount()
            
            if coorGEOM == True:
                sourceCrsAUTH = layer.crs().authid()
                # destCrsAUTH = u'EPSG:25830'
                destCrsAUTH = self.canvas.mapSettings().destinationCrs().authid()
                sourceCrs = QgsCoordinateReferenceSystem(sourceCrsAUTH)
                destCrs = QgsCoordinateReferenceSystem(destCrsAUTH)
                # tr = QgsCoordinateTransform(sourceCrs, destCrs)
                tr = QgsCoordinateTransform(sourceCrs, destCrs, QgsProject.instance())
                # print 'SOURCE=', sourceCrsAUTH, 'DEST=', destCrsAUTH

            for feature in features:
                if nofeat > maxfeat:
                    break    

                # print u'(nofeat %s, maxfeat %s, numfeat %s)'%(nofeat, maxfeat, numfeat )
                progress = 'Calculando punto %s de %s...'%(nofeat,numfeat)
                self.iface.mainWindow().statusBar().showMessage(progress)
                if coorGEOM == True:
                    geom = feature.geometry().asPoint()
                    XP0 = geom[0]
                    YP0 = geom[1]
                    geom = tr.transform(XP0, YP0)
                    XP = geom[0]
                    YP = geom[1]
                    # print XP, YP
                else:
                    XP = float(feature[campo_XP])
                    YP = float(feature[campo_YP])
                    
                if (not XP0 or not YP0):
                    matricula = 'NO-CARRETERA'

                # print 'XP0=', XP0,' YP0=',YP0,' XTra=', XP,' XTra=', YP
                carretera_pk = self.fun.pointToPK([XP,YP],iface,pintar='NO',no9000='SI')
                # carretera_pk = self.fun.pointToPK([point[0],point[1]],iface,pintar='NO',no9000='SI')
                # return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE, pointEJE]
                # carretera_pk [0],     [1],      [2],     [3],       [4],     [5],     [6],       [7]
                
                ############################################################
                ####    HAY QUE ANALIZAR LOS RESULTADOS 9000   ####
                ############################################################
                target  = codecs.open(log_csv, 'a',encoding='utf-8')
                if carretera_pk is not None:
                    atributos = carretera_pk[4]
                    # print str(nofeat),XP,YP, carretera_pk[0], round(carretera_pk[1],5), round(carretera_pk[5],3), round(carretera_pk[6],4), atributos['idMatricula']

                    pr = dest_layer.dataProvider()
                    dest_layer.startEditing()

                    fet = QgsFeature(dest_layer.fields())
                   
                    fieldnames = []
                    for field in fields:
                       #print "fieldname = "  + field.name()
                       fieldnames.append(field.name())                

                    fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(XP,YP)))
                    fet.setAttribute("carretera", carretera_pk[0])
                    fet.setAttribute("pk_calc", round(carretera_pk[1],5)) 
                    fet.setAttribute("distancia", round(carretera_pk[5],3)) 
                    fet.setAttribute("acimut", round(carretera_pk[6],4)) 
                    fet.setAttribute("XE", round(carretera_pk[7][0],3))
                    fet.setAttribute("YE", round(carretera_pk[7][1],3))
                    fet.setAttribute("idmatricula", atributos['idMatricula'])
                    if coorGEOM == True:
                        fet.setAttribute("XP", round(XP,3))
                        fet.setAttribute("YP", round(YP,3))
                    
                    
                    for field_name in fieldnames:
                        fet.setAttribute(field_name,feature[field_name]) 

                    # linea = u'"'+ carretera_pk[0] +'";"'+str(round(carretera_pk[1],5))+'";"'+str(round(carretera_pk[5],3))+'";"'+str(nofeat)+' OK";""'
                    # linea = u'"'+str(XP)+'";"'+str(YP)+'";"'+carretera_pk[0]+'";"'+str(round(carretera_pk[1],5))+'";"'+str(nofeat)+' OK";""'
                    linea = str(XP)+';'+str(YP)+';'+carretera_pk[0]+';'+str(round(carretera_pk[1],5))+';"'+str(nofeat)+' OK";""'

                    pr.addFeatures( [ fet ] )
                    dest_layer.updateExtents()
                    dest_layer.commitChanges()
                    
                else:
                    message = u"Punto muy alejado de una carretera"
                    # linea = u'"'+str(XP)+'";"'+str(YP)+'";"S/D";"'+str(nofeat)+' ERROR COORD";"'+ message+'"'
                    # linea = u'"'+str(XP)+'";"'+str(YP)+'";"s/d";"s/d";"'+str(nofeat)+' ERROR COORD";"'+ message+'"'
                    linea = str(XP)+';'+str(YP)+';"s/d";"s/d";"'+str(nofeat)+' ERROR COORD";"'+ message+'"'
                    # print str(nofeat),XP,YP, u"Punto muy alejado de una carretera"

                target.write(linea)
                target.write("\n")
                target.close()

                if maxfeat != 99999 and maxfeat<numfeat:
                    progressBar_dlg.setValue(100*nofeat/maxfeat)
                    infolbl.setText('INFO: ('+str(nofeat)+' / '+str(maxfeat)+') Total: '+str(numfeat)+' elementos')
                else:
                    progressBar_dlg.setValue(100*nofeat/numfeat)
                    infolbl.setText('INFO: ('+str(nofeat)+' / '+str(numfeat)+')')
                
                nofeat += 1
          

            if(es_memoria):
                QgsProject.instance().addMapLayer(dest_layer)
            else:
                pr = dest_layer.dataProvider()
                fields = pr.fields()
               
                field_names = []
                for field_name in fields:
                    field_names.append(field_name.name())

                #borramos el archivo shp y amigos...
                ruta, shp_file = os.path.split(dest_path)
                shp_name = shp_file.split(".")[0]
                
                if os.path.isfile(dest_path):
                     for path in os.listdir(ruta):
                         ruta_tmp, file = os.path.split(path)
                         if(file.split(".")[0]  == shp_name):
                             file_path= ruta + "/" + file
                             os.remove(file_path)
                    
                writer = QgsVectorFileWriter(dest_path, "latin-1", fields, QgsWkbTypes.Point, pr.crs(), "ESRI Shapefile")
                iter = dest_layer.getFeatures()
                for ft in iter:  # Loop on the subseted features
                    # Create a new feature for each original feature
                    new_ft = QgsFeature()
                    # Give it its geometry :
                    new_ft.setGeometry(ft.geometry())
                    attributes = []
                    for field in field_names:
                        attributes.append(ft[field])
                        #attributes.append(0)
                    #print attributes
                    # Only keep the 2 selected fields :
                    new_ft.setAttributes(attributes)
                    # Add the feature to the writer, ie. your output shapefile :
                    #print ft
                    writer.addFeature(new_ft)

                del writer # Features are written when the writer is deleted
                # new_layer = iface.addVectorLayer(dest_path, os.path.splitext(dest_path)[1].split(".")[0], "ogr")
                new_layer = iface.addVectorLayer(dest_path, dest_name, "ogr")

                QgsProject.instance().addMapLayer(new_layer)

            self.fun.showJCCMessage("--- TERMINADA LA CARGA DE DATOS ---")
            progress = '--- TERMINADA LA CARGA DE PUNTOS --- (%s/%s)'%(nofeat-1,numfeat)
            self.iface.mainWindow().statusBar().showMessage(progress)
            self.close()


        else:
            self.fun.showJCCMessage("Hay que seleccionar una tabla y seleccionar los campos X, Y")
        
            
        return
        


