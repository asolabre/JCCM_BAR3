# -*- coding: utf-8 -*-
"""
/***************************************************************************
 parcela_catastralDialog
                                 A QGIS plugin
 jcml_bar
                             -------------------
        begin                : 2016-06-06
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWidgets import QApplication, QDialog

from PyQt5 import QtGui, QtCore, uic

# from PyQt4.QtGui import *
# from PyQt4 import QtGui, uic

import os
from osgeo import ogr, osr
from qgis.core import *
import qgis.utils

# import urllib2
import urllib
import json
from time import sleep

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/parcela_catastral.ui'))


class parcela_catastralDialog(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(parcela_catastralDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        self.fun = Functions()
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.logoJCCM.setPixmap(QtGui.QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))

    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        return text.encode('utf-8')