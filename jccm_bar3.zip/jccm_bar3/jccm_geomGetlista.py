# -*- coding: utf-8 -*-
####################################################################################
# Obtenemos la Geometría del elemento pinchado de una capa de polígono
####################################################################################

from PyQt5.QtGui import QIcon, QCursor
from PyQt5.QtCore import Qt, QRect
from PyQt5.QtWidgets import QApplication, QMessageBox, QDialogButtonBox, QLabel, QTableWidget, QTextEdit, QTableWidgetItem

from qgis.gui import QgsDialog, QgsMapTool
from qgis.core import QgsWkbTypes, QgsGeometry, QgsPoint, QgsPointXY, QgsLineString

# from osgeo import gdal, osr, ogr
from osgeo import ogr
import urllib
import json

from math import fabs

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
current_configuration = configuration()

precision= 3 # Precisión de coordenadas y superficies

class jccm_geomGetlista(QgsMapTool):

    def __init__(self, canvas, iface, action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas    
        self.fun = Functions()
        cursor = QCursor()
        cursor.setShape(Qt.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        pass

        
    def canvasReleaseEvent(self, event): 
        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        coordMouse = "{:.{}f}, {:.{}f}".format(point.x(), precision, point.y(), precision)

        layer = self.iface.activeLayer()
        text2=''
        tittle="ERROR"
        if layer is None:
            text = u'Seleccione una capa de Polígonos'
            self.fun.showJCCMessageERR( text,text2,tittle)
            return
        if layer.type() != 0:
            text = u"La capa '"+ layer.name()  + u"' es de tipo "+str(layer.type())+'. NO VECTORIAL\n\n'
            text += u"SELECCIONE UNA CAPA DE POLÍGONOS"
            self.fun.showJCCMessageERR( text,text2,tittle)
            return
        geomTypeString=QgsWkbTypes.displayString(int(layer.wkbType()))
        tipos = ['POLYGON','MULTIPOLYGON','POLYGONZ','MULTIPOLYGONZ','POLYGONM','MULTIPOLYGONM','POLYGONZM','MULTIPOLYGONZM','POLYGON25D','MULTIPOLYGON25D']

        if geomTypeString.upper() not in tipos:
            text = u"La capa '"+ layer.name()  + u"' es de tipo " + geomTypeString+u'\n\n'
            text += u"SELECCIONE UNA CAPA DE POLÍGONOS"
            self.fun.showJCCMessageERR( text,text2,tittle)
            return

        fields = layer.fields()  
        field_names = [field.name() for field in fields]
        capa = layer.name() + ' -  TIPO: '+ geomTypeString

        # print geomTypeString, 'CAPA: ', layer.name()
        
        feats = [ feat for feat in layer.getFeatures() ]
        geo_pt = QgsGeometry.fromPointXY(QgsPointXY(point.x(), point.y()))
        id = -1

        camposATTRS = []
        listaGeometria =  'SISTEMA DE COORDENADAS: '+self.iface.mapCanvas().mapSettings().destinationCrs().authid() + u'\n'
        QApplication.setOverrideCursor(Qt.WaitCursor)
        for feat in feats:
            if geo_pt.within(feat.geometry()):
            
                geom = feat.geometry()
                ctra, pkini, pkfin, distEJE = self.fun.poligToPKINIPKFIN(geom, self.iface,'NO')
                print ( 'result : ',ctra, pkini, pkfin)

                id = feat.id()

                try:
                    elemId = str(id)+' - '+ field_names[0]+' - '+ str(feat.attribute(field_names[0]))
                except:
                    elemId = str(id)+' - '+ field_names[0]+' - '+ (feat.attribute(field_names[0])).decode('utf-8')
                
                for campo in field_names:
                    try:
                        valor = str(feat.attribute(campo))
                    except:
                        valor = '--- UNICODE ---'
                    elem  = campo + ':' +valor
                    
                    camposATTRS.append(elem)
                
                listaGeometria +=  u'Área = {:04.2f} m2'.format(geom.area()) + u'\n'
                listaGeometria +=  u'Perímetro = {:04.2f} m'.format(geom.length()) + u'\n'
                if geom.isMultipart():
                    polygon = geom.asMultiPolygon()
                    single = False
                else:
                    polygon = geom.asPolygon()
                    single = True
                
                listaGeometria += self.geomGetLista(polygon, single)
                    
                break
                
        if id == -1:
            QApplication.restoreOverrideCursor()
            text = u"No hay geometría en la posición del cursor"
            self.fun.showJCCMessageERR( text,text2, tittle)
            return
        
        text=u"DATOS DE POLÍGONO"
        self.showDialog(text,listaGeometria,camposATTRS, coordMouse, capa, elemId, ctra, pkini, pkfin, "JCCM")
        
        
    def showDialog(self, text,listaGeometria,listaDatos, coordMouse, capa, elemId, ctra, pkini, pkfin, tittle="JCCM"):
        main_window = self.iface.mainWindow()
        dialog = QgsDialog(main_window,
                           fl=Qt.WindowFlags(),
                           buttons=QDialogButtonBox.NoButton,
                           orientation=Qt.Vertical)
        dialog.setWindowTitle("LISTADO DE COORDENADAS")
        dialog.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        dialog.resize(530, 420)
        
        # Etiquetas
        labelCoordPinch = QLabel(dialog)
        labelCoordPinch.setGeometry(QRect(5, 5, 510, 20))
        labelCoordPinch.setAlignment(Qt.AlignBottom | Qt.AlignLeft)
        labelCoordPinch.setText("COORDENADAS CURSOR: " + coordMouse)
        labelCapa = QLabel(dialog)
        labelCapa.setGeometry(QRect(5, 25, 510, 20))
        labelCapa.setAlignment(Qt.AlignBottom | Qt.AlignLeft)
        labelCapa.setText("CAPA: " + capa)
        labelElemento = QLabel(dialog)
        labelElemento.setGeometry(QRect(5, 45, 510, 20))
        labelElemento.setAlignment(Qt.AlignBottom | Qt.AlignLeft)
        labelElemento.setText("ELEMENTO: " + elemId)
        labelCtraPks = QLabel(dialog)
        labelCtraPks.setGeometry(QRect(230, 45, 510, 20))
        labelCtraPks.setAlignment(Qt.AlignBottom | Qt.AlignLeft)
        if ctra == None:
            labelCtraPks.setText(' --- ')
        else:
            if pkini == 'Ctra sin PK' or  pkfin == 'Ctra sin PK':
                labelCtraPks.setText('Ctra: {}  PKINI: {}  PKFIN: {}'.format(ctra, 'Ctra sin PK', 'Ctra sin PK'))
            else:
                labelCtraPks.setText('Ctra: {}  PKINI: {:.3f}  PKFIN: {:.3f}'.format(ctra, pkini, pkfin))
        
        
        # Tabla de atributos
        tableWidget = QTableWidget(dialog)
        tableWidget.setGeometry(QRect(5, 65, 270, 340))
        tableWidget.setObjectName("tableWidget")
        tableWidget.setColumnCount(2)
        tableWidget.setRowCount(len(listaDatos))
        tableWidget.setColumnWidth( 0, 100)
        tableWidget.setColumnWidth( 1, 300)
        tableWidget.setHorizontalHeaderLabels (['CAMPO      ', 'VALOR ATRIBUTO    '])
        j=0
        for data in listaDatos:
            dataDescomp = data.split(':')
            tableWidget.setItem(j, 0,  QTableWidgetItem(dataDescomp[0]))
            tableWidget.setItem(j, 1, QTableWidgetItem(dataDescomp[1]))
            j+=1

        # Listado de Coordenadas
        textEdit = QTextEdit(dialog)
        textEdit.setGeometry(QRect(280, 65, 245, 340))
        textEdit.setObjectName("textEdit")
        textEdit.setText(listaGeometria)
        
        QApplication.restoreOverrideCursor()
        dialog.show()

        
    def geomGetLista(self, geomWKT, single):
        cadena =''
        for parte in geomWKT:
          cadena += u'Polígono '+str(geomWKT.index(parte)+1)+'\n'
          i=1
          if single:
              for pto in parte:
                cadena += " ".join([str(i),' - ',"{:.{}f}".format(pto[0], precision),' - ',"{:.{}f}".format(pto[1], precision),'\n'])
                i += 1
          else:
              for pto in parte[0]:
                cadena += " ".join([str(i),' - ',"{:.{}f}".format(pto[0], precision),' - ',"{:.{}f}".format(pto[1], precision),'\n'])
                i += 1          
        return cadena

