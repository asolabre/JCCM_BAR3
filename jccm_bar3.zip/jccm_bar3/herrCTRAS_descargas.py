# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrCTRAS_descargas.py
                                 A QGIS plugin
                             -------------------
        begin                : 2018-03-24
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.
 *
 *   Based in 'Quick Export' pluggin
 *                                                                         *
 ***************************************************************************/
"""

from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import QSettings, QCoreApplication, QTranslator, qVersion, Qt
from PyQt5.QtWidgets import QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox, QFileDialog
from PyQt5 import uic

from qgis.gui import QgsMessageBar
from qgis.core import QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication, QgsFeature, QgsGeometry
from qgis.utils import iface
from qgis.PyQt.QtPrintSupport import QPrinter

import os
from osgeo import ogr, osr
import urllib
import json
from time import sleep
import glob, codecs
from functools import partial
import shutil
import datetime
import locale
import tempfile
import sys
import subprocess
import csv
import timeit
import io


from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES
current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.environment["EPSG"]


current_configuration = configuration()

fichEstilo = '/Carreteras_CLM_WFS.qml'
fichEstiloPKS = '/GEO_PKS_WFS.qml'

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_descargas.ui'))


class herrCTRAS_descargas(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrCTRAS_descargas, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.logo.setPixmap(QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))
        
        self.fun = Functions()
        self.current_configuration = configuration()
        
        self.plugin_dir = os.path.dirname(__file__)
        # self.QgisVersion = QGis.QGIS_VERSION_INT
        self.QgisVersion = Qgis.QGIS_VERSION_INT

      
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)    
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        nomFich = u'C:/TEMP/JCCM_CTRAS_EJES.json'
        nomFichPKS = u'C:/TEMP/JCCM_CTRAS_PKS.json'
        self.lneFICHsalida.setText(nomFich)
        self.lneFICHsalida_PKS.setText(nomFichPKS)
        
        self.btnSeleccionfich.clicked.connect(self.salida_file_click)
        self.btnSeleccionfich_PKS.clicked.connect(self.salida_filePKS_click)
        self.buttonBoxOK.clicked.connect(self.DescargaFicheros)

        self.cbxProvincia.currentIndexChanged.connect(self.combos_updated)
        self.cbxTitularidad.currentIndexChanged.connect(self.combos_updated)
        self.cbxFuncionalidad.currentIndexChanged.connect(self.combos_updated)
        self.cbxMatricula.currentIndexChanged.connect(self.combos_updated)
        self.cbxTipoExport.currentIndexChanged.connect(self.cambiaFichs)
        self.chbMATR9000.stateChanged.connect(self.combos_updated)
        self.chbDESC_PKS.clicked.connect(self.cambiaWIDGETSPKS)
        
        self.strPrecision = "{:."+str(self.spnPRECISION.value())+"f}"
        
        # COMBOS DESPLEGABLES
        #  Combo Funcionalidad
        lista_Valores = self.fun.getValoresCampo('Funcionalidad','')
        self.cbxFuncionalidad.clear()
        if lista_Valores is not None:
            self.cbxFuncionalidad.addItem("Todo")
            self.cbxFuncionalidad.addItems(lista_Valores)
            
        #  Combo Titularidad
        lista_Valores = self.fun.getValoresCampo('Titularidad','')
        self.cbxTitularidad.clear()
        if lista_Valores is not None:
            self.cbxTitularidad.addItem("Todo")
            self.cbxTitularidad.addItems(lista_Valores)
            # if 'JCCM' in lista_Valores:
                # self.cbxTitularidad.setCurrentIndex(1+lista_Valores.index('JCCM'))
                
        #  Combo Provincia
        lista_Valores = self.fun.getValoresCampo('Provincia','')
        self.cbxProvincia.clear()
        if lista_Valores is not None:
            self.cbxProvincia.addItem("Todo")
            self.cbxProvincia.addItems(lista_Valores)
            # if 'Albacete' in lista_Valores:
                # self.cbxProvincia.setCurrentIndex(lista_Valores.index('Albacete'))
                
        #  Combo Matricula
        lista_Valores = self.fun.getValoresCampo('Matricula','')
        self.cbxMatricula.clear()
        if lista_Valores is not None:
            lista_Valores.insert(0, "%")
            self.cbxMatricula.addItems(lista_Valores)
            
        #  Combo TipoFich
        # lista_Valores = ['json','shp','kml','gpx','dxf']
        lista_Valores = ['json','gpkg']
        self.cbxTipoExport.clear()
        self.cbxTipoExport.addItems(lista_Valores)
        self.cbxTipoExport.setCurrentIndex(lista_Valores.index('json'))
        # self.cbxTipoExport.setCurrentIndex(lista_Valores.index('gpkg'))

            
    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()

        
    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        # return text.encode('utf-8')
        return text.encode('ISO-8859-14')
        
        
    def combos_updated(self):
        valcbxProvincia = self.cbxProvincia.currentText()
        if valcbxProvincia == 'Albacete':
            provELEGIDA = 'AB'
        elif valcbxProvincia == 'Ciudad Real':
            provELEGIDA = 'CR'
        elif valcbxProvincia == 'Cuenca':
            provELEGIDA = 'CU'
        elif valcbxProvincia == 'Guadalajara':
            provELEGIDA = 'GU'
        elif valcbxProvincia == 'Toledo':
            provELEGIDA = 'TO'
        elif valcbxProvincia == 'Todo':
            provELEGIDA = 'TODO'
        else:
            provELEGIDA = '--'
            
        if self.chbMATR9000.isChecked():
            valchbMATR9000 = 'NO9000'
        else:
            valchbMATR9000 = 'SI9000'
            
        valcbxProvincia = self.cbxProvincia.currentText()
        valcbxTitularidad = self.cbxTitularidad.currentText()
        valcbxFuncionalidad = self.cbxFuncionalidad.currentText()
        matrELEGIDA = self.cbxMatricula.currentText()
        self.lblINFO.setText(u'INFO: PROV: -'+valcbxProvincia+'- TITU: ' +valcbxTitularidad+ '- FUNC: ' +valcbxFuncionalidad+ '- MATR: '+matrELEGIDA + '- 9000: '+valchbMATR9000)
        
        ####################################################################################################################################################
        # FALTA METER AQUÍ EL CAMBIO DE NOMBRE DEL FICHEROS
        # - DETECTAR SI ESTA YA EN EL NOMBRE
        # - METER EL DATO EN EL NOMBRE
        # - CAMBIR ATAMBIÉN EL NOMBRE DE CAPA
        ####################################################################################################################################################

        pass
        
        
    def cambiaFichs(self):
        ext = self.cbxTipoExport.currentText()
        nomFich = self.lneFICHsalida.text()
        filenamePK, file_extension = os.path.splitext(nomFich)
        nomfich = filenamePK + '.' + ext
        self.lneFICHsalida.setText(nomfich)

        nomFichPKS = self.lneFICHsalida_PKS.text()
        filenamePK, file_extension = os.path.splitext(nomFichPKS)
        nomFichPKS = filenamePK + '.' + ext
        self.lneFICHsalida_PKS.setText(nomFichPKS)

        pass
    
        
    def cambiaWIDGETSPKS(self):
        if self.chbDESC_PKS.isChecked():
            self.lneFICHsalida_PKS.setEnabled(True)
            self.btnSeleccionfich_PKS.setEnabled(True)
            self.lneNOMcapa_PKS.setEnabled(True)
        else:
            self.lneFICHsalida_PKS.setEnabled(False)
            self.btnSeleccionfich_PKS.setEnabled(False)
            self.lneNOMcapa_PKS.setEnabled(False)
        pass
        

    def DescargaFicheros(self):
        if not self.chbSOLO2D.isChecked():
            result = 'La descarga con PK (valor M) puede eliminar elementos sin M'
            self.fun.showJCCMessage(result,text2="",tittle="JCCM - Descarga CTRAS",)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        progress = 'Descargando datos desde BASE DE DATOS DE CARRETERAS...'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)
        start = timeit.default_timer()
        estiloCAPA = os.path.join(os.path.dirname(__file__), current_configuration.otros["carpeta_estilos"] + fichEstilo)
        estiloCAPAPKS = os.path.join(os.path.dirname(__file__), current_configuration.otros["carpeta_estilos"] + fichEstiloPKS)
        
        fileTipe = self.cbxTipoExport.currentText()

        valcbxProvincia = self.cbxProvincia.currentText()
        valcbxTitularidad = self.cbxTitularidad.currentText()
        valcbxFuncionalidad = self.cbxFuncionalidad.currentText()
        
        if valcbxTitularidad == "Todo":
            valcbxTitularidad = '%'
        if valcbxFuncionalidad == "Todo":
            valcbxFuncionalidad = '%'
        if valcbxProvincia == "Todo":
            valcbxProvincia = '%'
            
        '''
        ###  LECTURA DE DATOS DE EJES ###
        '''
        whereTXT = '('  
        whereTXT+= ' Titularidad LIKE '+"'"+valcbxTitularidad+"'"
        whereTXT+= ' AND Funcionalidad LIKE '+"'"+valcbxFuncionalidad+"'"
        whereTXT+= ' AND Provincia LIKE '+"'"+valcbxProvincia+"')"

        whereTXT+= ' AND Matricula LIKE '+"'"+self.cbxMatricula.currentText()+"'"
        if self.chbMATR9000.isChecked():
            whereTXT+= ' AND Matricula <>'+ "'9000'"
            
        print (whereTXT)
        resultEJES = self.GetJSON(whereTXT)
        self.progressBar.setValue(40)
        self.lblINFO.setText('INFO: Leido fichero de EJES')
        nomLayer = self.lneNOMcapa.text()
        nomFich = self.lneFICHsalida.text()
        nomFichCorr = nomFich
        
        #  Caso de fichero .json EJES
        if self.cbxTipoExport.currentText() == 'json':
            try:
                to_unicode = unicode
            except NameError:
                to_unicode = str
            with io.open(nomFich, 'w', encoding='utf8') as f:
                strJson = json.dumps(resultEJES,
                                  indent=2, 
                                  sort_keys=True,
                                  separators=(',', ': '), 
                                  ensure_ascii=False)
                f.write(to_unicode(strJson))

            # ARREGLAR LOS M = null -  Se eliminan todos los M=null sustituyéndolos por 0
            self.fun.replace(nomFich, '              null', '              0')
            # self.fun.replace(nomFich, '              null', '              500.000000000000')
            self.progressBar.setValue(45)
            self.lblINFO.setText('INFO: Escrito fichero de EJES')

        else:
            #  Caso de fichero .gpkg
            dest_name = self.lneFICHsalida.text()
            dest_layer = self.createVectorLayer("linestringM?crs=epsg:"+str(srcVal), dest_name)

            pass
        
        '''
        ###  LECTURA DE DATOS DE PKS ###
        '''
        if self.chbDESC_PKS.isChecked():

            whereTXTPKS = 'Provincia LIKE '+"'"+valcbxProvincia+"'"
            whereTXTPKS += ' AND idctramo LIKE '+"'"+self.cbxMatricula.currentText()+"'"

            resultPKS = self.GetJSONPKS(whereTXTPKS)
            self.progressBar.setValue(85)
            self.lblINFO.setText('INFO: Leido fichero de PKS')

            nomLayerPKS = self.lneNOMcapa_PKS.text()
            nomFichPKS = self.lneFICHsalida_PKS.text()
            nomFichCorrPKS = nomFichPKS
            
            #  Caso de fichero .json PKs
            if self.cbxTipoExport.currentText() == 'json':
                with io.open(nomFichPKS, 'w', encoding='utf8') as f:
                    strJson = json.dumps(resultPKS,
                                      indent=2, 
                                      sort_keys=True,
                                      separators=(',', ': '), 
                                      ensure_ascii=False)
                    f.write(to_unicode(strJson))
        self.progressBar.setValue(90)
        self.lblINFO.setText('INFO: Escrito fichero de PKS')

       
        layer = QgsVectorLayer(json.dumps(resultEJES), nomLayer, "ogr")
        layer.loadNamedStyle(estiloCAPA)
        QgsProject.instance().addMapLayer(layer, False)

        # Colocamos la capa arriba del todo
        root = QgsProject.instance().layerTreeRoot()
        root.insertLayer(0, layer)
        
        if self.chbDESC_PKS.isChecked():
            layerPKS = QgsVectorLayer(json.dumps(resultPKS), nomLayerPKS, "ogr")
            layerPKS.loadNamedStyle(estiloCAPAPKS)
            QgsProject.instance().addMapLayer(layerPKS, False)
            # Colocamos la capa arriba del todo
            root = QgsProject.instance().layerTreeRoot()
            root.insertLayer(0, layerPKS)

        self.progressBar.setValue(95)
        self.lblINFO.setText('INFO: Cargadas CAPAS')

        # Zoom a la capa
        extent = layer.extent()
        iface.mapCanvas().setExtent(extent)
        
        stop = timeit.default_timer()
        QApplication.restoreOverrideCursor()
        
        self.progressBar.setValue(100)
        self.lblINFO.setText('INFO: TERMINADA LA CARGA')

        text = 'Guardado fichero de EJES \n'+nomFich+'\n'
        if self.chbDESC_PKS.isChecked():
            text += 'Guardado fichero de PKS \n'+nomFichPKS+'\n'
        text += 'Tiempo: '+"%0.2f"%(stop - start)+' seg.'
        self.fun.showJCCMessage('DESCARGA DE FICHEROS DE CARRETERAS',text)
        progress = 'Terminada la Descarga - Tiempo: ' +str(stop - start)+' seg.'
        self.iface.mainWindow().statusBar().showMessage(progress) 
      
        
    def GetJSON(self, whereTXT):
        # print whereTXT
        # url = u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?'
        url = current_configuration.environment["rest_carreteras"]
        values = {
                  'where' : whereTXT,
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': False,
                  'outFields': '*',
                  'geometryPrecision': 3,
                  'returnGeometry' : 'true',
                  'returnM': 'true' ,
                  'f': 'json'}
                  
        if self.chbSOLO2D.isChecked():
            values.update({'returnM': 'false'})
        # else:
            # result = 'La descarga con PK (valor M) puede eliminar elementos sin M'
            # self.fun.showJCCMessage(result,text2="",tittle="JCCM - Descarga CTRAS",)    
        
        str_values = {}
        # for k, v in values.iteritems():
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
            # print (k,v)
        # data = urllib.urlencode(str_values)
        data = urllib.parse.urlencode(str_values)
        print (url+data)
    
        try:
            # response = json.load(urllib2.urlopen(req))
            response = json.load(urllib.request.urlopen(url + data))
            # print (response)
            return response
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.fun.showJCCMessageERR(result,text2="",tittle="JCCM - Error de código",)
            return 'error'
            
        return response


    def GetJSONPKS(self, whereTXTPKS):
        url = u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_PKS_WFS/MapServer/0/query?'
        # url = current_configuration.environment["rest_carreteras"]
        values = {
                  'where' : whereTXTPKS,
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': False,
                  'outFields': '*',
                  'geometryPrecision': 3,
                  'returnGeometry' : 'true',
                  'f': 'json'}

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
            # print (k,v)
        data = urllib.parse.urlencode(str_values)
        print (url+data)
    
        try:
            response = json.load(urllib.request.urlopen(url + data))
            # print (response)
            return response
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.fun.showJCCMessageERR(result,text2="",tittle="JCCM - Error de código",)
            return 'error'
            
        return response


    def salida_file_click(self):
        dirFile = self.lneFICHsalida.text()
        fileTipe = self.cbxTipoExport.currentText()
        ext = "*.json"
        if fileTipe == 'json':
            filename, tipofile = QFileDialog.getSaveFileName(self, "Fichero JSON de salida", dirFile, ext)
            print (filename, tipofile)
            if filename != None and filename != "":
                self.lneFICHsalida.setText(filename)
            else:
                filename = dirFile
            # Comprobamos que existe el directorio y si no se crea
            if not os.path.exists(os.path.dirname(filename)):
                os.makedirs(os.path.dirname(filename))   
        else:
            text = 'NO ES POSIBLE GUARDAR FICHEROS DE TIPO '+fileTipe+' \n'
            self.fun.showJCCMessage('',text)            

            
    def salida_filePKS_click(self):
        dirFile = self.lneFICHsalida_PKS.text()
        fileTipe = self.cbxTipoExport.currentText()
        ext = "*.json"
        if fileTipe == 'json':
            filename, tipofile = QFileDialog.getSaveFileName(self, "Fichero JSON de salida", dirFile, ext)
            print (filename, tipofile)
            if filename != None and filename != "":
                self.lneFICHsalida_PKS.setText(filename)
            else:
                filename = dirFile
            # Comprobamos que existe el directorio y si no se crea
            if not os.path.exists(os.path.dirname(filename)):
                os.makedirs(os.path.dirname(filename))   
        else:
            text = 'NO ES POSIBLE GUARDAR FICHEROS DE TIPO '+fileTipe+' \n'
            self.fun.showJCCMessage('',text)            
            
            
            
'''
        # Funcion de Query a GEOBTA
        # --- EJEMPLO ---
        # http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?
        # --- VALORES ---
        # where=Matricula_Plan+LIKE+%27%25%27&
        # text=&
        # objectIds=&
        # time=&
        # geometry=&
        # geometryType=esriGeometryEnvelope&
        # inSR=&
        # spatialRel=esriSpatialRelIntersects&
        # relationParam=&
        # outFields=*&
        # returnGeometry=true&
        # returnTrueCurves=false&
        # maxAllowableOffset=&
        # geometryPrecision=&
        # outSR=&
        # returnIdsOnly=false&
        # returnCountOnly=true&
        # orderByFields=&
        # groupByFieldsForStatistics=&
        # outStatistics=&
        # returnZ=false&
        # returnM=true&
        # gdbVersion=&
        # returnDistinctValues=false&
        # resultOffset=&
        # resultRecordCount=&
        # queryByDistance=&
        # returnExtentsOnly=false&
        # datumTransformation=&
        # parameterValues=&
        # rangeValues=&
        # f=pjson
'''