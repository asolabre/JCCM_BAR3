# -*- coding: utf-8 -*-
"""
/***************************************************************************
 jcml_barDialog
                                 A QGIS plugin
 jcml_bar
                             -------------------
        begin                : 2016-06-06
        git sha              : $Format:%H$
        copyright            : (C) 2020 by Agustín Solabre Suárez/DIRECCIÓN GENERAL DE CARRETERAS
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import QSettings, Qt, QFileInfo
from PyQt5.QtWidgets import QDialog, QDialogButtonBox, QApplication, QListWidgetItem
from PyQt5 import uic

from qgis.core import QgsProject, QgsLayerDefinition, QgsRectangle, QgsMessageLog, QgsCoordinateReferenceSystem,QgsApplication

import os
from osgeo import ogr, osr
import urllib
import json
import ast 

from time import sleep

from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES
from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/gestorCapas_base.ui'))


class gestorCapas(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(gestorCapas, self).__init__(parent)
        self.setupUi(self)
        
        self.iface = iface;
        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.logo.setPixmap(QPixmap(":/plugins/jccm_bar3/iconos/jccm.jpg"))

        self.fun = Functions()
        self.qs = QSettings()

        self.current_configuration = configuration()
        
        # FICHERO DE DATOS DE CAPAS
        # fich_config = u'z:/cartografia/datos_Q/QSIG/config/capasQSIG.txt'
        fich_config = self.qs.value("JCCM_carreteras/JCCM_fich_config")
        
        # Buscamos el fich_config en unidadpropia, Z: U:
        if not os.path.exists(fich_config) or fich_config == os.path.join(os.path.dirname(__file__), './capasQSIG.txt'):
            uniProj = QgsProject.instance().fileName()[:2]
            listUnd = [uniProj, 'z:', 'u:']
            fich_config = u'z:/cartografia/datos_Q/QSIG/config/capasQSIG.txt'
            if self.fun.buscaFichUnd(listUnd, fich_config) is not None:
                fich_config = self.fun.buscaFichUnd(listUnd, fich_config)[0]
                self.qs.setValue('JCCM_carreteras/JCCM_fich_config', fich_config)
        
        # Buscamos el fich_config en la instalación del plugin
        if not os.path.exists(fich_config): 
            fich_config = os.path.join(os.path.dirname(__file__), './capasQSIG.txt')

        print ('fich_config: ', fich_config)
        
        linesFich = []
        with open(fich_config) as file:
            for line in file: 
                line = line.strip()
                try:
                    res = ast.literal_eval(line)  # Metodo convert a dict ast
                    # if 'nombre' in res:
                    listKeys =  ['type','source','nombre','estilo','grupo','agrupado']
                    flag = 1
                    for key in listKeys:
                        if key not in res:
                            flag = 0
                    if flag == 1: linesFich.append(res)
                    else: print ('LINEA NULA: '+line)
                except:
                    print ('LINEA NULA: '+line)

        if len(linesFich) == 0:
            text = 'No hay capas correctas en el fichero de configuración\n\n'
            text += fich_config
            self.fun.showJCCMessageERR(text,'',"Error de fichero de CONFIGURACIÓN DE CAPAS")
            ##########################################################################
            ###
            ###   REVISAR ESTO PUES NO FUNCIONA
            self.cancel()
            ##########################################################################

        capas_internas = self.getNombresPosiblesGrupo("Internas", linesFich)
            
        capas_externas = self.getNombresPosiblesGrupo("Externas", linesFich)
            
        self.createListCheckbox(capas_internas, self.lwiCheckBoxesINT)
        self.createListCheckbox(capas_externas, self.lwiCheckBoxesEXT)

        self.cargarSelectedButton.clicked.connect(lambda: self.cargarSelected(linesFich))

        self.buttonBox.button(QDialogButtonBox.Cancel).clicked.connect(self.cancel)


    def createListCheckbox(self, capas_inicio, listChk):
        for nombreCapa in capas_inicio:

            item = QListWidgetItem(nombreCapa)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            listChk.addItem(item)

    def getNombresPosiblesGrupo(self, grupo, linesFich):
        capas = []
        for capa in linesFich:
            if capa["grupo"] == grupo:
                capas.append(capa["nombre"])
        return capas


    def getCapaByNombre(self, nombre, linesFich):
        for capa in linesFich:
            if capa["nombre"] == nombre:
                return capa
        return None


    def cargarSelected(self, linesFich):
        self.close()

        for index in range(0,self.lwiCheckBoxesINT.count()):
            item = self.lwiCheckBoxesINT.item(index)
            if item.checkState() == Qt.Checked:
                nomCAPA = item
            else:
                continue
            nomCAPA =self.getCapaByNombre(item.text(), linesFich)

            if (nomCAPA["type"] != "Grupo"):
                layerEXIST = QgsProject.instance().mapLayersByName(item.text())
                if not layerEXIST:
                    capa = self.getCapaByNombre(item.text(), linesFich)
                    self.cargarCapa(capa)
                    
            if (nomCAPA["type"] == "Grupo"):
                root = QgsProject.instance().layerTreeRoot()            
                grupoEXIST = root.findGroup(item.text())
                # print ('GRUPO - ',nomCAPA["nombre"],nomCAPA)
                if grupoEXIST is None:
                    self.cargarCapa(nomCAPA)
        
        for index in range(0,self.lwiCheckBoxesEXT.count()):
            item = self.lwiCheckBoxesEXT.item(index)
            if item.checkState() == Qt.Checked:
                nomCAPA = item
            else:
                continue
            nomCAPA =self.getCapaByNombre(item.text(), linesFich)      
        
            if (nomCAPA["type"] != "Grupo"):
                layerEXIST = QgsProject.instance().mapLayersByName(item.text())
                if not layerEXIST:
                    capa = self.getCapaByNombre(item.text(), linesFich)
                    self.cargarCapa(capa)
                    
            if (nomCAPA["type"] == "Grupo"):
                root = QgsProject.instance().layerTreeRoot()            
                grupoEXIST = root.findGroup(item.text())
                # print ('GRUPO - ',nomCAPA["nombre"],nomCAPA)
                if grupoEXIST is None:
                    self.cargarCapa(nomCAPA)
        '''
        # Deselecciona todos los items
        for i in range(self.list_internas.count()):
            item = self.list_internas.item(i)
            # self.list_internas.setItemSelected(item, False)
            item.setSelected(False)
        for i in range(self.list_externas.count()):
            item = self.list_externas.item(i)
            # self.list_externas.setItemSelected(item, False)
            item.setSelected(False)
        pass
        '''
    
    def cargarCapa(self,data):
        if(data["type"] == "WFS"):
            layer = self.iface.addVectorLayer(data["source"], data["nombre"], data["type"])
            if layer == None:
                QgsMessageLog.logMessage( "Capa no encontrada: " + data["nombre"],"jccm_bar")
                return
            elif not layer.isValid():
                QgsMessageLog.logMessage( "Fallo al cargar la capa: " + data["nombre"],"jccm_bar")
                return
            else:
                if data["estilo"] != "Default":
                    QgsMessageLog.logMessage( "Cargando capa con estilo no default","jccm_bar")
                    QgsMessageLog.logMessage( os.path.join(os.path.dirname(__file__), self.current_configuration.otros["carpeta_estilos"] + u'/' +  data["estilo"]),"jccm_bar")
                    layer.loadNamedStyle(os.path.join(os.path.dirname(__file__), self.current_configuration.otros["carpeta_estilos"] + u'/' +  data["estilo"]))
            # Ponemos la capa arriba
            root = QgsProject.instance().layerTreeRoot()   
            myvl = root.findLayer(layer.id())
            myvlclone = myvl.clone()
            parent = myvl.parent()
            root.insertChildNode(0, myvlclone)
            parent.removeChildNode(myvl)

        elif (data["type"] == "WMS"):
            layer = self.iface.addRasterLayer(data["source"], data["nombre"], 'wms')
            if layer == None:
                QgsMessageLog.logMessage( "Capa no encontrada: " + data["nombre"],"jccm_bar")
                return
            elif not layer.isValid():
                QgsMessageLog.logMessage( "Fallo al cargar la capa: " + data["nombre"],"jccm_bar")
                return
            else:
                if data["estilo"] != "Default":
                    layer.loadNamedStyle(os.path.join(os.path.dirname(__file__), self.current_configuration.otros["carpeta_estilos"] + u'/' +  data["estilo"]))
            # Ponemos la capa arriba
            root = QgsProject.instance().layerTreeRoot()   
            myvl = root.findLayer(layer.id())
            myvlclone = myvl.clone()
            parent = myvl.parent()
            root.insertChildNode(0, myvlclone)
            parent.removeChildNode(myvl)
        
        elif (data["type"] == "SHP"):
            listUnd = ['v:', 'u:', 'z:','w:']
            fichResul = self.fun.buscaFichUnd(listUnd, data["source"])
            # layer = self.iface.addVectorLayer(data["source"], data["nombre"], "ogr")
            if fichResul is not None:
                layer = self.iface.addVectorLayer(fichResul[0], data["nombre"], "ogr")
            else:
                layer == None
            if layer == None:
                QgsMessageLog.logMessage( "Capa no encontrada: " + data["nombre"],"jccm_bar")
                return
            elif not layer.isValid():
                QgsMessageLog.logMessage( "Fallo al cargar la capa: " + data["nombre"],"jccm_bar")
                return
            else:
                if data["estilo"] != "Default":
                    layer.loadNamedStyle(os.path.join(os.path.dirname(__file__), self.current_configuration.otros["carpeta_estilos"] + u'/' +  data["estilo"]))
            # Ponemos la capa arriba
            root = QgsProject.instance().layerTreeRoot()   
            myvl = root.findLayer(layer.id())
            myvlclone = myvl.clone()
            parent = myvl.parent()
            root.insertChildNode(0, myvlclone)
            parent.removeChildNode(myvl)

        elif (data["type"] == "Raster"):
            listUnd = ['v:', 'u:', 'z:']
            fichResul = self.fun.buscaFichUnd(listUnd, data["source"])
            #layer = self.iface.addRasterLayer(data["source"], data["nombre"])
            layer = self.iface.addRasterLayer(fichResul[0], data["nombre"])
            if layer == None:
                QgsMessageLog.logMessage( "Capa no encontrada: " + data["nombre"],"jccm_bar")
                return
            elif not layer.isValid():
                QgsMessageLog.logMessage( "Fallo al cargar la capa: " + data["nombre"],"jccm_bar")
                return
            else:
                if data["estilo"] != "Default":
                    layer.loadNamedStyle(os.path.join(os.path.dirname(__file__), self.current_configuration.otros["carpeta_estilos"] + u'/' +  data["estilo"]))
            # Ponemos la capa arriba
            root = QgsProject.instance().layerTreeRoot()   
            myvl = root.findLayer(layer.id())
            myvlclone = myvl.clone()
            parent = myvl.parent()
            root.insertChildNode(0, myvlclone)
            parent.removeChildNode(myvl)
        
        elif (data["type"] == "Grupo"):
            listUnd = ['v:', 'u:', 'z:']
            fichResul = self.fun.buscaFichUnd(listUnd, data["source"])

            #if os.path.isfile(data["source"]):
            if os.path.isfile(fichResul[0]) and fichResul is not None:
                nomGRUPO = data["nombre"].replace(u' -Grupo-', '')
                root = QgsProject.instance().layerTreeRoot()
                #result=QgsLayerDefinition().loadLayerDefinition(data["source"], QgsProject.instance(), root)
                result=QgsLayerDefinition().loadLayerDefinition(fichResul[0], QgsProject.instance(), root)
                # result=QgsLayerDefinition().loadLayerDefinition(data["source"], root)
                if result[0]=='False':
                    QgsMessageLog.logMessage( "Fallo al cargar la capa: " + data["nombre"],"jccm_bar")
                    return
                
                # Se recoloca el grupo al principio de todo
                grupoANADIDO = root.findGroup(nomGRUPO)
                if grupoANADIDO is not None:
                    grupoCLONADO = grupoANADIDO.clone()
                    root.insertChildNode(0, grupoCLONADO)
                    root.removeChildNode(grupoANADIDO)

            else:
                text = "Fichero de GRUPO no encontrado: " + u'\n' + data["nombre"]
                self.fun.showJCCMessageERR(text,'',"Error de fichero de GRUPO")
                
    
    def cancel(self):
        self.reject()