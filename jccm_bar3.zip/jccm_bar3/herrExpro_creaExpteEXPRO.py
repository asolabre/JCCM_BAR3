# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           herrExpro_creaExpteEXPRO.py
Purpose: Creación de expediente de expropiaciones completo

        --------------------------------------------------------------------
        begin                : 2020-12-27
        git sha              : $Format:%H$
        copyright            : (C) 2020 by JCCM. Dirección General de Carreteras
        Codigo               : A. Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License",         or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt5.QtWidgets import QDialog, QFileDialog, QListWidgetItem
from PyQt5.QtGui import QIcon, QStandardItemModel, QStandardItem
from PyQt5.QtCore import QSettings, Qt, QVariant
from PyQt5 import uic
from qgis.core import Qgis, QgsProcessingFeatureSourceDefinition, QgsVectorLayer, QgsField, QgsProject, \
                    QgsFeature, QgsLayerTreeLayer, QgsMapLayer, QgsWkbTypes, QgsFeatureRequest, QgsExpression, QgsGeometry
from qgis import processing

from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QApplication

import sys
import os

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES
current_configuration = configuration()

# from .drawtools import DrawPolygon

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_expteExpro.ui'))

# VARIABLES
srcVal = current_configuration.environment["EPSG"]

# CLASES PROGRAMADAS
class herrExpro_creaExpteEXPRO(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
        """Constructor."""
        super(herrExpro_creaExpteEXPRO, self).__init__(parent)

        self.setupUi(self)

        self.iface = iface;
        self.fun = Functions()
        self.setVar = QSettings()

        # self.iface.messageBar().pushMessage(u'Crear Expediente de Expropiaciones', u'Crear Expediente de Expropiaciones', level=Qgis.Info)

        lista_CAPAS = self.getCAPAS()
        self.cbxCapaentrada.clear()
        self.cbxCapaentrada.addItems(lista_CAPAS)
        lastCapaentradaExpro = self.setVar.value("JCCM_carreteras/last/lastCapaentradaExpro")
        if lastCapaentradaExpro in lista_CAPAS:
            self.cbxCapaentrada.setCurrentIndex(lista_CAPAS.index(lastCapaentradaExpro))

        lista_CAPAS = self.getCAPAStermcat()
        if len(lista_CAPAS) == 0:
            text = u'NO EXISTE CAPA CON DEFINICIONES DE LOS PERÍMETROS DE TT.MM. CATASTRALES'
            self.fun.showJCCMessageERR(text,text2="",tittle="JCCM",)
            self.close()
            return
        capaTMcatastro = 'CAT_Municipios_CLM'
        self.cbxCapaTMC.clear()
        self.cbxCapaTMC.addItems(lista_CAPAS)
        if capaTMcatastro in lista_CAPAS:
            self.cbxCapaTMC.setCurrentIndex(lista_CAPAS.index(capaTMcatastro))

        self.setWindowIcon(QIcon(':/plugins/jccm_bar3/iconos/jccm.jpg'))
        self.btnGENERA.clicked.connect(self.generaExpteEXPRO)
        self.btnCANCELA.clicked.connect(self.cancela)
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        # self.btnSeleccionfich.clicked.connect(self.gml_salida_file_click)
        self.lblINFO.show() == True


    def getCAPAS(self):
        capas = []
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayer.VectorLayer:
                if layer.wkbType() == QgsWkbTypes.Polygon:
                    feat=layer.featureCount()
                    featsel=layer.selectedFeatureCount()
                    capas.append(layer.name())
                if layer.wkbType() == QgsWkbTypes.MultiPolygon:
                    feat=layer.featureCount()
                    featsel=layer.selectedFeatureCount()
                    capas.append(layer.name())
        return capas


    def getCAPAStermcat(self):
        capas = []
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayer.VectorLayer:
                if layer.wkbType() == QgsWkbTypes.Polygon:
                    # feat=layer.featureCount()
                    # featsel=layer.selectedFeatureCount()
                    if layer.fields().indexFromName('DELEGACIO') != -1 and layer.fields().indexFromName('MUNICIPIO') != -1:
                        print (u'AÑADIMOS CAPA -  ', layer.name())
                        capas.append(layer.name())
                if layer.wkbType() == QgsWkbTypes.MultiPolygon:
                    # feat=layer.featureCount()
                    # featsel=layer.selectedFeatureCount()
                    if layer.fields().indexFromName('DELEGACIO') != -1 and layer.fields().indexFromName('MUNICIPIO') != -1:
                        print (u'AÑADIMOS CAPA -  ', layer.name())
                        capas.append(layer.name())
        return capas


    def cancela(self):
        self.close()
        pass


    def generaExpteEXPRO(self):
        QApplication.setOverrideCursor(Qt.WaitCursor)

        # VARIABLES
        self.setVar.setValue("JCCM_carreteras/last/lastCapaentradaExpro", self.cbxCapaentrada.currentText())

        srs =  self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        # capaExpro = 'EXPRO_NERPIO'
        # capaTMcatastro = self.cbxCapaTMC.currentText()
        capaExpro = self.cbxCapaentrada.currentText()

        layerResultFile =u'C:/temp/GEOPKG_DEFAULT.gpkg'
        layerResultTable=u'EXPRO_RESULT'
        layerResultName =u'EXPRO_RESULT'
        layerResult = '%s|layername=%s'%(layerResultFile,layerResultTable)
        estiloCAPA = u'u:\cartografia\datos_Q\QSIG\ESTILOS CAPAS\PARC_EXPROPIADAS.qml'

        # Controlamos si las capas existen
        layerEXIST = QgsProject.instance().mapLayersByName(capaExpro)
        if not layerEXIST:
            message = u"PARECE QUE NO EXISTE LA CAPA\n"+capaExpro
            self.fun.showJCCMessage( message,'','Error de capa' )
            QApplication.restoreOverrideCursor()
            return

        # Se genera el fichero de destino de los datos.
        destLYR = self.creaFichRESUL("Polygon?crs=epsg:"+str(srcVal), layerResultName)
        QgsProject.instance().addMapLayer(destLYR)
        
        # Establecemos el estilo de la capa
        # estiloCAPA = os.path.join(os.path.dirname(__file__), self.current_configuration.catastro_tool["dir_estilos_catastro"] + u'/PARCELAS_SELECCION.qml')
        destLYR.loadNamedStyle(estiloCAPA)


        # Detectar TM de la capaExpro
        text1 = u'PASO 1. DETECTANDO TTMM'
        paso = 1
        self.iface.mainWindow().statusBar().showMessage(text1)
        self.lblINFO.setText(text1)
        self.progressBar.setValue(5)
        self.fun.wait(0.5)
        # print ( text1)

        '''
        layerEXIST = QgsProject.instance().mapLayersByName(capaTMcatastro)
        if not layerEXIST:
            message = u"PARECE QUE NO EXISTE LA CAPA\n"+capaTMcatastro
            self.fun.showJCCMessage( message,'','Error de capa' )
            QApplication.restoreOverrideCursor()
            return
        '''    
        
        listPolig = []
        layersExpro = QgsProject.instance().mapLayersByName(capaExpro)
        sf = layersExpro[0].selectedFeatures() #returns QgsFeature object
        if len(sf) == 0:
            sf = layersExpro[0].getFeatures() #returns QgsFeature object
        
        for feat in sf:
            listPolig.append(feat.geometry())
        listaProv, listaMuni = self.fun.buscaTTMMpoligono(listPolig)
        
        # print ('listaProv - ', listaProv)
        # print ('listaMuni - ', listaMuni)
        root = QgsProject.instance().layerTreeRoot()
        listcapaCatastro=[]
        listaTM = []
        numpasos = 2+len(listaMuni)*9
        numTermMuni = 0
        for Muni in listaMuni:
            numTermMuni += 1
            paso = 1+numTermMuni
            text1 = u'PASO %s. OBTENIENDO DATOS DE TTMM'&(paso)
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(100 * paso/numpasos)
            self.fun.wait(0.5)

            codigo_provincia = Muni[2][0:2]
            nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
            codineMuni = Muni[2]
            nombre_muni = Muni[1].upper()
            nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
            nombre_muni1, cmc = self.fun.consultaCatastroCodMunitoMunicipio(nombre_prov, codineMuni[2:5])
            codigo_muni_final = self.fun.completarCeros(cmc,3)
        
            codigo = self.fun.completarCeros(codigo_provincia,2) + codigo_muni_final
            nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (WEB)"
            listaTM.append(u'%s %s %s'%(codigo_provincia,codigo_muni_final, nombre_muni))

        '''
        ############################################################
        ############################################################
        ########## CONSULTA DE MUNICIPIOS DESDE CAPA
        ############################################################
        ############################################################
            
        processing.run("native:selectbylocation", {
                        'INPUT' : capaTMcatastro,
                        'INTERSECT' : capaExpro,
                        'METHOD' : 0,
                        'PREDICATE' : [0]
                        })
        layer=layerEXIST[0]
        feats = layer.selectedFeatures()
        numfeats = layer.selectedFeatureCount()
        if numfeats == 0:
            feats = layer.getFeatures()
            numfeats = layer.featureCount()

        muniAfec = []
        root = QgsProject.instance().layerTreeRoot()
        listcapaCatastro=[]


        listaTM = []
        for feature in feats:
            paso = 2
            text1 = u'PASO 2. OBTENIENDO DATOS DE TTMM'
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(100 * paso/numpasos)
            self.fun.wait(0.5)
            # print ( text1)

            #attrs = feature.attributes()
            valCampoProv = feature['DELEGACIO']
            valCampoMuni = feature['MUNICIPIO']
            muniAfec.append([valCampoProv,valCampoMuni])
            codigo_provincia = self.fun.completarCeros(str(valCampoProv),2)
            codigo_muni_ine = self.fun.completarCeros(str(valCampoMuni),3)

            # CONSULTA DE NOMBRE PROVINCIA DESDE COD_PROV - Se mete en functions.py
            try:
                nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
            except:
                QApplication.restoreOverrideCursor()
                resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(herrExpro_creaExpteEXPRO.py-133- self.fun.consultaCatastroCodProvtoProvincia)','','Capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                QApplication.restoreOverrideCursor()
                return

            # CONSULTA DE LOS MUNICIPIOS DE LA PROVINCIA
            try:
                result = self.fun.consultaCatastroCodMunitoMunicipio(nombre_prov, codigo_muni_ine)
            except:
                QApplication.restoreOverrideCursor()
                resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(herrExpro_creaExpteEXPRO.py-158 except1- self.fun.consultaCatastroCodMunitoMunicipio lin:159)','','Capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                QApplication.restoreOverrideCursor()
                return
            if result[0] == "ERROR":
                QApplication.restoreOverrideCursor()
                resp = self.fun.showJCCMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(herrExpro_creaExpteEXPRO.py-164 except2- self.fun.consultaCatastroCodMunitoMunicipio)','','Capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                QApplication.restoreOverrideCursor()
                return
            nombre_muni = result[0]
            codigo_muni_final = self.fun.completarCeros(result[1],3)
            nombre_muni = str(nombre_muni)
            codigo = self.fun.completarCeros(codigo_provincia,2) + codigo_muni_final
            nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (WEB)"
            listaTM.append(u'%s %s %s'%(codigo_provincia,codigo_muni_final, nombre_muni))
        '''


        model = QStandardItemModel()
        self.lvwLISTA_TM.setModel(model)
        for termmuni in listaTM:
            item = QStandardItem(termmuni)
            model.appendRow(item)

        numTermMuni = 0
        totalTermMuni = len(listaTM)
        for termmuni in listaTM:
            numTermMuni += 1
            codigo_provincia = termmuni[:2]
            codigo_muni_final= termmuni[3:6]
            nombre_muni= termmuni[7:]
            QApplication.restoreOverrideCursor()
            # print ('codigo_provincia - ', codigo_provincia, 'codigo_muni_final - ',codigo_muni_final, 'nombre_muni - ', nombre_muni)

            paso = 1+len(listaMuni)+numTermMuni
            text1 = u'PASO %s.%s CARGANDO %s %s'%(str(paso), str(numTermMuni),codigo, nombre_muni)
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(100 * (paso/numpasos))
            self.fun.wait(0.5)
            # print (text1)

            nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (WEB)"
            capaCatPol, capaCatPar = self.fun.cargaCatastroMuni(codigo_provincia, codigo_muni_final, nombre_muni, 'web', 'WEB', self.iface, mess = False)
            listcapaCatastro.append(capaCatPar)

        # # Se deseleccionan los elementos de capaTMcatastro
        # QgsProject.instance().mapLayersByName(capaTMcatastro)[0].removeSelection()

        numcapaCat = 0
        totalcapaCat = len(listcapaCatastro)
        for capaCatastro in listcapaCatastro:
            numcapaCat += 1
            codigo = capaCatastro[-5:]
            vlayerCAT = QgsProject.instance().mapLayersByName(capaCatastro)[0]
            cp = int(codigo[:2])
            cm = int(codigo[2:5])
            expr = "\"DELEGACIO\" = %d and \"MUNICIPIO\" = %d"%(cp,cm)
            selection = vlayerCAT.getFeatures(QgsFeatureRequest(QgsExpression("\"DELEGACIO\" = %d and \"MUNICIPIO\" = %d"%(cp,cm))))

            
            ############################################################
            ###   HAY QUE ESTUDIAR EL TEMA DE DESCUENTOS            ####
            ############################################################
            ############################################################
            ############################################################
            # listGeom = []
            # geomTMCAT = enumerate(selection)[0].geometry()
            # for feature in selection:
                # # listGeom.append(feature.geometry())
                
                # err = feature.geometry().validateGeometry()
                # if not err:
                    # geomTMCAT = geomTMCAT.combine(feature.geometry())
            # print (codigo, ' - Area=', geomTMCAT.area())


            # SELECCIÓN DE ELEMENTOS EN CAPACATASTRO
            # paso = 4
            paso = 1+len(listaMuni)+2*numTermMuni
            text1 = u'PASO %s.%s %s %s SELECCIONANDO ELEMENTOS'%(str(paso), str(numcapaCat), codigo, nombre_muni)
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            processing.run("native:selectbylocation", {
                            'INPUT' : capaCatastro,
                            'INTERSECT' : capaExpro,
                            'METHOD' : 0,
                            'PREDICATE' : [0]
                            })


            # Intersección de capas
            # paso = 5
            paso = 1+len(listaMuni)+3*numTermMuni
            #+ (1*numcapaCat)/(6*totalcapaCat)
            # text1 = u'PASO %s.%s %s INTERSEC. PARCELAS CATASTRALES'%(str(paso), str(numcapaCat),codigo)
            text1 = u'PASO %s.%s %s %s INTERSEC. PARCELAS CATASTRALES'%(str(paso), str(numcapaCat), codigo, nombre_muni)
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(100 * ((paso-3)*numcapaCat/totalcapaCat)/numpasos)
            self.fun.wait(0.5)
            # print ( text1)
            
            # { 
            # 'INPUT' : QgsProcessingFeatureSourceDefinition('CAT__PAR__NERPIO___02055_6b50f4cb_d206_4403_a987_39a9b088e1c5', True), 
            # 'INPUT_FIELDS' : [], 
            # 'OUTPUT' : 'TEMPORARY_OUTPUT', 
            # 'OVERLAY' : QgsProcessingFeatureSourceDefinition('CAT__PAR__NERPIO___02055_6b50f4cb_d206_4403_a987_39a9b088e1c5', True), 
            # 'OVERLAY_FIELDS' : [], 
            # 'OVERLAY_FIELDS_PREFIX' : '' 
            # }
            
            processing.run("native:intersection", {
                            'INPUT' : QgsProcessingFeatureSourceDefinition(capaCatastro, True),
                            'INPUT_FIELDS' : [],
                            'OUTPUT' : 'ogr:dbname=\'%s\' table=\"%s\" (geom) sql='%(layerResultFile,layerResultTable+'0',),
                            # 'OVERLAY' : capaExpro,
                            'OVERLAY' : QgsProcessingFeatureSourceDefinition(capaExpro, True),
                            'OVERLAY_FIELDS' : [],
                            'OVERLAY_FIELDS_PREFIX' : 'exp_'
                            })
            vlayer0 = QgsVectorLayer(layerResult+'0', layerResultName+'0', "ogr")
            if not vlayer0.isValid():
                print(u"FALLÓ LA CARGA DE LA CAPA!\n"+layerResult+'0')
            else:
                # Se añade campo TIPORES
                pr = vlayer0.dataProvider()
                vlayer0.startEditing()
                pr.addAttributes([QgsField('TIPORES',QVariant.String)])
                pr.addAttributes([QgsField('cod_term_m',QVariant.String)])
                vlayer0.commitChanges()
                # Se añade capa a la vista
                QgsProject.instance().addMapLayer(vlayer0)
                # Se modifica el valor del atributo
                vlayer0.startEditing()
                it = vlayer0.getFeatures()
                for feat in it:
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('TIPORES'), 'EXPRO')
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('cod_term_m'), codigo)
                vlayer0.commitChanges()
                alias = {'RC14':'localId','supcat':'areaValue'}

            # paso = 6
            paso = 1+len(listaMuni)+4*numTermMuni
            textPaso = u'COPIANDO PARCELAS INTERSECCIÓN A RESULT'
            self.copiaFeatToLayer(self.iface, ((paso-3)*numcapaCat/totalcapaCat), numpasos, textPaso, codigo, destLYR, vlayer0, alias)


            '''
            # Diferencia para localizar DESCUENTOS
            paso = 7
            # text1 = u'PASO %s. %s DIFER. DESC CATASTRALES'%(str(paso),codigo)
            text1 = u'PASO %s.%s %s %s DIFER. DESC CATASTRALES'%(str(paso), str(numcapaCat), codigo, nombre_muni)
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(100 * ((paso-3)*numcapaCat/totalcapaCat)/numpasos)
            self.fun.wait(0.5)
            # print ( text1)

            processing.run("native:difference", {
                            'INPUT' : capaExpro,
                            'OUTPUT' : 'ogr:dbname=\'%s\' table=\"%s\" (geom) sql='%(layerResultFile,layerResultTable+'1'),
                            'OVERLAY' : layerResultName
                            })
            vlayer0 = QgsVectorLayer(layerResult+'1', layerResultName+'1', "ogr")
            if not vlayer0.isValid():
                print(u"FALLÓ LA CARGA DE LA CAPA!\n"+layerResult+'1')
            else:
                # Se añade campo TIPORES
                pr = vlayer0.dataProvider()
                vlayer0.startEditing()
                pr.addAttributes([QgsField('TIPORES',QVariant.String)])
                pr.addAttributes([QgsField('cod_term_m',QVariant.String)])
                vlayer0.commitChanges()
                # Se añade capa a la vista
                QgsProject.instance().addMapLayer(vlayer0)
                # Se modifica el valor del atributo
                vlayer0.startEditing()
                it = vlayer0.getFeatures()
                for feat in it:
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('TIPORES'), 'DESCUENTO')
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('cod_term_m'), codigo)
                vlayer0.commitChanges()

            ############################################################
            ####   HAY QUE SABER SI EL DESCUENTO ESTÁ DENTRO DEL TM  ####
            ############################################################
            ############################################################
            ############################################################
            # mapcanvas = self.iface.mapCanvas()
            # layers = mapcanvas.layers()
            feats_A = [ feat for feat in vlayer0.getFeatures() ]    # Features de Descuentos
            # feats_B = vlayerCAT.getFeatures().next()                # Features de Terminos Municipales
            for i, feat in enumerate(feats_A):
                if geomTMCAT.contains(feat.geometry()):
                    # if listGeom.geometry().contains(feat.geometry()):
                    print ("La geometria SI está incluida en %s, "%(codigo), "feature: ", i)
                else:
                    print ("La geometria NO está incluida en %s, "%(codigo), "feature: ", i)


            paso = 8
            textPaso = u'COPIANDO PARCELAS DESCUENTOS A RESULT'
            self.copiaFeatToLayer(self.iface, ((paso-3)*numcapaCat/totalcapaCat), numpasos, textPaso, codigo, destLYR, vlayer0, alias)

            ############################################################
            ############################################################
            ############################################################
            '''


            # Cálculo restos de las parcelas seleccionadas
            # paso = 9
            paso = 1+len(listaMuni)+5*numTermMuni
            # text1 = u'PASO %s, %s CALC. RESTOS PARCELAS CATAST.'%(str(paso),codigo)
            text1 = u'PASO %s.%s %s %s CALC. RESTOS PARCELAS CATAST.'%(str(paso), str(numcapaCat), codigo, nombre_muni)
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(100 * ((paso-3)*numcapaCat/totalcapaCat)/numpasos)
            self.fun.wait(0.5)
            # print ( text1)

            processing.run("native:difference", {
                            'INPUT' : QgsProcessingFeatureSourceDefinition(capaCatastro, True),
                            'OUTPUT' : 'ogr:dbname=\'%s\' table=\"%s\" (geom) sql='%(layerResultFile,layerResultTable+'2'),
                            'OVERLAY' : capaExpro
                            })
            vlayer0 = QgsVectorLayer(layerResult+'2', layerResultName+'2', "ogr")
            if not vlayer0.isValid():
                print(u"FALLÓ LA CARGA DE LA CAPA!\n"+layerResult+'2')
            else:
                # Se añade campo TIPORES
                pr = vlayer0.dataProvider()
                vlayer0.startEditing()
                pr.addAttributes([QgsField('TIPORES',QVariant.String)])
                pr.addAttributes([QgsField('cod_term_m',QVariant.String)])
                vlayer0.commitChanges()
                # Se añade capa a la vista
                QgsProject.instance().addMapLayer(vlayer0)
                # Se modifica el valor del atributo
                vlayer0.startEditing()
                it = vlayer0.getFeatures()
                for feat in it:
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('TIPORES'), 'RESTO')
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('cod_term_m'), codigo)
                vlayer0.commitChanges()

            # paso = 10
            paso = 1+len(listaMuni)+6*numTermMuni
            textPaso = u'COPIANDO RESTOS PARCELAS A RESULT'
            self.copiaFeatToLayer(self.iface, ((paso-3)*numcapaCat/totalcapaCat), numpasos, textPaso, codigo, destLYR, vlayer0, alias)

            # Se deseleccionan los elementos
            QgsProject.instance().mapLayersByName( capaCatastro )[0].removeSelection()


        self.btnGENERA.setEnabled(False)

        text1 = u'--- FINALIZADO POR EL MOMENTO ---'
        self.iface.mainWindow().statusBar().showMessage(text1)
        self.lblINFO.setText(text1)
        # print ( text1)
        self.progressBar.setValue(100)
        QApplication.restoreOverrideCursor()


    def creaFichRESUL(self,uri,name,dest='memory'):
        # createVectorLayer(self,uri,name,dest='memory')
        #   Crea una capa vectorial memoria añadiendoles campos
        #           LISTA CAMPOS
        #   Devuelve la capa vectorial
        #   return vl

        vl = QgsVectorLayer(uri, name, dest)
        pr = vl.dataProvider()

        # Enter editing mode
        vl.startEditing()

        # add fields
        pr.addAttributes([
            # DATOS PARCELA CATASTRAL
            QgsField('no_orden'     ,QVariant.Int,   '',  0,0,u"Nº Orden.- Número de orden de la finca relativo al proyecto; único para cada finca dentro del expediente. Numérico: 1, 2,3…"),
            QgsField('cod_term_m'   ,QVariant.String,'',  5,0,u"Cod. Term. Municipal.- Código del término municipal donde radica la finca (ver tabla adjunta),"),
            QgsField('pedanía'      ,QVariant.String,'',150,0,u"Pedanía.- En caso de que el término municipal esté dividido en pedanías, nombre de la pedanía donde se ubica la finca."),
            QgsField('pol'          ,QVariant.String,'',  2,0,u"Poligono.- Polígono catastral donde se ubica la finca."),
            QgsField('par'          ,QVariant.String,'',  3,0,u"Parcela.- Parcela catastral donde se ubica la finca."),
            QgsField('subpar'       ,QVariant.String,'',  2,0,u"SubParcela.- Subparcela catastral donde ubica la finca (en caso de existir)."),
            QgsField('RC14'         ,QVariant.String,'', 20,0,u"Ref. Catrastal.- Referencia catastral."),
            QgsField('dirfinca'     ,QVariant.String,'',255,0,u"Dirección.- Para aquellas fincas de las que se disponga de este dato."),
            QgsField('paraje'       ,QVariant.String,'',255,0,u"Paraje.- Donde se encuentra la finca."),
            QgsField('uso'          ,QVariant.String,'',150,0,u"Uso.- Uso del terreno de la finca."),
            QgsField('concepto'     ,QVariant.String,'', 50,0,u"Concepto.- Dentro del proyecto a realizar, uso que se le dará al terreno; usado sobre todo por IACLM; ejemplo EDAR, línea eléctrica, tubería…"),
            QgsField('tipopropi'    ,QVariant.String,'',  1,0,u"Propiedad Pública.- 0 en caso de propiedad privada, 1 en caso de propiedad a nombre de la JCCM y 2 en caso de propiedad pública no JCCM."),
            QgsField('supcat'       ,QVariant.Double,'', 10,2,u"Superf. Catastral Comp.- Superficie completa de la finca según el catastro en metros cuadrados."),
            QgsField('calificacion' ,QVariant.String,'',  5,0,u"Calificación.- Urbana (U), o Rústica (R). Toda la columna de contener o R o U. Si es Domini Público poner R."),
            # DATOS SUPERFICIES EXPROPIACIÓN
            QgsField('superfpd'     ,QVariant.Double,'', 10,2,u"Superf. P.D.- Superficie en metros cuadrados a ser expropiada en pleno dominio."),
            QgsField('valorunitpd'  ,QVariant.Double,'', 10,2,u"Valor Unit. P.D.- Valor unitario por metro cuadrado que supone la expropiación en pleno dominio de esta finca."),
            QgsField('importepd'    ,QVariant.Double,'', 10,2,u"Importe P.D.- Importe total a abonar por la parte expropiada en pleno dominio."),
            QgsField('superfot'     ,QVariant.Double,'', 10,2,u"Superf. O.T.- Superficie en metros cuadrados a ser expropiada en ocupación temporal."),
            QgsField('valorunitot'  ,QVariant.Double,'', 10,2,u"Valor Unit. O.T.- Valor unitario por metro cuadrado que supone la expropiación en ocupación temporal de esta finca."),
            QgsField('importeot'    ,QVariant.Double,'', 10,2,u"Importe O.T.- Importe total a abonar por la parte expropiada en ocupación temporal."),
            QgsField('superfsp'     ,QVariant.Double,'', 10,2,u"Superf. S.P.- Superficie en metros cuadrados a ser expropiada en servidumbre de paso."),
            QgsField('valorunitsp'  ,QVariant.Double,'', 10,2,u"Valor Unit. S.P.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de paso de esta finca."),
            QgsField('importesp'    ,QVariant.Double,'', 10,2,u"Importe S.P.- Importe total a abonar por la parte expropiada en servidumbre de paso."),
            QgsField('superfsv'     ,QVariant.Double,'', 10,2,u"Superf. S.V.- Superficie en metros cuadrados a ser expropiada en servidumbre de vuelo."),
            QgsField('valorunitsv'  ,QVariant.Double,'', 10,2,u"Valor Unit. S.V.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de vuelo de esta finca."),
            QgsField('importesv'    ,QVariant.Double,'', 10,2,u"Importe S.V.- Importe total a abonar por la parte expropiada en servidumbre de vuelo."),
            # DATOS CAPA
            QgsField('TIPORES'      ,QVariant.String,'', 25,0,u"TIPO PARCELA.- 'EXPRO', 'RESTO', 'DESCUENTO'")

            ] )
        # Commit changes
        vl.commitChanges()
        return vl

    def copiaFeatToLayer(self, iface, paso, numpasos, textPaso, codigo, destLYR, vlayer, alias):
        # Se copian los elementos de layerResultName0 a layerResultName
        # text1 = u'PASO 8. %s COPIANDO DESCUENTOS A RESULT.'%(codigo)
        # destLYR = destLYR
        pr = destLYR.dataProvider()
        destfield_names = [field.name() for field in destLYR.fields()]
        srcfield_names = [field.name() for field in vlayer.fields()]

        text1 = u'PASO %s. %s %s'%(str(paso), codigo, textPaso)
        iface.mainWindow().statusBar().showMessage(text1)
        self.lblINFO.setText(text1)
        self.progressBar.setValue(100 * paso/numpasos)
        self.fun.wait(0.5)
        # print (text1)

        destLYR.startEditing()
        sourceLYR = vlayer

        values = [1]
        newIndex = 1
        for feat in destLYR.getFeatures():
            attrs = feat.attributes()
            if isinstance(attrs[0], int) == True:
                values.append(attrs[0])

        if len(values) != 0:
            newIndex = max(values) + 1
        else:
            newIndex = 1

        for feature in sourceLYR.getFeatures():
            fet = QgsFeature(destLYR.fields())
            fet.setGeometry(feature.geometry())
            concepto = 'DP CARRETERA'
            pol = 's/d'
            par = 's/d'
            calificacion = 's/d'
            tipopropi = '0'
            for field in destLYR.fields():
                if field.name() == 'fid':
                    fet.setAttribute('fid', newIndex)
                    newIndex += 1
                    continue
                if sourceLYR.fields().indexFromName(field.name()) != -1:
                    fet.setAttribute(field.name(), feature[field.name()])

                # Cálculo de campos
                concepto = 'DP CARRETERA'
                pol = 's/d'
                par = 's/d'
                calificacion = 's/d'
                tipopropi = '0'
                for aliascampo in alias:
                    if aliascampo in destfield_names and alias[aliascampo] in srcfield_names:
                        fet.setAttribute(aliascampo, feature[alias[aliascampo]])

                    if aliascampo == 'RC14' and feature['TIPORES'] != 'DESCUENTO':
                        RC14 = feature[alias['RC14']]
                        if RC14[5].isalpha():
                            pol = RC14[6:9]
                            par = RC14[9:14]
                            calificacion = 'R'
                            if RC14[10] == '9':
                                tipopropi = '2'
                            else:
                                tipopropi = '0'
                        else:
                            pol = RC14[:5]
                            par = RC14[5:7]
                            calificacion = 'U'
                            tipopropi = '0'

            fet.setAttribute('no_orden',    0)           #"Nº Orden.- Número de orden de la finca relativo al proyecto; único para cada finca dentro del expediente. Numérico: 1, 2,3…"
            # fet.setAttribute('cod_term_m',  codigo)      #"Cod. Term. Municipal.- Código del término municipal donde radica la finca (ver tabla adjunta)"
            fet.setAttribute('pedanía',     's/d')       #"Pedanía.- En caso de que el término municipal esté dividido en pedanías, nombre de la pedanía donde se ubica la finca."
            fet.setAttribute('pol',         pol)         #"Poligono.- Polígono catastral donde se ubica la finca."
            fet.setAttribute('par',         par)         #"Parcela.- Parcela catastral donde se ubica la finca."
            fet.setAttribute('subpar',      's/d')       #"SubParcela.- Subparcela catastral donde ubica la finca (en caso de existir)."
            # fet.setAttribute('RC14',        0)           #"Ref. Catrastal.- Referencia catastral."
            fet.setAttribute('dirfinca',    's/d')       #"Dirección.- Para aquellas fincas de las que se disponga de este dato."
            fet.setAttribute('paraje',      's/d')       #"Paraje.- Donde se encuentra la finca."
            fet.setAttribute('uso',         's/d')       #"Uso.- Uso del terreno de la finca."
            fet.setAttribute('concepto',    concepto)    #"Concepto.- Dentro del proyecto a realizar, uso que se le dará al terreno; usado sobre todo por IACLM; ejemplo EDAR, línea eléctrica, tubería…"
            fet.setAttribute('tipopropi',   tipopropi)   #"Propiedad Pública.- 0 en caso de propiedad privada, 1 en caso de propiedad a nombre de la JCCM y 2 en caso de propiedad pública no JCCM."
            # fet.setAttribute('supcat',      0)           #"Superf. Catastral Comp.- Superficie completa de la finca según el catastro en metros cuadrados."
            fet.setAttribute('calificacion',calificacion)#"Calificación.- Urbana (U) o Rústica (R). Toda la columna de contener o R o U. Si es Domini Público poner R."
            fet.setAttribute('superfpd',    feature.geometry().area())

            pr.addFeatures( [ fet ] )

        destLYR.updateExtents()
        destLYR.commitChanges()

        QgsProject.instance().removeMapLayer(vlayer)





'''
# RELACIÓN DE DATOS DEL PARCELARIO DICTADO POR LOS SSJJ DE LA CONSEJERÍA
# ----------------------------------------------------------------------
# Datos pensados para una hoja excel
# DATOS PARCELA CATASTRAL
# CAMPO         ,ALIAS                      ,DESCRIPCIÓN
'no_orden',     u"Nº Orden",                u"Nº Orden.- Número de orden de la finca relativo al proyecto; único para cada finca dentro del expediente. Numérico: 1, 2,3…"
'cod_term_m',   u"Cod. Term. Municipal",    u"Cod. Term. Municipal.- Código del término municipal donde radica la finca (ver tabla adjunta)"
'pedanía',      u"Pedanía",                 u"Pedanía.- En caso de que el término municipal esté dividido en pedanías, nombre de la pedanía donde se ubica la finca."
'pol',          u"Polígono",                u"Poligono.- Polígono catastral donde se ubica la finca."
'par',          u"Parcela",                 u"Parcela.- Parcela catastral donde se ubica la finca."
'subpar',       u"SubParcela",              u"SubParcela.- Subparcela catastral donde ubica la finca (en caso de existir)."
'RC14',         u"Ref. Catastral",          u"Ref. Catrastal.- Referencia catastral."
'dirfinca',     u"Dirección Finca",         u"Dirección.- Para aquellas fincas de las que se disponga de este dato."
'paraje',       u"Paraje",                  u"Paraje.- Donde se encuentra la finca."
'uso',          u"Uso",                     u"Uso.- Uso del terreno de la finca."
'concepto'      u"Concepto",                u"Concepto.- Dentro del proyecto a realizar, uso que se le dará al terreno; usado sobre todo por IACLM; ejemplo EDAR, línea eléctrica, tubería…"
'tipopropi'     u"P. Pública",              u"Propiedad Pública.- 0 en caso de propiedad privada, 1 en caso de propiedad a nombre de la JCCM y 2 en caso de propiedad pública no JCCM."
'supcat'        u"Superf. Catastral Comp.", u"Superf. Catastral Comp.- Superficie completa de la finca según el catastro en metros cuadrados."
'calificacion'  u"Calificación",            u"Calificación.- Urbana (U) o Rústica (R). Toda la columna de contener o R o U. Si es Domini Público poner R."
# DATOS LEVANTAMIENTO DE ACTAS
'registro',     u"Registro",                u"Registro.- Datos registrales que se rellenarán en caso de ser conocidos."
'tomo',         u"Tomo",                    u"Tomo, Datos registrales que se rellenarán en caso de ser conocidos."
'libro',        u"Libro",                   u"Libro, Datos registrales que se rellenarán en caso de ser conocidos."
'folio',        u"Folio",                   u"Folio, Datos registrales que se rellenarán en caso de ser conocidos."
'finca',        u"Finca",                   u"Finca, Datos registrales que se rellenarán en caso de ser conocidos."
'inscripcion',  u"Inscripción",             u"Inscripción, Datos registrales que se rellenarán en caso de ser conocidos. "
'suoregcomp',   u"Superf. Reg. Comp.",      u"Superficie Registral Completa.- Datos registrales que se rellenarán en caso de ser conocidos."
# DATOS SUPERFICIES EXPROPIACIÓN
'superfpd',     u"Superf. P.D.",            u"Superf. P.D.- Superficie en metros cuadrados a ser expropiada en pleno dominio."
'valorunitpd',  u"Valor Unit. P.D.",        u"Valor Unit. P.D.- Valor unitario por metro cuadrado que supone la expropiación en pleno dominio de esta finca."
'importepd',    u"Importe P.D.",            u"Importe P.D.- Importe total a abonar por la parte expropiada en pleno dominio."
'superfot',     u"Superf. O.T.",            u"Superf. O.T.- Superficie en metros cuadrados a ser expropiada en ocupación temporal."
'valorunitot',  u"Valor Unit. O.T.",        u"Valor Unit. O.T.- Valor unitario por metro cuadrado que supone la expropiación en ocupación temporal de esta finca."
'importeot',    u"Importe O.T.",            u"Importe O.T.- Importe total a abonar por la parte expropiada en ocupación temporal."
'superfsp',     u"Superf. S.P.",            u"Superf. S.P.- Superficie en metros cuadrados a ser expropiada en servidumbre de paso."
'valorunitsp',  u"Valor Unit. S.P.",        u"Valor Unit. S.P.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de paso de esta finca."
'importesp',    u"Importe S.P.",            u"Importe S.P.- Importe total a abonar por la parte expropiada en servidumbre de paso."
'superfsv',     u"Superf. S.V.",            u"Superf. S.V.- Superficie en metros cuadrados a ser expropiada en servidumbre de vuelo."
'valorunitsv',  u"Valor Unit. S.V.",        u"Valor Unit. S.V.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de vuelo de esta finca."
'importesv',    u"Importe S.V.",            u"Importe S.V.- Importe total a abonar por la parte expropiada en servidumbre de vuelo."
# DATOS TITULARES
'titularnombre',u"Titular Nombre",          u"Nombre del Titular.- Nombre del titular de la finca o del derecho SI ES PERSONA JURÍDICA, SOLO SE USA EL CAMPO NOMBRE."
'titularapel',  u"Titular Apellidos",       u"Apellidos del Titular.- Apellidos del titular de la finca o del derecho."
'titlardninif', u"DNI/NIF",                 u"DNI/NIF.- Dni o Nif del titular de la finca."
'titulardir',   u"Dirección Notificaciones",u"Dirección Notificaciones.- Dirección donde el titular quiere que se envíen las notificaciones."
'codpostal',    u"Cod  Postal",             u"Código Postal"
'poblacion',    u"Población",               u"Población"
'"provincia'     u"Provincia",              u"Provincia""
'porcpropiedad',u"% Propiedad",             u"% Propiedad.- Tanto por ciento de propiedad sobre la finca que tiene el titular; 100 en caso de titular único, 0 en caso de desconocimiento ,-1 en caso de arrendatario, -2 en caso de usufructuario  y -3 en caso de concesionario."
# DATOS ARRENDATARIOS
'derecho',      u"Derecho",                 u"Derecho.- Derecho por el que se indemniza al arrendatario."
'superfder',    u"Superf. D.",              u"Superf. D.- Superficie en metros cuadrados a ser expropiados que afectan al derecho correspondiente."
'valorunitder', u"Valor Unit. D.",          u"Valor Unit. D.- Valor unitario por metro cuadrado que supone la expropiación del derecho correspondiente."
'importeder',   u"Importe D.",              u"Importe D.- Importe total a abonar por la parte expropiada que afecta al derecho correspondiente."
'''

    ########################################
    ##  HERRAMIENTAS TRAIDAS DESDE QDRAW  ##
    ########################################

    # def drawPolygon(self):
        # if self.tool:
            # self.tool.reset()
        # self.tool = DrawPolygon(self.iface",       self.settings.getColor())
        ## u"# self.tool.setAction(self.actions[4])
        # self.tool.selectionDone.connect(self.draw)
        # self.tool.move.connect(self.updateSB)
        # self.iface.mapCanvas().setMapTool(self.tool)
        # self.drawShape = 'polygon'
        # self.toolname = 'drawPolygon'
        # self.resetSB()

