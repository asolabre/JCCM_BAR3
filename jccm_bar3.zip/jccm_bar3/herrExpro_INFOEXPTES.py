# -*- coding: utf-8 -*-
"""
/***************************************************************************
herrExpro_INFOEXPTES.py
                                 A QGIS plugin
                             -------------------
        begin                : 2020-03-10
        git sha              : $Format:%H$
        copyright            : (C) 2020 by Agustín Solabre Suárez/DIRECCIÓN GENERAL DE CARRETERAS
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

"""
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QSettings, QObject, Qt

from PyQt5.QtWidgets import QDialog, QDockWidget
from PyQt5 import uic

from qgis.core import QgsProject, QgsExpression, QgsFeatureRequest
from qgis.utils import iface

import sys
import os
from osgeo import ogr, osr, gdal

import urllib
import json
from time import sleep

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions3 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

from .herrExpro_REMISION import herrExpro_REMISION


# DATOS DE LA APLICACION
#------------------------
# capaEXPEXPRO = 'LIMITES DE EXPROPIACION'
capaEXPEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerLIMEXPRO")
if capaEXPEXPRO is None:
    capaEXPEXPRO=configuration().expropiacion["EXPlayerLIMEXPRO"]
camposEXPEXPRO = ['CTRA', 'EXPTE1', 'NOM_TRAMO']

dirEXPEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerLIMEXPROexptes")
if dirEXPEXPRO is None:
    dirEXPEXPRO=configuration().expropiacion["EXPlayerLIMEXPROexptes"]
campodirEXPEXPRO = 'DIR_DOC'


dw, _ = uic.loadUiType( os.path.join(os.path.dirname(__file__), './menus/herrExpro_infoexptesdock.ui') )


class herrExpro_infoexptes(QDockWidget, dw):

    def __init__(self, iface, parent=None):
        """Constructor."""
        super(herrExpro_infoexptes, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        
        self.current_configuration = configuration()
        self.fun = Functions()
        self.setVar = QSettings()
       
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self)
       
        self.listEXPEXPRO = self.rellenaCOMBOS()
        
        self.btnCANCELA.clicked.connect(self.cancela)
        self.btnEXPEXPRODOC.clicked.connect(self.irdocVERDOC)
        self.cbxEXPEXPRO.currentIndexChanged.connect(lambda: self.irdocEXPEXPRODOC())

        self.btnEXPTEANT.clicked.connect(self.irdocANT)
        self.btnEXPTESIG.clicked.connect(self.irdocSIG)
        self.btnEDITARDATOS.clicked.connect(self.EDITARDATOS)
        self.btnREMISEXPTE.clicked.connect(self.REMISEXPTE)
        self.btnZOOMALIMITES.clicked.connect(lambda: self.ZOOMALIMITES(capaEXPEXPRO, camposEXPEXPRO))

        # capaDATOS = capaEXPEXPRO
        # ordenDATO = 1
        # listaCAMPOS = camposEXPEXPRO
        # ordenCAMPO = 1
        
        self.show()


    def rellenaCOMBOS(self):
        # Rellenar combo EXPEXPRO
        self.cbxEXPEXPRO.clear()
        listEXPEXPRO = self.getDATOSLAYER(capaEXPEXPRO, camposEXPEXPRO, False)
        self.cbxEXPEXPRO.addItems(listEXPEXPRO)
        lastEXPEXPRO = self.setVar.value("JCCM_carreteras/EXPRlastEXPEXPRO")
        
        if lastEXPEXPRO in listEXPEXPRO:
            self.cbxEXPEXPRO.setCurrentIndex(listEXPEXPRO.index(lastEXPEXPRO))
        
        # Si la capa no está cargada, desactiva el botón correspondiente
        if (self.cbxEXPEXPRO.currentText()[:5] == 'FALTA'):
            # self.btnEXPEXPRO.setEnabled(False)
            self.btnEXPEXPRODOC.setEnabled(False)
        else: 
            self.irdocEXPEXPRODOC()
            # self.btnEXPEXPRO.setEnabled(True)

        return listEXPEXPRO
        
            
    def getDATOSLAYER(self,capaDATOS,listacampos,descendente):
        listaDATOS = []
        layer = self.fun.getLayerByName(capaDATOS)
        
        # Adaptamos el sistema de codificación a ISO-8859-14
        # codeSource = "ISO-8859-14"
        ####### SE DEBE ESTUDIAR LA CODIFICACION DE LA CAPA ##############
        # self.fun.getLayerByName(capaEXPEXPRO).dataProvider().setEncoding(u'UTF-8')
        ##################################################################

        if not layer:
            textoLOG = u'FALTA CAPA ' + capaDATOS

            return [u'FALTA CAPA ' + capaDATOS]
        else:
            # print u'Code System ACTUAL= ',layer.name(), layer.dataProvider().encoding()  
            # layer.setProviderEncoding(codeSource)
            layer.dataProvider().encoding()

        QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(True)
        for feat in layer.getFeatures():
            val =''
            count=0
            for campo in listacampos:  
                val1 = feat[campo]
                if not val1: 
                    val1 = '(s/d)'
                if (isinstance(val1,int) or isinstance(val1,float)):
                    val += str(val1)
                else:
                    val += val1
                count +=1
                if (count < len(listacampos)):
                    val += u' | '

            listaDATOS.append(val)
        listaDATOS = list(set(listaDATOS))
        
        # Ordenamos las listas correspondientes
        if descendente==True:
            listaDATOS.sort(reverse=True)
        else:
            listaDATOS.sort()

        if len(listaDATOS) == 0:
            return [u'FALTAN DATOS DE CAPA ' + capaDATOS]
        return listaDATOS

    '''
    def buscarEXPEXPRO(self):
        # if close is True:
            # self.close()    

        # VARIABLES
        capaDATOS = capaEXPEXPRO
        datoBUSCADO = self.cbxEXPEXPRO.currentText()
        ordenDATO = 1
        listaCAMPOS = camposEXPEXPRO
        ordenCAMPO = 1

        self.fun.zoomELEMENTO(iface, capaDATOS, datoBUSCADO, ordenDATO, listaCAMPOS, ordenCAMPO, 0 )
    '''
       
    def irdocEXPEXPRODOC(self):
        if (self.cbxEXPEXPRO.currentText()[:5] != 'FALTA'):
        
            if (self.cbxEXPEXPRO.count() >0):
                datoBUSCADO = self.cbxEXPEXPRO.currentText()
                # print ('self.listEXPEXPRO es ',listEXPEXPRO.index(datoBUSCADO))
                self.setVar.setValue("JCCM_carreteras/EXPRlastEXPEXPRO", datoBUSCADO)
                valorBUSCADO= (datoBUSCADO.split(' | '))[1]
                
                layer = self.fun.getLayerByName(capaEXPEXPRO)
                campo = camposEXPEXPRO[1]
                consulta = u'"'+campo+'" = \''+valorBUSCADO+'\''
                expr = QgsExpression( consulta )
                it = layer.getFeatures( QgsFeatureRequest( expr ) )
                ids = [j.id() for j in it]
                feats=layer.selectByIds(ids)

                feature = layer.selectedFeatures()[0]
                features = layer.selectedFeatures()
                # Se debe hacer que los valores 's/d' no aparezcan
                # Se debe hacer que aparezcan todos los TM

                valEXPEXPRODOC = feature[campodirEXPEXPRO]
                if not valEXPEXPRODOC:
                    valEXPEXPRODOC =''
                    self.btnEXPEXPRODOC.setEnabled(False)
                else:
                    fichero = valEXPEXPRODOC+u'/'
                    listUnd = ['v:', 'u:', 'z:']
                    self.fun.buscaFichUnd(listUnd, fichero)
                    if self.fun.buscaFichUnd(listUnd, fichero) is None:
                        self.btnEXPEXPRODOC.setEnabled(False)
                    else:
                        self.btnEXPEXPRODOC.setEnabled(True)


                # RELLENAMOS DATOS DEL CUADRO
                #------------------------------
                layer = self.fun.getLayerByName(capaEXPEXPRO)
                
                # index = self.listEXPEXPRO.index(datoBUSCADO)
                # self.lblINDEX.setText('{}/{}'.format(index,len(self.listEXPEXPRO)))

                idx = layer.fields().indexOf('TITULARIDA')
                listTITU = list(layer.uniqueValues(idx))
                self.TITULARIDA.clear()
                self.TITULARIDA.addItems(listTITU)
                if feature['TITULARIDA'] in listTITU:
                    self.TITULARIDA.setCurrentIndex(listTITU.index(feature['TITULARIDA']))
                
                idx = layer.fields().indexOf('FUNCIONALI')
                listFUNC = list(layer.uniqueValues(idx))
                self.FUNCIONALI.clear()
                self.FUNCIONALI.addItems(listFUNC)
                if feature['FUNCIONALI'] in listFUNC:
                    self.FUNCIONALI.setCurrentIndex(listFUNC.index(feature['FUNCIONALI']))                    

                '''
                self.EXPTE1.setText(feature['EXPTE1'])
                self.lblEXPRO.setText('EXPTE. EXPRO: (%s/%s)'%(self.cbxEXPEXPRO.findText(datoBUSCADO),self.cbxEXPEXPRO.count()))
                self.CTRA.setText(feature['CTRA'])
                self.PKINI.setText(str(feature['PKINI']))
                self.PKFIN.setText(str(feature['PKFIN']))
                self.CTRA_ANT.setText(feature['CTRA_ANT'])
                self.PKINI_ANT.setText(str(feature['PKINI_ANT']))
                self.PKFIN_ANT.setText(str(feature['PKFIN_ANT']))
                self.EXPTE2.setText(feature['EXPTE2'])
                self.EXPTE3.setText(feature['EXPTE3'])
                self.NOM_TRAMO.setText(feature['NOM_TRAMO'])
                self.NOM_PROYEC.setPlainText('PROYECTO: '+feature['NOM_PROYEC'])
                self.DIR_DOC.setPlainText(feature['DIR_DOC'])
                self.SUPERFICIE.setText(str(feature['SUPERFICIE'])+' m2')
                self.PROVINCIA.setText(feature['PROVINCIA'])
                self.TERM_MUNIC.setText(feature['TERM_MUNIC'])
                self.TERM_MUCOD.setText(str(feature['TERM_MUCOD']))
                self.ACAD_REV.setText(feature['ACAD_REV'])
                self.ID_REG.setText(str(feature['ID_REG']))
                self.REV_EXPTE.setText(feature['REV_EXPTE'])
                self.CAT_REMISI.setText(feature['CAT-REMISI'])
                self.CAT_ESTADO.setText(feature['CAT_ESTADO'])
                self.CAT_OBSERV.setPlainText('OBS.CAT.: '+feature['CAT_OBSERV'])
                '''
                
                self.EXPTE1.setText(feature['EXPTE1'])
                self.lblEXPRO.setText('EXPTE. EXPRO: (%s/%s)'%(self.cbxEXPEXPRO.findText(datoBUSCADO),self.cbxEXPEXPRO.count()))
                
                self.CTRA.setText(str(feature['CTRA']))
                self.PKINI.setText(str(feature['PKINI']))
                self.PKFIN.setText(str(feature['PKFIN']))
                self.CTRA_ANT.setText(str(feature['CTRA_ANT']))
                self.PKINI_ANT.setText(str(feature['PKINI_ANT']))
                self.PKFIN_ANT.setText(str(feature['PKFIN_ANT']))
                self.EXPTE2.setText(str(self.atribDATOcompleto(features, 'EXPTE2')))
                self.EXPTE3.setText(str(self.atribDATOcompleto(features, 'EXPTE3')))
                self.NOM_TRAMO.setText(str(self.atribDATOcompleto(features, 'NOM_TRAMO')))
                if self.atribDATOcompleto(features, 'NOM_PROYEC'): 
                    self.NOM_PROYEC.setPlainText('PROYECTO: '+self.atribDATOcompleto(features, 'NOM_PROYEC'))
                if self.atribDATOcompleto(features, 'DIR_DOC'):
                    self.DIR_DOC.setPlainText(str(self.atribDATOcompleto(features, 'DIR_DOC')))
                self.SUPERFICIE.setText(str(feature['SUPERFICIE'])+' m2')                                   # AQUÍ HABRÁ QUE SUMAR
                self.PROVINCIA.setText(str(feature['PROVINCIA']))
                self.TERM_MUNIC.setText(self.atribACUMULA(features, 'TERM_MUNIC'))      
                self.TERM_MUCOD.setText(str(self.atribACUMULA(features, 'TERM_MUCOD')))                     # AQUÍ HABRÁ QUE SUMAR
                self.ACAD_REV.setText(str(self.atribDATOcompleto(features,'ACAD_REV')))
                self.ID_REG.setText(str(feature['ID_REG']))
                self.REV_EXPTE.setText(str(self.atribDATOcompleto(features,'REV_EXPTE')))
                self.CAT_REMISI.setText(str(self.atribDATOcompleto(features,'CAT-REMISI')))
                self.CAT_ESTADO.setText(str(self.atribDATOcompleto(features,'CAT_ESTADO')))
                if self.atribDATOcompleto(features,'CAT_OBSERV'):
                    self.CAT_OBSERV.setPlainText('OBS.CAT.: '+str(self.atribDATOcompleto(features,'CAT_OBSERV')))
                
                '''
                # Hacer zoom a expte
                capaDATOS = capaEXPEXPRO
                ordenDATO = 1
                listaCAMPOS = camposEXPEXPRO
                ordenCAMPO = 1

                self.fun.zoomELEMENTO(iface, capaDATOS, datoBUSCADO, ordenDATO, listaCAMPOS, ordenCAMPO, 0 )
                '''
                
    def atribACUMULA(self, features, campo):
        valorFinal = ''
        for feature in features:
            valor = str(feature[campo])
            if valorFinal.find(valor) == -1:
                valorFinal += valor +', '
        valorFinal = valorFinal[:-2]
        return valorFinal
                
                
    def atribDATOcompleto(self, features, campo):
        result = features[0][campo]
        for feature in features:
            if feature[campo] != 's/d' and feature[campo] != '':
                result = feature[campo]
        return result 
        pass
                

    def irdocVERDOC(self):
        listUnd = ['v:', 'u:', 'z:']
        path = self.DIR_DOC.toPlainText()
        print (path)
        

        if self.fun.buscaFichUnd(listUnd, path) is None:
            print( "NO SE ENCUENTRA EL DIRECTORIO: ", path)
            # iface.messageBar().clearWidgets()
            # return
        else:
            pathDIREXP = self.fun.buscaFichUnd(listUnd, path)[0]
            
        os.startfile(pathDIREXP)

        
    def irdocANT(self):
        if (self.cbxEXPEXPRO.currentText()[:5] != 'FALTA'):
            datoBUSCADO = self.cbxEXPEXPRO.currentText()
            # print ('self.listEXPEXPRO es ',self.listEXPEXPRO.index(datoBUSCADO))
            self.setVar.setValue("JCCM_carreteras/EXPRlastEXPEXPRO", datoBUSCADO)
            
            if datoBUSCADO in self.listEXPEXPRO and self.listEXPEXPRO.index(datoBUSCADO)>0:
                self.cbxEXPEXPRO.setCurrentIndex(self.listEXPEXPRO.index(datoBUSCADO)-1)
                self.irdocEXPEXPRODOC()

        
    def irdocSIG(self):
        if (self.cbxEXPEXPRO.currentText()[:5] != 'FALTA'):
            datoBUSCADO = self.cbxEXPEXPRO.currentText()
            # print ('self.listEXPEXPRO es ',self.listEXPEXPRO.index(datoBUSCADO))
            self.setVar.setValue("JCCM_carreteras/EXPRlastEXPEXPRO", datoBUSCADO)
            
            if datoBUSCADO in self.listEXPEXPRO and self.listEXPEXPRO.index(datoBUSCADO) < len(self.listEXPEXPRO)-1:
                self.cbxEXPEXPRO.setCurrentIndex(self.listEXPEXPRO.index(datoBUSCADO)+1)
                self.irdocEXPEXPRODOC()


    def EDITARDATOS(self):
        self.fun.showJCCMessage("Herramienta en desarrollo")
        pass
        
        
    def ZOOMALIMITES(self, capaDATOS, listaCAMPOS):
        # Hacer zoom a expte
        # capaDATOS = capaEXPEXPRO
        # ordenDATO = 1
        # listaCAMPOS = camposEXPEXPRO
        # ordenCAMPO = 1

        datoBUSCADO = self.cbxEXPEXPRO.currentText()
        self.fun.zoomELEMENTO(iface, capaDATOS, datoBUSCADO, 1, listaCAMPOS, 1, 0 )
        pass


    def REMISEXPTE(self):
        listaVAL = []
        
        ## IDENTIFICAMOS EL´SIGUIENTE EXPEDIENTE A CREAREXPTE
        dirINFEXPRO = QSettings().value("JCCM_carreteras/JCCM_EXPRO/EXPlayerINFOEXPROexptes")
        if dirINFEXPRO is None:
            dirINFEXPRO=configuration().expropiacion["EXPlayerINFOEXPROexptes"]
        
        # Búsqueda de directorio nuevo de expte
        ExpteNUM = self.busquedaDirNuevoEXPTE(dirINFEXPRO)
        
        # Trasladamos loa valores al panel de REMISIÓN DE EXPEDIENTES
        listaVAL.append(ExpteNUM)                   # 00 NUMEXPRO;          Número de expediente;       2020033 
        listaVAL.append(u'')                        # 01 REGISTRO;          Número de Registro;         79945
        listaVAL.append(u'')                        # 02 FECHA;             Fecha de registro de entada;01/01/2020
        listaVAL.append(u'Actuacíón de oficio')     # 03 SOLICITANTE;       Solicitante del informe;    FRANCISCO MANGANESO HELIO
        listaVAL.append(u'Gerencia Provincial de Catastro') # 04 INTERESADO;        Destinatario final informe; Secretaría Provincial. EXPROPIACIONES
        listaVAL.append('')                         # 05 DNI;123456789
        listaVAL.append('')                         # 06 NOMBRE;            Titular de la parcela;      ANTONIO LOPEZ PEREZ
        listaVAL.append('')                         # 07 DOMICILIO;         Domicilio Comnicación;      C/ ELEMENTOS, 27
        listaVAL.append('')                         # 08 CODIGOPOST;        Cod.Postal Comnicación;     02630
        listaVAL.append('')                         # 09 TLFNO;             Teléfono Comunicación;      987654321
        listaVAL.append('')                         # 10 POBLACION;         Población Comunicación;     BONETE
        listaVAL.append(self.CTRA.text())           # 11 CARRETERA;         CARRETERA;                  CM3209
        listaVAL.append(self.PKINI.text())          # 12 KILOMETRO;         PK inicio tramo;            0
        listaVAL.append(self.PKFIN.text())          # 13 KILOMET2;          PK final tramo;             16124
        listaVAL.append('AMBAS')                    # 14 MARGEN;            IZQDA
        listaVAL.append('')                         #-- 15 OBSERVAPK;                                     ESTE ES UN FICHERO DE PRUEBA
        listaVAL.append(u'Remisión de expediente de expropiaciones a catastro')  # 16 TIPO;              Solicitud 
        listaVAL.append('')                         #-- 17 ARCHIVO;                                       PENDIENTE
        listaVAL.append('')                         # 18 IG;                Siglas Ingeniero            ASS
        listaVAL.append('')                         # 19 INGENIERO;         Ingeniero que firma;        MANOLO CALVO PELUDO
        listaVAL.append('')                         # 20 ADMIN;             Administrativo;             PALOMA JIMENEZ DIAZ
        listaVAL.append('FALSO')                    # 21 ESTAARCHIVADO;     Archivado;                  VERDADERO/FALSO
        listaVAL.append('')                         # 22 FECHAARCHIVO;      FECHAARCHIVO;               02/01/2020
        listaVAL.append(self.EXPTE1.text())         # 23 EXPTE_EXPROPIACION;Exediente remitido;         CN-AB-96/115
        listaVAL.append(self.EXPTE2.text()+' - '+self.EXPTE3.text()) # 24 EXPTES_RELACIONADOS;CN-AB-96/115-M
        listaVAL.append(self.NOM_TRAMO.text())      # 25 NOMBRE_TRAMO;      Nombre del tramo;           EjeManchuela_Villamalea_A31 (Tramo 2)
        listaVAL.append(u's/d')                     # 26 DECR_ACUERDO_RESOLUCION; Fecha decreto Expte;  30-OCTUBRE-06
        listaVAL.append(u's/d')                     # 27 ACTAS_PREVIAS;     Fechas de levantamiento de actas previas;   jun-07
        listaVAL.append(u's/d')                     # 20 REMISION_CATASTRAL;Fecha de remisión catastral;25/03/2019
        listaVAL.append('-')                        # 29 NUMORDEN;73-131
        listaVAL.append('-')                        # 30 POLIGONO;4-3
        listaVAL.append('-')                        # 31 PARCELAS;583-376
        listaVAL.append(self.TERM_MUNIC .text())    # 32 TM;                Términos Municipales comprendidos;  BONETE
        listaVAL.append('REMIS.CATASTRAL')          # 33 TIPO_EXPEDIENTE;   Tipo de expediente en el archivo de carreteras; NO INVASION
        listaVAL.append('02/01/2020')               # 34 FECHAINFORME;02/01/2020
        listaVAL.append(self.NOM_PROYEC.toPlainText()) # 35 TITULO_EXPROPIACION;                           ACONDICIONAMIENTO CTRA B-11 (CM-3209), P.K. 0 AL 16,124. MONTEALEGRE-BONETE-ESTACION DE BONETE
        listaVAL.append('')                         # 36 EXPTE_OBRA_RELACIONADO;CN-AB-95-115
        listaVAL.append('-')                        # 37 REF_CATASTRAL;400016BWJ9140S
        listaVAL.append('')                         # 38 FECHA_ULTIMO_TRAMITE;04/09/2018
        listaVAL.append('Remitido a Secc Expropiaciones') # 39 TRAMITE_EXPROPIACION;ARCHIVADO        
        listaVAL.append('juridicos.albacete@jccm.es')  # 40 CORREOELEC;juridicos.albacete@jccm.es
        
        self.remisExpteDialog = herrExpro_REMISION(self, listaVAL)
        result = self.remisExpteDialog.exec_()

        pass
        
    def busquedaDirNuevoEXPTE(self, dirINFEXPRO):
        # Búsqueda de directorio nuevo de expte
        anoLast = 2000
        expteLast = 0
        for subdir1 in self.listdirs(dirINFEXPRO):
            if subdir1[:3] == u'Año' and subdir1[-4:].isnumeric():
                if int(subdir1[-4:]) > anoLast:
                    anoLast = int(subdir1[-4:])
        dirExpteAno = dirINFEXPRO + u'Año_' + str(anoLast)
        for subdir2 in self.listdirs(dirExpteAno):
            if subdir2[:3] == u'EX-' and subdir2[-3:].isnumeric():
                if int(subdir2[-3:]) > expteLast:
                    expteLast = int(subdir2[-3:])
        ExpteNUM = str(anoLast) + self.fun.completarCeros(str(expteLast+1),3)
        return ExpteNUM

        
    def listdirs(self, path):
        if os.path.exists(path):
            return [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
        else:
            return ('NO EXISTE DIRECTORIO')

        
    def cancela(self):
        self.close()
        pass
        
