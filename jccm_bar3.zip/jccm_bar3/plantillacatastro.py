#!/usr/bin/env python
# -*- coding: utf-8 -*-

SRC_DICT = ['25828', '25829', '25830', '25831']

PLANTILLA_1 = """<?xml version="1.0" encoding="utf-8"?>
<!--Fichero GMl de parcelas catastrales para entregar a la D.G. del Catastro. Elaborada en QGIS, Aplicación JCCM_Carreteras v1.48-->
<gml:FeatureCollection xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:cp="urn:x-inspire:specification:gmlas:CadastralParcels:3.0" xmlns:base="urn:x-inspire:specification:gmlas:BaseTypes:3.2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="urn:x-inspire:specification:gmlas:CadastralParcels:3.0 http://inspire.ec.europa.eu/schemas/cp/3.0/CadastralParcels.xsd" gml:id="ES.LOCAL.1">
"""

PLANTILLA_2 = """  <gml:featureMember>
    <cp:CadastralParcel gml:id="{nmspc}.{localid}">
      <cp:areaValue uom="m2">"""

PLANTILLA_3 = """</cp:areaValue>
      <cp:beginLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></cp:beginLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_{nmspc}.{localid}" srsName="urn:ogc:def:crs:EPSG:{src}">
"""                 
             # <gml:surfaceMember>
               # <gml:Surface gml:id="Surface_{nmspclocalid}" srsName="urn:ogc:def:crs:EPSG:{src}">
                  # <gml:patches>
                    # <gml:PolygonPatch>                      # <gml:exterior>
                        # <gml:LinearRing>
                          # <gml:posList srsDimension="2">

                          # </gml:posList>
                        # </gml:LinearRing>
                      # </gml:exterior>

                    # </gml:PolygonPatch>
                  # </gml:patches>
                # </gml:Surface>
              # </gml:surfaceMember>
PLANTILLA_4 = """        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <base:Identifier>
          <base:localId>{localidf}</base:localId>
            <base:namespace>{nmspc}</base:namespace>
          </base:Identifier>
      </cp:inspireId>
      <cp:label></cp:label>
      <cp:nationalCadastralReference>{localidf}</cp:nationalCadastralReference>
    </cp:CadastralParcel>
  </gml:featureMember>
"""
   
PLANTILLA_5 = """</gml:FeatureCollection>"""